/**
 * Socket.IO main entry — room lifecycle + game handler registration.
 *
 * Room lifecycle events (bidirectional):
 *   room:join        client → server  { roomCode }
 *   room:leave       client → server  { roomCode }
 *   room:ready       client → server  { roomCode }
 *   room:state       server → room    { room, players }
 *   room:start       server → room    { state }           (game begins)
 *   room:chat        client → server  { roomCode, message }
 *   room:message     server → room    { username, message, timestamp }
 *   room:player_left server → room    { userId, username }
 */

const db          = require('../config/db');
const roomStore   = require('./roomStore');
const { socketAuth }    = require('./socketAuth');
const { registerKattamHandlers }      = require('./handlers/kattamHandler');
const { registerParamapadamHandlers } = require('./handlers/paramapadamHandler');
const { createGameState: createKattam }      = require('../game-logic/kattam/engine');
const { createGameState: createParamapadam } = require('../game-logic/paramapadam/engine');
const logger = require('../utils/logger');

function initSocket(io) {
  // Authenticate every connection
  io.use(socketAuth);

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.user.username} (${socket.id})`);

    // Register game-specific handlers
    registerKattamHandlers(io, socket);
    registerParamapadamHandlers(io, socket);

    // ── JOIN ROOM ──────────────────────────────────────────
    socket.on('room:join', async ({ roomCode }) => {
      try {
        const { rows: [room] } = await db.query(
          "SELECT gr.*, g.slug AS game_slug FROM game_rooms gr JOIN games g ON g.id = gr.game_id WHERE gr.room_code = $1 AND gr.status IN ('waiting','active')",
          [roomCode]
        );
        if (!room) return socket.emit('room:error', { message: 'Room not found' });

        socket.join(roomCode);
        logger.info(`${socket.user.username} joined room ${roomCode}`);

        const { rows: players } = await db.query(
          `SELECT rp.seat_index, rp.color, rp.is_ready, u.id, u.username, u.avatar_url
           FROM room_players rp JOIN users u ON u.id = rp.user_id
           WHERE rp.room_id = $1 ORDER BY rp.seat_index`,
          [room.id]
        );

        // Send current room state to the joiner
        socket.emit('room:state', { room, players });

        // Notify others
        socket.to(roomCode).emit('room:player_joined', {
          userId:    socket.user.id,
          username:  socket.user.username,
          avatarUrl: socket.user.avatar_url,
        });

        // If room is already active, send the current game state
        const liveRoom = roomStore.get(roomCode);
        if (liveRoom) {
          socket.emit(`${liveRoom.gameSlug}:state`, { state: liveRoom.state, lastMove: null });
        }
      } catch (err) {
        logger.error('room:join error', err);
        socket.emit('room:error', { message: 'Could not join room' });
      }
    });

    // ── READY ──────────────────────────────────────────────
    socket.on('room:ready', async ({ roomCode }) => {
      try {
        await db.query(
          `UPDATE room_players rp
           SET is_ready = true
           FROM game_rooms gr
           WHERE rp.room_id = gr.id AND gr.room_code = $1 AND rp.user_id = $2`,
          [roomCode, socket.user.id]
        );

        const { rows: [room] } = await db.query(
          "SELECT * FROM game_rooms WHERE room_code = $1",
          [roomCode]
        );
        const { rows: players } = await db.query(
          `SELECT rp.*, u.username FROM room_players rp JOIN users u ON u.id = rp.user_id
           WHERE rp.room_id = $1`,
          [room.id]
        );

        io.to(roomCode).emit('room:state', { room, players });

        // All players ready → start the game
        const allReady = players.length >= room.max_players &&
                         players.every(p => p.is_ready);

        if (allReady) {
          await startGame(io, roomCode, room, players);
        }
      } catch (err) {
        logger.error('room:ready error', err);
      }
    });

    // ── CHAT ──────────────────────────────────────────────
    socket.on('room:chat', ({ roomCode, message }) => {
      if (!message || message.trim().length > 300) return;
      io.to(roomCode).emit('room:message', {
        userId:    socket.user.id,
        username:  socket.user.username,
        message:   message.trim(),
        timestamp: new Date().toISOString(),
      });
    });

    // ── LEAVE / DISCONNECT ─────────────────────────────────
    socket.on('room:leave', ({ roomCode }) => handleLeave(io, socket, roomCode));
    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.user.username}`);
      // Note: in a production system track which rooms this socket was in
      // and broadcast leave events accordingly.
    });
  });
}

// ─── Start Game ─────────────────────────────────────────────
async function startGame(io, roomCode, room, players) {
  const playerIds = players
    .sort((a, b) => a.seat_index - b.seat_index)
    .map(p => p.user_id);

  const { rows: [game] } = await db.query('SELECT slug FROM games WHERE id = $1', [room.game_id]);
  const gameSlug = game.slug;

  // Build initial game state from the right engine
  let initialState;
  if (gameSlug === 'kattam-vilayattu') {
    initialState = createKattam(room.game_level || 2, playerIds);
  } else {
    initialState = createParamapadam(playerIds);
  }

  // Create session in DB
  const { rows: [session] } = await db.query(
    `INSERT INTO game_sessions (room_id, game_id) VALUES ($1, $2) RETURNING id`,
    [room.id, room.game_id]
  );

  // Update room status
  await db.query(
    "UPDATE game_rooms SET status = 'active', started_at = NOW() WHERE room_code = $1",
    [roomCode]
  );

  // Store in memory
  roomStore.set(roomCode, {
    gameSlug,
    sessionId: session.id,
    state:     initialState,
    startedAt: Date.now(),
    timerRef:  null,
  });

  logger.info(`Game started in room ${roomCode}: ${gameSlug}`);
  io.to(roomCode).emit('room:start', { gameSlug, state: initialState, players });
}

// ─── Handle Leave ────────────────────────────────────────────
async function handleLeave(io, socket, roomCode) {
  socket.leave(roomCode);
  io.to(roomCode).emit('room:player_left', {
    userId:   socket.user.id,
    username: socket.user.username,
  });

  // If game is active when player leaves, abandon it
  const liveRoom = roomStore.get(roomCode);
  if (liveRoom) {
    await db.query(
      "UPDATE game_rooms SET status = 'abandoned', finished_at = NOW() WHERE room_code = $1",
      [roomCode]
    );
    io.to(roomCode).emit('room:abandoned', {
      message: `${socket.user.username} left the game. Room abandoned.`,
    });
    roomStore.delete(roomCode);
  }
}

module.exports = { initSocket };

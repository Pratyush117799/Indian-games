// ═══════════════════════════════════════════════════
//  EFFECTS · Visual / audio effects layer
//  Capture animation, Grace flash, Fact card, Win bloom
// ═══════════════════════════════════════════════════

import { COLORS, NAMES, FACTS, GRACE_DEVA } from './config.js';
import { se, HOME } from './geometry.js';

let _factIndex = 0;
let _factTimer = null;

// ── Grace throw flash (Devanagari numeral) ─────────
export function graceFlash(val) {
  const el = document.getElementById('grace-flash');
  if (!el) return;
  el.textContent = GRACE_DEVA[val] || '';
  el.style.display = 'block';
  el.classList.remove('anim-grace-flash');
  // Force reflow then re-add class
  void el.offsetWidth;
  el.classList.add('anim-grace-flash');
  setTimeout(() => {
    el.style.display = 'none';
    el.classList.remove('anim-grace-flash');
  }, 950);
}

// ── Historical fact card slide-up ──────────────────
export function showFact() {
  clearTimeout(_factTimer);
  const card = document.getElementById('fact-card');
  if (!card) return;
  document.getElementById('fact-text').textContent = FACTS[_factIndex++ % FACTS.length];
  card.classList.remove('hidden', 'hiding');
  _factTimer = setTimeout(() => hideFact(), 5500);
}
function hideFact() {
  const card = document.getElementById('fact-card');
  if (!card) return;
  card.classList.add('hiding');
  setTimeout(() => card.classList.add('hidden'), 420);
}

// ── Capture effect (pawn spins + shrinks out) ──────
// Returns a Promise that resolves when animation is done.
export function captureEffect(player, pawnIdx) {
  return new Promise(resolve => {
    const el = document.getElementById(`pg-${player}-${pawnIdx}`);
    if (!el) { resolve(); return; }
    el.style.transition = 'transform 0.38s ease, opacity 0.38s ease';
    const t = el.getAttribute('transform') || '';
    el.setAttribute('transform', t + ' scale(0) rotate(360deg)');
    el.style.opacity = '0';
    setTimeout(resolve, 420);
  });
}

// ── Win bloom animation (Charkoni lotus expands) ───
export function winBloom(team) {
  const layer = document.getElementById('layer-charkoni');
  if (!layer) return;

  const cx = HOME.x, cy = HOME.y;
  // Pulse the Charkoni border gold
  const glow = se('rect', {
    x: 255, y: 255, width: 90, height: 90, rx: 3,
    fill: 'none',
    stroke: COLORS[team === 0 ? 0 : 1],
    'stroke-width': 4,
    opacity: 0.9,
  });
  layer.appendChild(glow);

  // Radiating particle rings
  const RING_COUNT = 8;
  for (let i = 0; i < RING_COUNT; i++) {
    const angle = (i / RING_COUNT) * Math.PI * 2;
    const tx    = Math.sin(angle) * 60;
    const ty    = -Math.cos(angle) * 60;
    const p = se('circle', {
      cx, cy, r: 4,
      fill: '#E8C96A',
      style: `--tx:${tx.toFixed(0)}px;--ty:${ty.toFixed(0)}px;
              animation:winParticle 0.9s ease ${(i * 60)}ms forwards`,
    });
    layer.appendChild(p);
  }

  // Fade the glow out after burst
  setTimeout(() => {
    glow.style.transition = 'opacity 0.8s ease';
    glow.style.opacity    = '0';
    setTimeout(() => glow.remove(), 900);
  }, 600);
}

// ── Show win overlay ───────────────────────────────
export function showWinOverlay(team, players) {
  const teamLabel = team === 0 ? 'A' : 'B';
  document.getElementById('wo-deva').textContent  = 'विजय!';
  document.getElementById('wo-title').textContent = `Team ${teamLabel} Wins!`;
  document.getElementById('wo-sub').textContent   =
    `${players.map(p => NAMES[p]).join(' & ')} — The Emperor is pleased.`;

  const overlay = document.getElementById('win-overlay');
  overlay.classList.remove('hidden');
  // Trigger fade-in
  requestAnimationFrame(() => {
    requestAnimationFrame(() => overlay.classList.add('visible'));
  });
}

import React, { useState, useCallback } from 'react';
import Board from '../Board/Board';
import { CowrieDice, StickDice } from '../Dice/Dice';
import PlayerPanel from '../UI/PlayerPanel';
import WinCelebration from '../UI/WinCelebration';
import MoveLog from '../UI/MoveLog';
import TournamentBracket from '../UI/TournamentBracket';
import EmojiReactionPicker, { EmojiFloat } from '../UI/EmojiReaction';
import { PLAYER_COLORS, DICE_STYLE, GAME_MODE } from '../../game/constants';

export default function GameScreen({
  gameState, onRollDice, onSelectMove, onHome,
  passPlayPrompt, animatingPawn, animPositions = {},
  muted, onToggleMute,
  showMoveLog = true,
  themeId = 'temple_stone',
  tournament, onTournamentMatchResult,
}) {
  const [selectedPawn, setSelectedPawn]     = useState(null);
  const [selectedMoves, setSelectedMoves]   = useState([]);
  const [showBracket, setShowBracket]       = useState(false);
  const [showEmoji, setShowEmoji]           = useState(false);
  const [floatingEmojis, setFloatingEmojis] = useState([]);

  const { players=[], currentPlayer=0, phase, diceResult, winner, finishOrder, mode, history=[] } = gameState || {};
  const currentColor  = PLAYER_COLORS[currentPlayer];
  const DiceComp      = gameState?.diceStyle === DICE_STYLE.STICK ? StickDice : CowrieDice;
  const isHumanTurn   = players[currentPlayer] && !players[currentPlayer]?.isAi;
  const canRoll       = phase === 'ROLL' && isHumanTurn;
  const isAiTurn      = players[currentPlayer]?.isAi;
  const isTournament  = !!tournament?.currentMatch;

  const handlePawnClick = useCallback((pawn, moves) => {
    if (phase !== 'MOVE' || !moves.length) return;
    if (moves.length === 1) { setSelectedPawn(null); setSelectedMoves([]); onSelectMove(moves[0]); return; }
    setSelectedPawn(pawn); setSelectedMoves(moves);
  }, [phase, onSelectMove]);

  const pickMove = useCallback((move) => {
    setSelectedPawn(null); setSelectedMoves([]); onSelectMove(move);
  }, [onSelectMove]);

  const addEmoji = (emoji) => {
    const id=Date.now(), x=window.innerWidth/2+(Math.random()-.5)*120, y=window.innerHeight/2+(Math.random()-.5)*80;
    setFloatingEmojis(p=>[...p,{id,emoji,x,y}]);
  };

  const handleWin = useCallback((action) => {
    if (action==='again' && isTournament && winner!==null) {
      onTournamentMatchResult?.(tournament.currentMatch.matchId, winner);
      setShowBracket(true); return;
    }
    onHome();
  }, [isTournament, tournament, winner, onTournamentMatchResult, onHome]);

  if (winner !== null) {
    return (
      <WinCelebration
        winner={winner} finishOrder={finishOrder}
        isTournamentMatch={isTournament}
        onPlayAgain={() => handleWin('again')}
        onHome={onHome}
      />
    );
  }

  return (
    <div className="game-screen" style={{ position:'relative' }}>
      {/* Pass & Play prompt */}
      {passPlayPrompt && (
        <div className="pass-overlay">
          <div className="pass-card">
            <div className="pass-dot" style={{ background: passPlayPrompt.color }} />
            <p className="pass-text">Pass to</p>
            <p className="pass-name" style={{ color: passPlayPrompt.color }}>{passPlayPrompt.playerName}</p>
            <button className="btn-primary" onClick={passPlayPrompt.onReady}>Ready ▶</button>
          </div>
        </div>
      )}

      {showBracket && tournament && (
        <TournamentBracket
          players={tournament.playerIds}
          results={[tournament.results?.sf1, tournament.results?.sf2, tournament.results?.final].filter(r=>r!=null)}
          onClose={()=>{ setShowBracket(false); onHome(); }}
        />
      )}

      {floatingEmojis.map(({id,emoji,x,y})=>(
        <EmojiFloat key={id} emoji={emoji} x={x} y={y}
          onDone={()=>setFloatingEmojis(p=>p.filter(e=>e.id!==id))}/>
      ))}

      {/* Top bar */}
      <div className="game-topbar">
        <button className="icon-btn" onClick={onHome}>⌂</button>
        <div className="turn-indicator" style={{ color: currentColor }}>
          <span className="turn-dot" style={{ background: currentColor }}/>
          <span>{players[currentPlayer]?.name}</span>
          {isAiTurn && <span className="thinking-dots">···</span>}
        </div>
        <div style={{ display:'flex', gap:4 }}>
          <button className="icon-btn" onClick={()=>setShowEmoji(v=>!v)}>😄</button>
          {mode===GAME_MODE.TOURNAMENT && <button className="icon-btn" onClick={()=>setShowBracket(true)}>🏆</button>}
          <button className="icon-btn" onClick={onToggleMute}>{muted?'🔇':'🔊'}</button>
        </div>
      </div>

      {/* Player panels — top: Yellow(2) + Green(1) */}
      <div className="panels-top">
        {players[2] && <PlayerPanel player={players[2]} isActive={currentPlayer===2} isAi={players[2].isAi}/>}
      </div>

      {/* Main: left(Blue) + board + right(Green) */}
      <div className="game-main">
        <div className="panel-side left">
          {players[3] && <PlayerPanel player={players[3]} isActive={currentPlayer===3} isAi={players[3].isAi}/>}
        </div>

        <div className="board-area" style={{ position:'relative' }}>
          <Board
            gameState={gameState} onPawnClick={handlePawnClick}
            selectedPawn={selectedPawn} animatingPawn={animatingPawn}
            animPositions={animPositions} themeId={themeId}
          />
          <EmojiReactionPicker visible={showEmoji} onPick={addEmoji} onDismiss={()=>setShowEmoji(false)}/>
        </div>

        <div className="panel-side right">
          {players[1] && <PlayerPanel player={players[1]} isActive={currentPlayer===1} isAi={players[1].isAi}/>}
        </div>
      </div>

      {/* Bottom panel — Red(0) */}
      <div className="panels-bottom">
        {players[0] && <PlayerPanel player={players[0]} isActive={currentPlayer===0} isAi={players[0].isAi}/>}
      </div>

      {/* Dice */}
      <div className="dice-area">
        <DiceComp result={diceResult} rolling={isAiTurn&&phase==='ROLL'}
          onRoll={canRoll?onRollDice:undefined} disabled={!canRoll}
          currentPlayerColor={currentColor}/>
      </div>

      {/* Doublet disambiguation */}
      {selectedMoves.length > 1 && (
        <div className="move-choices">
          {selectedMoves.map((move,i)=>(
            <button key={i} className="move-choice-btn" style={{ borderColor:currentColor }} onClick={()=>pickMove(move)}>
              {move.isHalf ? `½ split` : `Full — ${move.newPathSteps} steps`}
            </button>
          ))}
        </div>
      )}

      {showMoveLog && <MoveLog history={history}/>}

      <div className="phase-hint">
        {phase==='ROLL'&&isHumanTurn&&'🎲'}
        {phase==='MOVE'&&isHumanTurn&&'👆'}
        {isAiTurn&&<span style={{opacity:.4}}>🤖</span>}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
//  BOARD · SVG board rendering
//  Draws: arms, silk texture, grid, castles, Charkoni, labels
// ═══════════════════════════════════════════════════

import { CS } from './config.js';
import { se } from './geometry.js';
import { CASTLES } from './paths.js';

const $ = id => document.getElementById(id);

export function drawBoard() {
  _drawArms();
  _drawGrid();
  _drawCastles();
  _drawCharkoni();
  _drawLabels();
}

// ── Arms (background rectangles + silk overlay) ────
function _drawArms() {
  const layer = $('layer-bg');
  layer.innerHTML = '';

  // Outer glow frame
  layer.appendChild(se('rect', {
    x: 13, y: 13, width: 574, height: 574, rx: 3,
    fill: 'none', stroke: 'rgba(201,153,58,0.1)', 'stroke-width': 1.5,
  }));

  const arms = [
    { x: 255, y:  15, w: 90, h: 240 }, // North
    { x: 255, y: 345, w: 90, h: 240 }, // South
    { x:  15, y: 255, w: 240, h: 90 }, // West
    { x: 345, y: 255, w: 240, h: 90 }, // East
  ];
  arms.forEach(a => {
    layer.appendChild(se('rect', {
      x: a.x, y: a.y, width: a.w, height: a.h, rx: 2,
      fill: '#1C0606',
      stroke: 'rgba(201,153,58,0.2)', 'stroke-width': 0.8,
    }));
    layer.appendChild(se('rect', {
      x: a.x, y: a.y, width: a.w, height: a.h, rx: 2,
      fill: 'url(#silk)',
    }));
  });

  // Subtle player-colour tints at arm tips
  const tints = [
    { x: 255, y:  15, w: 90, h: 75,  fill: 'rgba(232,197,0,0.05)' },   // Yellow N
    { x: 255, y: 510, w: 90, h: 75,  fill: 'rgba(74,127,193,0.045)' }, // Black  S
    { x:  15, y: 255, w: 75, h: 90,  fill: 'rgba(58,139,26,0.045)' },  // Green  W
    { x: 510, y: 255, w: 75, h: 90,  fill: 'rgba(201,58,58,0.045)' },  // Red    E
  ];
  tints.forEach(t => layer.appendChild(se('rect', {
    x: t.x, y: t.y, width: t.w, height: t.h, fill: t.fill,
  })));
}

// ── Grid lines (gold thread) ───────────────────────
function _drawGrid() {
  const layer = $('layer-grid');
  layer.innerHTML = '';
  const g = { stroke: 'rgba(201,153,58,0.15)', 'stroke-width': '0.6' };

  // North arm: 7 horizontal row separators + 2 vertical col separators
  for (let r = 1; r < 8; r++)
    layer.appendChild(se('line', { x1: 255, y1: 15 + r * CS, x2: 345, y2: 15 + r * CS, ...g }));
  for (let c = 1; c < 3; c++)
    layer.appendChild(se('line', { x1: 255 + c * CS, y1: 15, x2: 255 + c * CS, y2: 255, ...g }));

  // South arm
  for (let r = 1; r < 8; r++)
    layer.appendChild(se('line', { x1: 255, y1: 345 + r * CS, x2: 345, y2: 345 + r * CS, ...g }));
  for (let c = 1; c < 3; c++)
    layer.appendChild(se('line', { x1: 255 + c * CS, y1: 345, x2: 255 + c * CS, y2: 585, ...g }));

  // West arm: 7 vertical col separators + 2 horizontal row separators
  for (let c = 1; c < 8; c++)
    layer.appendChild(se('line', { x1: 15 + c * CS, y1: 255, x2: 15 + c * CS, y2: 345, ...g }));
  for (let r = 1; r < 3; r++)
    layer.appendChild(se('line', { x1: 15, y1: 255 + r * CS, x2: 255, y2: 255 + r * CS, ...g }));

  // East arm
  for (let c = 1; c < 8; c++)
    layer.appendChild(se('line', { x1: 345 + c * CS, y1: 255, x2: 345 + c * CS, y2: 345, ...g }));
  for (let r = 1; r < 3; r++)
    layer.appendChild(se('line', { x1: 345, y1: 255 + r * CS, x2: 585, y2: 255 + r * CS, ...g }));
}

// ── Castle squares ─────────────────────────────────
function _drawCastles() {
  const layer = $('layer-castles');
  layer.innerHTML = '';
  CASTLES.forEach(c => {
    layer.appendChild(se('rect', {
      x: c.x - CS / 2, y: c.y - CS / 2, width: CS, height: CS, rx: 1,
      fill:   'rgba(78,6,6,0.72)',
      stroke: 'rgba(201,153,58,0.72)',
      'stroke-width': '1',
      class: 'castle-sq',
    }));
    // Diamond marker
    layer.appendChild(se('path', {
      d: `M${c.x},${c.y - 5}L${c.x + 5},${c.y}L${c.x},${c.y + 5}L${c.x - 5},${c.y}Z`,
      fill: 'rgba(201,153,58,0.58)',
    }));
  });
}

// ── Charkoni (lotus mandala) ───────────────────────
function _drawCharkoni() {
  const layer = $('layer-charkoni');
  layer.innerHTML = '';
  const cx = 300, cy = 300;

  // Base square
  layer.appendChild(se('rect', {
    x: 255, y: 255, width: 90, height: 90, rx: 3,
    fill: 'url(#grad-charkoni)',
    stroke: 'url(#grad-gold)', 'stroke-width': 2,
  }));
  layer.appendChild(se('rect', {
    x: 255, y: 255, width: 90, height: 90, rx: 3,
    fill: 'url(#silk)',
  }));

  // 8 lotus petals
  [0, 45, 90, 135, 180, 225, 270, 315].forEach((deg, i) => {
    const a  = (deg * Math.PI) / 180;
    const px = cx + Math.sin(a) * 18;
    const py = cy - Math.cos(a) * 18;
    layer.appendChild(se('ellipse', {
      cx: px.toFixed(2), cy: py.toFixed(2),
      rx: 4.2, ry: 8.5,
      fill:   `rgba(139,26,26,${i % 2 === 0 ? 0.75 : 0.5})`,
      stroke: 'rgba(201,153,58,0.38)', 'stroke-width': 0.7,
      transform: `rotate(${deg},${px.toFixed(2)},${py.toFixed(2)})`,
    }));
  });

  // Concentric circles
  [28, 18, 8].forEach((r, i) => layer.appendChild(se('circle', {
    cx, cy, r, fill: 'none',
    stroke: `rgba(201,153,58,${0.26 + i * 0.15})`,
    'stroke-width': i === 2 ? 1.4 : 0.8,
  })));

  // Centre jewel
  layer.appendChild(se('circle', { cx, cy, r: 6, fill: '#8B1A1A', stroke: 'rgba(201,153,58,0.8)', 'stroke-width': 1 }));
  layer.appendChild(se('circle', { cx, cy, r: 2.5, fill: 'rgba(232,201,106,0.88)' }));

  // Label
  const t = se('text', {
    x: cx, y: cy + 38,
    'text-anchor': 'middle',
    'font-family': 'Cinzel,serif',
    'font-size': '5.5',
    fill: 'rgba(201,153,58,0.5)',
    'letter-spacing': '1.8',
  });
  t.textContent = 'CHARKONI';
  layer.appendChild(t);
}

// ── Arm labels (Devanagari) ────────────────────────
function _drawLabels() {
  const layer = $('layer-labels');
  layer.innerHTML = '';
  const lbls = [
    { x: 300, y:  9, t: 'पीला', rot: 0   },
    { x: 300, y: 597, t: 'काला', rot: 0   },
    { x:   8, y: 300, t: 'हरा',  rot: -90 },
    { x: 597, y: 300, t: 'लाल',  rot: 90  },
  ];
  lbls.forEach(l => {
    const t = se('text', {
      x: l.x, y: l.y,
      'text-anchor': 'middle',
      'font-family': 'Cinzel,serif',
      'font-size': '7',
      fill: 'rgba(201,153,58,0.42)',
      'letter-spacing': '1.2',
      transform: l.rot ? `rotate(${l.rot},${l.x},${l.y})` : undefined,
    });
    t.textContent = l.t;
    layer.appendChild(t);
  });
}

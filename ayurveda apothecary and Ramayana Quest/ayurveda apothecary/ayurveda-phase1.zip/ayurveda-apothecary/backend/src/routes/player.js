/**
 * player.js — Player CRUD + XP + achievements
 */
import { Router } from 'express';
import { z }      from 'zod';
import { db }     from '../config/db.js';
import { v4 as uuid } from 'uuid';

export const playerRouter = Router();

// POST /api/players — create or load player
playerRouter.post('/', async (req, res) => {
  try {
    const { name = 'Apprentice' } = req.body;
    const { rows } = await db.query(
      `INSERT INTO players (id, name)
       VALUES ($1, $2)
       ON CONFLICT DO NOTHING
       RETURNING *`,
      [uuid(), name]
    );
    res.status(201).json(rows[0] ?? { error: 'Player exists' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/players/:id/xp — award XP + recalculate rank
playerRouter.patch('/:id/xp', async (req, res) => {
  try {
    const { amount, source } = req.body;
    const { rows } = await db.query(
      `UPDATE players SET xp_total = xp_total + $1, last_seen = NOW()
       WHERE id = $2 RETURNING xp_total, level, rank`,
      [amount, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Player not found' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/players/:id/sanskriti
playerRouter.patch('/:id/sanskriti', async (req, res) => {
  try {
    const { amount } = req.body;
    const { rows } = await db.query(
      `UPDATE players SET sanskriti_score = sanskriti_score + $1 WHERE id = $2 RETURNING sanskriti_score`,
      [amount, req.params.id]
    );
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/players/leaderboard?type=xp|sanskriti&limit=20
playerRouter.get('/leaderboard', async (req, res) => {
  try {
    const type  = req.query.type === 'sanskriti' ? 'sanskriti_score' : 'xp_total';
    const limit = Math.min(parseInt(req.query.limit ?? '20'), 100);
    const { rows } = await db.query(
      `SELECT id, name, avatar, rank, xp_total, sanskriti_score, streak_best
       FROM players ORDER BY ${type} DESC LIMIT $1`,
      [limit]
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

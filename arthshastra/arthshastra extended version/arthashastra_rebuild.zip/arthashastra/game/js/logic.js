/**
 * logic.js
 * Pure game logic for Arthashastra: Rise of Chandragupta.
 * No DOM. No side effects. Takes state, returns new state.
 */

/* ═══════════════════════════════════════════════════════
   INITIAL STATE
═══════════════════════════════════════════════════════ */
export function createInitialState() {
  return {
    turn:      1,
    year:      321,
    actionsLeft: 3,
    resources: { gold: 450, army: 120, food: 280, dharma: 65, happiness: 72 },
    deltas:    { gold: 35, army: 5, food: 20, dharma: 3 },
    stats:     { military: 75, dharma: 65, economy: 60, influence: 45 },
    researched: new Set(),
    events:    [],
    selectedTerritory: null,
  };
}

/* ═══════════════════════════════════════════════════════
   TERRITORY DATA
═══════════════════════════════════════════════════════ */
export function createTerritories() {
  return [
    { id:'magadha',     name:'Magadha',       hindi:'मगध',         owner:'player',     strength:80,  wealth:90,  type:'capital',   population:500 },
    { id:'pataliputra', name:'Pataliputra',   hindi:'पाटलिपुत्र',   owner:'player',     strength:70,  wealth:80,  type:'city',      population:300 },
    { id:'nalanda',     name:'Nalanda',       hindi:'नालंदा',       owner:'player',     strength:40,  wealth:60,  type:'temple',    population:150 },
    { id:'nanda',       name:'Nanda Kingdom', hindi:'नंद राज्य',    owner:'nanda',      strength:120, wealth:100, type:'capital',   population:400 },
    { id:'taxila',      name:'Takshashila',   hindi:'तक्षशिला',     owner:'persian',    strength:90,  wealth:110, type:'city',      population:350 },
    { id:'kalinga',     name:'Kalinga',       hindi:'कलिंग',        owner:'kalinga',    strength:100, wealth:75,  type:'capital',   population:320 },
    { id:'saurashtra',  name:'Saurashtra',    hindi:'सौराष्ट्र',    owner:'saurashtra', strength:70,  wealth:85,  type:'port',      population:200 },
    { id:'kosala',      name:'Kosala',        hindi:'कोसल',         owner:'kosala',     strength:65,  wealth:60,  type:'city',      population:250 },
    { id:'panchala',    name:'Panchala',      hindi:'पांचाल',       owner:'neutral',    strength:55,  wealth:65,  type:'plains',    population:180 },
    { id:'mathura',     name:'Mathura',       hindi:'मथुरा',        owner:'neutral',    strength:50,  wealth:70,  type:'city',      population:200 },
    { id:'avanti',      name:'Avanti',        hindi:'अवंती',        owner:'neutral',    strength:60,  wealth:65,  type:'plains',    population:170 },
    { id:'vatsa',       name:'Vatsa',         hindi:'वत्स',         owner:'neutral',    strength:45,  wealth:55,  type:'plains',    population:140 },
    { id:'anga',        name:'Anga',          hindi:'अंग',          owner:'neutral',    strength:50,  wealth:60,  type:'port',      population:160 },
    { id:'gandhara',    name:'Gandhara',      hindi:'गंधार',        owner:'neutral',    strength:55,  wealth:70,  type:'mountains', population:150 },
    { id:'sindhu',      name:'Sindhu',        hindi:'सिंधु',        owner:'neutral',    strength:60,  wealth:80,  type:'river',     population:220 },
    { id:'deccan',      name:'Deccan',        hindi:'दक्षिण',       owner:'neutral',    strength:65,  wealth:55,  type:'plains',    population:200 },
  ];
}

/* ═══════════════════════════════════════════════════════
   FACTIONS
═══════════════════════════════════════════════════════ */
export const FACTIONS = {
  player:     { name:'Mauryan Empire',   emoji:'🏰', relation:'player',  color:'#8B1A1A' },
  nanda:      { name:'Nanda Empire',     emoji:'⚔',  relation:'hostile', color:'#1A3B6B' },
  persian:    { name:'Seleucid Force',   emoji:'🏛',  relation:'hostile', color:'#8B4513' },
  kalinga:    { name:'Kalinga Kingdom',  emoji:'🐘', relation:'hostile', color:'#1A6B3B' },
  saurashtra: { name:'Saurashtra',       emoji:'🚢', relation:'neutral', color:'#8B8B00' },
  kosala:     { name:'Kosala',           emoji:'🌸', relation:'neutral', color:'#8B008B' },
  neutral:    { name:'Independent',      emoji:'🏔',  relation:'neutral', color:'#555555' },
};

/* ═══════════════════════════════════════════════════════
   TECHNOLOGIES
═══════════════════════════════════════════════════════ */
export const TECHNOLOGIES = [
  { id:'saptanga',   name:'Saptanga Rajya',   emoji:'👑', desc:'+20% all income',          cost:200, effect:'income',   shloka:'कोशमूलो दण्डः' },
  { id:'dandaniti',  name:'Dandaniti',         emoji:'⚖', desc:'+30 army strength',         cost:150, effect:'military', shloka:'दण्डः शासनसाधनम्' },
  { id:'kosha',      name:'Kosha Vyavastha',   emoji:'🏦', desc:'+50 gold per turn',         cost:180, effect:'gold',     shloka:'कोशो राज्यस्य मूलम्' },
  { id:'gupta',      name:'Gupta Chakra',      emoji:'🕵', desc:'Spies 50% cheaper',         cost:120, effect:'spy',      shloka:'गूढपुरुषाः कार्याः' },
  { id:'ashvamedha', name:'Ashvamedha Yajna',  emoji:'🐎', desc:'+25 dharma, +10 happiness', cost:250, effect:'dharma',   shloka:'धर्मो रक्षति रक्षितः' },
  { id:'vanika',     name:'Vanika Patha',       emoji:'🐪', desc:'+15 economy, trade bonus',  cost:200, effect:'trade',    shloka:'वाणिज्यं वर्धयेद् राज्यम्' },
];

/* ═══════════════════════════════════════════════════════
   ACTION LOGIC
═══════════════════════════════════════════════════════ */
export function doAction(actionType, state, territories) {
  const s = { ...state, resources: { ...state.resources }, stats: { ...state.stats }, deltas: { ...state.deltas } };

  if (s.actionsLeft <= 0) return { state: s, result: 'no_actions', message: 'No actions remaining this turn.' };

  const costs = { recruit:150, spy:80, trade:100, dharma:60, harvest:50, diplomacy:70 };
  const cost  = costs[actionType];
  if (cost && s.resources.gold < cost)
    return { state: s, result: 'insufficient_gold', message: `Need ${cost} gold.` };

  s.resources.gold -= cost || 0;
  s.actionsLeft--;

  switch (actionType) {
    case 'recruit':
      s.resources.army = Math.min(500, s.resources.army + 30 + Math.floor(s.stats.military / 10));
      s.stats.military = Math.min(100, s.stats.military + 3);
      break;
    case 'spy':
      s.stats.influence = Math.min(100, s.stats.influence + 8);
      break;
    case 'trade':
      s.deltas.gold     = Math.min(200, s.deltas.gold + 25);
      s.stats.economy   = Math.min(100, s.stats.economy + 5);
      s.stats.influence = Math.min(100, s.stats.influence + 3);
      break;
    case 'dharma':
      s.resources.dharma    = Math.min(100, s.resources.dharma + 12);
      s.resources.happiness = Math.min(100, s.resources.happiness + 8);
      s.stats.influence     = Math.min(100, s.stats.influence + 4);
      break;
    case 'harvest':
      s.resources.food   = Math.min(600, s.resources.food + 40);
      s.deltas.food      = Math.min(100, s.deltas.food + 10);
      s.stats.economy    = Math.min(100, s.stats.economy + 3);
      s.resources.happiness = Math.min(100, s.resources.happiness + 3);
      break;
    case 'diplomacy':
      s.stats.influence = Math.min(100, s.stats.influence + 12);
      s.resources.dharma = Math.min(100, s.resources.dharma + 5);
      break;
  }

  return { state: s, result: 'ok' };
}

/* ═══════════════════════════════════════════════════════
   RESEARCH
═══════════════════════════════════════════════════════ */
export function researchTech(techId, state) {
  const tech = TECHNOLOGIES.find(t => t.id === techId);
  if (!tech || state.researched.has(techId)) return { state, result: 'already_known' };
  if (state.resources.gold < tech.cost) return { state, result: 'insufficient_gold', needed: tech.cost };

  const s = {
    ...state,
    resources:  { ...state.resources, gold: state.resources.gold - tech.cost },
    stats:      { ...state.stats },
    deltas:     { ...state.deltas },
    researched: new Set([...state.researched, techId]),
  };

  switch (tech.effect) {
    case 'income':   s.deltas.gold = Math.min(200, s.deltas.gold + 20); s.deltas.food = Math.min(100, s.deltas.food + 10); break;
    case 'military': s.resources.army = Math.min(500, s.resources.army + 30); s.stats.military = Math.min(100, s.stats.military + 20); break;
    case 'gold':     s.deltas.gold = Math.min(200, s.deltas.gold + 50); break;
    case 'dharma':   s.resources.dharma = Math.min(100, s.resources.dharma + 25); s.resources.happiness = Math.min(100, s.resources.happiness + 10); break;
    case 'trade':    s.stats.economy = Math.min(100, s.stats.economy + 15); s.deltas.gold = Math.min(200, s.deltas.gold + 15); break;
  }

  return { state: s, result: 'ok', tech };
}

/* ═══════════════════════════════════════════════════════
   TERRITORY ACTIONS
═══════════════════════════════════════════════════════ */
export function invadeTerritory(territory, state, territories, factions) {
  const owned = territory.owner === 'player';
  if (owned) return fortifyTerritory(territory, state);

  const s = { ...state, resources: { ...state.resources }, stats: { ...state.stats } };
  const armyBonus = s.stats.military / 100;
  const effectiveArmy = s.resources.army * (1 + armyBonus);
  const successChance = Math.min(0.9, effectiveArmy / (territory.strength * 1.3));

  if (Math.random() < successChance) {
    // Victory
    const updatedTerr = territories.map(t =>
      t.id === territory.id ? { ...t, owner: 'player', strength: Math.max(20, t.strength - 30) } : t
    );
    s.resources.army = Math.max(0, s.resources.army - Math.floor(territory.strength * 0.3));
    s.resources.gold += territory.wealth * 5;
    s.deltas.gold    += Math.floor(territory.wealth * 0.3);
    s.resources.dharma = Math.max(0, s.resources.dharma - 8);
    s.stats.military   = Math.min(100, s.stats.military + 3);
    return { state: s, territories: updatedTerr, result: 'victory', territory };
  } else {
    // Defeat
    s.resources.army = Math.max(0, s.resources.army - Math.floor(territory.strength * 0.4));
    s.resources.dharma = Math.max(0, s.resources.dharma - 5);
    s.resources.happiness = Math.max(0, s.resources.happiness - 8);
    return { state: s, territories, result: 'defeat', territory };
  }
}

export function annexTerritory(territory, state, territories) {
  if (territory.owner !== 'neutral')
    return { state, territories, result: 'not_neutral' };

  const s = { ...state, resources: { ...state.resources }, stats: { ...state.stats } };
  const influenceBonus = s.stats.influence / 100;
  const dharmaBonus    = s.resources.dharma / 100;
  const successChance  = Math.min(0.85, 0.35 + influenceBonus * 0.3 + dharmaBonus * 0.25);

  if (Math.random() < successChance) {
    const updatedTerr = territories.map(t =>
      t.id === territory.id ? { ...t, owner: 'player' } : t
    );
    s.resources.gold    -= 100;
    s.deltas.gold       += Math.floor(territory.wealth * 0.2);
    s.stats.influence   = Math.min(100, s.stats.influence + 5);
    s.resources.dharma  = Math.min(100, s.resources.dharma + 5);
    return { state: s, territories: updatedTerr, result: 'annexed', territory };
  } else {
    s.resources.gold -= 50;
    return { state: s, territories, result: 'rebuffed', territory };
  }
}

export function fortifyTerritory(territory, state) {
  const s = { ...state, resources: { ...state.resources } };
  if (s.resources.gold < 80)
    return { state: s, result: 'insufficient_gold', needed: 80 };
  s.resources.gold -= 80;
  // Fortification is reflected in territory data (handled in main.js)
  return { state: s, result: 'fortified', strengthGain: 15 };
}

export function spyOnTerritory(territory, state, territories) {
  const s = { ...state, resources: { ...state.resources }, stats: { ...state.stats } };
  const cost = state.researched.has('gupta') ? 40 : 80;
  if (s.resources.gold < cost)
    return { state: s, territories, result: 'insufficient_gold', needed: cost };

  s.resources.gold -= cost;
  const successChance = Math.min(0.85, 0.5 + s.stats.influence / 200);

  if (Math.random() < successChance) {
    const reduction = Math.floor(territory.strength * 0.2);
    const updatedTerr = territories.map(t =>
      t.id === territory.id ? { ...t, strength: Math.max(10, t.strength - reduction) } : t
    );
    s.stats.influence = Math.min(100, s.stats.influence + 4);
    return { state: s, territories: updatedTerr, result: 'spy_success', territory, reduction };
  } else {
    s.resources.dharma = Math.max(0, s.resources.dharma - 3);
    return { state: s, territories, result: 'spy_caught', territory };
  }
}

/* ═══════════════════════════════════════════════════════
   END OF TURN
═══════════════════════════════════════════════════════ */
export function processTurnEnd(state, territories, factions) {
  const s = {
    ...state,
    resources:   { ...state.resources },
    stats:       { ...state.stats },
    deltas:      { ...state.deltas },
    actionsLeft: 3,
    turn:        state.turn + 1,
    year:        state.year - 1,
  };

  const playerTerrs = territories.filter(t => t.owner === 'player');

  // ── Income phase ──────────────────────────────────────
  s.resources.gold      = Math.max(0, Math.min(9999, s.resources.gold + s.deltas.gold));
  s.resources.food      = Math.max(0, Math.min(999,  s.resources.food + s.deltas.food));
  s.resources.dharma    = Math.max(0, Math.min(100,  s.resources.dharma + s.deltas.dharma));
  s.resources.army      = Math.max(0, Math.min(500,  s.resources.army + s.deltas.army));

  // ── Territory income ──────────────────────────────────
  const territoryGold = playerTerrs.reduce((acc, t) => acc + Math.floor(t.wealth * 0.4), 0);
  s.resources.gold = Math.min(9999, s.resources.gold + territoryGold);

  // ── Upkeep (army costs food and gold) ────────────────
  const armyUpkeep = Math.floor(s.resources.army * 0.15);
  s.resources.gold = Math.max(0, s.resources.gold - armyUpkeep);
  s.resources.food = Math.max(0, s.resources.food - Math.floor(s.resources.army * 0.1));

  // ── Happiness decay if food low ───────────────────────
  if (s.resources.food < 100) {
    s.resources.happiness = Math.max(0, s.resources.happiness - 10);
    s.resources.dharma    = Math.max(0, s.resources.dharma - 5);
  }

  // ── Dharma decay from large empires without governance ─
  if (playerTerrs.length > 8 && s.resources.dharma > 0) {
    s.resources.dharma = Math.max(0, s.resources.dharma - 2);
  }

  // ── Faction AI: hostile factions grow and occasionally attack ──
  const updatedTerritories = [...territories];
  const events = [];

  Object.entries(factions).forEach(([factionId, faction]) => {
    if (factionId === 'player' || factionId === 'neutral') return;
    const factionTerrs = updatedTerritories.filter(t => t.owner === factionId);
    if (factionTerrs.length === 0) return;

    // Factions grow in strength over time
    factionTerrs.forEach(t => {
      const idx = updatedTerritories.findIndex(x => x.id === t.id);
      if (idx >= 0) {
        updatedTerritories[idx] = {
          ...updatedTerritories[idx],
          strength: Math.min(200, updatedTerritories[idx].strength + Math.floor(Math.random() * 5)),
        };
      }
    });

    // Occasional hostile faction attack (low probability)
    if (faction.relation === 'hostile' && Math.random() < 0.12 && s.turn > 3) {
      const adjacentPlayerTerrs = playerTerrs.filter(() => Math.random() < 0.3);
      if (adjacentPlayerTerrs.length > 0 && factionTerrs.length > 0) {
        const target = adjacentPlayerTerrs[Math.floor(Math.random() * adjacentPlayerTerrs.length)];
        const attacker = factionTerrs[0];
        const attackStrength = updatedTerritories.find(t => t.id === attacker.id)?.strength || attacker.strength;

        if (attackStrength > s.resources.army * 0.5) {
          events.push({
            text:  `${faction.emoji} ${faction.name} raids ${target.name}! Your garrison holds, but the territory is weakened.`,
            type:  'bad',
          });
          const tIdx = updatedTerritories.findIndex(x => x.id === target.id);
          if (tIdx >= 0) {
            updatedTerritories[tIdx] = {
              ...updatedTerritories[tIdx],
              strength: Math.max(10, updatedTerritories[tIdx].strength - 10),
            };
          }
          s.resources.army = Math.max(0, s.resources.army - 15);
        }
      }
    }
  });

  // ── Neutral territories can sometimes join diplomatically ─
  const neutralTerrs = territories.filter(t => t.owner === 'neutral');
  if (neutralTerrs.length > 0 && s.stats.influence > 60 && Math.random() < 0.05) {
    const convert = neutralTerrs[Math.floor(Math.random() * neutralTerrs.length)];
    const idx = updatedTerritories.findIndex(t => t.id === convert.id);
    if (idx >= 0) {
      updatedTerritories[idx] = { ...updatedTerritories[idx], owner: 'player' };
      events.push({
        text: `🌸 ${convert.name} (${convert.hindi}) joins the Mauryan fold peacefully, drawn by your reputation.`,
        type: 'good',
      });
    }
  }

  return { state: s, territories: updatedTerritories, events };
}

/* ═══════════════════════════════════════════════════════
   VICTORY CHECK
═══════════════════════════════════════════════════════ */
export function checkVictory(territories) {
  const player = territories.filter(t => t.owner === 'player').length;
  const total  = territories.length;
  if (player >= 12 || player / total >= 0.75)
    return { won: true, playerCount: player, total };
  return { won: false };
}

/* ═══════════════════════════════════════════════════════
   SERIALISE / DESERIALISE  (for save system)
═══════════════════════════════════════════════════════ */
export function serialiseState(state) {
  return {
    ...state,
    researched: [...state.researched],
  };
}

export function deserialiseState(raw) {
  return {
    ...raw,
    researched: new Set(raw.researched || []),
  };
}

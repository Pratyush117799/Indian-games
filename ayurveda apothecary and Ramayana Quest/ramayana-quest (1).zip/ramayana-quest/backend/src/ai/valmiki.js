import Anthropic from '@anthropic-ai/sdk';
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const SARVAM_URL = 'https://api.sarvam.ai/v1/chat/completions';
const rl = new Map();
function checkRL(ip) {
  const now = Date.now(), e = rl.get(ip) ?? { count:0, resetAt:now+3600000 };
  if (now > e.resetAt) { rl.set(ip, {count:1, resetAt:now+3600000}); return true; }
  if (e.count >= 20) return false;
  e.count++; rl.set(ip, e); return true;
}
function sanitise(t) { return t.replace(/<[^>]*>/g,'').replace(/[^\p{L}\p{N}\s?.!,\-']/gu,'').trim().slice(0,600); }
function buildPrompt(character, age=12) {
  const c = character ? `Player is playing as ${character}.` : '';
  const a = age<=10 ? 'Simple words, vivid stories.' : age<=15 ? 'Explain Sanskrit, connect to modern life.' : 'Full poetic depth.';
  return `You are Sage Valmiki (महर्षि वाल्मीकि), the Adi Kavi and author of the Ramayana. Address the player as "young seeker." Voice: poetic, wise. EXPERTISE: All 7 Kandas, character psychology, historical geography (Ayodhya, Hampi, Adam's Bridge, Sri Lanka), modern connections (Diwali, Hanuman Chalisa, Ram Rajya). ${c} STYLE: 2-4 sentences. One story moment. Connect ancient to modern. ${a}`;
}
async function callSarvam(messages) {
  if (!process.env.SARVAM_API_KEY) throw new Error('No Sarvam key');
  const r = await fetch(SARVAM_URL, {
    method:'POST', headers:{'Content-Type':'application/json','api-subscription-key':process.env.SARVAM_API_KEY},
    body: JSON.stringify({ model:'sarvam-m', messages, max_tokens:350, temperature:0.75 }),
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok) throw new Error(`Sarvam ${r.status}`);
  return (await r.json()).choices?.[0]?.message?.content ?? null;
}
async function callClaude(system, messages) {
  const r = await anthropic.messages.create({ model:'claude-opus-4-6', max_tokens:350, system, messages });
  return r.content[0]?.text ?? null;
}
export async function askValmiki({ question, history=[], character=null, playerAge=12, ip='x' }) {
  if (!checkRL(ip)) throw Object.assign(new Error('Rate limit exceeded.'), {code:429});
  const clean = sanitise(question);
  if (clean.length < 2) throw new Error('Too short.');
  const system = buildPrompt(character, playerAge);
  const msgs = [...history.slice(-8).map(m=>({role:m.role==='valmiki'?'assistant':'user',content:sanitise(m.content)})),{role:'user',content:clean}];
  let text=null, model='claude-opus-4-6';
  if (process.env.SARVAM_API_KEY) try { text=await callSarvam([{role:'system',content:system},...msgs]); model='sarvam-m'; } catch(e) { console.warn('Sarvam failed:', e.message); }
  if (!text) { text=await callClaude(system,msgs); }
  if (!text) throw new Error('No response.');
  return { text, model, timestamp:new Date().toISOString() };
}
export async function valmikiRouteHandler(req, res) {
  try {
    const { question, history, character, playerAge } = req.body;
    if (!question) return res.status(400).json({ error:'Question required.' });
    const ip = req.headers['x-forwarded-for']?.split(',')[0] ?? req.socket?.remoteAddress ?? 'x';
    res.json(await askValmiki({ question, history, character, playerAge, ip }));
  } catch(err) {
    if (err.code===429) return res.status(429).json({error:err.message});
    console.error(err);
    res.status(500).json({error:'Sage Valmiki is in deep meditation. Try again shortly.'});
  }
}

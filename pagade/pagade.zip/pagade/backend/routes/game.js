const express = require('express');
const router = express.Router();
const svc = require('../services/gameService');

// POST /games — start a new game session
router.post('/', async (req, res, next) => {
  try {
    const { mode, diceStyle, seats } = req.body;
    if (!mode || !seats || !Array.isArray(seats)) {
      return res.status(400).json({ error: { message: 'mode and seats required' } });
    }
    const result = await svc.createGame({ mode, diceStyle: diceStyle || 'cowrie', seats });
    res.status(201).json(result);
  } catch (err) { next(err); }
});

// GET /games/:id
router.get('/:id', async (req, res, next) => {
  try {
    const game = await svc.getGame(req.params.id);
    if (!game) return res.status(404).json({ error: { message: 'Game not found' } });
    res.json({ game });
  } catch (err) { next(err); }
});

// PATCH /games/:id/state — save game state (client persists state as JSON)
router.patch('/:id/state', async (req, res, next) => {
  try {
    const { state } = req.body;
    if (!state) return res.status(400).json({ error: { message: 'state required' } });
    await svc.saveGameState(req.params.id, state);
    res.json({ saved: true });
  } catch (err) { next(err); }
});

// POST /games/:id/moves — log a move
router.post('/:id/moves', async (req, res, next) => {
  try {
    await svc.logMove({ gameId: req.params.id, ...req.body });
    res.status(201).json({ logged: true });
  } catch (err) { next(err); }
});

// POST /games/:id/complete
router.post('/:id/complete', async (req, res, next) => {
  try {
    const { winnerPlayerId, durationSecs, playerStats } = req.body;
    await svc.completeGame({ gameId: req.params.id, winnerPlayerId, durationSecs });
    if (playerStats && Array.isArray(playerStats)) {
      for (const ps of playerStats) {
        await svc.updatePlayerStats(ps);
      }
    }
    res.json({ completed: true });
  } catch (err) { next(err); }
});

// GET /games/:id/moves — full move log (for replay)
router.get('/:id/moves', async (req, res, next) => {
  try {
    const moves = await svc.getGameMoves(req.params.id);
    res.json({ moves });
  } catch (err) { next(err); }
});

module.exports = router;

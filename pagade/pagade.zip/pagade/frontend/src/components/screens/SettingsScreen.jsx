import React from 'react';
import { DICE_STYLE } from '../../game/constants';
import { BOARD_THEMES } from '../../game/boardThemes';

export default function SettingsScreen({ settings, onUpdate, onReset, onBack, gamesWon = 0 }) {
  const { diceStyle, boardTheme, showMoveLog, animSpeed, playerName } = settings;

  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: '#0f0804', animation: 'fadeIn .3s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '14px 16px',
        borderBottom: '1px solid rgba(139,105,20,.2)',
        background: '#1a0e06',
        flexShrink: 0,
      }}>
        <button onClick={onBack} style={{
          background: 'none', border: '1px solid rgba(139,105,20,.25)',
          color: '#C8A96A', width: 32, height: 32, borderRadius: '50%',
          cursor: 'pointer', fontSize: '.85rem',
        }}>←</button>
        <span style={{ fontSize: '.95rem', fontWeight: 500, color: '#F0C84A' }}>⚙ Settings</span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 20 }}>

        {/* Player name */}
        <Section label="Profile">
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input
              type="text"
              placeholder="Display name"
              value={playerName}
              maxLength={24}
              onChange={e => onUpdate('playerName', e.target.value)}
              style={{
                flex: 1, padding: '8px 12px', borderRadius: 8,
                border: '1px solid rgba(139,105,20,.3)',
                background: '#2c1a0e', color: '#F5EAD0',
                fontSize: '.85rem', outline: 'none',
              }}
            />
          </div>
        </Section>

        {/* Dice */}
        <Section label="Default dice">
          <div style={{ display: 'flex', gap: 6 }}>
            <ToggleBtn active={diceStyle===DICE_STYLE.COWRIE} onClick={()=>onUpdate('diceStyle',DICE_STYLE.COWRIE)}>🐚 Cowrie</ToggleBtn>
            <ToggleBtn active={diceStyle===DICE_STYLE.STICK}  onClick={()=>onUpdate('diceStyle',DICE_STYLE.STICK)}>🎴 Stick</ToggleBtn>
          </div>
        </Section>

        {/* Board theme */}
        <Section label="Board theme">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {Object.values(BOARD_THEMES).map(theme => {
              const locked = gamesWon < theme.unlockWins;
              const active = boardTheme === theme.id;
              return (
                <button
                  key={theme.id}
                  onClick={() => !locked && onUpdate('boardTheme', theme.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '8px 12px', borderRadius: 8,
                    border: `1px solid ${active ? '#D4A017' : 'rgba(139,105,20,.2)'}`,
                    background: active ? 'rgba(212,160,23,.1)' : '#2c1a0e',
                    cursor: locked ? 'not-allowed' : 'pointer',
                    opacity: locked ? 0.45 : 1,
                    transition: 'all .2s', textAlign: 'left',
                  }}
                >
                  <span style={{ fontSize: '1.1rem' }}>{theme.emoji}</span>
                  <div>
                    <div style={{ fontSize: '.82rem', color: active ? '#F0C84A' : '#C8A96A', fontWeight: active ? 500 : 400 }}>
                      {theme.name}
                    </div>
                    <div style={{ fontSize: '.65rem', color: '#5a3820', marginTop: 1 }}>
                      {locked ? `🔒 Unlock at ${theme.unlockWins} wins` : theme.description}
                    </div>
                  </div>
                  {active && <span style={{ marginLeft: 'auto', color: '#D4A017', fontSize: '.8rem' }}>✓</span>}
                </button>
              );
            })}
          </div>
        </Section>

        {/* Move log */}
        <Section label="Move log">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '.82rem', color: '#C8A96A' }}>Show history sidebar</span>
            <Toggle value={showMoveLog} onChange={v => onUpdate('showMoveLog', v)} />
          </div>
        </Section>

        {/* Animation speed */}
        <Section label="Animation speed">
          <div style={{ display: 'flex', gap: 6 }}>
            {['fast','normal','slow'].map(s => (
              <ToggleBtn key={s} active={animSpeed===s} onClick={()=>onUpdate('animSpeed',s)}>
                {s === 'fast' ? '⚡' : s === 'slow' ? '🌿' : '◎'} {s.charAt(0).toUpperCase()+s.slice(1)}
              </ToggleBtn>
            ))}
          </div>
        </Section>

        {/* Stats */}
        <Section label="Your stats">
          <div style={{ display: 'flex', gap: 10 }}>
            {[
              { label: 'Wins', val: gamesWon, color: '#D4A017' },
              { label: 'Themes', val: Object.values(BOARD_THEMES).filter(t => gamesWon >= t.unlockWins).length, color: '#27AE60' },
            ].map(s => (
              <div key={s.label} style={{
                flex: 1, background: '#2c1a0e', borderRadius: 8, padding: '10px',
                textAlign: 'center',
              }}>
                <div style={{ fontSize: '1.4rem', fontWeight: 500, color: s.color }}>{s.val}</div>
                <div style={{ fontSize: '.65rem', color: '#5a3820', marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </Section>

        {/* Reset */}
        <button
          onClick={onReset}
          style={{
            width: '100%', padding: '10px', borderRadius: 8,
            border: '1px solid rgba(192,57,43,.35)',
            background: 'transparent', color: 'rgba(192,57,43,.7)',
            fontSize: '.8rem', cursor: 'pointer', marginTop: 4,
          }}
        >Reset all settings</button>

      </div>
    </div>
  );
}

function Section({ label, children }) {
  return (
    <div>
      <div style={{
        fontSize: '.6rem', fontWeight: 500, color: '#5a3820',
        letterSpacing: '.08em', textTransform: 'uppercase',
        marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8,
      }}>
        {label}
        <div style={{ flex: 1, height: '0.5px', background: 'rgba(139,105,20,.2)' }} />
      </div>
      {children}
    </div>
  );
}

function ToggleBtn({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '6px 12px', borderRadius: 6,
        border: `1px solid ${active ? '#D4A017' : 'rgba(139,105,20,.2)'}`,
        background: active ? 'rgba(212,160,23,.12)' : '#2c1a0e',
        color: active ? '#F0C84A' : '#C8A96A',
        fontSize: '.78rem', cursor: 'pointer', transition: 'all .2s',
      }}
    >{children}</button>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button
      onClick={() => onChange(!value)}
      style={{
        width: 42, height: 24, borderRadius: 12,
        border: 'none', padding: 0, cursor: 'pointer', position: 'relative',
        background: value ? '#D4A017' : '#3d2410',
        transition: 'background .2s',
      }}
    >
      <span style={{
        position: 'absolute', top: 3, width: 18, height: 18,
        borderRadius: '50%', background: '#fff',
        left: value ? 21 : 3,
        transition: 'left .2s',
        boxShadow: '0 1px 3px rgba(0,0,0,.4)',
      }} />
    </button>
  );
}

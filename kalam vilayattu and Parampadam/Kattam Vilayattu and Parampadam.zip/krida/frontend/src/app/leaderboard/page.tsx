'use client';
import { useEffect, useState } from 'react';
import { Trophy, Star } from 'lucide-react';
import { clsx } from 'clsx';
import api from '@/lib/api';
import type { LeaderboardEntry, GameSlug } from '@/types';

const GAMES: { slug: GameSlug; label: string; tamil: string }[] = [
  { slug: 'kattam-vilayattu', label: 'Kattam Vilayattu', tamil: 'கட்டம்' },
  { slug: 'paramapadam',      label: 'Paramapadam',      tamil: 'பரமபதம்' },
];

const RANK_STYLE = ['text-yellow-500','text-gray-400','text-orange-400'];

export default function LeaderboardPage() {
  const [game, setGame]   = useState<GameSlug>('kattam-vilayattu');
  const [data, setData]   = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/leaderboard/${game}?limit=30`)
      .then(r => setData(r.data.leaderboard))
      .finally(() => setLoading(false));
  }, [game]);

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 space-y-6">
      <div className="text-center space-y-1">
        <Trophy className="mx-auto text-kolam" size={36} />
        <h1 className="text-2xl font-bold text-temple">Leaderboard</h1>
        <p className="text-sm text-gray-400">Top players ranked by ELO rating</p>
      </div>

      {/* Game switcher */}
      <div className="flex gap-2 justify-center">
        {GAMES.map(g => (
          <button key={g.slug} onClick={() => setGame(g.slug)}
            className={clsx('px-4 py-1.5 rounded-full text-sm font-medium transition',
              game === g.slug ? 'bg-clay text-cream' : 'bg-white border border-clay/20 text-clay hover:bg-clay/5')}>
            {g.label} <span className="font-tamil text-xs">· {g.tamil}</span>
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-cream border-b border-clay/10">
            <tr>
              {['#','Player','Rating','W','L','Win%','Best Time'].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wide">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-12 text-gray-300 animate-pulse">Loading…</td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-12 text-gray-300">No games played yet</td></tr>
            ) : (
              data.map((e) => (
                <tr key={e.id} className="border-b border-clay/5 hover:bg-cream/50 transition">
                  <td className="px-4 py-3">
                    <span className={clsx('font-bold text-base', RANK_STYLE[e.rank-1] || 'text-gray-500')}>
                      {e.rank <= 3 ? ['🥇','🥈','🥉'][e.rank-1] : `#${e.rank}`}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-medium text-temple">{e.username}</td>
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-1">
                      <Star size={12} className="text-kolam" />
                      {e.rating}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-leaf font-medium">{e.wins}</td>
                  <td className="px-4 py-3 text-red-400">{e.losses}</td>
                  <td className="px-4 py-3 text-gray-600">{e.win_rate}%</td>
                  <td className="px-4 py-3 text-gray-400 text-xs">
                    {e.best_time_secs ? `${Math.floor(e.best_time_secs/60)}m ${e.best_time_secs%60}s` : '—'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

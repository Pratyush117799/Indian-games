/**
 * EmojiReaction — floating emoji burst triggered by tap during a game.
 * Shown as a circular quick-pick toolbar (6 emojis).
 * Auto-dismisses after 3 seconds or on selection.
 *
 * Usage: Place absolutely over the board area.
 * Props:
 *   visible: boolean
 *   onPick(emoji): called with selected emoji
 *   onDismiss: called after auto-dismiss
 */

import React, { useEffect, useState, useRef } from 'react';

const REACTION_EMOJIS = ['😄', '😱', '🤯', '🙏', '🔥', '👑'];

export default function EmojiReactionPicker({ visible, onPick, onDismiss }) {
  const timerRef = useRef(null);

  useEffect(() => {
    if (!visible) return;
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => onDismiss?.(), 3000);
    return () => clearTimeout(timerRef.current);
  }, [visible]);

  if (!visible) return null;

  return (
    <div style={{
      position: 'absolute',
      bottom: 90,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 60,
      display: 'flex',
      gap: 6,
      background: 'rgba(26,14,6,.92)',
      border: '1px solid rgba(139,105,20,.3)',
      borderRadius: 40,
      padding: '8px 14px',
      animation: 'fadeUp .25s ease',
      backdropFilter: 'blur(4px)',
    }}>
      {REACTION_EMOJIS.map(emoji => (
        <button
          key={emoji}
          onClick={() => { onPick?.(emoji); onDismiss?.(); }}
          style={{
            background: 'none', border: 'none',
            fontSize: '1.4rem', cursor: 'pointer',
            padding: '2px 4px', borderRadius: 8,
            transition: 'transform .15s',
            lineHeight: 1,
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = 'scale(1.3)'; }}
          onMouseLeave={e => { e.currentTarget.style.transform = 'scale(1)'; }}
        >
          {emoji}
        </button>
      ))}
    </div>
  );
}

// ── Floating emoji burst that animates across the screen ────────────────────

export function EmojiFloat({ emoji, x, y, onDone }) {
  useEffect(() => {
    const t = setTimeout(() => onDone?.(), 1200);
    return () => clearTimeout(t);
  }, []);

  return (
    <div
      style={{
        position: 'fixed',
        left: x, top: y,
        fontSize: '2rem',
        pointerEvents: 'none',
        zIndex: 200,
        animation: 'emojiFloat 1.2s ease-out forwards',
      }}
    >
      <style>{`
        @keyframes emojiFloat {
          0%   { transform: translateY(0)   scale(.8); opacity: 0; }
          20%  { transform: translateY(-12px) scale(1.2); opacity: 1; }
          80%  { transform: translateY(-48px) scale(1);   opacity: .9; }
          100% { transform: translateY(-72px) scale(.8); opacity: 0; }
        }
      `}</style>
      {emoji}
    </div>
  );
}

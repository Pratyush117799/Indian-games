import { create } from 'zustand';
import type { GameRoom, RoomPlayer, KattamState, ParamapadamState, GameSlug } from '@/types';

interface GameStore {
  // Room
  room:        GameRoom | null;
  players:     RoomPlayer[];
  gameSlug:    GameSlug | null;

  // Live game states
  kattamState:      KattamState | null;
  paramapadamState: ParamapadamState | null;

  // UI
  lastEvent:   string | null;
  chatMessages: { userId: string; username: string; message: string; timestamp: string }[];

  // Actions
  setRoom:        (room: GameRoom, players: RoomPlayer[]) => void;
  setPlayers:     (players: RoomPlayer[]) => void;
  setGameStarted: (gameSlug: GameSlug, state: KattamState | ParamapadamState) => void;
  setKattamState: (state: KattamState) => void;
  setParamapadamState: (state: ParamapadamState) => void;
  setLastEvent:   (event: string | null) => void;
  addChatMessage: (msg: GameStore['chatMessages'][0]) => void;
  reset:          () => void;
}

export const useGameStore = create<GameStore>((set) => ({
  room:             null,
  players:          [],
  gameSlug:         null,
  kattamState:      null,
  paramapadamState: null,
  lastEvent:        null,
  chatMessages:     [],

  setRoom:    (room, players) => set({ room, players }),
  setPlayers: (players)       => set({ players }),

  setGameStarted: (gameSlug, state) => set({
    gameSlug,
    kattamState:      gameSlug === 'kattam-vilayattu' ? state as KattamState      : null,
    paramapadamState: gameSlug === 'paramapadam'      ? state as ParamapadamState : null,
  }),

  setKattamState:      (state) => set({ kattamState: state }),
  setParamapadamState: (state) => set({ paramapadamState: state }),
  setLastEvent:        (event) => set({ lastEvent: event }),

  addChatMessage: (msg) =>
    set((s) => ({ chatMessages: [...s.chatMessages.slice(-100), msg] })),

  reset: () => set({
    room: null, players: [], gameSlug: null,
    kattamState: null, paramapadamState: null,
    lastEvent: null, chatMessages: [],
  }),
}));

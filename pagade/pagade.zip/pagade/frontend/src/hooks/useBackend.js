/**
 * useBackend — persists game state to the backend after each move.
 * Decoupled from useGame so the game works fully offline too.
 * Call wrapWithBackend(gameId, selectMove) to get a persisted selectMove.
 */

import { useRef, useCallback } from 'react';
import { games } from '../game/api';

export function useBackend() {
  const gameIdRef = useRef(null);
  const startTimeRef = useRef(null);

  // Create a new game record in the DB
  const createGameRecord = useCallback(async ({ mode, diceStyle, players }) => {
    const seats = players.map((p, i) => ({
      seat: i,
      color: ['Red','Green','Yellow','Blue'][i],
      playerId: p.playerId || null,
      isAi: p.isAi,
      aiLevel: p.aiLevel || null,
    }));
    const { data, error } = await games.create({ mode, diceStyle, seats });
    if (data?.gameId) {
      gameIdRef.current = data.gameId;
      startTimeRef.current = Date.now();
    }
    return gameIdRef.current;
  }, []);

  // Persist state snapshot after each move
  const persistState = useCallback(async (state) => {
    if (!gameIdRef.current) return;
    // Fire-and-forget — don't await to avoid blocking UI
    games.saveState(gameIdRef.current, state).catch(() => {});
  }, []);

  // Log an individual move
  const logMove = useCallback(async ({ seat, moveNumber, diceResult, move, capture }) => {
    if (!gameIdRef.current) return;
    games.logMove(gameIdRef.current, {
      seat,
      moveNumber,
      diceValues: diceResult?.values || [],
      diceTotal:  diceResult?.total  || 0,
      pawnIndex:  move?.pawnId ?? null,
      fromStatus: move?.fromStatus   || null,
      toStatus:   move?.newStatus    || null,
      fromPos:    move?.fromPathSteps ?? null,
      toPos:      move?.newPathSteps  ?? null,
      capturedPawn: capture ? { seat: capture.playerId, pawnIndex: capture.pawnId } : null,
    }).catch(() => {});
  }, []);

  // Mark game complete + update player stats
  const completeGame = useCallback(async ({ winner, players: gamePlayers }) => {
    if (!gameIdRef.current) return;
    const durationSecs = startTimeRef.current
      ? Math.round((Date.now() - startTimeRef.current) / 1000)
      : null;
    const playerStats = gamePlayers
      .filter(p => p.playerId)
      .map(p => ({
        playerId: p.playerId,
        won: p.id === winner,
        captures: p.captures || 0,
      }));
    games.complete(gameIdRef.current, {
      winnerPlayerId: gamePlayers.find(p => p.id === winner)?.playerId || null,
      durationSecs,
      playerStats,
    }).catch(() => {});
  }, []);

  return { createGameRecord, persistState, logMove, completeGame, gameId: gameIdRef.current };
}

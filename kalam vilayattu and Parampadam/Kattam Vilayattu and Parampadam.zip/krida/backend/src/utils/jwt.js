const jwt  = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db   = require('../config/db');

const ACCESS_SECRET  = process.env.JWT_SECRET;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;

/**
 * Sign a short-lived access token (15 min default).
 */
function signAccessToken(payload) {
  return jwt.sign(payload, ACCESS_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m',
    issuer:    'krida-api',
  });
}

/**
 * Sign a long-lived refresh token (7 days default).
 * Persists the token in the DB for rotation tracking.
 */
async function signRefreshToken(userId) {
  const token = jwt.sign({ sub: userId, jti: uuidv4() }, REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
    issuer:    'krida-api',
  });

  const decoded = jwt.decode(token);
  const expiresAt = new Date(decoded.exp * 1000);

  await db.query(
    'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
    [userId, token, expiresAt]
  );

  return token;
}

/**
 * Verify an access token; throws if invalid / expired.
 */
function verifyAccessToken(token) {
  return jwt.verify(token, ACCESS_SECRET, { issuer: 'krida-api' });
}

/**
 * Verify a refresh token against the DB (rotation check).
 */
async function verifyRefreshToken(token) {
  const decoded = jwt.verify(token, REFRESH_SECRET, { issuer: 'krida-api' });

  const { rows } = await db.query(
    `SELECT * FROM refresh_tokens
     WHERE token = $1 AND user_id = $2 AND expires_at > NOW()`,
    [token, decoded.sub]
  );

  if (!rows.length) throw new Error('Refresh token invalid or expired');

  return decoded;
}

/**
 * Revoke a refresh token (logout / rotation).
 */
async function revokeRefreshToken(token) {
  await db.query('DELETE FROM refresh_tokens WHERE token = $1', [token]);
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  revokeRefreshToken,
};

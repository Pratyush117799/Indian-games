/**
 * roomStore.js — In-memory store for active game states.
 *
 * Key:   roomCode (string)
 * Value: {
 *   gameSlug:    string,
 *   sessionId:   string (UUID),
 *   state:       object  (game engine state),
 *   startedAt:   Date,
 *   timerRef:    NodeJS.Timeout | null,
 * }
 *
 * In production, replace with Redis for horizontal scaling.
 */

const store = new Map();

const roomStore = {
  get:    (code)         => store.get(code),
  set:    (code, data)   => store.set(code, data),
  delete: (code)         => store.delete(code),
  has:    (code)         => store.has(code),
  all:    ()             => [...store.entries()],

  /** Update only specific fields of an existing room entry. */
  patch(code, partial) {
    const existing = store.get(code);
    if (!existing) return null;
    const updated = { ...existing, ...partial };
    store.set(code, updated);
    return updated;
  },
};

module.exports = roomStore;

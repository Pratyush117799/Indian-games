-- Migration: 001_initial_schema.sql
-- Run: psql -U krida_user -d krida_db -f 001_initial_schema.sql
-- Description: Creates all base tables for Krida platform

\i '../schema.sql'

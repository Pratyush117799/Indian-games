const router  = require('express').Router();
const ctrl    = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many auth attempts, please try again later.' },
});

router.post('/register', authLimiter, ctrl.registerRules, ctrl.register);
router.post('/login',    authLimiter, ctrl.loginRules,    ctrl.login);
router.post('/refresh',  ctrl.refresh);
router.post('/logout',   ctrl.logout);
router.get ('/me',       authenticate, ctrl.me);

module.exports = router;

/**
 * gardenSlice.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Living herb garden state — planted herbs, growth progress, seasonal data.
 *
 * The garden persists in localStorage and syncs growth in real-time
 * using the season/time engine.
 */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getGrowthProgress, getSeasonalContext, getHerbGrowthRate } from '../game-engine/seasons.js';
import { getHerbById }                   from '../game-engine/herbs.data.js';

const LS_KEY = 'ayurveda_garden';

// Maximum plots available (expands with level)
const PLOTS_BY_LEVEL = [4, 6, 8, 10, 12, 14, 16, 18, 20, 24];
export const getPlotsForLevel = (level) => PLOTS_BY_LEVEL[Math.min(level - 1, PLOTS_BY_LEVEL.length - 1)];

// ── Thunks ─────────────────────────────────────────────────────────────────
export const loadGarden = createAsyncThunk('garden/load', async () => {
  const stored = localStorage.getItem(LS_KEY);
  if (stored) {
    try { return JSON.parse(stored); } catch {}
  }
  return { plots: [], lastTended: null };
});

export const saveGarden = createAsyncThunk('garden/save', async (_, { getState }) => {
  const { garden } = getState();
  localStorage.setItem(LS_KEY, JSON.stringify(garden));
  return true;
});

/**
 * Tick: recalculate all growth progress from real-world time.
 * Called every 60 seconds by the Garden scene.
 */
export const tickGarden = createAsyncThunk('garden/tick', async (_, { getState }) => {
  const { garden } = getState();
  const now = Date.now();

  const updatedPlots = garden.plots.map(plot => {
    if (!plot.herbId || plot.harvested) return plot;
    const herb     = getHerbById(plot.herbId);
    if (!herb) return plot;
    const progress = getGrowthProgress(plot.herbId, herb.growTime, plot.plantedAt);
    return { ...plot, progress: progress.progress, readyToHarvest: progress.done };
  });

  return { plots: updatedPlots, lastTick: now };
});

// ── Slice ─────────────────────────────────────────────────────────────────────
const gardenSlice = createSlice({
  name: 'garden',
  initialState: {
    plots:         [],    // array of plot objects (see schema below)
    lastTended:    null,
    lastTick:      null,
    seasonalCtx:   null,  // refreshed on load
    status:        'idle',
  },

  /* Plot schema:
    {
      plotId:          string   — unique "plot_0" … "plot_23"
      herbId:          string | null
      plantedAt:       ISO string | null
      wateredAt:       ISO string | null
      progress:        0–1
      readyToHarvest:  boolean
      harvested:       boolean
      growthRate:      { multiplier, status, reason }
    }
  */

  reducers: {

    initPlots: (state, { payload: maxPlots }) => {
      // Ensure we have the right number of plots
      if (state.plots.length >= maxPlots) return;
      const existing = state.plots.length;
      for (let i = existing; i < maxPlots; i++) {
        state.plots.push({
          plotId:         `plot_${i}`,
          herbId:         null,
          plantedAt:      null,
          wateredAt:      null,
          progress:       0,
          readyToHarvest: false,
          harvested:      false,
          growthRate:     { multiplier: 1, status: 'normal', reason: '' },
        });
      }
    },

    plantHerb: (state, { payload: { plotId, herbId } }) => {
      const plot = state.plots.find(p => p.plotId === plotId);
      if (!plot || plot.herbId) return;   // plot occupied
      const growthRate = getHerbGrowthRate(herbId);
      Object.assign(plot, {
        herbId,
        plantedAt:      new Date().toISOString(),
        wateredAt:      null,
        progress:       0,
        readyToHarvest: false,
        harvested:      false,
        growthRate,
      });
    },

    waterHerb: (state, { payload: plotId }) => {
      const plot = state.plots.find(p => p.plotId === plotId);
      if (!plot || !plot.herbId || plot.harvested) return;
      // Watering boosts progress by 5% if within last 24h not watered
      const lastWatered = plot.wateredAt ? new Date(plot.wateredAt) : null;
      const hoursAgo    = lastWatered ? (Date.now() - lastWatered.getTime()) / 3_600_000 : Infinity;
      if (hoursAgo >= 8) {
        plot.progress    = Math.min(1, plot.progress + 0.05);
        plot.wateredAt   = new Date().toISOString();
      }
    },

    harvestHerb: (state, { payload: plotId }) => {
      const plot = state.plots.find(p => p.plotId === plotId);
      if (!plot || !plot.readyToHarvest) return;
      plot.harvested = true;
      // Caller must dispatch addHerb with the yield amount
    },

    clearPlot: (state, { payload: plotId }) => {
      const plot = state.plots.find(p => p.plotId === plotId);
      if (!plot) return;
      Object.assign(plot, {
        herbId: null, plantedAt: null, wateredAt: null,
        progress: 0, readyToHarvest: false, harvested: false,
        growthRate: { multiplier: 1, status: 'normal', reason: '' },
      });
    },

    refreshSeasonalContext: (state) => {
      state.seasonalCtx = getSeasonalContext();
    },

    markTended: (state) => {
      state.lastTended = new Date().toISOString();
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(loadGarden.fulfilled, (s, { payload }) => {
        s.plots       = payload.plots       ?? [];
        s.lastTended  = payload.lastTended  ?? null;
        s.seasonalCtx = getSeasonalContext();
        s.status      = 'ready';
      })
      .addCase(tickGarden.fulfilled, (s, { payload }) => {
        s.plots    = payload.plots;
        s.lastTick = payload.lastTick;
      });
  },
});

export const {
  initPlots, plantHerb, waterHerb, harvestHerb,
  clearPlot, refreshSeasonalContext, markTended,
} = gardenSlice.actions;

// ── Selectors ─────────────────────────────────────────────────────────────────
export const selectPlots         = (s) => s.garden.plots;
export const selectSeasonalCtx   = (s) => s.garden.seasonalCtx;
export const selectReadyToHarvest= (s) => s.garden.plots.filter(p => p.readyToHarvest && !p.harvested);
export const selectEmptyPlots    = (s) => s.garden.plots.filter(p => !p.herbId);
export const selectOccupiedPlots = (s) => s.garden.plots.filter(p => !!p.herbId);

export default gardenSlice.reducer;

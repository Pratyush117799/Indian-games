# Ashtapada · अष्टापद
### The Ancient Indian 8×8 Spiral Race Game · c.500 BCE

> *"No Ashtapada, no chess — at least not the same as we play today."*
> — BoardGameGeek, Ashtapada Documentary

---

## Project Structure

```
ashtapada/
│
├── frontend/                   # Pure HTML/CSS/JS — no build step needed
│   ├── index.html              # Main shell — all 4 screens
│   ├── css/
│   │   └── style.css           # Karnataka design language, animations
│   └── js/
│       ├── constants.js        # Board geometry, PATH spiral, castle squares, dice
│       ├── engine.js           # Game logic — pure state, no DOM
│       ├── renderer.js         # SVG board renderer + animations
│       ├── ai.js               # AI: Beginner / Prince / Maharaja
│       └── app.js              # App controller — wires everything together
│
├── backend/                    # Node.js + Express + Socket.IO
│   ├── server.js               # Entry point — HTTP + WebSocket
│   ├── routes/
│   │   ├── game.js             # Game CRUD + move recording + replay
│   │   ├── users.js            # User profiles + stat tracking
│   │   └── leaderboard.js      # Global + regional rankings
│   └── middleware/
│       └── ws.js               # Real-time multiplayer socket handler
│
├── database/
│   ├── schema.sql              # PostgreSQL schema — all tables
│   └── models/
│       ├── Game.js             # Game DB queries
│       └── User.js             # User DB queries
│
├── features/
│   └── FEATURES.md            # AI engine, daily challenge, replay,
│                               # progression, chess ancestry, probability overlay
│
├── package.json
└── README.md
```

---

## Setup

### Frontend only (play vs AI immediately)
```bash
# No build step. Just open in browser:
open frontend/index.html
# Or serve with any static server:
npx serve frontend
```

### Full stack (multiplayer + leaderboard)
```bash
npm install
# Set your Postgres connection string:
export DATABASE_URL=postgresql://localhost/ashtapada
npm run db:init          # Create all tables
npm run dev              # nodemon on port 3000
```

---

## Game Mechanics Summary

| Mechanic        | Detail                                                      |
|-----------------|-------------------------------------------------------------|
| Board           | 8×8 monochrome grid — historically authentic (no colour alt) |
| Path            | Clockwise-inward spiral — 64 steps from corner to centre    |
| Castle squares  | 12 sanctuary cells — no capture possible here               |
| Dice            | 4 cowrie shells: 0=skip, 1-3=move, 4 mouths-up=move 8      |
| Capture         | Land on opponent (non-castle) → they return to start        |
| Blockade        | 2 same-colour pieces on one cell → opponent cannot pass     |
| Win condition   | All 4 pieces reach the centre 4 HOME squares                |

---

## Cowrie Dice Probability

| Mouths up | Move | Probability |
|-----------|------|-------------|
| 0         | Skip | 6.25%       |
| 1         | 1    | 25%         |
| 2         | 2    | 37.5%       |
| 3         | 3    | 25%         |
| 4         | 8    | 6.25%       |

---

## Cultural Context

Ashtapada is documented in Buddhist texts from ~500 BCE (Brahma-jala Sutta),
Jain texts (Sutrakritanga, ~300 BCE), and Patanjali's Mahabhasya (~200 BCE).

The 8×8 board passed from Ashtapada → Chaturanga (~600 CE) → Shatranj (Persia)
→ Medieval Chess → Modern Chess (1475 CE).

Every chess game played today is played on what was once the Ashtapada board.

---

*Part of the Krida Ancient Indian Games Hub · pagade.in*

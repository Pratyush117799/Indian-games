import { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '../context/GameContext.jsx';

export default function GameLog() {
  const { log } = useGame();
  const bodyRef = useRef(null);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [log]);

  return (
    <div className="log-panel">
      <div className="log-head">Chronicle · इतिहास</div>
      <div className="log-body" ref={bodyRef}>
        <AnimatePresence initial={false}>
          {log.map((entry, i) => (
            <motion.div key={i} className="log-entry"
              initial={{ opacity:0, x:-10 }}
              animate={{ opacity: i === log.length - 1 ? 0.9 : 0.52, x:0 }}
              transition={{ duration:0.28 }}
            >
              {entry}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

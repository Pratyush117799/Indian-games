-- ── 001_players.sql ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS players (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name              VARCHAR(50) NOT NULL DEFAULT 'Apprentice',
  avatar            VARCHAR(30) DEFAULT 'default',
  dosha_type        VARCHAR(20),
  xp_total          INTEGER     NOT NULL DEFAULT 0,
  level             INTEGER     NOT NULL DEFAULT 1,
  rank              VARCHAR(30) NOT NULL DEFAULT 'Shishya',
  sanskriti_score   INTEGER     NOT NULL DEFAULT 0,
  -- Virtues
  virtue_dharma     INTEGER     NOT NULL DEFAULT 0,
  virtue_courage    INTEGER     NOT NULL DEFAULT 0,
  virtue_wisdom     INTEGER     NOT NULL DEFAULT 0,
  virtue_devotion   INTEGER     NOT NULL DEFAULT 0,
  -- Streak
  streak_current    INTEGER     NOT NULL DEFAULT 0,
  streak_best       INTEGER     NOT NULL DEFAULT 0,
  streak_last_date  DATE,
  -- Metadata
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  settings          JSONB       NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_players_xp       ON players(xp_total DESC);
CREATE INDEX IF NOT EXISTS idx_players_sanskriti ON players(sanskriti_score DESC);

/**
 * ui.js
 * All DOM updates for the Arthashastra game screen.
 * Receives state; never owns it.
 */

import { FACTIONS, TECHNOLOGIES } from './logic.js';
import { OWNER_COLOURS } from './map.js';

const $ = id => document.getElementById(id);

/* ═══════════════════════════════════════════════════════
   TOP BAR RESOURCES
═══════════════════════════════════════════════════════ */
export function updateResources(state) {
  const r = state.resources;
  const d = state.deltas;

  $('res-gold').textContent      = r.gold.toLocaleString();
  $('res-army').textContent      = r.army;
  $('res-food').textContent      = r.food;
  $('res-dharma').textContent    = r.dharma;
  $('res-happiness').textContent = r.happiness + '%';

  $('delta-gold').textContent    = (d.gold >= 0 ? '+' : '') + d.gold;
  $('delta-army').textContent    = (d.army >= 0 ? '+' : '') + d.army;
  $('delta-food').textContent    = (d.food >= 0 ? '+' : '') + d.food;

  $('delta-gold').className      = 'resource-delta ' + (d.gold >= 0 ? 'delta-pos' : 'delta-neg');

  $('turn-year').textContent     = state.year;
  $('turn-number').textContent   = state.turn;
  $('actions-left').textContent  = state.actionsLeft;
}

/* ═══════════════════════════════════════════════════════
   STAT BARS (left panel)
═══════════════════════════════════════════════════════ */
export function updateStatBars(state) {
  const s = state.stats;
  [
    ['mil',    s.military],
    ['dharma', s.dharma],
    ['eco',    s.economy],
    ['inf',    s.influence],
  ].forEach(([key, val]) => {
    const el  = $('stat-' + key);
    const bar = $('bar-'  + key);
    if (el)  el.textContent  = val + '%';
    if (bar) bar.style.width = val + '%';
  });
}

/* ═══════════════════════════════════════════════════════
   TERRITORY LIST (left panel)
═══════════════════════════════════════════════════════ */
export function renderTerritoryList(territories, selectedId, onSelectFn) {
  const container = $('territory-list');
  if (!container) return;

  const playerTerrs = territories.filter(t => t.owner === 'player');
  const total       = territories.length;

  const countEl = $('terr-count');
  if (countEl) countEl.textContent = `${playerTerrs.length}/${total}`;

  container.innerHTML = playerTerrs.map(t => `
    <div class="territory-item ${selectedId === t.id ? 'active' : ''}"
         onclick="window.__onTerritoryPanelClick?.('${t.id}')">
      <div>
        <span class="terr-name">${t.name}</span>
        <span class="terr-hindi">${t.hindi}</span>
      </div>
      <span class="terr-stats">⚔${t.strength} 🪙${t.wealth}</span>
    </div>
  `).join('');

  // Expose click handler for inline onclick
  window.__onTerritoryPanelClick = onSelectFn;
}

/* ═══════════════════════════════════════════════════════
   FACTION LIST
═══════════════════════════════════════════════════════ */
export function renderFactionList(territories) {
  const container = $('faction-list');
  if (!container) return;

  container.innerHTML = Object.entries(FACTIONS)
    .filter(([id]) => id !== 'player' && id !== 'neutral')
    .map(([id, f]) => {
      const count   = territories.filter(t => t.owner === id).length;
      const tagCls  = f.relation === 'hostile' ? 'hostile' : f.relation === 'allied' ? 'allied' : 'neutral';
      return `
        <div class="faction-row">
          <span class="faction-emoji">${f.emoji}</span>
          <div class="faction-info">
            <span class="faction-name">${f.name}</span>
            <span class="faction-terr">${count} territories</span>
          </div>
          <span class="faction-tag tag-${tagCls}">${f.relation.toUpperCase()}</span>
        </div>
      `;
    }).join('');
}

/* ═══════════════════════════════════════════════════════
   TECHNOLOGY LIST
═══════════════════════════════════════════════════════ */
export function renderTechList(researched, onResearchFn) {
  const container = $('tech-list');
  if (!container) return;

  container.innerHTML = TECHNOLOGIES.map(t => {
    const done = researched.has(t.id);
    return `
      <div class="tech-item ${done ? 'researched' : ''}" onclick="${done ? '' : `window.__onTechClick?.('${t.id}')`}">
        <span class="tech-icon">${t.emoji}</span>
        <div class="tech-body">
          <div class="tech-name">${t.name}</div>
          <div class="tech-effect">${t.desc}</div>
          <div class="tech-shloka">${t.shloka}</div>
        </div>
        <span class="tech-cost">${done ? '✓ KNOWN' : '🪙' + t.cost}</span>
      </div>
    `;
  }).join('');

  window.__onTechClick = onResearchFn;
}

/* ═══════════════════════════════════════════════════════
   EVENT LOG
═══════════════════════════════════════════════════════ */
export function addEvent(text, type = 'neutral') {
  const log = $('event-log');
  if (!log) return;
  const entry = document.createElement('div');
  entry.className = `event-entry event-${type}`;
  entry.textContent = text;
  log.insertBefore(entry, log.firstChild);
  if (log.children.length > 25) log.removeChild(log.lastChild);
}

export function clearEvents() {
  const log = $('event-log');
  if (log) log.innerHTML = '';
}

/* ═══════════════════════════════════════════════════════
   CHANAKYA ADVISOR PANEL
═══════════════════════════════════════════════════════ */
let _advisorTimer = null;

export function showAdvisor(text, shloka = null, autoDismiss = true) {
  const box   = $('advisor-box');
  const quote = $('advisor-quote');
  const sloka = $('advisor-shloka');

  if (!box || !quote) return;

  quote.textContent = text;
  if (sloka) { sloka.textContent = shloka || ''; sloka.style.display = shloka ? 'block' : 'none'; }

  box.classList.remove('hidden');
  if (_advisorTimer) clearTimeout(_advisorTimer);
  if (autoDismiss) {
    _advisorTimer = setTimeout(() => box.classList.add('hidden'), 8000);
  }
}

export function hideAdvisor() {
  $('advisor-box')?.classList.add('hidden');
}

/* ═══════════════════════════════════════════════════════
   BOTTOM BAR — selected territory info
═══════════════════════════════════════════════════════ */
export function updateSelectionBar(territory, state) {
  const titleEl   = $('sel-title');
  const descEl    = $('sel-desc');
  const actionsEl = $('territory-actions');

  if (!territory) {
    if (titleEl)   titleEl.textContent = '🗺 SELECT A PROVINCE';
    if (descEl)    descEl.textContent  = 'Click any territory on the map to view details and available actions';
    if (actionsEl) actionsEl.style.display = 'none';
    return;
  }

  const owned    = territory.owner === 'player';
  const isNeutral = territory.owner === 'neutral';
  const faction  = FACTIONS[territory.owner];
  const typeLabels = {
    capital:'Capital', city:'City', temple:'Sacred Temple',
    port:'Port City', plains:'Plains', mountains:'Mountain Pass',
    river:'River Valley',
  };
  const typeLabel = typeLabels[territory.type] || 'Territory';
  const ownerLabel = owned ? 'Your Empire' : (faction?.name || 'Independent');

  if (titleEl) titleEl.innerHTML = `${owned ? '🏴' : '🚩'} ${territory.name} <span style="font-weight:300;opacity:0.6">${territory.hindi}</span>`;
  if (descEl)  descEl.textContent = `${typeLabel} · Owner: ${ownerLabel} · ⚔ ${territory.strength} · 🪙 ${territory.wealth} · Population: ${territory.population}K`;

  if (actionsEl) {
    actionsEl.style.display = 'flex';
    const invadeBtn = $('btn-invade');
    const annexBtn  = $('btn-annex');
    const spyBtn    = $('btn-spy-terr');

    if (owned) {
      if (invadeBtn) { invadeBtn.textContent = '🏗 FORTIFY'; invadeBtn.disabled = false; }
      if (annexBtn)  { annexBtn.textContent  = '📜 MANAGE';  annexBtn.disabled  = false; }
      if (spyBtn)    { spyBtn.textContent    = '🌾 DEVELOP'; spyBtn.disabled    = false; }
    } else {
      if (invadeBtn) { invadeBtn.textContent = '⚔ INVADE';    invadeBtn.disabled = false; }
      if (annexBtn)  { annexBtn.textContent  = isNeutral ? '🤝 ANNEX' : '📯 DIPLOMACY'; annexBtn.disabled = false; }
      if (spyBtn)    { spyBtn.textContent    = '🕵 SPY';      spyBtn.disabled    = false; }
    }
  }
}

/* ═══════════════════════════════════════════════════════
   ACTION BUTTONS (enable/disable)
═══════════════════════════════════════════════════════ */
export function updateActionButtons(state) {
  const noActions = state.actionsLeft <= 0;
  ['recruit','spy','trade','dharma','harvest','diplomacy'].forEach(a => {
    const btn = $('btn-' + a);
    if (btn) btn.disabled = noActions;
  });
}

/* ═══════════════════════════════════════════════════════
   NOTIFICATION TOAST
═══════════════════════════════════════════════════════ */
export function showNotification(title, body, type = 'neutral') {
  const el = $('notification');
  if (!el) return;
  $('notif-title').textContent = title;
  $('notif-body').textContent  = body;
  el.className = 'show notif-' + type;
  setTimeout(() => { el.className = ''; }, 3500);
}

/* ═══════════════════════════════════════════════════════
   DECISION MODAL
═══════════════════════════════════════════════════════ */
export function showModal(title, body, options) {
  $('modal-title').textContent = title;
  $('modal-body').innerHTML    = body.replace(/\n/g, '<br>');
  const opts = $('modal-options');
  opts.innerHTML = '';
  options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = `modal-btn ${opt.cls || ''}`;
    btn.textContent = opt.label;
    btn.onclick = () => {
      opt.action();
      $('modal').classList.remove('active');
    };
    opts.appendChild(btn);
  });
  $('modal').classList.add('active');
}

export function closeModal() {
  $('modal')?.classList.remove('active');
}

/* ═══════════════════════════════════════════════════════
   VICTORY SCREEN
═══════════════════════════════════════════════════════ */
export function showVictory(title, narrative) {
  const vs = $('victory-screen');
  if (!vs) return;
  $('victory-title').textContent = title;
  $('victory-desc').textContent  = narrative;
  vs.classList.add('show');
}

/* ═══════════════════════════════════════════════════════
   PLAYER HUD (top-right of nav: samrat name + title)
═══════════════════════════════════════════════════════ */
export function updatePlayerHUD(player) {
  const nameEl  = $('player-name');
  const titleEl = $('player-title');
  if (nameEl  && player?.name)         nameEl.textContent  = player.name;
  if (titleEl && player?.currentTitle) titleEl.textContent = player.currentTitle.label;
}

/* ═══════════════════════════════════════════════════════
   SAVE SLOT INDICATOR
═══════════════════════════════════════════════════════ */
export function updateSaveIndicator(slotIndex) {
  const el = $('save-slot-indicator');
  if (el) el.textContent = `Slot ${slotIndex + 1}`;
}

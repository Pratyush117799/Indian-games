const { verifyAccessToken } = require('../utils/jwt');
const db = require('../config/db');

/**
 * Socket.IO middleware — authenticate every connecting socket.
 * Client must pass  { auth: { token: '<accessToken>' } }  in handshake options.
 */
async function socketAuth(socket, next) {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('AUTH_MISSING'));

    const decoded = verifyAccessToken(token);
    const { rows } = await db.query(
      'SELECT id, username, avatar_url FROM users WHERE id = $1',
      [decoded.sub]
    );
    if (!rows.length) return next(new Error('AUTH_USER_NOT_FOUND'));

    socket.user = rows[0]; // attach to socket for later handlers
    next();
  } catch (err) {
    next(new Error('AUTH_INVALID'));
  }
}

module.exports = { socketAuth };

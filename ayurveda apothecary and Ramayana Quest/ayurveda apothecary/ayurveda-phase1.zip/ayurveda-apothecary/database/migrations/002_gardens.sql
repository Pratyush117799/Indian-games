-- ── 002_gardens.sql ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS garden_plots (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id       UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  plot_index      INTEGER     NOT NULL,
  herb_id         VARCHAR(50),
  planted_at      TIMESTAMPTZ,
  watered_at      TIMESTAMPTZ,
  progress        FLOAT       NOT NULL DEFAULT 0,
  ready_to_harvest BOOLEAN    NOT NULL DEFAULT FALSE,
  harvested       BOOLEAN     NOT NULL DEFAULT FALSE,
  UNIQUE (player_id, plot_index)
);

CREATE INDEX IF NOT EXISTS idx_garden_player ON garden_plots(player_id);

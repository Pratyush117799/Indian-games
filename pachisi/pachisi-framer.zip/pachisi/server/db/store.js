'use strict';
const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data.json');

function _read() {
  if (!fs.existsSync(DB_PATH)) {
    const seed = {
      games: [],
      stats: { gamesPlayed: 0, teamAWins: 0, teamBWins: 0, totalMoves: 0 }
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(seed, null, 2));
    return seed;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function _write(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ── Games ──────────────────────────────────────────
function createGame(id) {
  const db = _read();
  const game = {
    id,
    startedAt: new Date().toISOString(),
    endedAt:   null,
    winner:    null,
    moves:     0,
    state:     null
  };
  db.games.push(game);
  db.stats.gamesPlayed++;
  _write(db);
  return game;
}

function saveState(id, state) {
  const db = _read();
  const g  = db.games.find(g => g.id === id);
  if (!g) return null;
  g.state = state;
  g.moves = (g.moves || 0) + 1;
  db.stats.totalMoves = (db.stats.totalMoves || 0) + 1;
  _write(db);
  return g;
}

function endGame(id, winner) {
  const db = _read();
  const g  = db.games.find(g => g.id === id);
  if (!g) return null;
  g.endedAt = new Date().toISOString();
  g.winner  = winner;
  if (winner === 'A') db.stats.teamAWins++;
  else if (winner === 'B') db.stats.teamBWins++;
  _write(db);
  return g;
}

function getGame(id) {
  return _read().games.find(g => g.id === id) || null;
}

function getStats() {
  return _read().stats;
}

function recentGames(limit = 10) {
  const db = _read();
  return db.games
    .filter(g => g.endedAt)
    .sort((a, b) => new Date(b.endedAt) - new Date(a.endedAt))
    .slice(0, limit)
    .map(({ id, startedAt, endedAt, winner, moves }) =>
      ({ id, startedAt, endedAt, winner, moves }));
}

module.exports = { createGame, saveState, endGame, getGame, getStats, recentGames };

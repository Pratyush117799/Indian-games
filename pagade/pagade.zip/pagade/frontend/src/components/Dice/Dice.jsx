/**
 * Dice components — CowrieDice and StickDice
 * Animated roll using CSS + SVG. No external assets.
 */

import React, { useState, useEffect } from 'react';
import { PLAYER_COLORS } from '../../game/constants';

// ─── Cowrie Shell Dice ────────────────────────────────────────────────────────

export function CowrieDice({ result, rolling, onRoll, disabled, currentPlayerColor }) {
  const [displayResult, setDisplayResult] = useState(null);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    if (rolling) {
      setAnimating(true);
      setDisplayResult(null);
    } else if (result) {
      setAnimating(false);
      setDisplayResult(result);
    }
  }, [rolling, result]);

  const shells = result?.shellResults || Array(6).fill(false);

  return (
    <div className="dice-container cowrie-container">
      <div className={`cowrie-grid ${animating ? 'rolling' : ''}`}>
        {shells.map((isMouth, i) => (
          <CowrieShell key={i} isMouth={isMouth} delay={i * 40} animating={animating} />
        ))}
      </div>

      {displayResult && (
        <div className="dice-total" style={{ color: currentPlayerColor }}>
          {displayResult.total}
        </div>
      )}

      <button
        className="roll-btn"
        onClick={onRoll}
        disabled={disabled || animating}
        style={{ '--player-color': currentPlayerColor }}
      >
        {animating ? '…' : '🎲'}
      </button>
    </div>
  );
}

function CowrieShell({ isMouth, delay, animating }) {
  return (
    <svg
      viewBox="0 0 24 14"
      width={28}
      height={18}
      style={{
        animationDelay: animating ? `${delay}ms` : '0ms',
        animation: animating ? 'shellSpin 0.3s ease-in-out infinite alternate' : 'none',
      }}
    >
      {/* Shell body */}
      <ellipse cx="12" cy="7" rx="11" ry="6" fill={isMouth ? '#F5DEB3' : '#8B7355'} />
      <ellipse cx="12" cy="7" rx="9" ry="4" fill={isMouth ? '#FAEFD0' : '#6B5335'} />
      {/* Aperture (mouth) */}
      {isMouth && (
        <>
          <ellipse cx="12" cy="9" rx="5" ry="2" fill="#3d1f00" />
          <path d="M7 9 Q12 7 17 9" stroke="#5d3000" strokeWidth="0.5" fill="none" />
        </>
      )}
      {/* Ribs */}
      {[9, 12, 15].map(x => (
        <line key={x} x1={x} y1={1.5} x2={x} y2={12.5} stroke="rgba(0,0,0,0.12)" strokeWidth={0.5} />
      ))}
    </svg>
  );
}

// ─── Stick Dice ───────────────────────────────────────────────────────────────

const STICK_FACES_DOT_LAYOUT = {
  1: [[50, 50]],
  3: [[25, 25], [50, 50], [75, 75]],
  4: [[25, 25], [75, 25], [25, 75], [75, 75]],
  6: [[25, 20], [75, 20], [25, 50], [75, 50], [25, 80], [75, 80]],
};

export function StickDice({ result, rolling, onRoll, disabled, currentPlayerColor }) {
  const [animating, setAnimating] = useState(false);
  const [spinVals, setSpinVals] = useState([1, 1]);

  useEffect(() => {
    if (rolling) {
      setAnimating(true);
      // Random flicker during roll
      const iv = setInterval(() => {
        setSpinVals([
          [1,3,4,6][Math.floor(Math.random()*4)],
          [1,3,4,6][Math.floor(Math.random()*4)],
        ]);
      }, 80);
      setTimeout(() => {
        clearInterval(iv);
        setAnimating(false);
      }, 600);
      return () => clearInterval(iv);
    } else if (result?.values?.length >= 2) {
      setSpinVals(result.values);
    }
  }, [rolling, result]);

  const vals = animating ? spinVals : (result?.values || [1, 1]);

  return (
    <div className="dice-container stick-container">
      <div className="stick-pair">
        {vals.slice(0,2).map((v, i) => (
          <SingleStick key={i} value={v} spinning={animating} delay={i * 30} isDoublet={result?.isDoublet} />
        ))}
      </div>

      {result && !animating && (
        <div className="dice-total" style={{ color: currentPlayerColor }}>
          {result.total}
          {result.isDoublet && <span className="doublet-badge">✦</span>}
        </div>
      )}

      <button
        className="roll-btn"
        onClick={onRoll}
        disabled={disabled || animating}
        style={{ '--player-color': currentPlayerColor }}
      >
        {animating ? '…' : '🎲'}
      </button>
    </div>
  );
}

function SingleStick({ value, spinning, delay, isDoublet }) {
  const dots = STICK_FACES_DOT_LAYOUT[value] || [];

  return (
    <svg
      viewBox="0 0 100 100"
      width={48}
      height={48}
      style={{
        animationDelay: `${delay}ms`,
        animation: spinning ? 'stickSpin 0.18s linear infinite' : 'none',
        filter: isDoublet && !spinning ? 'drop-shadow(0 0 6px #D4A017)' : 'none',
        transition: 'filter 0.3s',
      }}
    >
      {/* Stick die body — elongated rectangle */}
      <rect x="5" y="5" width="90" height="90" rx="14" fill="#FAEFD0" stroke="#8B6914" strokeWidth="2.5" />
      <rect x="8" y="8" width="84" height="84" rx="11" fill="none" stroke="rgba(139,105,20,0.3)" strokeWidth="1" />

      {dots.map(([cx, cy], i) => (
        <circle key={i} cx={cx} cy={cy} r={7} fill="#2c1a0e" />
      ))}
    </svg>
  );
}

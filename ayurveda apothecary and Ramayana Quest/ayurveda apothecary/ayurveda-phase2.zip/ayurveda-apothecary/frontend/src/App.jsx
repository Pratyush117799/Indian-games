import React, { useState, useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { loadPlayer, updateStreak } from './store/playerSlice.js'
import { loadGarden } from './store/gardenSlice.js'
import NavBar from './components/shared/NavBar.jsx'
import HubScene from './scenes/Hub.jsx'
import GardenScene from './scenes/Garden.jsx'
import ApothecaryScene from './scenes/Apothecary.jsx'
import PatientScene from './scenes/PatientRoom.jsx'
import CompendiumScene from './scenes/Compendium.jsx'

const SCENES = { hub: HubScene, garden: GardenScene, craft: ApothecaryScene, patients: PatientScene, compendium: CompendiumScene }

export default function App() {
  const dispatch = useDispatch()
  const [scene, setScene] = useState('hub')

  useEffect(() => {
    dispatch(loadPlayer())
    dispatch(loadGarden())
    dispatch(updateStreak())
  }, [dispatch])

  const SceneComponent = SCENES[scene] || HubScene

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <NavBar scene={scene} setScene={setScene} />
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <SceneComponent setScene={setScene} />
      </div>
    </div>
  )
}

'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { useAuthStore } from '@/store/authStore';

export default function RegisterPage() {
  const router   = useRouter();
  const { register, isLoading } = useAuthStore();
  const [form, setForm]   = useState({ username: '', email: '', password: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    try {
      await register(form.username, form.email, form.password);
      toast.success('Account created! Welcome to Krida.');
      router.push('/');
    } catch (err: any) {
      const apiErrors = err?.response?.data?.errors;
      if (Array.isArray(apiErrors)) {
        const map: Record<string, string> = {};
        apiErrors.forEach((e: any) => { map[e.path] = e.msg; });
        setErrors(map);
      } else {
        setErrors({ global: err?.response?.data?.error || 'Registration failed.' });
      }
    }
  }

  const field = (id: keyof typeof form, label: string, type = 'text', hint?: string) => (
    <div>
      <label className="text-sm font-medium text-gray-700 block mb-1">{label}</label>
      <input type={type} required className="input"
        value={form[id]}
        onChange={(e) => setForm({ ...form, [id]: e.target.value })}
        placeholder={hint} />
      {errors[id] && <p className="text-red-600 text-xs mt-1">{errors[id]}</p>}
    </div>
  );

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="card w-full max-w-md space-y-6">
        <div className="text-center">
          <span className="text-4xl">♟</span>
          <h1 className="text-2xl font-bold text-temple mt-2">Join Krida</h1>
          <p className="text-sm text-gray-500">Create your account to play traditional Tamil games</p>
        </div>

        {errors.global && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-2.5 rounded-lg">
            {errors.global}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {field('username', 'Username', 'text', 'e.g. kolam_player')}
          {field('email',    'Email',    'email', 'you@example.com')}
          {field('password', 'Password', 'password', 'Min 8 chars, 1 uppercase, 1 number')}
          <button type="submit" disabled={isLoading} className="btn-primary w-full">
            {isLoading ? 'Creating account…' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-clay font-semibold hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}

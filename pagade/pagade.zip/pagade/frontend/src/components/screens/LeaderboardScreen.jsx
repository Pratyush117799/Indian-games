import React, { useEffect, useState } from 'react';
import { players as api } from '../../game/api';
import { PLAYER_COLORS } from '../../game/constants';

const PODIUM_COLORS = ['#D4A017', '#C8A96A', '#8B6914'];

export default function LeaderboardScreen({ onBack }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.leaderboard().then(({ data }) => {
      if (data?.players) setRows(data.players);
      setLoading(false);
    });
  }, []);

  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: 'radial-gradient(ellipse at 50% 0%, rgba(212,160,23,.1) 0%, transparent 55%), #0f0804',
      animation: 'fadeIn .4s ease',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '14px 16px',
        borderBottom: '1px solid rgba(139,105,20,.2)',
      }}>
        <button onClick={onBack} style={{ background: 'none', border: '1px solid rgba(139,105,20,.25)', color: '#C8A96A', width: 32, height: 32, borderRadius: '50%', cursor: 'pointer', fontSize: '.85rem' }}>←</button>
        <span style={{ fontSize: '.9rem', fontWeight: 500, color: '#F0C84A' }}>🏆 Leaderboard</span>
      </div>

      {loading ? (
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#7a5c3a', fontSize: '.85rem' }}>
          Loading…
        </div>
      ) : rows.length === 0 ? (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, color: '#7a5c3a' }}>
          <span style={{ fontSize: '2rem', opacity: .4 }}>✦</span>
          <span style={{ fontSize: '.8rem' }}>No games played yet</span>
          <span style={{ fontSize: '.7rem', color: '#5a3820' }}>Play a game with a registered player to appear here</span>
        </div>
      ) : (
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 10px' }}>

          {/* Top 3 podium */}
          {rows.length >= 3 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginBottom: 20, padding: '8px 0' }}>
              {[1, 0, 2].map(i => rows[i] && (
                <PodiumSlot key={i} player={rows[i]} pos={i + 1} />
              ))}
            </div>
          )}

          {/* Full table */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{
              display: 'grid', gridTemplateColumns: '28px 1fr 36px 36px 36px',
              padding: '4px 10px', gap: 4,
              fontSize: '.6rem', color: '#5a3820', letterSpacing: '.06em', textTransform: 'uppercase',
            }}>
              <span>#</span><span>Player</span><span style={{ textAlign: 'right' }}>W</span><span style={{ textAlign: 'right' }}>%</span><span style={{ textAlign: 'right' }}>🔥</span>
            </div>

            {rows.slice(0, 50).map((row, i) => (
              <div key={row.id} style={{
                display: 'grid', gridTemplateColumns: '28px 1fr 36px 36px 36px',
                padding: '7px 10px', gap: 4,
                background: i < 3 ? 'rgba(212,160,23,.06)' : 'rgba(44,26,14,.4)',
                borderRadius: 8, alignItems: 'center',
                border: i === 0 ? '1px solid rgba(212,160,23,.25)' : '1px solid transparent',
              }}>
                <span style={{ fontSize: '.72rem', color: PODIUM_COLORS[i] || '#5a3820', fontWeight: i < 3 ? 500 : 400 }}>
                  {i < 3 ? ['①','②','③'][i] : row.rank}
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, minWidth: 0 }}>
                  <div style={{
                    width: 24, height: 24, borderRadius: '50%',
                    background: '#3d2410', border: '1.5px solid #5a3820',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '.65rem', color: '#C8A96A', flexShrink: 0,
                  }}>
                    {(row.display_name || row.username || '?').slice(0, 2).toUpperCase()}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: '.78rem', color: '#F5EAD0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {row.display_name || row.username}
                    </div>
                    <div style={{ fontSize: '.6rem', color: '#5a3820' }}>{row.games_played}G</div>
                  </div>
                </div>
                <span style={{ fontSize: '.75rem', color: '#C8A96A', textAlign: 'right', fontWeight: 500 }}>{row.games_won}</span>
                <span style={{ fontSize: '.72rem', color: '#7a5c3a', textAlign: 'right' }}>{row.win_pct}%</span>
                <span style={{ fontSize: '.72rem', color: row.best_streak >= 5 ? '#D4A017' : '#5a3820', textAlign: 'right' }}>
                  {row.best_streak > 0 ? row.best_streak : '—'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PodiumSlot({ player, pos }) {
  const heights = [1, 3, 2]; // 2nd tallest, 1st tallest, 3rd tallest → order: pos 2, 1, 3
  const h = pos === 1 ? 64 : pos === 2 ? 52 : 40;
  const c = PODIUM_COLORS[pos - 1];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, width: 72 }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%',
        background: '#3d2410', border: `2px solid ${c}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '.65rem', color: c, fontWeight: 500,
      }}>
        {(player.display_name || player.username || '?').slice(0, 2).toUpperCase()}
      </div>
      <div style={{ fontSize: '.65rem', color: c, textAlign: 'center', maxWidth: 68, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {player.display_name || player.username}
      </div>
      <div style={{
        width: '100%', height: h,
        background: `linear-gradient(to top, ${c}33, ${c}11)`,
        border: `1px solid ${c}44`,
        borderBottom: 'none',
        borderRadius: '4px 4px 0 0',
        display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
        paddingTop: 6,
      }}>
        <span style={{ fontSize: '.75rem', color: c, fontWeight: 500 }}>{pos === 1 ? '①' : pos === 2 ? '②' : '③'}</span>
      </div>
    </div>
  );
}

/**
 * crafting.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Crafting recipe engine for Ayurveda Apothecary.
 *
 * Recipe categories:
 *   churna    — dry herbal powder blend
 *   kwatha    — herbal decoction (boiled)
 *   avaleha   — herbal jam/linctus
 *   taila     — herbal oil
 *   ghrita    — medicated ghee
 *   lepa      — topical paste
 *   arka      — herbal distillate
 *   swarasa   — fresh juice extract
 *
 * Crafting mini-game mechanics:
 *   - Each recipe requires specific herbs in specific quantities
 *   - Order of addition matters for some recipes (flagged with orderedMix: true)
 *   - Grinding intensity (1-5) affects potency
 *   - Heating temperature (cold/warm/hot) affects final properties
 *   - Wrong combinations produce a "failed remedy" with partial effect
 */

import { getHerbById } from './herbs.data.js';
import { getDoshaForPatient, DOSHA_PROFILES } from './doshas.js';

/* ── RECIPE DATABASE (60 recipes) ─────────────────────────────────────────── */

export const RECIPES = [

  /* ═══ CHURNA — DRY POWDER BLENDS ═══════════════════════════════════════ */

  {
    id: 'triphala_churna',
    name: 'Triphala Churna',
    category: 'churna',
    rarity: 'common',
    targetDosha: 'all',
    targetCondition: 'Constipation & Detox',
    ingredients: [
      { herbId: 'haritaki',  quantity: 1, unit: 'pinch' },
      { herbId: 'bibhitaki', quantity: 1, unit: 'pinch' },
      { herbId: 'amla',      quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 3,
    heat: 'none',
    dosage: '1 tsp with warm water at bedtime',
    timeToMake: 120,
    potency: 90,
    xpReward: 30,
    description: 'The supreme tridoshic formula. Three fruits ground to fine powder in equal parts. Said to contain all six tastes of Ayurveda.',
    unlockLevel: 1,
    funFact: 'Triphala has been taken by millions of Indians every night for 3000 years. No other herbal formula has been in continuous daily use this long!',
    healingPower: 80,
  },

  {
    id: 'trikatu_churna',
    name: 'Trikatu Churna',
    category: 'churna',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Sluggish Digestion & Congestion',
    ingredients: [
      { herbId: 'ginger',      quantity: 1, unit: 'pinch' },
      { herbId: 'pepper',      quantity: 1, unit: 'pinch' },
      { herbId: 'long_pepper', quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 3,
    heat: 'none',
    dosage: '1/4 tsp with honey before meals',
    timeToMake: 90,
    potency: 85,
    xpReward: 25,
    description: 'Three pungents — ginger, black pepper, and long pepper — in equal measure. The ultimate digestive fire kindler.',
    unlockLevel: 1,
    funFact: '"Trikatu" means "three pungents." Ancient physicians gave this to patients recovering from illness to restart their digestive system — it works like a metabolic spark plug!',
    healingPower: 75,
  },

  {
    id: 'ashwagandha_churna',
    name: 'Ashwagandha Churna',
    category: 'churna',
    rarity: 'uncommon',
    targetDosha: 'vata',
    targetCondition: 'Anxiety, Fatigue & Low Immunity',
    ingredients: [
      { herbId: 'ashwagandha', quantity: 2, unit: 'pinch' },
      { herbId: 'licorice',    quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: '1 tsp with warm milk and a little ghee at bedtime',
    timeToMake: 120,
    potency: 88,
    xpReward: 40,
    description: 'The royal stress formula. Ashwagandha is the primary adaptogen, licorice provides sweetness and mucus membrane protection.',
    unlockLevel: 3,
    funFact: 'Modern clinical trials show Ashwagandha reduces cortisol (stress hormone) by up to 30%. Ancient texts said it makes you "invincible to disease" — they weren\'t far wrong!',
    healingPower: 82,
  },

  {
    id: 'brahmi_churna',
    name: 'Brahmi Churna',
    category: 'churna',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Memory & Mental Clarity',
    ingredients: [
      { herbId: 'brahmi',       quantity: 2, unit: 'pinch' },
      { herbId: 'shankhpushpi', quantity: 1, unit: 'pinch' },
      { herbId: 'licorice',     quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: '1/2 tsp with ghee and honey, morning on empty stomach',
    timeToMake: 150,
    potency: 85,
    xpReward: 45,
    description: 'The scholar\'s formula. Three medhya (brain) herbs combined to enhance memory, focus, and cognitive speed.',
    unlockLevel: 4,
    funFact: 'Ancient Indian students drank Brahmi milk before exams! Modern studies show Bacopa monnieri (Brahmi) significantly improves memory retention after 12 weeks of use.',
    healingPower: 78,
  },

  {
    id: 'sitopaladi_churna',
    name: 'Sitopaladi Churna',
    category: 'churna',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Cough, Cold & Respiratory Issues',
    ingredients: [
      { herbId: 'long_pepper', quantity: 2, unit: 'pinch' },
      { herbId: 'cardamom',    quantity: 1, unit: 'pinch' },
      { herbId: 'cinnamon',    quantity: 1, unit: 'pinch' },
    ],
    orderedMix: true,
    grindLevel: 3,
    heat: 'none',
    dosage: '1/2 tsp with honey 3 times daily',
    timeToMake: 100,
    potency: 80,
    xpReward: 20,
    description: 'The classic respiratory formula. Sweet spices combined to soothe airways and clear congestion gently.',
    unlockLevel: 2,
    funFact: 'Sitopaladi is given to babies for cough in Ayurvedic tradition. The name comes from "sitopala" meaning sugar candy — because it was made sweet for palatability!',
    healingPower: 70,
  },

  {
    id: 'amlaki_churna',
    name: 'Amlaki Rasayana',
    category: 'churna',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Immunity, Skin & Anti-aging',
    ingredients: [
      { herbId: 'amla',    quantity: 3, unit: 'pinch' },
      { herbId: 'ginger',  quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: '1 tsp with warm water every morning',
    timeToMake: 90,
    potency: 88,
    xpReward: 35,
    description: 'Amla (Indian Gooseberry) is the supreme anti-aging herb. This simple formula is the foundation of dozens of complex recipes.',
    unlockLevel: 2,
    funFact: 'One small amla fruit has as much Vitamin C as 20 oranges — AND the Vitamin C doesn\'t break down when cooked, unlike oranges. Heat actually increases its bioavailability!',
    healingPower: 75,
  },

  /* ═══ KWATHA — HERBAL DECOCTIONS ════════════════════════════════════════ */

  {
    id: 'dashamoola_kwatha',
    name: 'Dashamoola Kwatha',
    category: 'kwatha',
    rarity: 'rare',
    targetDosha: 'vata',
    targetCondition: 'Vata Pain — Joint & Muscle',
    ingredients: [
      { herbId: 'gokshura',    quantity: 2, unit: 'gram' },
      { herbId: 'kantakari',   quantity: 2, unit: 'gram' },
      { herbId: 'eranda',      quantity: 1, unit: 'gram' },
      { herbId: 'ginger',      quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 2,
    heat: 'hot',
    dosage: '30ml twice daily on empty stomach',
    timeToMake: 600,
    potency: 92,
    xpReward: 70,
    description: 'Ten roots (dasha = 10, moola = root) decocted together. Considered the supreme Vata formula in all classical Ayurvedic texts.',
    unlockLevel: 6,
    funFact: 'Dashamoola uses roots from 10 specific trees and shrubs. Ancient Ayurvedic physicians memorised all 10 and their properties as a student rite of passage!',
    healingPower: 88,
  },

  {
    id: 'guduchi_kwatha',
    name: 'Guduchi Kwatha',
    category: 'kwatha',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Chronic Fever & Liver Detox',
    ingredients: [
      { herbId: 'guduchi',  quantity: 3, unit: 'gram' },
      { herbId: 'ginger',   quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'hot',
    dosage: '30ml warm, twice daily',
    timeToMake: 300,
    potency: 87,
    xpReward: 50,
    description: 'The immunomodulator decoction. Giloy stem and ginger boiled together in 8 parts water, reduced to 2 parts.',
    unlockLevel: 4,
    funFact: 'During COVID-19, Guduchi Kwatha became so popular in India that Giloy plant stocks depleted across the country! It had a verified role in immune recovery.',
    healingPower: 82,
  },

  {
    id: 'tulsi_kwatha',
    name: 'Tulsi Kwatha',
    category: 'kwatha',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Cold, Cough & Mild Fever',
    ingredients: [
      { herbId: 'tulsi',    quantity: 3, unit: 'gram' },
      { herbId: 'ginger',   quantity: 1, unit: 'gram' },
      { herbId: 'pepper',   quantity: 1, unit: 'pinch' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'hot',
    dosage: 'One cup warm, 3 times daily with honey',
    timeToMake: 180,
    potency: 78,
    xpReward: 20,
    description: 'The household cold remedy. Found in every Indian grandmother\'s recipe book, now validated by modern science.',
    unlockLevel: 1,
    funFact: 'Tulsi Kwatha was India\'s first FDA-approved Ayurvedic medicine for COVID-19 immunity. Grandmothers have been prescribing it for centuries before any approval!',
    healingPower: 68,
  },

  {
    id: 'arjuna_kwatha',
    name: 'Arjuna Kwatha',
    category: 'kwatha',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Heart Strength & Blood Pressure',
    ingredients: [
      { herbId: 'arjuna',   quantity: 3, unit: 'gram' },
      { herbId: 'licorice', quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 2,
    heat: 'hot',
    dosage: '30ml twice daily, morning and evening',
    timeToMake: 420,
    potency: 90,
    xpReward: 60,
    description: 'Arjuna bark (the heart herb) gently simmered to release its cardioprotective compounds. A daily cardiac tonic.',
    unlockLevel: 5,
    funFact: 'Arjuna bark contains compounds similar to digitalis — the heart drug derived from foxglove — but far gentler and without side effects. Charaka prescribed it 2500 years ago for "hridaya roga" (heart disease)!',
    healingPower: 85,
  },

  /* ═══ AVALEHA — HERBAL JAMS ══════════════════════════════════════════════ */

  {
    id: 'chyawanprash',
    name: 'Chyawanprash',
    category: 'avaleha',
    rarity: 'legendary',
    targetDosha: 'all',
    targetCondition: 'Supreme Rejuvenation & Immunity',
    ingredients: [
      { herbId: 'amla',         quantity: 5, unit: 'gram' },
      { herbId: 'ashwagandha',  quantity: 2, unit: 'gram' },
      { herbId: 'brahmi',       quantity: 1, unit: 'gram' },
      { herbId: 'shatavari',    quantity: 2, unit: 'gram' },
      { herbId: 'licorice',     quantity: 1, unit: 'gram' },
      { herbId: 'cinnamon',     quantity: 1, unit: 'pinch' },
      { herbId: 'cardamom',     quantity: 1, unit: 'pinch' },
      { herbId: 'long_pepper',  quantity: 1, unit: 'pinch' },
    ],
    orderedMix: true,
    grindLevel: 3,
    heat: 'warm',
    dosage: '1 tsp every morning with warm milk',
    timeToMake: 1800,
    potency: 97,
    xpReward: 200,
    description: 'The supreme Rasayana of Ayurveda — a jam made with amla as base and 48 herbs mixed with honey and ghee. Created for the sage Chyavana who ate it to regain his youth.',
    unlockLevel: 10,
    funFact: 'Chyawanprash is named after the sage Chyavana Rishi who was rejuvenated by this formula. It is described in texts from 900 BCE — making it one of the oldest known pharmaceutical formulations in history!',
    healingPower: 95,
  },

  {
    id: 'brahma_rasayana',
    name: 'Brahma Rasayana',
    category: 'avaleha',
    rarity: 'rare',
    targetDosha: 'pitta',
    targetCondition: 'Brain Power & Longevity',
    ingredients: [
      { herbId: 'brahmi',       quantity: 3, unit: 'gram' },
      { herbId: 'shankhpushpi', quantity: 2, unit: 'gram' },
      { herbId: 'amla',         quantity: 3, unit: 'gram' },
      { herbId: 'licorice',     quantity: 1, unit: 'gram' },
    ],
    orderedMix: true,
    grindLevel: 4,
    heat: 'warm',
    dosage: '1 tsp with ghee and milk in the morning',
    timeToMake: 900,
    potency: 92,
    xpReward: 120,
    description: 'The mental mastery formula — prescribed for students, teachers, and those needing prolonged mental effort. A complete brain tonic in jam form.',
    unlockLevel: 8,
    funFact: 'Ancient Indian universities (gurukulas) gave Brahma Rasayana to students during their 12-year education period. Graduates were expected to memorise entire Vedic texts — this was their supplement!',
    healingPower: 87,
  },

  /* ═══ TAILA — HERBAL OILS ════════════════════════════════════════════════ */

  {
    id: 'brahmi_taila',
    name: 'Brahmi Taila',
    category: 'taila',
    rarity: 'uncommon',
    targetDosha: 'vata',
    targetCondition: 'Stress, Hair Loss & Headaches',
    ingredients: [
      { herbId: 'brahmi',   quantity: 3, unit: 'gram' },
      { herbId: 'amla',     quantity: 2, unit: 'gram' },
      { herbId: 'bhringraj',quantity: 2, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 2,
    heat: 'warm',
    dosage: 'Apply to scalp and head, massage gently. Leave 30 min or overnight.',
    timeToMake: 720,
    potency: 85,
    xpReward: 55,
    description: 'Brain herbs in sesame oil base, slow-cooked to infuse. Applied to scalp to reduce mental Vata and strengthen hair roots.',
    unlockLevel: 5,
    funFact: 'Brahmi oil head massage (Shiro Abhyanga) was a daily ritual in ancient India — even kings received it every morning. Modern research shows scalp massage increases hair density by 68%!',
    healingPower: 78,
  },

  {
    id: 'ksheerabala_taila',
    name: 'Ksheerabala Taila',
    category: 'taila',
    rarity: 'rare',
    targetDosha: 'vata',
    targetCondition: 'Nerve Disorders & Paralysis',
    ingredients: [
      { herbId: 'bala',     quantity: 3, unit: 'gram' },
      { herbId: 'ashwagandha', quantity: 2, unit: 'gram' },
    ],
    orderedMix: true,
    grindLevel: 2,
    heat: 'warm',
    dosage: 'Massage on affected areas. Full body for nerve disorders.',
    timeToMake: 900,
    potency: 90,
    xpReward: 75,
    description: 'Bala (strength) herb cooked in sesame oil with milk — the "milk-strength oil." Considered the supreme nervine tonic for external use.',
    unlockLevel: 7,
    funFact: 'Ksheerabala Taila is one of the most complex preparations — it requires cooking the herb in equal parts of milk and oil, then slowly evaporating all water. Precision was required 2000 years before thermometers!',
    healingPower: 85,
  },

  {
    id: 'neem_taila',
    name: 'Neem Taila',
    category: 'taila',
    rarity: 'common',
    targetDosha: 'pitta',
    targetCondition: 'Skin Infections & Wounds',
    ingredients: [
      { herbId: 'neem',  quantity: 5, unit: 'gram' },
      { herbId: 'turmeric', quantity: 2, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 2,
    heat: 'hot',
    dosage: 'Apply topically on affected skin 2-3 times daily.',
    timeToMake: 480,
    potency: 82,
    xpReward: 35,
    description: 'The antimicrobial powerhouse oil. Neem\'s broad-spectrum action combined with turmeric\'s wound-healing creates a potent topical formula.',
    unlockLevel: 3,
    funFact: 'Neem oil has been used as natural pesticide in Indian farming for centuries — and is approved by organic farming standards worldwide. It kills 200 types of insects but is safe for humans!',
    healingPower: 76,
  },

  /* ═══ GHRITA — MEDICATED GHEE ═══════════════════════════════════════════ */

  {
    id: 'brahmi_ghrita',
    name: 'Brahmi Ghrita',
    category: 'ghrita',
    rarity: 'rare',
    targetDosha: 'pitta',
    targetCondition: 'Epilepsy, Mental Disorders & Memory',
    ingredients: [
      { herbId: 'brahmi',       quantity: 4, unit: 'gram' },
      { herbId: 'shankhpushpi', quantity: 2, unit: 'gram' },
      { herbId: 'licorice',     quantity: 1, unit: 'gram' },
    ],
    orderedMix: true,
    grindLevel: 3,
    heat: 'warm',
    dosage: '1 tsp on empty stomach, morning and evening',
    timeToMake: 1200,
    potency: 93,
    xpReward: 100,
    description: 'Brain herbs infused into pure ghee (clarified butter). Ghee carries active compounds deep into brain tissue — the supreme medhya (brain) preparation.',
    unlockLevel: 8,
    funFact: 'Ghee is the ideal lipid carrier for brain herbs because fatty acids naturally cross the blood-brain barrier. Ancient Ayurvedic physicians understood neurological drug delivery 2000 years before neuroscience!',
    healingPower: 88,
  },

  {
    id: 'panchagavya_ghrita',
    name: 'Shatavari Ghrita',
    category: 'ghrita',
    rarity: 'uncommon',
    targetDosha: 'vata',
    targetCondition: 'Female Reproductive Health',
    ingredients: [
      { herbId: 'shatavari', quantity: 4, unit: 'gram' },
      { herbId: 'licorice',  quantity: 2, unit: 'gram' },
      { herbId: 'amla',      quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 3,
    heat: 'warm',
    dosage: '1 tsp with warm milk, morning',
    timeToMake: 900,
    potency: 88,
    xpReward: 65,
    description: 'Shatavari in ghee — the supreme female reproductive tonic. Used from adolescence through menopause in Ayurvedic women\'s health.',
    unlockLevel: 6,
    funFact: 'Shatavari Ghrita was prescribed to every woman in ancient India beginning at age 12. It contains phytoestrogens — plant compounds that mimic the body\'s own hormones!',
    healingPower: 83,
  },

  /* ═══ LEPA — TOPICAL PASTES ══════════════════════════════════════════════ */

  {
    id: 'turmeric_lepa',
    name: 'Haldi Lepa',
    category: 'lepa',
    rarity: 'common',
    targetDosha: 'pitta',
    targetCondition: 'Skin Glow & Wound Healing',
    ingredients: [
      { herbId: 'turmeric', quantity: 2, unit: 'gram' },
      { herbId: 'rose',     quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: 'Mix with milk or water. Apply to face/skin for 20 minutes.',
    timeToMake: 60,
    potency: 75,
    xpReward: 15,
    description: 'The most ancient beauty ritual — the traditional bridal Haldi paste. Turmeric illuminates skin while rose soothes and perfumes.',
    unlockLevel: 1,
    funFact: 'The Haldi ceremony (turmeric paste applied before Indian weddings) has been practised for over 4000 years! Brides were "golden" — turmeric genuinely improves skin luminosity.',
    healingPower: 70,
  },

  {
    id: 'chandan_lepa',
    name: 'Chandan-Rose Lepa',
    category: 'lepa',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Fever, Skin Rashes & Inflammation',
    ingredients: [
      { herbId: 'chandan', quantity: 2, unit: 'gram' },
      { herbId: 'rose',    quantity: 2, unit: 'gram' },
      { herbId: 'aloe',    quantity: 2, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: 'Apply to forehead for fever. Apply to rashes or burns.',
    timeToMake: 90,
    potency: 80,
    xpReward: 35,
    description: 'Cooling, fragrant paste for Pitta conditions. Sandalwood absorbs heat, rose soothes, aloe heals.',
    unlockLevel: 4,
    funFact: 'Sandalwood paste on the forehead is used in Hindu worship — the tilaka mark. But it originated as fever treatment! Priests were using the coolest Pitta treatment while conducting rituals.',
    healingPower: 74,
  },

  {
    id: 'neem_haridra_lepa',
    name: 'Neem-Haridra Lepa',
    category: 'lepa',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Acne & Skin Infections',
    ingredients: [
      { herbId: 'neem',     quantity: 3, unit: 'gram' },
      { herbId: 'turmeric', quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 4,
    heat: 'none',
    dosage: 'Apply on acne or infected skin. Leave 15 minutes.',
    timeToMake: 60,
    potency: 78,
    xpReward: 20,
    description: 'Simple, powerful antimicrobial paste. Two of India\'s most potent topical medicines combined.',
    unlockLevel: 2,
    funFact: 'Dermatologists in India still prescribe neem + turmeric paste for acne, fungal infections, and psoriasis — because it works as well as many pharmaceutical creams!',
    healingPower: 72,
  },

  /* ═══ SWARASA — FRESH JUICE EXTRACTS ════════════════════════════════════ */

  {
    id: 'amla_swarasa',
    name: 'Amla Swarasa',
    category: 'swarasa',
    rarity: 'common',
    targetDosha: 'pitta',
    targetCondition: 'Immunity Boost & Vitamin C',
    ingredients: [
      { herbId: 'amla', quantity: 5, unit: 'fresh_fruit' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'none',
    dosage: '30ml every morning on empty stomach',
    timeToMake: 30,
    potency: 80,
    xpReward: 15,
    description: 'Fresh Indian Gooseberry juice — pure, unadulterated Vitamin C and antioxidants.',
    unlockLevel: 1,
    funFact: 'Amla juice consumed daily can delay biological aging by protecting DNA from free radical damage. Multiple clinical studies confirm what Ayurveda said for millennia!',
    healingPower: 75,
  },

  {
    id: 'tulsi_ginger_swarasa',
    name: 'Tulsi-Adrak Swarasa',
    category: 'swarasa',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Cold, Fever & Respiratory Infections',
    ingredients: [
      { herbId: 'tulsi',  quantity: 5, unit: 'leaf' },
      { herbId: 'ginger', quantity: 1, unit: 'inch' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'none',
    dosage: 'Fresh juice, 30ml with honey, 3 times daily',
    timeToMake: 20,
    potency: 76,
    xpReward: 10,
    description: 'The instant home remedy — fresh tulsi and ginger juice with honey. 15 minutes from garden to medicine.',
    unlockLevel: 1,
    funFact: 'This is the most commonly prescribed home remedy by AYUSH (India\'s government Ayurvedic ministry). During the 2009 swine flu epidemic, schools across India gave this juice to children daily!',
    healingPower: 65,
  },

  {
    id: 'karela_swarasa',
    name: 'Karela Swarasa',
    category: 'swarasa',
    rarity: 'common',
    targetDosha: 'kapha',
    targetCondition: 'Blood Sugar & Diabetes',
    ingredients: [
      { herbId: 'karela', quantity: 2, unit: 'medium_fruit' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'none',
    dosage: '30ml every morning, 30 minutes before breakfast',
    timeToMake: 15,
    potency: 82,
    xpReward: 18,
    description: 'Bitter melon juice — naturally bitter, powerfully medicinal. The Ayurvedic diabetes management staple.',
    unlockLevel: 2,
    funFact: 'Bitter melon contains polypeptide-p — a plant insulin! WHO recognises it as a valid complementary therapy for Type 2 diabetes. Bitter taste is the signal that medicine is working!',
    healingPower: 77,
  },

  /* ═══ ARKA — DISTILLATES ═════════════════════════════════════════════════ */

  {
    id: 'rose_arka',
    name: 'Gulab Arka (Rose Water)',
    category: 'arka',
    rarity: 'uncommon',
    targetDosha: 'pitta',
    targetCondition: 'Eye Health, Mood & Skin',
    ingredients: [
      { herbId: 'rose', quantity: 10, unit: 'fresh_flower' },
    ],
    orderedMix: false,
    grindLevel: 1,
    heat: 'hot',
    dosage: 'Apply to eyes with cotton. Spritz on face. Drink 2 tsp diluted in water.',
    timeToMake: 480,
    potency: 78,
    xpReward: 40,
    description: 'Steam distillation of rose petals — capturing the aromatic healing essence in pure water. Multi-use: eye, face, and emotional healing.',
    unlockLevel: 5,
    funFact: 'Rose water was invented by the Persian scholar Ibn Sina who learned distillation techniques from Indian Ayurvedic texts. Persian rose water is now world-famous — but the technique was Indian!',
    healingPower: 71,
  },

  {
    id: 'ajwain_arka',
    name: 'Ajwain Arka',
    category: 'arka',
    rarity: 'uncommon',
    targetDosha: 'kapha',
    targetCondition: 'Severe Indigestion & Colic',
    ingredients: [
      { herbId: 'ginger',   quantity: 2, unit: 'gram' },
      { herbId: 'cardamom', quantity: 1, unit: 'gram' },
    ],
    orderedMix: false,
    grindLevel: 2,
    heat: 'hot',
    dosage: '20ml with equal warm water, after meals',
    timeToMake: 360,
    potency: 82,
    xpReward: 45,
    description: 'Distillate of digestive spices — concentrated aromatic water carrying volatile healing compounds.',
    unlockLevel: 6,
    funFact: 'Arka distillation was an advanced pharmaceutical technique of ancient India. Ayurvedic texts from 700 CE describe distillation equipment identical to what modern chemists use!',
    healingPower: 76,
  },
];

/* ── RECIPE LOOKUP FUNCTIONS ─────────────────────────────────────────────── */

export const getRecipeById       = (id)       => RECIPES.find(r => r.id === id) ?? null;
export const getRecipesByCategory= (cat)      => RECIPES.filter(r => r.category === cat);
export const getRecipesByDosha   = (dosha)    => RECIPES.filter(r => r.targetDosha === dosha || r.targetDosha === 'all');
export const getRecipesByLevel   = (level)    => RECIPES.filter(r => r.unlockLevel <= level);
export const getRecipesByRarity  = (rarity)   => RECIPES.filter(r => r.rarity === rarity);

/* ── CRAFTING ENGINE ─────────────────────────────────────────────────────── */

/**
 * Attempt to craft a recipe from the player's herb inventory.
 *
 * @param {string} recipeId - target recipe
 * @param {Object} inventory - { herbId: quantity } player inventory
 * @param {number} grindSkill - player's grinding skill level (1-5)
 * @returns {Object} crafting result
 */
export function attemptCraft(recipeId, inventory, grindSkill = 3) {
  const recipe = getRecipeById(recipeId);
  if (!recipe) return { success: false, reason: 'Recipe not found' };

  // Check ingredient availability
  const missing = [];
  for (const ing of recipe.ingredients) {
    const have = inventory[ing.herbId] ?? 0;
    if (have < ing.quantity) {
      missing.push({ herbId: ing.herbId, need: ing.quantity, have });
    }
  }
  if (missing.length > 0) {
    return {
      success: false,
      reason: `Missing ingredients`,
      missing,
      canPartial: missing.length < recipe.ingredients.length / 2,
    };
  }

  // Calculate potency based on player skill vs required grind level
  const grindDiff = grindSkill - recipe.grindLevel;
  const potencyMod = grindDiff >= 0 ? 1 + grindDiff * 0.05 : 1 + grindDiff * 0.10;
  const finalPotency = Math.min(100, Math.round(recipe.potency * potencyMod));

  // Determine outcome tier
  let tier;
  if      (finalPotency >= 95) tier = 'masterwork';
  else if (finalPotency >= 85) tier = 'excellent';
  else if (finalPotency >= 70) tier = 'good';
  else if (finalPotency >= 55) tier = 'average';
  else                         tier = 'weak';

  // Ingredients consumed
  const consumed = recipe.ingredients.reduce((acc, ing) => {
    acc[ing.herbId] = (acc[ing.herbId] ?? 0) + ing.quantity;
    return acc;
  }, {});

  return {
    success:       true,
    recipeId,
    recipeName:    recipe.name,
    category:      recipe.category,
    potency:       finalPotency,
    tier,
    healingPower:  Math.round(recipe.healingPower * potencyMod),
    xpEarned:      Math.round(recipe.xpReward * (tier === 'masterwork' ? 1.5 : tier === 'excellent' ? 1.2 : 1)),
    consumed,
    timeToMake:    recipe.timeToMake,
    description:   recipe.description,
    dosage:        recipe.dosage,
  };
}

/**
 * Suggest the best recipe to craft for a patient's symptoms.
 *
 * @param {string[]} symptoms — patient's symptom list
 * @param {Object}   inventory — player's herb inventory
 * @param {number}   playerLevel — to filter by unlock level
 * @returns {Array} sorted list of { recipe, completeness, missingHerbs }
 */
export function suggestRecipesForSymptoms(symptoms, inventory, playerLevel = 1) {
  const { dosha } = getDoshaForPatient(symptoms);
  const eligible  = getRecipesByLevel(playerLevel);

  return eligible
    .map(recipe => {
      const totalIngredients = recipe.ingredients.length;
      const available = recipe.ingredients.filter(i => (inventory[i.herbId] ?? 0) >= i.quantity);
      const missing   = recipe.ingredients.filter(i => (inventory[i.herbId] ?? 0) < i.quantity);
      const completeness = Math.round((available.length / totalIngredients) * 100);
      const doshaMatch = recipe.targetDosha === dosha || recipe.targetDosha === 'all';

      return {
        recipe,
        completeness,
        missingHerbs: missing.map(i => getHerbById(i.herbId)?.name ?? i.herbId),
        doshaMatch,
        score: completeness + (doshaMatch ? 30 : 0) + (recipe.potency * 0.3),
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5); // top 5 suggestions
}

/**
 * Check if player has discovered a recipe from herb combinations
 * (free discovery — combining herbs without a known recipe).
 *
 * @param {string[]} herbIds — herbs being combined
 * @returns {Object|null} discovered recipe or null
 */
export function discoverRecipe(herbIds) {
  const sorted = [...herbIds].sort();
  for (const recipe of RECIPES) {
    const recipeHerbs = recipe.ingredients.map(i => i.herbId).sort();
    // Check if herb set is a subset of recipe ingredients
    const isSubset = sorted.every(h => recipeHerbs.includes(h));
    const sizeMatch = sorted.length >= Math.ceil(recipeHerbs.length * 0.75);
    if (isSubset && sizeMatch) return recipe;
  }
  return null;
}

export default {
  RECIPES,
  getRecipeById,
  getRecipesByCategory,
  getRecipesByDosha,
  getRecipesByLevel,
  attemptCraft,
  suggestRecipesForSymptoms,
  discoverRecipe,
};

// ═══════════════════════════════════════════════════
//  ENGINE · Core game rule functions
//
//  All functions are pure with respect to board rules.
//  They READ G.pawns but delegate STATE MUTATION to
//  main.js / the step-animation pipeline.
// ═══════════════════════════════════════════════════

import { TEAMS, GRACE_VALS } from './config.js';
import { PATHS, isCastle, isSafe } from './paths.js';
import { G } from './state.js';

// ── Which pawns can legally move with this throw? ──
export function getMovable(player, val, grace) {
  const result = [];
  for (let i = 0; i < 4; i++) {
    const pawn = G.pawns[player][i];
    if (pawn.pos === 80) continue;               // already home

    if (pawn.pos === -1) {
      if (grace) result.push(i);                 // needs Grace to enter
      continue;
    }
    const tp = pawn.pos + val;
    if (tp > 80) continue;                       // overshoot

    if (tp < 80) {
      const sq = PATHS[player][tp];
      // Cannot land on a castle already held by opponent
      if (isCastle(sq.x, sq.y) && hasOpponent(player, sq)) continue;
    }
    result.push(i);
  }
  return result;
}

// ── Target path position for a pawn move ──
export function getTargetPos(player, pawnIdx, val) {
  const pos = G.pawns[player][pawnIdx].pos;
  return pos === -1 ? 0 : pos + val;
}

// ── Check whether any opponent pawn occupies {x,y} ──
export function hasOpponent(myPlayer, sq) {
  for (let p = 0; p < 4; p++) {
    if (p === myPlayer || TEAMS[p] === TEAMS[myPlayer]) continue;
    for (let i = 0; i < 4; i++) {
      const pw = G.pawns[p][i];
      if (pw.pos < 0 || pw.pos >= 80) continue;
      const psq = PATHS[p][pw.pos];
      if (psq.x === sq.x && psq.y === sq.y) return true;
    }
  }
  return false;
}

// ── Resolve captures after a pawn lands on `sq` ──
// Returns array of { player, pawnIdx } that were captured.
export function resolveCapturesAt(landingPlayer, sq) {
  if (isSafe(landingPlayer, G.pawns[landingPlayer]
      ? G.pawns[landingPlayer].findIndex(pw => {
          if (pw.pos < 0 || pw.pos >= 80) return false;
          const s = PATHS[landingPlayer][pw.pos];
          return s.x === sq.x && s.y === sq.y;
        })
      : -1)) return [];

  const captured = [];
  for (let p = 0; p < 4; p++) {
    if (p === landingPlayer || TEAMS[p] === TEAMS[landingPlayer]) continue;
    for (let i = 0; i < 4; i++) {
      const pw = G.pawns[p][i];
      if (pw.pos < 0 || pw.pos >= 80) continue;
      const osq = PATHS[p][pw.pos];
      if (osq.x === sq.x && osq.y === sq.y && !isSafe(p, pw.pos)) {
        captured.push({ player: p, pawnIdx: i });
      }
    }
  }
  return captured;
}

// ── Improved capture resolution (takes explicit landingIdx) ──
export function resolveCapturesFull(landingPlayer, landingIdx) {
  if (landingIdx < 0 || landingIdx >= 80) return [];
  if (isSafe(landingPlayer, landingIdx)) return [];

  const sq  = PATHS[landingPlayer][landingIdx];
  const out = [];
  for (let p = 0; p < 4; p++) {
    if (p === landingPlayer || TEAMS[p] === TEAMS[landingPlayer]) continue;
    for (let i = 0; i < 4; i++) {
      const pw = G.pawns[p][i];
      if (pw.pos < 0 || pw.pos >= 80) continue;
      if (!isSafe(p, pw.pos)) {
        const osq = PATHS[p][pw.pos];
        if (osq.x === sq.x && osq.y === sq.y)
          out.push({ player: p, pawnIdx: i });
      }
    }
  }
  return out;
}

// ── Check if a team has won ──
// Returns winning team (0|1) or null
export function checkWin() {
  for (let team = 0; team < 2; team++) {
    const players = [0, 1, 2, 3].filter(p => TEAMS[p] === team);
    if (players.every(p => G.pawns[p].every(pw => pw.pos === 80)))
      return team;
  }
  return null;
}

/**
 * useSounds — manages Pagade's 6-sound audio palette using Web Audio API.
 * Generates sounds procedurally (no asset files required).
 * All sounds muted by default; single toggle in UI.
 */

import { useRef, useCallback, useState } from 'react';

export function useSounds() {
  const ctxRef = useRef(null);
  const [muted, setMuted] = useState(true); // muted by default per design doc

  const getCtx = () => {
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    if (ctxRef.current.state === 'suspended') ctxRef.current.resume();
    return ctxRef.current;
  };

  const play = useCallback((type) => {
    if (muted) return;
    try {
      const ctx = getCtx();
      switch (type) {
        case 'roll':   playCowrieClatter(ctx);    break;
        case 'move':   playTableTap(ctx);          break;
        case 'safe':   playBell(ctx);              break;
        case 'capture':playDholBeat(ctx);          break;
        case 'home':   playNadaswaram(ctx);        break;
        case 'win':    playWinFanfare(ctx);        break;
      }
    } catch (e) { /* audio blocked */ }
  }, [muted]);

  const toggleMute = () => setMuted(m => !m);

  return { play, muted, toggleMute };
}

// ─── Sound generators ─────────────────────────────────────────────────────────

function playCowrieClatter(ctx) {
  // Short burst of filtered noise — shell clatter
  for (let i = 0; i < 4; i++) {
    setTimeout(() => {
      const buf = ctx.createBuffer(1, ctx.sampleRate * 0.05, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let j = 0; j < data.length; j++) data[j] = (Math.random() * 2 - 1) * 0.3;
      const src = ctx.createBufferSource();
      const filt = ctx.createBiquadFilter();
      filt.type = 'bandpass';
      filt.frequency.value = 800 + Math.random() * 400;
      filt.Q.value = 3;
      src.buffer = buf;
      src.connect(filt);
      filt.connect(ctx.destination);
      src.start();
    }, i * 40);
  }
}

function playTableTap(ctx) {
  // Soft tabla hit — sine + quick decay
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.frequency.setValueAtTime(180, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.08);
  gain.gain.setValueAtTime(0.4, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(); osc.stop(ctx.currentTime + 0.12);
}

function playBell(ctx) {
  // Temple bell — pure tone with long decay
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.frequency.value = 880;
  osc.type = 'sine';
  gain.gain.setValueAtTime(0.3, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(); osc.stop(ctx.currentTime + 0.8);
  // Harmonic
  const osc2 = ctx.createOscillator();
  const g2 = ctx.createGain();
  osc2.frequency.value = 1320;
  g2.gain.setValueAtTime(0.1, ctx.currentTime);
  g2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
  osc2.connect(g2); g2.connect(ctx.destination);
  osc2.start(); osc2.stop(ctx.currentTime + 0.5);
}

function playDholBeat(ctx) {
  // Capture hit — deep thud + sharp crack
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.frequency.setValueAtTime(100, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.1);
  gain.gain.setValueAtTime(0.6, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(); osc.stop(ctx.currentTime + 0.18);
}

function playNadaswaram(ctx) {
  // Home — ascending 3-note fanfare
  const notes = [523.25, 659.25, 783.99]; // C5 E5 G5
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const t = ctx.currentTime + i * 0.15;
    osc.frequency.value = freq;
    osc.type = 'sawtooth';
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.2, t + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(t); osc.stop(t + 0.3);
  });
}

function playWinFanfare(ctx) {
  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const t = ctx.currentTime + i * 0.12;
    osc.frequency.value = freq;
    osc.type = 'sawtooth';
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.25, t + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(t); osc.stop(t + 0.5);
  });
}

/**
 * compendiumSlice.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Herb compendium state — which herbs are unlocked, filtered, and searched.
 */
import { createSlice } from '@reduxjs/toolkit';
import { HERBS }        from '../game-engine/herbs.data.js';

const compendiumSlice = createSlice({
  name: 'compendium',
  initialState: {
    filter:   { rarity: 'all', dosha: 'all', season: 'all', search: '' },
    selected: null,   // herbId currently being viewed
    sortBy:   'name', // name | rarity | season | xpValue
  },
  reducers: {
    setFilter:    (s, { payload }) => { s.filter = { ...s.filter, ...payload }; },
    clearFilters: (s)              => { s.filter = { rarity:'all', dosha:'all', season:'all', search:'' }; },
    selectHerb:   (s, { payload }) => { s.selected = payload; },
    clearSelected:(s)              => { s.selected = null; },
    setSortBy:    (s, { payload }) => { s.sortBy = payload; },
  },
});

export const { setFilter, clearFilters, selectHerb, clearSelected, setSortBy } = compendiumSlice.actions;

// Derived selector — returns filtered + sorted herbs, marking unlocked status
export const selectFilteredHerbs = (unlockedIds) => (state) => {
  const { filter, sortBy } = state.compendium;

  return HERBS
    .filter(h => {
      if (filter.rarity !== 'all' && h.rarity  !== filter.rarity)  return false;
      if (filter.season !== 'all' && h.season  !== filter.season)  return false;
      if (filter.dosha  !== 'all' && h.dosha[filter.dosha] !== -1) return false;
      if (filter.search) {
        const q = filter.search.toLowerCase();
        return h.name.toLowerCase().includes(q)      ||
               h.sanskrit.toLowerCase().includes(q)  ||
               h.hindi.toLowerCase().includes(q)     ||
               h.uses.some(u => u.toLowerCase().includes(q));
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'rarity') {
        const order = { common:1, uncommon:2, rare:3, legendary:4 };
        return (order[b.rarity] ?? 0) - (order[a.rarity] ?? 0);
      }
      if (sortBy === 'xpValue') return b.xpValue - a.xpValue;
      if (sortBy === 'season')  return a.season.localeCompare(b.season);
      return a.name.localeCompare(b.name);
    })
    .map(h => ({ ...h, unlocked: unlockedIds.includes(h.id) }));
};

export default compendiumSlice.reducer;


/**
 * questSlice.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Active quest / patient encounter state.
 */

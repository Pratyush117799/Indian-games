/**
 * index.js — Ramayana Quest Game Engine
 * Single entry point. Re-exports everything.
 */
export * from './story.data.js';
export * from './characters.js';
export * from './consequences.js';
export * from './geography.js';
export * from './valmiki.js';

// Shared Sanskriti Score constants
export const SANSKRITI_REWARDS = {
  quizCorrect:      8,
  quizWrong:        2,
  moralChoice:      10,
  kandaComplete:    25,
  miniGamePerfect:  15,
  miniGameGood:     8,
  consecutiveDays:  5,
};

// XP level thresholds (shared with Ayurveda Apothecary via localStorage)
export const XP_LEVELS = [0, 100, 250, 450, 700, 1000, 1400, 1900, 2500];
export const LEVEL_RANKS = [
  'Shishya',       // 0
  'Seekha',        // 1
  'Adhyetru',      // 2
  'Pravakta',      // 3
  'Acharya',       // 4
  'Mahacharya',    // 5
  'Kavi',          // 6
  'Mahakavi',      // 7
  'Valmiki Tulya', // 8  — highest
];

export function getLevelFromXP(xp) {
  let level = 0;
  for (let i = 0; i < XP_LEVELS.length; i++) {
    if (xp >= XP_LEVELS[i]) level = i;
  }
  return { level, rank: LEVEL_RANKS[level] ?? LEVEL_RANKS[LEVEL_RANKS.length - 1] };
}

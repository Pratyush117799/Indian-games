import { Router } from 'express';
export const playerRouter = Router();
playerRouter.get('/:id', (req,res) => res.json({id:req.params.id}));
playerRouter.post('/', (req,res) => {
  const {tag,character='rama'} = req.body;
  if (!tag) return res.status(400).json({error:'Tag required'});
  res.json({id:`rq_${Date.now()}`,tag,character,virtues:{dharma:0,courage:0,devotion:0,wisdom:0},sankr:0});
});
playerRouter.patch('/:id/virtues', (req,res) => res.json({id:req.params.id,virtues:req.body.virtues}));

/**
 * Board.jsx — full SVG 19×19 Pagade board.
 *
 * Features in this version:
 *  • Theme-aware cell colours via boardThemes
 *  • Step-by-step pawn animation via useAnimatedMove
 *  • Blockade detection — crown badge + opponent can't-land highlight
 *  • Arm ownership tint for active player
 *  • Compact player-colour labels at arm tips
 *  • Home pawn cluster rendering
 */

import React, { useMemo, useCallback } from 'react';
import BoardCell from './BoardCell';
import Pawn from './Pawn';
import {
  GRID_SIZE, CELL_SIZE, MAIN_PATH, SAFE_LANES,
  HOME_CELL, isValidCell, PLAYER_COLORS, STATUS,
  PLAYER_ENTRY, PATH_LENGTH,
} from '../../game/constants';
import { getPawnCell } from '../../game/engine';
import { getTheme } from '../../game/boardThemes';

const BOARD_PX = GRID_SIZE * CELL_SIZE;

// Pre-build valid cell set
const VALID_CELLS = new Set();
for (let r = 0; r < GRID_SIZE; r++)
  for (let c = 0; c < GRID_SIZE; c++)
    if (isValidCell(r, c)) VALID_CELLS.add(`${r},${c}`);

// Arm highlight rects per player [x, y, w, h]
const ARM_RECTS = [
  [8*CELL_SIZE, 11*CELL_SIZE, 3*CELL_SIZE, 8*CELL_SIZE], // Red   — bottom
  [11*CELL_SIZE,  8*CELL_SIZE, 8*CELL_SIZE, 3*CELL_SIZE], // Green — right
  [8*CELL_SIZE,  0,            3*CELL_SIZE, 8*CELL_SIZE], // Yellow— top
  [0,            8*CELL_SIZE,  8*CELL_SIZE, 3*CELL_SIZE], // Blue  — left
];

// Arm tip label positions [x, y, anchor]
const ARM_LABELS = [
  { x: 9.5*CELL_SIZE, y: BOARD_PX - 6,        anchor: 'middle' }, // Red
  { x: BOARD_PX - 6,  y: 9.5*CELL_SIZE + 4,   anchor: 'end'    }, // Green
  { x: 9.5*CELL_SIZE, y: 10,                   anchor: 'middle' }, // Yellow
  { x: 6,             y: 9.5*CELL_SIZE + 4,    anchor: 'start'  }, // Blue
];

export default function Board({
  gameState, onPawnClick, selectedPawn, animatingPawn,
  animPositions = {},      // from useAnimatedMove: "pid-pawnId" → { r, c }
  themeId = 'temple_stone',
}) {
  const { players = [], validMoves = [], currentPlayer = 0 } = gameState || {};
  const theme = getTheme(themeId);

  // ── Valid move landing cells ─────────────────────────────────────────────
  const validCells = useMemo(() => {
    const s = new Set();
    for (const m of validMoves)
      if (m.landingCell) s.add(`${m.landingCell.r},${m.landingCell.c}`);
    return s;
  }, [validMoves]);

  // ── Movable pawn IDs ─────────────────────────────────────────────────────
  const movablePawnIds = useMemo(
    () => new Set(validMoves.map(m => m.pawnId)),
    [validMoves]
  );

  // ── Cell → pawn list ─────────────────────────────────────────────────────
  const cellPawns = useMemo(() => {
    const map = {};
    for (const player of players) {
      for (const pawn of player.pawns) {
        if (pawn.status === STATUS.HOME) continue;
        const key = `${pawn.playerId}-${pawn.id}`;
        // Use animated override position if present
        const cell = animPositions[key] || getPawnCell(pawn);
        if (!cell) continue;
        const ck = `${cell.r},${cell.c}`;
        if (!map[ck]) map[ck] = [];
        map[ck].push({ pawn, player, cell });
      }
    }
    return map;
  }, [players, animPositions]);

  // ── Blockade detection ───────────────────────────────────────────────────
  // A cell is blockaded if 2+ pawns of the SAME player are on it (ACTIVE)
  const blockadeCells = useMemo(() => {
    const bmap = {}; // "r,c" → playerId
    for (const player of players) {
      const counts = {};
      for (const pawn of player.pawns) {
        if (pawn.status !== STATUS.ACTIVE) continue;
        const cell = getPawnCell(pawn);
        if (!cell) continue;
        const ck = `${cell.r},${cell.c}`;
        counts[ck] = (counts[ck] || 0) + 1;
      }
      for (const [ck, cnt] of Object.entries(counts)) {
        if (cnt >= 2) bmap[ck] = player.id;
      }
    }
    return bmap;
  }, [players]);

  const handlePawnClick = useCallback((pawn) => {
    const moves = validMoves.filter(m => m.pawnId === pawn.id);
    if (moves.length) onPawnClick?.(pawn, moves);
  }, [validMoves, onPawnClick]);

  return (
    <div className="board-wrapper">
      <svg
        viewBox={`0 0 ${BOARD_PX} ${BOARD_PX}`}
        width="100%" height="100%"
        style={{ maxWidth: BOARD_PX, maxHeight: BOARD_PX, display: 'block', margin: '0 auto' }}
      >
        <defs>
          <style>{`
            @keyframes cellPulse { 0%,100%{opacity:.35} 50%{opacity:.95} }
            @keyframes pawnGlow  { 0%,100%{r:15px;opacity:.28} 50%{r:19px;opacity:.75} }
            @keyframes homeSpin  { to{transform:rotate(360deg)} }
          `}</style>
        </defs>

        {/* Board background */}
        <rect
          width={BOARD_PX} height={BOARD_PX}
          fill={theme.vars?.['--board-bg'] || '#1a0e06'}
        />
        {/* Outer border */}
        <rect
          x={1} y={1} width={BOARD_PX - 2} height={BOARD_PX - 2}
          fill="none" stroke={theme.vars?.['--border-main'] || '#8B6914'}
          strokeWidth={2} rx={4}
        />

        {/* ── All board cells ── */}
        {Array.from(VALID_CELLS).map(key => {
          const [r, c] = key.split(',').map(Number);
          const isValid     = validCells.has(key);
          const isBlockaded = blockadeCells[key] !== undefined;
          const highlight   = isValid ? 'valid' : undefined;
          return (
            <BoardCell
              key={key} r={r} c={c}
              highlight={highlight}
              themeId={themeId}
            />
          );
        })}

        {/* Blockade cells — can't-land overlay for opponent */}
        {Object.entries(blockadeCells).map(([ck, pid]) => {
          if (pid === currentPlayer) return null; // own blockade — friendly
          const [r, c] = ck.split(',').map(Number);
          return (
            <rect
              key={`bl-${ck}`}
              x={c * CELL_SIZE + 1} y={r * CELL_SIZE + 1}
              width={CELL_SIZE - 2} height={CELL_SIZE - 2}
              fill={PLAYER_COLORS[pid]}
              fillOpacity={0.12}
              rx={2}
              pointerEvents="none"
            />
          );
        })}

        {/* Active player arm tint */}
        {(() => {
          const [ax, ay, aw, ah] = ARM_RECTS[currentPlayer];
          return (
            <rect
              x={ax} y={ay} width={aw} height={ah}
              fill={PLAYER_COLORS[currentPlayer]}
              fillOpacity={0.055}
              rx={2}
              pointerEvents="none"
            />
          );
        })()}

        {/* Player colour labels at arm tips */}
        {players.map((player, pid) => {
          const lbl = ARM_LABELS[pid];
          if (!lbl) return null;
          return (
            <text
              key={`lbl-${pid}`}
              x={lbl.x} y={lbl.y}
              fontSize={8} fontWeight="500"
              textAnchor={lbl.anchor}
              fill={PLAYER_COLORS[pid]}
              opacity={0.7}
              style={{ userSelect: 'none', pointerEvents: 'none' }}
            >
              {player.name}
            </text>
          );
        })}

        {/* ── Pawns ── */}
        {players.map(player =>
          player.pawns.map(pawn => {
            if (pawn.status === STATUS.HOME) return null;
            const animKey = `${pawn.playerId}-${pawn.id}`;
            const cell = animPositions[animKey] || getPawnCell(pawn);
            if (!cell) return null;
            const ck = `${cell.r},${cell.c}`;
            const stack = cellPawns[ck] || [];
            const si = stack.findIndex(e => e.pawn === pawn);
            const stacked = stack.length > 1;

            const isMovable = movablePawnIds.has(pawn.id) && player.id === currentPlayer;
            const isAnim    = animatingPawn === animKey;
            const isSel     = selectedPawn?.id === pawn.id && selectedPawn?.playerId === pawn.playerId;

            // Blockade leader — first pawn of a same-cell pair
            const isBlockadeLeader = (
              stacked &&
              si === 0 &&
              stack.length >= 2 &&
              stack.every(e => e.pawn.playerId === player.id)
            );

            return (
              <Pawn
                key={animKey}
                pawn={pawn}
                cell={cell}
                isMovable={isMovable}
                isAnimating={isAnim}
                isSelected={isSel}
                isBlockadeLeader={isBlockadeLeader}
                stacked={stacked}
                stackOffset={si}
                themeId={themeId}
                onClick={() => handlePawnClick(pawn)}
              />
            );
          })
        )}

        {/* ── Home pawns cluster ── */}
        <HomePawns players={players} />

        {/* Current player indicator — small dot at board center */}
        <circle
          cx={9.5 * CELL_SIZE} cy={9.5 * CELL_SIZE}
          r={5}
          fill={PLAYER_COLORS[currentPlayer]}
          opacity={0.85}
          style={{ animation: 'pawnGlow 2s ease-in-out infinite' }}
        />
      </svg>
    </div>
  );
}

// ── Home cluster ──────────────────────────────────────────────────────────────

const HOME_OFFSETS = [
  [-7, -7], [7, -7], [-7, 7], [7, 7],
  [-3, 0], [3, 0], [0, -3], [0, 3],
];

function HomePawns({ players }) {
  const homePawns = [];
  for (const player of players)
    for (const pawn of player.pawns)
      if (pawn.status === STATUS.HOME) homePawns.push({ pawn, player });

  return homePawns.map(({ pawn, player }, i) => {
    const [dx, dy] = HOME_OFFSETS[i % HOME_OFFSETS.length] || [0, 0];
    const cx = HOME_CELL.c * CELL_SIZE + CELL_SIZE / 2 + dx;
    const cy = HOME_CELL.r * CELL_SIZE + CELL_SIZE / 2 + dy;
    return (
      <circle
        key={`home-${player.id}-${pawn.id}`}
        cx={cx} cy={cy} r={5.5}
        fill={PLAYER_COLORS[player.id]}
        stroke="rgba(255,220,100,0.8)"
        strokeWidth={1.2}
      />
    );
  });
}

const express = require('express');
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

// GET /players/leaderboard
router.get('/leaderboard', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT id, username, display_name, games_played, games_won, best_streak,
              total_captures, rank,
              CASE WHEN games_played > 0
                THEN ROUND(100.0 * games_won / games_played, 1) ELSE 0
              END AS win_pct
       FROM leaderboard LIMIT 100`
    );
    res.json({ players: rows });
  } catch (err) { next(err); }
});

// POST /players — create/register player
router.post('/', async (req, res, next) => {
  try {
    const { username, displayName } = req.body;
    if (!username || username.length < 2 || username.length > 32) {
      return res.status(400).json({ error: { message: 'Username must be 2–32 chars' } });
    }
    const id = uuidv4();
    const { rows } = await query(
      `INSERT INTO players (id, username, display_name)
       VALUES ($1, $2, $3)
       ON CONFLICT (username) DO UPDATE SET last_seen=NOW()
       RETURNING id, username, display_name, games_played, games_won, active_skin, active_board, dice_style`,
      [id, username.trim(), displayName || username.trim()]
    );
    res.status(201).json({ player: rows[0] });
  } catch (err) { next(err); }
});

// GET /players/:id
router.get('/:id', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT id, username, display_name, games_played, games_won,
              total_captures, win_streak, best_streak,
              unlocked_skins, unlocked_boards, active_skin, active_board, dice_style
       FROM players WHERE id=$1`,
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: { message: 'Player not found' } });
    res.json({ player: rows[0] });
  } catch (err) { next(err); }
});

// PATCH /players/:id/preferences
router.patch('/:id/preferences', async (req, res, next) => {
  try {
    const { activeSkin, activeBoard, diceStyle, soundEnabled } = req.body;
    await query(
      `UPDATE players SET
         active_skin  = COALESCE($2, active_skin),
         active_board = COALESCE($3, active_board),
         dice_style   = COALESCE($4, dice_style),
         sound_enabled = COALESCE($5, sound_enabled)
       WHERE id = $1`,
      [req.params.id, activeSkin, activeBoard, diceStyle, soundEnabled]
    );
    res.json({ updated: true });
  } catch (err) { next(err); }
});

module.exports = router;

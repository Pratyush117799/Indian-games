/**
 * chanakya.js
 * Rule-based AI advisor — Acharya Chanakya
 *
 * Reads the full game state and produces contextually relevant advice
 * drawn from the Arthashastra's actual concepts: Saptanga, Mandala theory,
 * Shadgunya (6 foreign policies), Kosha, Dharma, and more.
 *
 * No external API. Entirely deterministic + weighted.
 * ~250 situation-specific responses across 12 strategic dimensions.
 */

/* ═══════════════════════════════════════════════════════
   SITUATION EVALUATOR
   Returns a ranked list of { category, urgency, key } describing
   the current game state from most to least pressing.
═══════════════════════════════════════════════════════ */
export function evaluateSituation(state, territories, factions) {
  const signals = [];
  const r = state.resources;
  const s = state.stats;
  const playerTerrs = territories.filter(t => t.owner === 'player');
  const hostileTerrs = territories.filter(t => factions[t.owner]?.relation === 'hostile');
  const neutralTerrs = territories.filter(t => t.owner === 'neutral');
  const totalTerrs = territories.length;
  const playerPct = playerTerrs.length / totalTerrs;

  // ── Resource crises ────────────────────────────────────
  if (r.gold < 100)      signals.push({ cat: 'gold_crisis',     urgency: 10 });
  if (r.gold < 200)      signals.push({ cat: 'gold_low',        urgency: 7  });
  if (r.gold > 600)      signals.push({ cat: 'gold_surplus',    urgency: 3  });
  if (r.army < 80)       signals.push({ cat: 'army_weak',       urgency: 9  });
  if (r.army > 300)      signals.push({ cat: 'army_strong',     urgency: 2  });
  if (r.food < 120)      signals.push({ cat: 'food_crisis',     urgency: 8  });
  if (r.food > 400)      signals.push({ cat: 'food_surplus',    urgency: 2  });
  if (r.dharma < 30)     signals.push({ cat: 'dharma_crisis',   urgency: 9  });
  if (r.dharma > 80)     signals.push({ cat: 'dharma_high',     urgency: 2  });
  if (r.happiness < 40)  signals.push({ cat: 'happiness_low',   urgency: 8  });

  // ── Territorial position ───────────────────────────────
  if (playerPct < 0.2)   signals.push({ cat: 'early_game',      urgency: 5  });
  if (playerPct >= 0.5)  signals.push({ cat: 'mid_game',        urgency: 4  });
  if (playerPct >= 0.75) signals.push({ cat: 'late_game',       urgency: 6  });
  if (neutralTerrs.length > 0) signals.push({ cat: 'neutrals_available', urgency: 4 });
  if (hostileTerrs.length > playerTerrs.length) signals.push({ cat: 'outnumbered', urgency: 7 });

  // ── Stat imbalances ────────────────────────────────────
  if (s.military > 80 && r.gold > 300) signals.push({ cat: 'ready_to_strike', urgency: 6 });
  if (s.economy < 40)  signals.push({ cat: 'economy_weak',    urgency: 6  });
  if (s.economy > 75)  signals.push({ cat: 'economy_strong',  urgency: 2  });
  if (s.influence < 35) signals.push({ cat: 'influence_low',  urgency: 5  });

  // ── Turn progression ───────────────────────────────────
  if (state.turn <= 3)   signals.push({ cat: 'opening',         urgency: 6  });
  if (state.turn > 15)   signals.push({ cat: 'mid_campaign',    urgency: 3  });
  if (state.turn > 30)   signals.push({ cat: 'long_campaign',   urgency: 4  });
  if (state.actionsLeft === 0) signals.push({ cat: 'end_of_turn', urgency: 3 });

  // ── Tech / research ────────────────────────────────────
  if (state.researched.size === 0) signals.push({ cat: 'no_research', urgency: 5 });
  if (state.researched.size >= 4)  signals.push({ cat: 'well_researched', urgency: 2 });

  // ── Mandala logic: nearest hostile ────────────────────
  const nearestHostile = hostileTerrs
    .filter(t => {
      const dx = t.x - 0.62, dy = t.y - 0.55;
      return Math.hypot(dx, dy) < 0.18;
    });
  if (nearestHostile.length > 0) signals.push({ cat: 'threat_near', urgency: 8 });

  // Sort by urgency descending
  signals.sort((a, b) => b.urgency - a.urgency);
  return signals;
}

/* ═══════════════════════════════════════════════════════
   RESPONSE CORPUS
   Keyed by situation category. Each entry is an array of
   advice strings. One is picked with slight randomisation
   weighted toward variety (avoids repeating the same line).
═══════════════════════════════════════════════════════ */
const RESPONSES = {

  opening: [
    "The wise king first consolidates what he has. Magadha is strong — fortify its borders and fill the Kosha before any conquest. The Arthashastra says: an empty treasury is the root of all calamities.",
    "Samrat, we begin well. The Nanda treasury is fat with plunder — their weakness is complacency. First three turns: trade, recruit, and spy. Do not invade until your Sena numbers above 180.",
    "Kautilya's first lesson: the king must first know himself. What are Magadha's strengths? Gold and learning. Build on both before you reach outward.",
    "321 BCE. The world is in flux. Alexander's generals squabble over his corpse. The Nanda cling to power through cruelty, not merit. Your opening advantage is legitimacy, Samrat — use it.",
  ],

  gold_crisis: [
    "The Kosha — the treasury — is the very root of the state. Without gold, there is no army. Without an army, there is no kingdom. Open the trade routes immediately, Samrat. Everything else can wait.",
    "An empty treasury is more dangerous than a thousand enemy swords. Your first action must be Vanik Path — establish trade. Levy taxes on the wealthy. Harvest the fields. Gold before war.",
    "Arthashastra Book II states clearly: the king who neglects his treasury will be destroyed even without enemies. Open two trade routes this turn. Recruit nothing until the Kosha recovers.",
    "The Nanda grew fat on taxation. We need not be cruel — but we must be efficient. Develop your existing territories first. Each city you own should be paying into the treasury. Neglect none.",
  ],

  gold_low: [
    "Your Suvarna reserves concern me. A military campaign now would leave Magadha exposed. One turn of trade and harvest — then we may speak of conquest.",
    "Samrat, the Arthashastra prescribes: build wealth in peace, spend it in war. We are below the threshold for a major campaign. Consolidate the treasury first.",
    "Consider the Kosha Vyavastha if you have not yet — it pays handsomely. The Silk Route too, once researched, turns every trade action into gold that multiplies over turns.",
  ],

  gold_surplus: [
    "The treasury overflows — a fine problem to have. But idle gold is wasted power. Invest in the Ashvamedha Yajna for dharma, or recruit a second army corps. Wealth must be put to work.",
    "Kautilya warns against hoarding: wealth that does not circulate does not grow. This is the moment to fund a campaign, or research Dandaniti to amplify your military permanently.",
    "You have the gold to strike. The question is not whether to move — it is where. Which enemy is weakest? Which neutral can be won cheapest? Let us discuss the Mandala.",
  ],

  army_weak: [
    "Samrat — your Sena is too thin for any offensive action. A king who marches with fewer soldiers than his enemy courts disaster. Recruit immediately, even at the cost of one other action.",
    "The Arthashastra is explicit: never attack without numerical advantage unless terrain or stratagem gives you the edge. We have neither today. Strengthen the Sena first.",
    "Your military position is precarious. The Nanda outnumber you. The Persians are watching. This is not cowardice — it is Dandaniti, the science of war. Only a fool fights before he is ready.",
    "Two things before any invasion: your army must outnumber theirs, and your food stores must sustain a campaign. We lack the first. Recruit. Then we talk of conquest.",
  ],

  army_strong: [
    "Your Sena is formidable. The moment approaches for expansion. Which territory has you chosen, Samrat?",
    "A strong army is only valuable if deployed with wisdom. Do not let your soldiers sit idle — every turn without conquest is a turn your rivals grow stronger.",
  ],

  food_crisis: [
    "The granaries are depleting. An army that cannot eat cannot fight — and a people that cannot eat will revolt. Krishi Vikas must be your priority this turn. Everything else waits.",
    "Arthashastra Book II on agriculture: 'The king who neglects farming ruins his kingdom more surely than any foreign invasion.' Your food stores are dangerously low, Samrat.",
    "Hunger breeds rebellion faster than injustice. Invest in Krishi Vikas. Consider also conquering an agricultural territory — Panchala and Avanti are both fertile plains.",
  ],

  food_surplus: [
    "The granaries are full — your people are fed, your army is sustained. This is the foundation of all strength. Now we may turn to the question of expansion.",
    "Food security achieved. Kautilya would approve. Now redirect this surplus: well-fed troops fight harder, and a happy population supports your campaigns with less coercion.",
  ],

  dharma_crisis: [
    "Samrat, I must speak plainly: your Dharma has fallen to dangerous levels. The people begin to whisper. Nobles question your legitimacy. Rebuild it now — a king without dharma rules only by fear, and fear is unstable.",
    "The Arthashastra says a king must be just to be loved, and loved to be secure. You have sacrificed too much dharma for conquest. Spread Dharma this turn. Build temples. Release some prisoners. The Praja must see their Samrat's righteousness.",
    "A king's greatest weapon is the love of his people. You are losing it. The Ashvamedha Yajna, the construction of temples, the pardoning of debts — these restore what ruthless policy has stripped away.",
    "Low dharma has a compounding cost: reduced happiness, reduced loyalty, increased rebellion risk. The Arthashastra prescribes: every five turns of aggressive policy must be balanced with two turns of righteous governance.",
  ],

  dharma_high: [
    "Your dharma is exemplary, Samrat. The people call you righteous. This gives you a diplomatic advantage — neutral kingdoms are more likely to accept annexation peacefully when approached by a just king.",
    "High dharma is your greatest strategic asset for diplomacy. Use it now — send Rajdoot to the neutral kingdoms. A just king's ambassadors are received as friends, not threats.",
  ],

  happiness_low: [
    "The Praja are restless. Unhappy people do not pay taxes willingly, do not serve in armies with loyalty, and — at the extreme — invite the enemies of the king to enter as liberators. Address this before it festers.",
    "Rebellion grows in unhappy hearts. Your happiness metric is low. The causes are usually: heavy taxation, military losses, food shortages, or perceived injustice. Which applies to your situation?",
    "Arthashastra prescribes: the king who makes his people suffer for his ambitions will find those ambitions turned against him. A content Praja is worth ten additional regiments.",
  ],

  ready_to_strike: [
    "Your army is strong and your treasury is full. This is the moment Kautilya calls Vigraha — offensive war. Choose your target wisely. The weakest enemy, not the nearest, should fall first.",
    "The stars align for conquest, Samrat. Military strength high, treasury sufficient. Apply the Mandala principle: the territory directly adjacent to your border is both the greatest threat and the greatest opportunity. Strike there.",
    "You are ready. Do not hesitate further — in war, hesitation is defeat before the battle begins. Select your target and invade. Then consolidate before striking again.",
  ],

  outnumbered: [
    "The hostile kingdoms control more territory than you. This demands the Shadgunya — the six foreign policies. Use Sandhi (peace) with one enemy to fight another. Divide before you conquer.",
    "You are outnumbered in territories. Direct confrontation across all fronts is unwise. The Arthashastra's Mandala theory says: make peace with your enemy's enemy. Turn one hostile faction neutral through diplomacy, then focus on the other.",
    "When outnumbered, the Arthashastra prescribes Asana — waiting and watching. Grow your economy. Research technologies. Let the hostile kingdoms exhaust themselves fighting each other. Then strike the weakened victor.",
  ],

  neutrals_available: [
    "Neutral kingdoms are Kautilya's first counsel: they cost less to acquire than hostile ones and come without the damage of war. A neutral annexed through Rajdoot is worth twice a hostile one taken by sword.",
    "The neutral territories are yours to claim — the question is whether by diplomacy or force. Your Dharma rating determines which is cheaper. If your dharma is high, send ambassadors. If low, prepare your Sena.",
    "Do not overlook the neutral kingdoms in your rush toward the hostile ones. Mathura and Panchala are rich territories that will submit to a strong, just king without bloodshed.",
  ],

  threat_near: [
    "There is a hostile force near your borders. The Arthashastra is clear: you must either strengthen your defences immediately, or strike before they do. Waiting in this position is the most dangerous choice.",
    "A hostile kingdom borders your territory. Kautilya's Mandala theory: your neighbour is always a potential enemy, your neighbour's neighbour a potential ally. Who can we recruit against this threat?",
    "The proximity of a hostile faction demands action. Either: deploy Gupta spies to weaken them internally, recruit Sena to deter attack, or — if your forces are ready — strike first before they consolidate.",
  ],

  early_game: [
    "In the opening phase, the Arthashastra prescribes three actions before conquest: fill the treasury, train the army, establish at least one trade route. We have barely begun. Patience.",
    "These first turns are foundation-laying. Every decision now compounds over the whole campaign. Prioritise trade and Krishi Vikas over military action. The wars come soon enough.",
    "The early game belongs to the Kosha — the treasury. A king who begins his campaign with full coffers can recover from early military setbacks. A king who begins poor cannot.",
  ],

  mid_game: [
    "You have grown significantly, Samrat. The middle phase of any campaign is where discipline matters most. Avoid overextension — hold what you have, consolidate, then expand methodically.",
    "The mid-campaign is the most dangerous phase: you are large enough to be a target, but not yet strong enough to be untouchable. Maintain your Sena strength and your diplomatic web simultaneously.",
    "Half the subcontinent may soon be yours. But remember — it is easier to conquer than to govern. Make sure your occupied territories are producing income and loyalty, not just sitting under your banner.",
  ],

  late_game: [
    "Chakravarti Samrat is within reach. Three-quarters of the subcontinent — that is the threshold. You need a few more victories. Choose your targets with care: the remaining hostile factions are likely well-fortified.",
    "The end game is about finishing power, not further expansion. Crush one major faction completely, then absorb the neutrals diplomatically. You need not fight every remaining battle.",
    "Victory approaches. But the final push is where campaigns are lost. Do not neglect your Dharma in the race to finish — a Dharmic Emperor's legacy endures. A ruthless conqueror's lasts only until the next revolt.",
  ],

  no_research: [
    "You have not yet begun research into the Arthashastra's laws. This is a significant oversight. Kosha Vyavastha alone would double your gold income. Saptanga Rajya gives +20% to everything. Invest in Vidya — knowledge multiplies all other resources.",
    "Samrat, the great texts await. Kautilya spent decades compiling the Arthashastra precisely so that rulers need not learn strategy by failure. Research at least one technology this turn.",
  ],

  well_researched: [
    "Your Vidya is admirable. Four or more doctrines mastered — you have studied the Arthashastra well. The benefits compound now. Focus on applying this knowledge in the field.",
    "Good. The scholarly foundation is laid. Now the challenge is execution. All the theory in the world means nothing without the will to act decisively.",
  ],

  economy_weak: [
    "Your economic infrastructure is weak. Artha — wealth — is the second of the four Purusharthas, and Kautilya places it above all for a king. Without a thriving economy, military campaigns cannot be sustained.",
    "The economy needs investment. Open trade routes. Develop your wealthiest territories. Research Vanika (Silk Route Trade). An economic foundation supports everything else — army, diplomacy, dharma.",
  ],

  economy_strong: [
    "Your economy is flourishing. This is the foundation of all power. Kautilya would approve — he wrote more chapters on Artha than on warfare. Use this surplus to fund your next campaign.",
  ],

  influence_low: [
    "Your diplomatic influence is low. The kingdoms of Bharatvarsha do not yet fear or respect you sufficiently. Send more Rajdoot missions. Every turn of diplomacy without war increases your standing.",
    "Prabhav — influence — is the soft power that makes hard power cheaper. A kingdom that fears your reputation needs fewer soldiers to conquer. Invest in diplomacy this turn.",
  ],

  end_of_turn: [
    "Your actions for this Yuga are spent. End the turn and let the seasons pass. The Arthashastra advises: after action, reflection. Review what was accomplished and what was not.",
    "The turn is complete. Click 'End Yuga' and let time advance. Every turn you delay is a turn the enemy uses to grow stronger.",
  ],

  mid_campaign: [
    "Fifteen turns into the campaign. Your decisions are compounding now — good ones and bad ones alike. The Arthashastra says: a campaign's middle period reveals the king's true character.",
  ],

  long_campaign: [
    "Thirty turns. The campaign is long. Is your strategy working? If not, this is the moment to change it — not out of desperation, but out of wisdom. Kautilya adjusted his plans many times before placing Chandragupta on the throne.",
    "A prolonged campaign risks war-weariness and economic strain. Make sure your income is growing, not just your territories. Speed of consolidation matters now.",
  ],

  // ── Fallback general wisdom ──────────────────────────
  general: [
    "The Arthashastra teaches: a king must be always active, always vigilant. The moment he rests, his enemies advance.",
    "Kautilya wrote 15 books, 150 chapters, 6,000 shlokas — all in service of one goal: making a just king powerful and a powerful king just. Which are you working on today, Samrat?",
    "Consider the Saptanga — the seven pillars of the state: Swami (king), Amatya (ministers), Janapada (territory), Durga (fortress), Kosha (treasury), Danda (army), Mitra (ally). Which pillar is weakest?",
    "The Mandala theory of foreign policy: your neighbour is a potential enemy. Your neighbour's neighbour is a potential ally. Your neighbour's neighbour's neighbour is another potential enemy. Map this web before you move.",
    "Shadgunya — the six foreign policies: Sandhi (peace), Vigraha (war), Asana (neutrality), Yana (march), Samshraya (alliance), Dvaidhibhava (dual policy). Which applies to your current position?",
    "A king who reads the Arthashastra knows: every action has four possible outcomes — gain, loss, maintenance, improvement. Ask these four questions before every decision.",
    "The wise administrator makes enemies unnecessary through wealth, unnecessary through strength, and impossible through justice. You need not conquer what will submit to a worthy king.",
    "Remember Kautilya's triangle: Artha (material prosperity), Dharma (righteous conduct), Kama (pleasure). A king who neglects any one of the three creates the conditions for his own downfall.",
    "Do not be deceived by peace into inaction. The Arthashastra says: a king must always be engaged in conquest — either of territory, or of knowledge, or of himself.",
    "The Arthashastra is not a book of cruelty. It is a book of realism. Kautilya understood that a prosperous, just kingdom is also the most durable one. Dharma and Artha are allies, not enemies.",
  ],
};

/* ═══════════════════════════════════════════════════════
   RESPONSE TRACKER
   Avoids repeating the same line twice in a session.
═══════════════════════════════════════════════════════ */
const _used = new Map(); // category → Set of used indices

function pickResponse(category) {
  const pool = RESPONSES[category] || RESPONSES.general;
  if (!_used.has(category)) _used.set(category, new Set());
  const used = _used.get(category);

  // Reset if all used
  if (used.size >= pool.length) used.clear();

  let idx;
  do { idx = Math.floor(Math.random() * pool.length); } while (used.has(idx));
  used.add(idx);
  return pool[idx];
}

/* ═══════════════════════════════════════════════════════
   ACTION-TRIGGERED ADVICE
   Called immediately when player takes a specific action.
═══════════════════════════════════════════════════════ */
const ACTION_ADVICE = {
  recruit: [
    "Good. The Arthashastra prescribes a standing army of at least four corps. Recruitment now is investment in future conquest.",
    "Sena strengthened. Remember: an army that does not march eventually becomes a burden on the treasury. Plan your campaign.",
    "More soldiers. Kautilya would say: the value of an army is in the fear it creates as much as the battles it wins.",
  ],
  spy: [
    "The Gupta Chakra — our intelligence network. Kautilya himself ran a vast spy system. Information is worth more than soldiers.",
    "Spies deployed. The Arthashastra devotes three entire chapters to espionage. A well-informed king rarely needs to fight.",
    "Good. Let our agents weaken the enemy from within. Sow discord among their ministers. Starve their treasury. Make their subjects doubt their king.",
  ],
  trade: [
    "The Vanik Path is open. Trade enriches both the treasury and the relations between kingdoms. Kautilya valued merchants highly.",
    "Commerce flows. Every trade route is a thread of soft power — economic dependency is often stronger than military occupation.",
    "The Arthashastra devotes more chapters to trade regulation than to military strategy. Kautilya understood that economic power is the foundation of all other power.",
  ],
  dharma: [
    "Dharma spread. The people see their king's righteousness. This goodwill compounds — it reduces rebellion risk and improves diplomatic reception.",
    "Temples built, justice administered. A dharmic king's reputation travels faster than his armies. Neutral kingdoms will receive our Rajdoot warmly.",
    "The Arthashastra says: a king is righteous when he administers the law without passion, greed or delusion. Spread Dharma — not as performance, but as practice.",
  ],
  harvest: [
    "The farms are expanded. Kautilya wrote extensively on agriculture — irrigation, crop rotation, land measurement. A fed kingdom fights better.",
    "Krishi Vikas complete. Food security is the most underrated strategic asset. An army that knows its people are fed fights with more heart.",
    "Agricultural expansion done. Remember: Arthashastra Book II prescribes the king to personally inspect irrigation works. The land is the kingdom's greatest asset.",
  ],
  diplomacy: [
    "Rajdoot dispatched. The art of the ambassador: speak softly, but let your Sena's reputation precede you. Diplomacy works best when backed by credible force.",
    "Ambassadors sent. A diplomatic victory is worth three military ones — it costs less, damages less, and creates less resentment among the conquered people.",
    "Good. The Arthashastra lists four forms of winning over an enemy: Sama (conciliation), Dana (gifts), Bheda (division), Danda (force). Diplomacy is the first and cheapest.",
  ],
};

export function getActionAdvice(actionType) {
  const pool = ACTION_ADVICE[actionType] || RESPONSES.general;
  if (!_used.has('action_'+actionType)) _used.set('action_'+actionType, new Set());
  const used = _used.get('action_'+actionType);
  if (used.size >= pool.length) used.clear();
  let idx;
  do { idx = Math.floor(Math.random() * pool.length); } while (used.has(idx));
  used.add(idx);
  return pool[idx];
}

/* ═══════════════════════════════════════════════════════
   TERRITORY-SPECIFIC ADVICE
   Called when player selects a territory.
═══════════════════════════════════════════════════════ */
export function getTerritoryAdvice(territory, state, factions) {
  const owned = territory.owner === 'player';
  const neutral = territory.owner === 'neutral';
  const faction = factions[territory.owner];
  const armyRatio = state.resources.army / territory.strength;

  if (owned) {
    if (territory.wealth > 70)
      return `${territory.name} is one of your richest territories. Ensure it is well-defended — wealthy provinces attract raiders and ambitious neighbours.`;
    if (territory.type === 'temple')
      return `${territory.name} is a sacred site. Its value is in Dharma, not gold. Use it to boost your righteousness rating before diplomatic missions.`;
    if (territory.population > 300)
      return `${territory.name} is populous — a great source of recruits and tax revenue. Keep its happiness high or risk internal discontent.`;
    return `${territory.name} is under your banner. Consider developing it further — its strength is ${territory.strength}, its wealth ${territory.wealth}. Both can be improved.`;
  }

  if (neutral) {
    const approach = state.resources.dharma > 60 ? 'diplomatic' : 'military';
    if (approach === 'diplomatic')
      return `${territory.name} is unaligned and your Dharma is high. A Rajdoot mission has good chances of peaceful annexation — cheaper than invasion, less damage to the territory's productivity.`;
    return `${territory.name} is neutral with strength ${territory.strength}. Your army ${armyRatio > 1.4 ? 'has the advantage — invasion is viable' : 'may struggle — consider diplomacy first'}.`;
  }

  // Hostile territory
  if (armyRatio < 1.0)
    return `${territory.name} is controlled by ${faction?.name}. Their strength of ${territory.strength} exceeds your army. Do not invade yet — recruit first, or weaken them with spies.`;
  if (armyRatio < 1.3)
    return `${territory.name} — ${faction?.name} — is formidable. You can win, but it will cost you. Consider deploying Gupta spies first to reduce their strength before invading.`;
  return `${territory.name} is within your power to take. ${faction?.name} holds it with ${territory.strength} strength — your Sena is strong enough. The Arthashastra says: strike when you are stronger, not when you are desperate.`;
}

/* ═══════════════════════════════════════════════════════
   MAIN API
   getAdvice(state, territories, factions) → { text, shloka? }
   Called by main.js for turn-based advisor updates.
═══════════════════════════════════════════════════════ */
const SHLOKAS = {
  gold_crisis:   '"कोशो दण्डमूलः" — The treasury is the root of punishment (power). — Arthashastra 2.1',
  army_weak:     '"अमित्रसाध्यो भवति दण्डः" — Military power that cannot subdue enemies is worthless. — Arthashastra 9.1',
  dharma_crisis: '"प्रजासुखे सुखं राज्ञः" — In the happiness of the subjects lies the happiness of the king. — Arthashastra 1.19',
  ready_to_strike: '"आयस्य प्रधानं दण्डः" — Military power is the prime means of gaining wealth. — Arthashastra 7.1',
  neutrals_available: '"सामदानभेददण्डाश्च" — Conciliation, gifts, division, punishment — the four tools. — Arthashastra 2.10',
  outnumbered:   '"सर्वान् पर्यायेण साधयेत्" — Overcome all enemies in turn, one by one. — Arthashastra 7.13',
  general:       '"आत्मनो बलमन्विच्छेत्" — Always seek to know your own strength first. — Arthashastra 6.1',
};

export function getAdvice(state, territories, factions) {
  const signals = evaluateSituation(state, territories, factions);

  // Pick the highest-urgency situation we have a response for
  let category = 'general';
  for (const sig of signals) {
    if (RESPONSES[sig.cat]) { category = sig.cat; break; }
  }

  const text   = pickResponse(category);
  const shloka = SHLOKAS[category] || null;
  return { text, shloka, category };
}

/* ═══════════════════════════════════════════════════════
   END-OF-TURN VERDICT
   Chanakya rates what the player did this turn.
═══════════════════════════════════════════════════════ */
export function getTurnVerdict(actionsUsed, state) {
  if (actionsUsed === 0)
    return "You took no action this turn, Samrat. Inaction is itself a decision — and rarely a wise one.";
  if (actionsUsed === 1)
    return "One action only. There was more you could have done. The Arthashastra warns against the king who is content with half-measures.";
  if (actionsUsed >= 3 && state.resources.dharma > 50 && state.resources.gold > 200)
    return "A productive turn, Samrat. Treasury healthy, dharma maintained, actions taken. Kautilya would be satisfied.";
  if (state.resources.dharma < 30)
    return "The turn ends, but your dharma deficit grows. Military strength without righteousness builds an empire that is always one revolt away from collapse.";
  if (state.resources.gold < 100)
    return "The treasury is nearly empty. Whatever was accomplished this turn, next turn must prioritise the Kosha above all else.";
  return "The turn passes. Reflect on whether your actions moved you toward Chakravarti Samrat — or merely maintained the status quo.";
}

/* ═══════════════════════════════════════════════════════
   FINAL VERDICT
   Called at game end. Returns title + narrative.
═══════════════════════════════════════════════════════ */
export function getFinalVerdict(state, playerTerrs, totalTerrs) {
  const pct = playerTerrs / totalTerrs;
  const d   = state.resources.dharma;
  const turns = state.turn;

  let title, narrative;

  if (pct >= 0.75 && d > 70) {
    title = 'Dharmic Chakravarti Samrat';
    narrative = `In ${turns} turns, you united ${playerTerrs} of ${totalTerrs} provinces — not merely through conquest, but through wisdom and righteousness. The Arthashastra's highest ideal: a king who is both powerful and just. Kautilya himself could not have hoped for a finer student.`;
  } else if (pct >= 0.75 && d > 40) {
    title = 'Pragmatic Samrat';
    narrative = `${playerTerrs} territories in ${turns} turns — an empire built by cold calculation and hard effort. Your dharma was adequate, your strategy sound. History will record you as effective. Whether it calls you great depends on what you build next.`;
  } else if (pct >= 0.75) {
    title = 'Ruthless Conqueror';
    narrative = `You conquered ${playerTerrs} territories in ${turns} turns — but at a cost. Your dharma rating tells the story: this was an empire built on fear, not love. Kautilya warns: such empires are inherited by revolt, not by heirs. The work of governance begins now.`;
  } else if (pct >= 0.5) {
    title = 'Regional Maharaja';
    narrative = `Half the subcontinent bows to you. Respectable — but the Arthashastra's vision of Chakravarti is not half-measures. Study the Mandala. Strengthen the Kosha. The final push awaits your return.`;
  } else {
    title = 'Raja of Magadha';
    narrative = `The campaign was honourable but incomplete. ${playerTerrs} territories gained. The Arthashastra teaches that there is no shame in a slow campaign — only in an abandoned one. Return with a fresh strategy.`;
  }

  return { title, narrative };
}

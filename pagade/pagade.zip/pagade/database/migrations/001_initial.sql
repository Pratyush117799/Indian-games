-- Pagade Database Schema
-- PostgreSQL

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── Players ────────────────────────────────────────────────────────────────
CREATE TABLE players (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username      VARCHAR(32) UNIQUE NOT NULL,
  display_name  VARCHAR(64),
  avatar_index  INT DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  last_seen     TIMESTAMPTZ DEFAULT NOW(),

  -- Stats
  games_played  INT DEFAULT 0,
  games_won     INT DEFAULT 0,
  total_captures INT DEFAULT 0,
  win_streak    INT DEFAULT 0,
  best_streak   INT DEFAULT 0,

  -- Cosmetics (unlocked item IDs stored as JSON arrays)
  unlocked_skins  JSONB DEFAULT '["default"]',
  unlocked_boards JSONB DEFAULT '["temple_stone"]',
  active_skin     VARCHAR(32) DEFAULT 'default',
  active_board    VARCHAR(32) DEFAULT 'temple_stone',

  -- Preferences
  dice_style      VARCHAR(16) DEFAULT 'cowrie',  -- 'cowrie' | 'stick'
  sound_enabled   BOOLEAN DEFAULT TRUE
);

-- ─── Games ──────────────────────────────────────────────────────────────────
CREATE TABLE games (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  mode          VARCHAR(20) NOT NULL,  -- 'solo_ai' | 'pass_play' | 'tournament'
  status        VARCHAR(16) DEFAULT 'active',  -- 'active' | 'completed' | 'abandoned'
  dice_style    VARCHAR(16) DEFAULT 'cowrie',
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  completed_at  TIMESTAMPTZ,
  duration_secs INT,

  -- Snapshot of the complete game state (for resume / replay)
  state_json    JSONB NOT NULL DEFAULT '{}',

  -- Winner info
  winner_player_id UUID REFERENCES players(id) ON DELETE SET NULL
);

-- ─── Game Participants ───────────────────────────────────────────────────────
CREATE TABLE game_players (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  game_id    UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  player_id  UUID REFERENCES players(id) ON DELETE SET NULL,  -- NULL = AI / guest
  seat       INT NOT NULL CHECK (seat BETWEEN 0 AND 3),       -- 0=Red,1=Green,2=Yellow,3=Blue
  color      VARCHAR(8) NOT NULL,
  is_ai      BOOLEAN DEFAULT FALSE,
  ai_level   VARCHAR(16),   -- 'beginner' | 'prince' | 'maharaja'
  finished   BOOLEAN DEFAULT FALSE,
  finish_rank INT,           -- 1st, 2nd, 3rd, 4th
  captures   INT DEFAULT 0,

  UNIQUE(game_id, seat)
);

-- ─── Move Log ───────────────────────────────────────────────────────────────
CREATE TABLE moves (
  id          BIGSERIAL PRIMARY KEY,
  game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  seat        INT NOT NULL,
  move_number INT NOT NULL,
  dice_values JSONB NOT NULL,   -- e.g. [3, 4] for stick dice, [4] for cowrie
  dice_total  INT NOT NULL,
  pawn_index  INT,              -- 0-3, null if no valid move (pass)
  from_status VARCHAR(8),       -- BELLY | ACTIVE | SAFE
  to_status   VARCHAR(8),
  from_pos    INT,
  to_pos      INT,
  captured_pawn JSONB,          -- { seat, pawnIndex } if capture occurred
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Tournaments ─────────────────────────────────────────────────────────────
CREATE TABLE tournaments (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         VARCHAR(128) NOT NULL,
  status       VARCHAR(16) DEFAULT 'open',  -- 'open' | 'in_progress' | 'completed'
  max_players  INT DEFAULT 16,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  started_at   TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);

CREATE TABLE tournament_players (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tournament_id UUID NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  player_id     UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  registered_at TIMESTAMPTZ DEFAULT NOW(),
  eliminated    BOOLEAN DEFAULT FALSE,
  final_rank    INT,
  UNIQUE(tournament_id, player_id)
);

CREATE TABLE tournament_rounds (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tournament_id UUID NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  round_number  INT NOT NULL,
  game_id       UUID REFERENCES games(id) ON DELETE SET NULL,
  status        VARCHAR(16) DEFAULT 'pending'
);

-- ─── Leaderboard View ───────────────────────────────────────────────────────
CREATE VIEW leaderboard AS
SELECT
  p.id,
  p.username,
  p.display_name,
  p.games_played,
  p.games_won,
  p.best_streak,
  p.total_captures,
  CASE WHEN p.games_played > 0
    THEN ROUND(100.0 * p.games_won / p.games_played, 1)
    ELSE 0
  END AS win_pct,
  ROW_NUMBER() OVER (ORDER BY p.games_won DESC, p.win_pct DESC) AS rank
FROM players p
WHERE p.games_played >= 1;

-- ─── Indexes ────────────────────────────────────────────────────────────────
CREATE INDEX idx_games_status ON games(status);
CREATE INDEX idx_game_players_game ON game_players(game_id);
CREATE INDEX idx_moves_game ON moves(game_id, move_number);
CREATE INDEX idx_tournament_players ON tournament_players(tournament_id);

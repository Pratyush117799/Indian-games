/**
 * BoardCell — single grid cell with full theme support.
 *
 * Zone types:
 *   'home'       — central square (✦ yantra)
 *   'safe_lane'  — private channel (per-player colour from theme)
 *   'safe_path'  — lotus safe square on main path
 *   'arm'        — standard traversal cell
 *
 * Highlight states:
 *   'valid'      — pulsing gold outline (valid move landing)
 *   'selected'   — bright selected state
 *   'blockade'   — subtle enemy blockade tint
 */

import React from 'react';
import {
  CELL_SIZE, SAFE_PATH_POSITIONS, MAIN_PATH,
  SAFE_LANES, HOME_CELL, PLAYER_ENTRY,
} from '../../game/constants';
import { getTheme, getSafeLaneColor } from '../../game/boardThemes';

// ─── Pre-built lookup table ───────────────────────────────────────────────────
function buildMeta() {
  const map = {};
  const k = (r, c) => `${r},${c}`;

  // Safe path positions (lotus squares on main path)
  for (const idx of SAFE_PATH_POSITIONS) {
    const cell = MAIN_PATH[idx];
    map[k(cell.r, cell.c)] = { zone: 'safe_path' };
  }
  // Safe lanes
  for (let pid = 0; pid < 4; pid++) {
    SAFE_LANES[pid].forEach((cell, li) => {
      map[k(cell.r, cell.c)] = { zone: 'safe_lane', playerId: pid, laneIndex: li };
    });
  }
  // Home
  map[k(HOME_CELL.r, HOME_CELL.c)] = { zone: 'home' };

  return map;
}
const META     = buildMeta();
const ENTRY_SET = new Set(PLAYER_ENTRY.map(e => `${MAIN_PATH[e].r},${MAIN_PATH[e].c}`));

// ─── BoardCell ─────────────────────────────────────────────────────────────────

export default React.memo(function BoardCell({
  r, c, highlight, themeId = 'temple_stone', children,
}) {
  const metaKey = `${r},${c}`;
  const meta    = META[metaKey];
  const theme   = getTheme(themeId);
  const cc      = theme.cellColors;

  const x = c * CELL_SIZE;
  const y = r * CELL_SIZE;
  const sz = CELL_SIZE - 1;

  // ── Determine fill & stroke ──────────────────────────────────────────────
  let fill   = cc.default || '#f5efe6';
  let stroke = '#c4aa84';
  let sw     = 0.5;
  let rx     = 0;

  if (meta?.zone === 'home') {
    fill   = cc.home    || '#2c1a0e';
    stroke = '#8B6914';
    sw     = 1.5;
    rx     = 4;
  } else if (meta?.zone === 'safe_lane') {
    fill   = getSafeLaneColor(themeId, meta.playerId);
    stroke = '#00000015';
    sw     = 0.5;
  } else if (meta?.zone === 'safe_path') {
    fill   = cc.safePath || '#f0f7e8';
    stroke = '#7aad4a';
    sw     = 1;
  }

  // ── Highlight overrides ───────────────────────────────────────────────────
  if (highlight === 'valid') {
    fill   = '#fffbec';
    stroke = '#D4A017';
    sw     = 2;
  } else if (highlight === 'selected') {
    fill   = '#fff3cd';
    stroke = '#D4A017';
    sw     = 2.5;
  } else if (highlight === 'blockade') {
    // Enemy blockade — subtle red tint overlay (don't override fill, just add opacity)
  }

  return (
    <g>
      <rect
        x={x + 0.5} y={y + 0.5}
        width={sz} height={sz}
        fill={fill} stroke={stroke} strokeWidth={sw}
        rx={rx}
      />

      {/* Home yantra */}
      {meta?.zone === 'home' && (
        <text
          x={x + CELL_SIZE / 2} y={y + CELL_SIZE / 2 + 4}
          fontSize={18} textAnchor="middle" dominantBaseline="middle"
          fill="#8B6914"
          style={{ userSelect: 'none', pointerEvents: 'none' }}
        >✦</text>
      )}

      {/* Lotus on safe path */}
      {meta?.zone === 'safe_path' && (
        <text
          x={x + CELL_SIZE / 2} y={y + CELL_SIZE / 2 + 4}
          fontSize={13} textAnchor="middle" dominantBaseline="middle"
          style={{ userSelect: 'none', pointerEvents: 'none' }}
        >🪷</text>
      )}

      {/* Entry gold dot */}
      {ENTRY_SET.has(metaKey) && meta?.zone !== 'safe_path' && (
        <circle cx={x + CELL_SIZE - 7} cy={y + 7} r={3} fill="#D4A017" opacity={0.65} />
      )}

      {/* Valid move pulse ring */}
      {highlight === 'valid' && (
        <rect
          x={x + 1} y={y + 1} width={sz - 1} height={sz - 1}
          fill="none" stroke="#D4A017" strokeWidth={1.5} rx={2}
          opacity={0.5}
          style={{ animation: 'cellPulse 1.2s ease-in-out infinite' }}
        />
      )}

      {children}
    </g>
  );
});

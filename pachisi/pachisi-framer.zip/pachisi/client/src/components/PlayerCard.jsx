import { motion, AnimatePresence } from 'framer-motion';
import { COLORS, NAMES, DEVA } from '../game/config.js';
import { useGame } from '../context/GameContext.jsx';

const TEAMS_LABEL = [
  'Team A · You',
  'Team B · AI',
  'Team A · AI',
  'Team B · AI',
];
const DOT_COLORS = ['var(--y)', 'var(--r)', 'var(--bl)', 'var(--g)'];

export default function PlayerCard({ player }) {
  const { cur, pawns } = useGame();
  const active = cur === player;
  const dotCol = DOT_COLORS[player];

  return (
    <motion.div
      className={`player-card${active ? ' active' : ''}`}
      animate={active
        ? { borderColor:'rgba(201,153,58,0.5)',  backgroundColor:'rgba(201,153,58,0.075)' }
        : { borderColor:'rgba(201,153,58,0.26)', backgroundColor:'rgba(201,153,58,0.025)' }
      }
      transition={{ duration:0.35 }}
    >
      {/* Top bar */}
      <AnimatePresence>
        {active && (
          <motion.div className="pc-bar"
            initial={{ scaleX:0, opacity:0 }}
            animate={{ scaleX:1, opacity:1 }}
            exit={{    scaleX:0, opacity:0 }}
            transition={{ duration:0.35 }}
          />
        )}
      </AnimatePresence>

      <div className="pc-header">
        <motion.span
          className="pc-pip"
          style={{ background:dotCol }}
          animate={active
            ? { boxShadow:[`0 0 4px ${dotCol}`,`0 0 14px ${dotCol}`,`0 0 4px ${dotCol}`] }
            : { boxShadow:'none' }
          }
          transition={{ duration:1.4, repeat:active ? Infinity : 0 }}
        />
        <span className="pc-name">{NAMES[player]} · {DEVA[player]}</span>
        <span className="pc-team">{TEAMS_LABEL[player]}</span>
      </div>

      <div className="pc-dots">
        {pawns[player].map((pw, i) => (
          <motion.span key={i}
            className={`pawn-dot ${pw.pos === 80 ? 'hm' : pw.pos >= 0 ? 'ob' : ''}`}
            style={{ background:dotCol, color:dotCol }}
            animate={
              pw.pos === 80  ? { opacity:1, boxShadow:`0 0 6px ${dotCol}`, scale:1.15 } :
              pw.pos >= 0    ? { opacity:0.85, scale:1, boxShadow:'none' } :
                               { opacity:0.28, scale:1, boxShadow:'none' }
            }
            transition={{ duration:0.3 }}
          />
        ))}
      </div>
    </motion.div>
  );
}

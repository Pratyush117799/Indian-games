require('dotenv').config();

const http    = require('http');
const express = require('express');
const { Server } = require('socket.io');
const helmet  = require('helmet');
const cors    = require('cors');
const morgan  = require('morgan');
const rateLimit = require('express-rate-limit');

const logger  = require('./utils/logger');
const { errorHandler, notFound } = require('./middleware/errorHandler');
const { initSocket } = require('./socket');

// ── Routes ────────────────────────────────────────────────────
const authRoutes        = require('./routes/auth');
const gamesRoutes       = require('./routes/games');
const roomsRoutes       = require('./routes/rooms');
const leaderboardRoutes = require('./routes/leaderboard');
const historyRoutes     = require('./routes/history');

// ── App setup ─────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);

// Socket.IO
const io = new Server(server, {
  cors: {
    origin:      process.env.CLIENT_URL || 'http://localhost:3000',
    credentials: true,
  },
  transports: ['websocket', 'polling'],
});

initSocket(io);

// ── Global Middleware ─────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin:      process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json({ limit: '2mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev', {
  stream: { write: (msg) => logger.info(msg.trim()) },
}));

// Global rate limiter (per-route limiters override for auth endpoints)
app.use('/api', rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
  max:      parseInt(process.env.RATE_LIMIT_MAX       || '100'),
  standardHeaders: true,
  legacyHeaders:   false,
}));

// ── Routes ────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));

app.use('/api/auth',        authRoutes);
app.use('/api/games',       gamesRoutes);
app.use('/api/rooms',       roomsRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/history',     historyRoutes);

// ── Error handling ────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start ────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '5000');
server.listen(PORT, () => {
  logger.info(`🚀  Krida API running on http://localhost:${PORT}`);
  logger.info(`🔌  Socket.IO ready`);
  logger.info(`🌿  Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = { app, server };

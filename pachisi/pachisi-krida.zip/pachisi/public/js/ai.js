// ═══════════════════════════════════════════════════
//  AI · Heuristic computer opponent
// ═══════════════════════════════════════════════════

import { TEAMS, GRACE_VALS } from './config.js';
import { PATHS, isCastle, isSafe } from './paths.js';
import { G } from './state.js';
import { getMovable, getTargetPos } from './engine.js';

// Choose the best pawn to move for a given player + throw
export function chooseMove(player, val, grace) {
  const movable = getMovable(player, val, grace);
  if (!movable.length) return null;

  let bestScore = -Infinity;
  let bestPawn  = movable[0];

  for (const pawnIdx of movable) {
    const score = _score(player, pawnIdx, val, grace);
    if (score > bestScore) {
      bestScore = score;
      bestPawn  = pawnIdx;
    }
  }
  return bestPawn;
}

// ── Scoring heuristic ──────────────────────────────
function _score(player, pawnIdx, val, grace) {
  const pawn = G.pawns[player][pawnIdx];
  const tp   = pawn.pos === -1 ? 0 : pawn.pos + val;

  // Reaching home is always the best move
  if (tp === 80) return 10000;

  let score = tp; // base: further along = better

  if (tp < 80) {
    const sq = PATHS[player][tp];

    // Land on a castle → safety bonus
    if (isCastle(sq.x, sq.y)) score += 22;

    // In return home column → strong bonus
    if (tp >= 72) score += 38;

    // Capture an opponent → large bonus + free turn
    for (let op = 0; op < 4; op++) {
      if (op === player || TEAMS[op] === TEAMS[player]) continue;
      for (let oi = 0; oi < 4; oi++) {
        const opw = G.pawns[op][oi];
        if (opw.pos < 0 || opw.pos >= 80) continue;
        if (isSafe(op, opw.pos)) continue;
        const osq = PATHS[op][opw.pos];
        if (osq.x === sq.x && osq.y === sq.y) score += 68;
      }
    }

    // Exposed to capture? Penalty
    if (_isExposed(player, tp, sq)) score -= 18;

    // Block partner's threatened pawn? Small bonus
    if (_coversPartner(player, sq)) score += 8;
  }

  // Grace: entering a new pawn is usually good
  if (pawn.pos === -1 && grace) score += 30;

  // Prefer moving the pawn furthest along (avoid spreading too thin)
  if (pawn.pos > 40) score += 12;

  return score;
}

// Will an opponent be able to reach `sq` on their next throw?
function _isExposed(myPlayer, targetIdx, sq) {
  // Don't flag safe squares
  if (isSafe(myPlayer, targetIdx)) return false;
  for (let p = 0; p < 4; p++) {
    if (p === myPlayer || TEAMS[p] === TEAMS[myPlayer]) continue;
    for (let i = 0; i < 4; i++) {
      const opw = G.pawns[p][i];
      if (opw.pos < 0 || opw.pos >= 80) continue;
      // Check all possible throw values
      for (const v of [2, 3, 4, 5, 6, 10, 25]) {
        const tp2 = opw.pos + v;
        if (tp2 >= 0 && tp2 < 80) {
          const tsq = PATHS[p][tp2];
          if (tsq.x === sq.x && tsq.y === sq.y) return true;
        }
      }
    }
  }
  return false;
}

// Is a partner pawn on `sq`, potentially benefitting from company?
function _coversPartner(myPlayer, sq) {
  for (let i = 0; i < 4; i++) {
    if (TEAMS[i] !== TEAMS[myPlayer] || i === myPlayer) continue;
    for (let pi = 0; pi < 4; pi++) {
      const pw = G.pawns[i][pi];
      if (pw.pos < 0 || pw.pos >= 80) continue;
      const psq = PATHS[i][pw.pos];
      if (psq.x === sq.x && psq.y === sq.y) return true;
    }
  }
  return false;
}

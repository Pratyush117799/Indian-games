/**
 * Kattam Vilayattu — Game Logic Engine
 *
 * Grid sizes:  Level 1 → 3×3 (3 pieces each)
 *              Level 2 → 4×4 (4 pieces each)
 *              Level 3 → 5×5 (5 pieces each)
 *
 * Phase 1 — PLACEMENT: Players alternate placing pieces on empty intersections.
 * Phase 2 — MOVEMENT:  Players alternate moving one piece to an adjacent connected point.
 * Win: All own pieces aligned in a single row, column, or diagonal.
 */

const LEVEL_CONFIG = {
  1: { size: 3, pieces: 3 },
  2: { size: 4, pieces: 4 },
  3: { size: 5, pieces: 5 },
};

/**
 * Create a fresh game state.
 * @param {number} level  1 | 2 | 3
 * @param {string[]} playerIds  Array of exactly 2 player UUIDs
 */
function createGameState(level, playerIds) {
  const { size, pieces } = LEVEL_CONFIG[level] || LEVEL_CONFIG[2];
  const total = size * size;

  return {
    level,
    size,
    piecesPerPlayer: pieces,
    board: Array(total).fill(null),       // null | playerId
    phase: 'placement',                   // 'placement' | 'movement'
    currentPlayerIndex: 0,
    players: playerIds,
    piecesPlaced: { [playerIds[0]]: 0, [playerIds[1]]: 0 },
    winner: null,
    moveCount: 0,
  };
}

/**
 * Convert (row, col) to flat index.
 */
function idx(row, col, size) {
  return row * size + col;
}

/**
 * Build the adjacency list for a grid of given size.
 * Connects horizontal, vertical, AND diagonal neighbours.
 */
function buildAdjacency(size) {
  const adj = {};
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const i = idx(r, c, size);
      adj[i] = [];
      const dirs = [-1, 0, 1];
      for (const dr of dirs) {
        for (const dc of dirs) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < size && nc >= 0 && nc < size) {
            adj[i].push(idx(nr, nc, size));
          }
        }
      }
    }
  }
  return adj;
}

/**
 * Return all winning lines for a grid of given size.
 * A winning line is the full row, column, or main/anti diagonal.
 */
function buildWinLines(size) {
  const lines = [];
  // Rows
  for (let r = 0; r < size; r++) {
    lines.push(Array.from({ length: size }, (_, c) => idx(r, c, size)));
  }
  // Columns
  for (let c = 0; c < size; c++) {
    lines.push(Array.from({ length: size }, (_, r) => idx(r, c, size)));
  }
  // Main diagonal
  lines.push(Array.from({ length: size }, (_, i) => idx(i, i, size)));
  // Anti diagonal
  lines.push(Array.from({ length: size }, (_, i) => idx(i, size - 1 - i, size)));

  return lines;
}

/**
 * Check if a player has all their pieces on one winning line.
 */
function checkWin(board, playerId, winLines) {
  const playerCells = new Set(
    board.reduce((acc, owner, i) => { if (owner === playerId) acc.push(i); return acc; }, [])
  );

  return winLines.some(line => line.every(cell => playerCells.has(cell)));
}

/**
 * Apply a placement move.
 * Returns { newState, error }
 */
function applyPlacement(state, playerId, cellIndex) {
  const currentPlayer = state.players[state.currentPlayerIndex];
  if (playerId !== currentPlayer)      return { error: 'Not your turn' };
  if (state.phase !== 'placement')     return { error: 'Not in placement phase' };
  if (state.board[cellIndex] !== null) return { error: 'Cell already occupied' };

  const newBoard      = [...state.board];
  newBoard[cellIndex] = playerId;

  const placed = { ...state.piecesPlaced, [playerId]: state.piecesPlaced[playerId] + 1 };
  const winLines = buildWinLines(state.size);

  // Check win during placement
  const winner = checkWin(newBoard, playerId, winLines) ? playerId : null;

  const totalPlaced = Object.values(placed).reduce((a, b) => a + b, 0);
  const allPlaced   = totalPlaced >= state.players.length * state.piecesPerPlayer;

  return {
    newState: {
      ...state,
      board:           newBoard,
      piecesPlaced:    placed,
      phase:           winner || !allPlaced ? state.phase : 'movement',
      currentPlayerIndex: (state.currentPlayerIndex + 1) % state.players.length,
      winner,
      moveCount: state.moveCount + 1,
    },
  };
}

/**
 * Apply a movement move.
 * Returns { newState, error }
 */
function applyMovement(state, playerId, fromIndex, toIndex) {
  const currentPlayer = state.players[state.currentPlayerIndex];
  if (playerId !== currentPlayer)       return { error: 'Not your turn' };
  if (state.phase !== 'movement')       return { error: 'Not in movement phase' };
  if (state.board[fromIndex] !== playerId) return { error: 'That piece is not yours' };
  if (state.board[toIndex] !== null)    return { error: 'Destination is occupied' };

  const adj = buildAdjacency(state.size);
  if (!adj[fromIndex].includes(toIndex)) return { error: 'Not an adjacent cell' };

  const newBoard      = [...state.board];
  newBoard[fromIndex] = null;
  newBoard[toIndex]   = playerId;

  const winLines = buildWinLines(state.size);
  const winner   = checkWin(newBoard, playerId, winLines) ? playerId : null;

  return {
    newState: {
      ...state,
      board:  newBoard,
      currentPlayerIndex: (state.currentPlayerIndex + 1) % state.players.length,
      winner,
      moveCount: state.moveCount + 1,
    },
  };
}

/**
 * Get all legal moves for the current player.
 * Returns array of { type, from?, to } objects.
 */
function getLegalMoves(state) {
  const playerId = state.players[state.currentPlayerIndex];
  const moves    = [];

  if (state.phase === 'placement') {
    state.board.forEach((owner, i) => {
      if (owner === null) moves.push({ type: 'place', to: i });
    });
  } else {
    const adj = buildAdjacency(state.size);
    state.board.forEach((owner, from) => {
      if (owner === playerId) {
        adj[from].forEach(to => {
          if (state.board[to] === null) moves.push({ type: 'move', from, to });
        });
      }
    });
  }

  return moves;
}

module.exports = {
  createGameState,
  applyPlacement,
  applyMovement,
  getLegalMoves,
  buildWinLines,
  buildAdjacency,
  LEVEL_CONFIG,
};

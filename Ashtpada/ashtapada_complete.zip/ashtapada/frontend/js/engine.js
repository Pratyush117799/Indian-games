'use strict';

/*
 * GameEngine
 * Manages the full Ashtapada game state and rules.
 * Zero DOM dependencies — testable in isolation.
 */
class GameEngine {
  constructor() {
    this.pieces = [];
    this.currentPlayer = 0;
    this.phase = 'roll';   // 'roll' | 'move' | 'gameover'
    this.winner = null;
    this.diceResult = null;
    this.validMoves = [];
    this.mode = 'vs-ai';
    this.aiDifficulty = 'prince';
    this.moveHistory = [];
  }

  /* ── Setup ──────────────────────────────────────────────── */

  reset(mode = 'vs-ai', aiDifficulty = 'prince') {
    this.mode = mode;
    this.aiDifficulty = aiDifficulty;
    this.currentPlayer = 0;
    this.phase = 'roll';
    this.winner = null;
    this.diceResult = null;
    this.validMoves = [];
    this.moveHistory = [];
    this.pieces = [];

    for (let p = 0; p < NUM_PLAYERS; p++) {
      for (let id = 0; id < PIECES_PER_PLAYER; id++) {
        this.pieces.push({
          player: p,
          id,
          step: -1,        // -1 = off-board
          pieceIndex: p * PIECES_PER_PLAYER + id
        });
      }
    }
  }

  /* ── Dice ───────────────────────────────────────────────── */

  roll() {
    if (this.phase !== 'roll') return null;

    this.diceResult = rollCowries();
    const { value } = this.diceResult;

    if (value === 0) {
      this._nextPlayer();
      return { ...this.diceResult, skipped: true, reason: 'no-mouths' };
    }

    this.validMoves = this._computeValidMoves();

    if (this.validMoves.length === 0) {
      this._nextPlayer();
      return { ...this.diceResult, skipped: true, reason: 'no-valid-moves' };
    }

    this.phase = 'move';
    return { ...this.diceResult, skipped: false };
  }

  /* ── Move ───────────────────────────────────────────────── */

  move(pieceIndex) {
    if (this.phase !== 'move') return null;

    const moveData = this.validMoves.find(m => m.pieceIndex === pieceIndex);
    if (!moveData) return null;

    const piece = this.pieces[pieceIndex];
    const { toStep, fromStep } = moveData;

    piece.step = toStep;

    /* Capture check (castle squares are immune) */
    const captured = [];
    if (!CASTLE_STEPS.has(toStep)) {
      const [dr, dc] = PATH[toStep];
      for (let i = 0; i < this.pieces.length; i++) {
        if (i === pieceIndex) continue;
        const other = this.pieces[i];
        if (other.player === piece.player) continue;
        if (other.step < 0 || other.step >= HOME_STEP) continue;
        const [or, oc] = PATH[other.step];
        if (or === dr && oc === dc) {
          other.step = -1;
          captured.push(i);
        }
      }
    }

    /* Record move */
    this.moveHistory.push({ pieceIndex, fromStep, toStep, captured, player: piece.player });

    /* Win check */
    const winner = this._checkWin();
    if (winner !== null) {
      this.winner = winner;
      this.phase = 'gameover';
    } else {
      this.phase = 'roll';
      this._nextPlayer();
    }

    this.validMoves = [];
    return { fromStep, toStep, captured, winner: this.winner };
  }

  /* ── Queries ─────────────────────────────────────────────── */

  isValidMove(pieceIndex) {
    return this.validMoves.some(m => m.pieceIndex === pieceIndex);
  }

  getValidMoveIndices() {
    return this.validMoves.map(m => m.pieceIndex);
  }

  getPiecesForPlayer(player) {
    return this.pieces.filter(p => p.player === player);
  }

  getOffBoardPieces(player) {
    return this.pieces.filter(p => p.player === player && p.step === -1);
  }

  getHomePieces(player) {
    return this.pieces.filter(p => p.player === player && p.step >= HOME_STEP);
  }

  getOnBoardPieces(player) {
    return this.pieces.filter(p => p.player === player && p.step >= 0 && p.step < HOME_STEP);
  }

  pieceBoardCell(piece) {
    if (piece.step < 0) return null;
    return PATH[piece.step];
  }

  homeCount(player) {
    return this.getHomePieces(player).length;
  }

  /* ── Private ─────────────────────────────────────────────── */

  _computeValidMoves() {
    const { currentPlayer, diceResult, pieces } = this;
    if (!diceResult || diceResult.value === 0) return [];

    const moves = [];
    const value = diceResult.value;

    for (let i = 0; i < pieces.length; i++) {
      const p = pieces[i];
      if (p.player !== currentPlayer) continue;
      if (p.step >= HOME_STEP) continue; // already home

      if (p.step === -1) {
        /* Enter board at step 0 */
        moves.push({ pieceIndex: i, fromStep: -1, toStep: 0 });
      } else {
        const toStep = Math.min(p.step + value, PATH_LENGTH - 1);
        moves.push({ pieceIndex: i, fromStep: p.step, toStep });
      }
    }

    return moves;
  }

  _checkWin() {
    for (let p = 0; p < NUM_PLAYERS; p++) {
      if (this.getPiecesForPlayer(p).every(pc => pc.step >= HOME_STEP)) {
        return p;
      }
    }
    return null;
  }

  _nextPlayer() {
    this.currentPlayer = 1 - this.currentPlayer;
    this.diceResult = null;
  }

  /* ── Serialise (for multiplayer/replay) ─────────────────── */

  toJSON() {
    return {
      pieces: this.pieces.map(p => ({ ...p })),
      currentPlayer: this.currentPlayer,
      phase: this.phase,
      winner: this.winner,
      diceResult: this.diceResult,
      moveHistory: [...this.moveHistory]
    };
  }

  fromJSON(data) {
    Object.assign(this, data);
    this.pieces = data.pieces.map(p => ({ ...p }));
  }
}

/**
 * main.js
 * Arthashastra: Rise of Chandragupta — game entry point.
 * Owns all mutable state. Wires UI, map, logic, and Chanakya AI.
 */

import {
  createInitialState, createTerritories, FACTIONS,
  doAction, researchTech, invadeTerritory, annexTerritory,
  fortifyTerritory, spyOnTerritory, processTurnEnd,
  checkVictory, serialiseState, deserialiseState,
} from './logic.js';

import { MapRenderer, TERRITORY_SHAPES } from './map.js';
import { getAdvice, getActionAdvice, getTerritoryAdvice, getTurnVerdict, getFinalVerdict } from './chanakya.js';
import {
  updateResources, updateStatBars, renderTerritoryList,
  renderFactionList, renderTechList, addEvent, showAdvisor,
  updateSelectionBar, updateActionButtons, showNotification,
  showModal, showVictory, updatePlayerHUD, updateSaveIndicator,
} from './ui.js';
import { getPlayer, getOrCreateGuest, saveGame, loadSave, recordCampaignEnd, getCurrentTitle, calculateLegacyScore } from '../portal/js/auth.js';

/* ═══════════════════════════════════════════════════════
   GAME STATE
═══════════════════════════════════════════════════════ */
let state       = createInitialState();
let territories = createTerritories();
let gameOver    = false;
let mapRenderer = null;
let currentPlayer = null;
let activeSaveSlot = 0;

/* ═══════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  // Load player identity
  currentPlayer = getPlayer() || getOrCreateGuest();
  updatePlayerHUD({ ...currentPlayer, currentTitle: getCurrentTitle(currentPlayer) });

  // Map renderer
  mapRenderer = new MapRenderer(
    'map-container',
    onTerritoryClick,
    onTerritoryHover,
  );

  // Check for a loaded save (passed via sessionStorage from portal)
  const savedSlot = sessionStorage.getItem('arthashastra_load_slot');
  if (savedSlot !== null) {
    const slot = parseInt(savedSlot, 10);
    const loaded = loadSave(currentPlayer, slot);
    if (loaded) {
      state       = deserialiseState(loaded.state);
      territories = territories.map(t => {
        const patch = loaded.territories.find(x => x.id === t.id);
        return patch ? { ...t, ...patch } : t;
      });
      state.researched = loaded.researched;
      activeSaveSlot = slot;
      sessionStorage.removeItem('arthashastra_load_slot');
    }
  }

  initGame();
});

function initGame() {
  renderAll();
  mapRenderer.render(buildMapTerritories());

  showAdvisor(
    "Welcome, Samrat! The year is 321 BCE. Magadha awaits your command. Expand your empire through wisdom, strategy, and righteous warfare.",
    null,
    false,
  );

  addEvent('🏰 Year 321 BCE — Chandragupta Maurya ascends the throne of Magadha.', 'important');
  addEvent('📜 Acharya Chanakya whispers: The path to Chakravarti Samrat begins now.', 'neutral');

  updateSaveIndicator(activeSaveSlot);

  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !gameOver)  endTurn();
    if (e.key === 'Escape')              closeModal();
    if (e.key === 's' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); quickSave(); }
  });
}

function renderAll() {
  updateResources(state);
  updateStatBars(state);
  updateActionButtons(state);
  renderTerritoryList(territories, state.selectedTerritory?.id, onTerritoryPanelSelect);
  renderFactionList(territories);
  renderTechList(state.researched, onResearch);
}

/* ═══════════════════════════════════════════════════════
   MAP TERRITORY DATA
   Merges logic territory data with map shape IDs.
═══════════════════════════════════════════════════════ */
function buildMapTerritories() {
  const map = {};
  territories.forEach(t => {
    if (TERRITORY_SHAPES[t.id]) {
      map[t.id] = { ...t };
    }
  });
  return map;
}

/* ═══════════════════════════════════════════════════════
   MAP EVENTS
═══════════════════════════════════════════════════════ */
function onTerritoryClick(id) {
  const t = territories.find(x => x.id === id);
  if (!t) return;
  state = { ...state, selectedTerritory: t };
  updateSelectionBar(t, state);

  // Chanakya advice for this territory
  const advice = getTerritoryAdvice(t, state, FACTIONS);
  showAdvisor(advice);

  renderTerritoryList(territories, id, onTerritoryPanelSelect);
}

function onTerritoryHover(id) {
  // Tooltip handled by map renderer via SVG
}

function onTerritoryPanelSelect(id) {
  const t = territories.find(x => x.id === id);
  if (t) { mapRenderer._handleClick(id); onTerritoryClick(id); }
}

/* ═══════════════════════════════════════════════════════
   PLAYER ACTIONS (called from HTML onclick)
═══════════════════════════════════════════════════════ */
window.doActionBtn = function(actionType) {
  if (gameOver) return;
  const result = doAction(actionType, state, territories);

  if (result.result === 'no_actions') {
    showNotification('No Actions Left', 'End the turn to continue.', 'neutral'); return;
  }
  if (result.result === 'insufficient_gold') {
    showNotification('Insufficient Suvarna', result.message, 'bad'); return;
  }

  state = result.state;

  const advice = getActionAdvice(actionType);
  showAdvisor(advice);
  addEvent(actionEventText(actionType, state), 'neutral');

  renderAll();
  autoSave();
};

function actionEventText(type, s) {
  const texts = {
    recruit:   `⚔ Sena reinforced. Army: ${s.resources.army}`,
    spy:       `🕵 Gupta agents deployed. Influence: ${s.stats.influence}%`,
    trade:     `🐪 Vanik Path opened. Gold delta: +${s.deltas.gold}/turn`,
    dharma:    `🪷 Dharma spread. Righteousness: ${s.resources.dharma}`,
    harvest:   `🌾 Krishi Vikas complete. Food stores: ${s.resources.food}`,
    diplomacy: `📯 Rajdoot dispatched. Influence: ${s.stats.influence}%`,
  };
  return texts[type] || 'Action taken.';
}

/* ═══════════════════════════════════════════════════════
   TERRITORY ACTIONS (invade, annex, spy, fortify)
═══════════════════════════════════════════════════════ */
window.invadeSelected = function() {
  const t = state.selectedTerritory;
  if (!t || gameOver) return;

  if (t.owner === 'player') {
    // Fortify
    const result = fortifyTerritory(t, state);
    if (result.result === 'insufficient_gold') {
      showNotification('Insufficient Gold', 'Need 80 Suvarna to fortify.', 'bad'); return;
    }
    territories = territories.map(x =>
      x.id === t.id ? { ...x, strength: x.strength + result.strengthGain } : x
    );
    state = result.state;
    addEvent(`🏗 ${t.name} fortified. Strength +${result.strengthGain}.`, 'good');
    showNotification('Fortified!', `${t.name} is stronger now.`, 'good');
  } else {
    // Invade modal
    showModal(
      `⚔ Invade ${t.name}?`,
      `${t.name} (${t.hindi}) is held by ${FACTIONS[t.owner]?.name || 'Unknown'}.\n\nTheir strength: ${t.strength}\nYour army: ${state.resources.army}\nSuccess chance: ~${Math.round(Math.min(90, (state.resources.army / (t.strength * 1.3)) * 100))}%\n\nCost: Army casualties. Dharma -8.`,
      [
        { label: '⚔ LAUNCH INVASION', cls: 'btn-danger', action: () => executeInvade(t) },
        { label: '↩ RETREAT',          cls: '',           action: () => {} },
      ],
    );
  }
};

function executeInvade(t) {
  const result = invadeTerritory(t, state, territories, FACTIONS);
  state       = result.state;
  territories = result.territories;

  if (result.result === 'victory') {
    addEvent(`🏆 ${t.name} conquered! Territory added to the empire.`, 'good');
    showNotification('Victory!', `${t.name} is now under the Mauryan banner.`, 'good');
    showAdvisor(
      `${t.name} falls! The Arthashastra's Vigraha doctrine bears fruit. But consolidate before you strike again, Samrat.`,
    );
    mapRenderer.render(buildMapTerritories());
    checkForVictory();
  } else {
    addEvent(`💀 Invasion of ${t.name} failed! Army weakened.`, 'bad');
    showNotification('Defeat', `Your forces retreat from ${t.name}.`, 'bad');
    showAdvisor(
      `We could not take ${t.name} today. The Arthashastra counsels: when defeated, do not despair — assess, recover, and return stronger.`,
    );
  }

  renderAll();
  autoSave();
}

window.annexSelected = function() {
  const t = state.selectedTerritory;
  if (!t || gameOver) return;

  if (t.owner === 'player') {
    showNotification('Already Yours', `${t.name} is part of your empire.`, 'neutral'); return;
  }
  if (t.owner !== 'neutral') {
    showModal(
      `📯 Diplomatic Mission to ${t.name}`,
      `${FACTIONS[t.owner]?.name} controls ${t.name}. Direct diplomacy with a hostile faction is difficult.\n\nThis mission may improve relations but is unlikely to secure the territory without prior military pressure.`,
      [
        { label: '📯 SEND DELEGATION', cls: '', action: () => executeDiplomacy(t) },
        { label: '↩ CANCEL',           cls: '', action: () => {} },
      ],
    );
    return;
  }

  showModal(
    `🤝 Annex ${t.name}?`,
    `${t.name} (${t.hindi}) is an independent territory.\n\nYour influence: ${state.stats.influence}%\nYour dharma: ${state.resources.dharma}\nDiplomatic cost: 100 Suvarna\n\nSuccess chance depends on your reputation.`,
    [
      { label: '🤝 SEND RAJDOOT', cls: '', action: () => executeAnnex(t) },
      { label: '↩ CANCEL',        cls: '', action: () => {} },
    ],
  );
};

function executeAnnex(t) {
  const result = annexTerritory(t, state, territories);
  state       = result.state;
  territories = result.territories;

  if (result.result === 'annexed') {
    addEvent(`🤝 ${t.name} annexed peacefully through diplomacy.`, 'good');
    showNotification('Annexation Success!', `${t.name} joins the Mauryan Empire.`, 'good');
    showAdvisor('A bloodless victory, Samrat! Sama — the art of conciliation — costs far less than war. Kautilya would approve.');
    mapRenderer.render(buildMapTerritories());
    checkForVictory();
  } else {
    addEvent(`📯 Diplomatic mission to ${t.name} rebuffed. 50 gold spent.`, 'bad');
    showNotification('Mission Failed', `${t.name} declines our overtures for now.`, 'neutral');
  }
  renderAll();
  autoSave();
}

function executeDiplomacy(t) {
  state = { ...state, resources: { ...state.resources }, stats: { ...state.stats } };
  state.resources.gold = Math.max(0, state.resources.gold - 50);
  state.stats.influence = Math.min(100, state.stats.influence + 5);
  addEvent(`📯 Delegation sent to ${FACTIONS[t.owner]?.name}. Relations slightly improved.`, 'neutral');
  showNotification('Delegation Sent', 'Relations improving.', 'neutral');
  renderAll();
}

window.spySelected = function() {
  const t = state.selectedTerritory;
  if (!t || gameOver || t.owner === 'player') return;

  const result = spyOnTerritory(t, state, territories);
  state       = result.state;
  territories = result.territories;

  if (result.result === 'spy_success') {
    addEvent(`🕵 Spies sabotage ${t.name}. Strength reduced by ${result.reduction}.`, 'good');
    showNotification('Spies Succeed!', `${t.name}'s strength reduced by ${result.reduction}.`, 'good');
    showAdvisor('Our Gupta agents operate unseen. A weakened enemy costs fewer soldiers to defeat. This is the Arthashastra way.');
    mapRenderer.render(buildMapTerritories());
  } else if (result.result === 'spy_caught') {
    addEvent(`🚨 Our spies were caught in ${t.name}! Dharma reduced.`, 'bad');
    showNotification('Spies Caught', 'Our agents were exposed. Dharma suffers.', 'bad');
  } else {
    showNotification('Insufficient Gold', 'Spying requires more Suvarna.', 'bad');
  }
  renderAll();
  autoSave();
};

/* ═══════════════════════════════════════════════════════
   RESEARCH
═══════════════════════════════════════════════════════ */
function onResearch(techId) {
  if (gameOver) return;
  const result = researchTech(techId, state);

  if (result.result === 'already_known') {
    showNotification('Already Known', 'This wisdom is already yours.', 'neutral'); return;
  }
  if (result.result === 'insufficient_gold') {
    showNotification('Insufficient Suvarna', `Need ${result.needed} gold to learn this.`, 'bad'); return;
  }

  state = result.state;
  const tech = result.tech;
  addEvent(`📖 Mastered: ${tech.name} — ${tech.desc}`, 'important');
  showAdvisor(`"${tech.name}" — the wisdom of Arthashastra reveals itself. ${tech.shloka}`, tech.shloka);
  showNotification(`${tech.emoji} ${tech.name} Learned!`, tech.desc, 'good');
  renderAll();
  autoSave();
}

/* ═══════════════════════════════════════════════════════
   END TURN
═══════════════════════════════════════════════════════ */
window.endTurn = function() {
  if (gameOver) return;

  const actionsUsed = 3 - state.actionsLeft;
  const verdict = getTurnVerdict(actionsUsed, state);

  const result = processTurnEnd(state, territories, FACTIONS);
  state       = result.state;
  territories = result.territories;

  // Add turn events
  result.events.forEach(ev => addEvent(ev.text, ev.type));
  addEvent(`⏭ Turn ${state.turn - 1} complete. Year: ${state.year + 1} BCE.`, 'neutral');

  // Chanakya end-of-turn advice
  const advice = getAdvice(state, territories, FACTIONS);
  showAdvisor(advice.text, advice.shloka);

  mapRenderer.render(buildMapTerritories());
  renderAll();
  checkForVictory();
  autoSave();
};

/* ═══════════════════════════════════════════════════════
   VICTORY CHECK
═══════════════════════════════════════════════════════ */
function checkForVictory() {
  const check = checkVictory(territories);
  if (!check.won) return;

  gameOver = true;
  setTimeout(() => {
    const verdict = getFinalVerdict(state, check.playerCount, check.total);

    // Record to player profile
    const legacyPts = calculateLegacyScore({
      territoriesOwned: check.playerCount,
      totalTerritories: check.total,
      dharma:           state.resources.dharma,
      turns:            state.turn,
      researched:       state.researched.size,
    });
    const newTitles = recordCampaignEnd(currentPlayer, { won: true, legacyPoints: legacyPts });
    if (newTitles.length > 0) {
      addEvent(`🏆 New title earned: ${newTitles.map(t => t.label).join(', ')}!`, 'important');
    }

    showVictory(verdict.title, verdict.narrative + `\n\nLegacy Points earned: +${legacyPts}`);
  }, 800);
}

/* ═══════════════════════════════════════════════════════
   SAVE / LOAD
═══════════════════════════════════════════════════════ */
function autoSave() {
  if (!currentPlayer || gameOver) return;
  saveGame(currentPlayer, activeSaveSlot, serialiseState(state), territories, state.researched);
}

function quickSave() {
  autoSave();
  showNotification('Game Saved', `Saved to Slot ${activeSaveSlot + 1}`, 'good');
}

window.quickSave = quickSave;

/* ═══════════════════════════════════════════════════════
   MISC WINDOW EXPORTS (called from HTML inline)
═══════════════════════════════════════════════════════ */
window.closeModal  = () => { document.getElementById('modal')?.classList.remove('active'); };
window.resetView   = () => mapRenderer?.resetView();
window.returnToPortal = () => { window.location.href = '../portal/index.html'; };

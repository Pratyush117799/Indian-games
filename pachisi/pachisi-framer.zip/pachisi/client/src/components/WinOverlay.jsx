import { motion, AnimatePresence } from 'framer-motion';
import { COLORS, NAMES, TEAMS } from '../game/config.js';
import { useGame } from '../context/GameContext.jsx';

const PARTICLE_COUNT = 24;

export default function WinOverlay() {
  const { over, winner } = useGame();
  if (!over || winner === null) return null;

  const team    = winner;
  const players = [0,1,2,3].filter(p => TEAMS[p] === team);
  const color   = team === 0 ? '#E8C96A' : '#C93A3A';

  return (
    <AnimatePresence>
      <motion.div
        className="win-overlay"
        initial={{ opacity:0 }}
        animate={{ opacity:1 }}
        transition={{ duration:0.7, delay:0.3 }}
      >
        {/* Particle burst */}
        <div className="particles">
          {Array.from({length:PARTICLE_COUNT},(_,i)=>{
            const angle = (i / PARTICLE_COUNT) * 360;
            const dist  = 120 + Math.random() * 160;
            const rad   = angle * Math.PI / 180;
            const tx    = Math.cos(rad) * dist;
            const ty    = Math.sin(rad) * dist;
            const size  = 4 + Math.random() * 8;
            return (
              <motion.div key={i}
                style={{
                  position:'absolute', top:'50%', left:'50%',
                  width:size, height:size,
                  borderRadius: Math.random() > 0.5 ? '50%' : '2px',
                  background: i%3===0 ? '#E8C96A' : i%3===1 ? color : '#FAF3E0',
                  transformOrigin:'center',
                }}
                initial={{ x:0, y:0, scale:1, opacity:1, rotate:0 }}
                animate={{ x:tx, y:ty, scale:0, opacity:0, rotate:Math.random()*360 }}
                transition={{ duration:1.4, delay:0.4+i*0.025, ease:'easeOut' }}
              />
            );
          })}
        </div>

        {/* Devanagari victory word */}
        <motion.div className="wo-deva"
          initial={{ scale:0.3, opacity:0 }}
          animate={{ scale:[0.3,1.15,1], opacity:1 }}
          transition={{ type:'spring', stiffness:300, damping:22, delay:0.5 }}
          style={{ textShadow:`0 0 60px ${color}` }}
        >
          विजय!
        </motion.div>

        {/* Title */}
        <motion.h2 className="wo-title"
          initial={{ y:30, opacity:0 }}
          animate={{ y:0,  opacity:1 }}
          transition={{ delay:0.8, type:'spring', stiffness:280, damping:24 }}
        >
          Team {team===0?'A':'B'} Wins!
        </motion.h2>

        {/* Players */}
        <motion.p className="wo-sub"
          initial={{ y:20, opacity:0 }}
          animate={{ y:0,  opacity:1 }}
          transition={{ delay:1.0, duration:0.5 }}
        >
          {players.map(p=>NAMES[p]).join(' & ')} — The Emperor is pleased.
        </motion.p>

        {/* Player colour badges */}
        <motion.div style={{display:'flex',gap:12,marginBottom:30}}
          initial={{ scale:0, opacity:0 }}
          animate={{ scale:1, opacity:1 }}
          transition={{ delay:1.2, type:'spring', stiffness:400 }}
        >
          {players.map(p=>(
            <motion.div key={p}
              style={{
                width:44, height:44, borderRadius:'50%',
                background:COLORS[p], border:'2px solid rgba(255,255,255,0.3)',
                boxShadow:`0 0 20px ${COLORS[p]}`,
              }}
              animate={{ scale:[1,1.15,1] }}
              transition={{ duration:1.8, repeat:Infinity, delay:p*0.3 }}
            />
          ))}
        </motion.div>

        <motion.button
          className="btn-royal"
          onClick={() => location.reload()}
          initial={{ y:20, opacity:0 }}
          animate={{ y:0,  opacity:1 }}
          whileHover={{ scale:1.05, boxShadow:'0 0 36px rgba(201,153,58,0.5)' }}
          whileTap={{ scale:0.96 }}
          transition={{ delay:1.4 }}
        >
          Play Again
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}

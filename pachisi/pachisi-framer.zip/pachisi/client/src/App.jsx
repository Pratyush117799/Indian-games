import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { GameProvider, useGame } from './context/GameContext.jsx';
import IntroScreen from './components/IntroScreen.jsx';
import FactCard    from './components/FactCard.jsx';
import PlayerCard  from './components/PlayerCard.jsx';
import GameLog     from './components/GameLog.jsx';
import Board       from './components/Board.jsx';
import PawnLayer   from './components/PawnLayer.jsx';
import CowriePanel from './components/CowriePanel.jsx';
import WinOverlay  from './components/WinOverlay.jsx';

export default function App() {
  const [started, setStarted] = useState(false);
  return (
    <AnimatePresence mode="wait">
      {!started
        ? <IntroScreen key="intro" onStart={() => setStarted(true)}/>
        : <GameRoot    key="game"/>
      }
    </AnimatePresence>
  );
}

function GameRoot() {
  return (
    <GameProvider>
      <motion.div
        initial={{ opacity:0, y:14 }}
        animate={{ opacity:1, y:0  }}
        transition={{ duration:0.55, ease:'easeOut' }}
        style={{ position:'relative', zIndex:1 }}
      >
        <GameLayout/>
        <FactCard/>
        <WinOverlay/>
      </motion.div>
    </GameProvider>
  );
}

function GameLayout() {
  const { hint, phase } = useGame();
  return (
    <div className="game-root">
      <header className="game-header">
        <span className="g-brand">Krida · पचीसी · Pachisi</span>
        <nav className="g-nav">
          <button className="btn-ghost" onClick={() => location.reload()}>New Game</button>
        </nav>
      </header>

      <div className="g-main">
        {/* LEFT */}
        <aside className="panel">
          <PlayerCard player={0}/>
          <PlayerCard player={2}/>
          <CowriePanel/>
          <motion.div className="hint-panel"
            animate={{ borderColor: phase === 'select' ? 'rgba(201,153,58,0.65)' : 'rgba(201,153,58,0.26)' }}
            transition={{ duration:0.4 }}
          >
            <AnimatePresence mode="wait">
              <motion.p key={hint} className="hint-text"
                initial={{ opacity:0, y:5 }}
                animate={{ opacity:1, y:0 }}
                exit={{    opacity:0, y:-5 }}
                transition={{ duration:0.22 }}
              >
                {hint}
              </motion.p>
            </AnimatePresence>
          </motion.div>
        </aside>

        {/* BOARD */}
        <motion.div id="board-wrap"
          initial={{ scale:0.90, opacity:0 }}
          animate={{ scale:1,    opacity:1 }}
          transition={{ type:'spring', stiffness:160, damping:22, delay:0.18 }}
        >
          <Board><PawnLayer/></Board>
        </motion.div>

        {/* RIGHT */}
        <aside className="panel">
          <PlayerCard player={1}/>
          <PlayerCard player={3}/>
          <GameLog/>
          <StatsPanel/>
        </aside>
      </div>
    </div>
  );
}

function StatsPanel() {
  const { setStats, stats } = useGame();
  useEffect(() => {
    fetch('/api/games/meta/stats')
      .then(r => r.json())
      .then(d => { if (d?.ok) setStats(d.stats); })
      .catch(() => {});
  }, []);
  if (!stats) return null;
  return (
    <motion.div className="stats-panel"
      initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:0.9 }}
    >
      {[['Games played',stats.gamesPlayed],['Team A wins',stats.teamAWins],['Team B wins',stats.teamBWins]]
        .map(([l,v]) => (
          <div className="stats-row" key={l}><span>{l}</span><strong>{v??'—'}</strong></div>
        ))}
    </motion.div>
  );
}

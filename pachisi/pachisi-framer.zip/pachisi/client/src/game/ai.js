import { TEAMS } from './config.js';
import { PATHS, isCastle, isSafe } from './paths.js';
import { getMovable, getTargetPos } from './engine.js';

export function chooseMove(pawns, player, val, grace) {
  const movable = getMovable(pawns, player, val, grace);
  if (!movable.length) return null;
  let best = -Infinity, pick = movable[0];
  for (const i of movable) {
    const s = _score(pawns, player, i, val, grace);
    if (s > best) { best = s; pick = i; }
  }
  return pick;
}

function _score(pawns, player, pawnIdx, val, grace) {
  const {pos} = pawns[player][pawnIdx];
  const tp = pos === -1 ? 0 : pos + val;
  if (tp === 80) return 10000;
  let s = tp;
  if (tp < 80) {
    const sq = PATHS[player][tp];
    if (isCastle(sq.x, sq.y)) s += 22;
    if (tp >= 72) s += 38;
    for (let p = 0; p < 4; p++) {
      if (p === player || TEAMS[p] === TEAMS[player]) continue;
      for (let i = 0; i < 4; i++) {
        const {pos:opos} = pawns[p][i];
        if (opos < 0 || opos >= 80 || isSafe(p, opos)) continue;
        const osq = PATHS[p][opos];
        if (osq.x === sq.x && osq.y === sq.y) s += 70;
      }
    }
    if (_exposed(pawns, player, tp, sq)) s -= 18;
  }
  if (pos === -1 && grace) s += 30;
  if (pos > 40) s += 12;
  return s;
}

function _exposed(pawns, myP, targetIdx, sq) {
  if (isSafe(myP, targetIdx)) return false;
  for (let p = 0; p < 4; p++) {
    if (p === myP || TEAMS[p] === TEAMS[myP]) continue;
    for (let i = 0; i < 4; i++) {
      const {pos} = pawns[p][i];
      if (pos < 0 || pos >= 80) continue;
      for (const v of [2,3,4,5,6,10,25]) {
        const tp2 = pos + v;
        if (tp2 >= 0 && tp2 < 80) {
          const tsq = PATHS[p][tp2];
          if (tsq.x === sq.x && tsq.y === sq.y) return true;
        }
      }
    }
  }
  return false;
}

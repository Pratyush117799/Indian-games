import type { Metadata } from 'next';
import '@/styles/globals.css';
import { Toaster } from 'react-hot-toast';
import Navbar from '@/components/layout/Navbar';

export const metadata: Metadata = {
  title:       'Krida — Traditional Indian Games',
  description: 'Play Kattam Vilayattu and Paramapadam online. Ancient Tamil board games, revived.',
  icons:       { icon: '/assets/icons/favicon.ico' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-cream">
        <Navbar />
        <main className="flex-1">{children}</main>
        <footer className="text-center text-xs text-clay/50 py-4 border-t border-clay/10">
          © {new Date().getFullYear()} Krida · Traditional Indian Games Platform ·{' '}
          <span className="font-tamil">கட்டம் விளையாட்டு · பரமபதம்</span>
        </footer>
        <Toaster
          position="top-right"
          toastOptions={{
            style: { background: '#FFF8E7', border: '1px solid #8B4513', color: '#5C2A00' },
          }}
        />
      </body>
    </html>
  );
}

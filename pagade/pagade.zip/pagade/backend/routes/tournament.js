const express = require('express');
const router = express.Router();
const svc = require('../services/tournamentService');

router.get('/', async (req, res, next) => {
  try {
    const tournaments = await svc.listTournaments();
    res.json({ tournaments });
  } catch (err) { next(err); }
});

router.post('/', async (req, res, next) => {
  try {
    const { name, maxPlayers } = req.body;
    if (!name) return res.status(400).json({ error: { message: 'name required' } });
    const result = await svc.createTournament({ name, maxPlayers });
    res.status(201).json(result);
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const t = await svc.getTournament(req.params.id);
    if (!t) return res.status(404).json({ error: { message: 'Not found' } });
    res.json({ tournament: t });
  } catch (err) { next(err); }
});

router.post('/:id/join', async (req, res, next) => {
  try {
    const { playerId } = req.body;
    if (!playerId) return res.status(400).json({ error: { message: 'playerId required' } });
    const result = await svc.joinTournament({ tournamentId: req.params.id, playerId });
    res.json(result);
  } catch (err) { next(err); }
});

module.exports = router;

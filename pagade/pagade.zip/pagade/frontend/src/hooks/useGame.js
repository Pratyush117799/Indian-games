/**
 * useGame v2 — central hook with move history, animation support, resume.
 */
import { useReducer, useCallback, useEffect, useRef, useState } from 'react';
import { initGame, applyRoll, applyMove, roll } from '../game/engine';
import { chooseBestMove, aiThinkDelay } from '../game/ai';
import { AI_LEVEL, GAME_MODE, STATUS } from '../game/constants';

function gameReducer(state, action) {
  switch (action.type) {
    case 'INIT':
      return { ...action.payload, animatingPawn: null, lastEvent: null, history: [] };
    case 'RESUME':
      return { ...action.payload, animatingPawn: null, lastEvent: null, history: action.payload.history || [] };
    case 'SET_STATE':
      return { ...action.payload, animatingPawn: state.animatingPawn, lastEvent: state.lastEvent, history: state.history };
    case 'START_ANIMATE':
      return { ...state, phase: 'ANIMATE', animatingPawn: action.pawnKey };
    case 'END_ANIMATE':
      return { ...state, animatingPawn: null };
    case 'SET_EVENT':
      return { ...state, lastEvent: action.event };
    case 'ADD_HISTORY':
      return { ...state, history: [...(state.history || []), action.entry].slice(-40) };
    default:
      return state;
  }
}

const INIT_STATE = {
  phase: 'IDLE', players: [], currentPlayer: 0,
  diceResult: null, validMoves: [], lastCapture: null,
  winner: null, moveNumber: 0, finishOrder: [],
  animatingPawn: null, lastEvent: null, history: [],
};

export function useGame() {
  const [state, dispatch] = useReducer(gameReducer, INIT_STATE);
  const aiRunning = useRef(false);
  const [passPlayPrompt, setPassPlayPrompt] = useState(null);

  const startGame = useCallback(({ mode, numPlayers = 4, aiPlayers = [], diceStyle, aiLevel }) => {
    const initial = initGame({ mode, numPlayers, aiPlayers, diceStyle });
    if (aiLevel) initial.players.forEach(p => { if (p.isAi) p.aiLevel = aiLevel; });
    dispatch({ type: 'INIT', payload: initial });
  }, []);

  const resumeGame = useCallback((savedState) => {
    dispatch({ type: 'RESUME', payload: savedState });
  }, []);

  const rollDice = useCallback(() => {
    if (state.phase !== 'ROLL') return;
    const diceResult = roll(state.diceStyle);
    dispatch({ type: 'SET_EVENT', event: { type: 'ROLL', ...diceResult } });
    dispatch({ type: 'ADD_HISTORY', entry: { type: 'ROLL', playerId: state.currentPlayer, label: `${diceResult.total}${diceResult.isDoublet ? ' ✦' : ''}` }});
    const next = applyRoll(state, diceResult);
    dispatch({ type: 'SET_STATE', payload: next });
  }, [state]);

  const selectMove = useCallback((moveAction, onAnimStart) => {
    if (state.phase !== 'MOVE') return;
    const pawnKey = `${moveAction.pawnId}-${state.currentPlayer}`;
    dispatch({ type: 'START_ANIMATE', pawnKey });
    onAnimStart?.();

    setTimeout(() => {
      const next = applyMove(state, moveAction);
      let eventType = 'MOVE';
      if (next.lastCapture)                    eventType = 'CAPTURE';
      else if (moveAction.newStatus === 'HOME') eventType = 'HOME';
      else if (moveAction.newStatus === 'SAFE') eventType = 'SAFE';

      const histLabel = eventType === 'CAPTURE' ? `cut P${(next.lastCapture?.playerId ?? 0)+1}`
                      : eventType === 'HOME'    ? 'HOME!'
                      : eventType === 'SAFE'    ? 'safe'
                      : `+${state.diceResult?.total || ''}`;

      dispatch({ type: 'SET_EVENT', event: { type: eventType, ...moveAction, attackerId: state.currentPlayer } });
      dispatch({ type: 'ADD_HISTORY', entry: { type: eventType, playerId: state.currentPlayer, label: histLabel }});
      dispatch({ type: 'END_ANIMATE' });
      dispatch({ type: 'SET_STATE', payload: next });

      if (next.phase === 'ROLL' && state.mode === GAME_MODE.PASS_PLAY) {
        const np = next.players[next.currentPlayer];
        if (np && !np.isAi) {
          setPassPlayPrompt({ playerName: np.name, color: np.color, onReady: () => setPassPlayPrompt(null) });
        }
      }
    }, 480);
  }, [state]);

  useEffect(() => {
    const player = state.players?.[state.currentPlayer];
    if (!player?.isAi) return;
    if (!['ROLL','MOVE'].includes(state.phase)) return;
    if (aiRunning.current) return;
    aiRunning.current = true;

    async function runAi() {
      if (state.phase === 'ROLL') {
        await aiThinkDelay(player.aiLevel || AI_LEVEL.PRINCE);
        const dr = roll(state.diceStyle);
        dispatch({ type: 'SET_EVENT', event: { type: 'ROLL', ...dr } });
        dispatch({ type: 'ADD_HISTORY', entry: { type: 'ROLL', playerId: state.currentPlayer, label: `${dr.total}${dr.isDoublet ? ' ✦' : ''}` }});
        const rolled = applyRoll(state, dr);
        dispatch({ type: 'SET_STATE', payload: rolled });
        aiRunning.current = false;
        return;
      }
      if (state.phase === 'MOVE') {
        await aiThinkDelay(player.aiLevel || AI_LEVEL.PRINCE);
        const best = chooseBestMove(state, player.aiLevel || AI_LEVEL.PRINCE);
        if (!best) { aiRunning.current = false; return; }
        dispatch({ type: 'START_ANIMATE', pawnKey: `${best.pawnId}-${state.currentPlayer}` });
        await new Promise(r => setTimeout(r, 520));
        const next = applyMove(state, best);
        let et = 'MOVE';
        if (next.lastCapture)           et = 'CAPTURE';
        else if (best.newStatus==='HOME') et = 'HOME';
        else if (best.newStatus==='SAFE') et = 'SAFE';
        dispatch({ type: 'SET_EVENT', event: { type: et, ...best, attackerId: state.currentPlayer } });
        dispatch({ type: 'ADD_HISTORY', entry: { type: et, playerId: state.currentPlayer, label: et==='CAPTURE'?`cut P${(next.lastCapture?.playerId??0)+1}`:et==='HOME'?'HOME!':et==='SAFE'?'safe':`+${state.diceResult?.total||''}` }});
        dispatch({ type: 'END_ANIMATE' });
        dispatch({ type: 'SET_STATE', payload: next });
        aiRunning.current = false;
      }
    }
    runAi().catch(() => { aiRunning.current = false; });
  }, [state.phase, state.currentPlayer, state.players]);

  return {
    state, startGame, resumeGame, rollDice, selectMove,
    passPlayPrompt,
    isCurrentPlayerHuman: () => { const p = state.players?.[state.currentPlayer]; return p && !p.isAi; },
    getValidMovesForPawn: (id) => (state.validMoves||[]).filter(m=>m.pawnId===id),
  };
}

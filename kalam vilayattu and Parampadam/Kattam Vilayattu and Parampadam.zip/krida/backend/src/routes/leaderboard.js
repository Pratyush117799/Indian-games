const router = require('express').Router();
const ctrl   = require('../controllers/leaderboardController');
const { authenticate } = require('../middleware/auth');

router.get('/:gameSlug',     ctrl.getLeaderboard);
router.get('/:gameSlug/me',  authenticate, ctrl.getMyRank);

module.exports = router;

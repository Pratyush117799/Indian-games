# Krida — Traditional Indian Games Platform
> **Kattam Vilayattu** (கட்டம் விளையாட்டு) &  **Paramapadam** (பரமபதம்)
> Real-time multiplayer · Leaderboards · Full game history & replay

---

## Stack

| Layer      | Technology                              |
|------------|-----------------------------------------|
| Frontend   | Next.js 14 · TypeScript · Tailwind CSS  |
| State      | Zustand · Socket.IO-client              |
| Backend    | Node.js · Express · Socket.IO           |
| Database   | PostgreSQL 15                           |
| Auth       | JWT (access + refresh) · bcrypt         |
| Realtime   | Socket.IO WebSockets                    |

---

## Project Structure

```
krida/
├── frontend/                   # Next.js App Router
│   └── src/
│       ├── app/
│       │   ├── page.tsx                  # Home / game catalog
│       │   ├── layout.tsx                # Root layout + Navbar
│       │   ├── auth/login/page.tsx
│       │   ├── auth/register/page.tsx
│       │   ├── games/
│       │   │   ├── kattam-vilayattu/play/page.tsx
│       │   │   └── paramapadam/play/page.tsx
│       │   ├── leaderboard/page.tsx
│       │   └── history/page.tsx
│       ├── components/
│       │   ├── layout/Navbar.tsx
│       │   ├── games/
│       │   │   ├── RoomLobby.tsx
│       │   │   ├── kattam/KattamBoard.tsx
│       │   │   └── paramapadam/ParamapadamBoard.tsx
│       ├── store/
│       │   ├── authStore.ts              # Zustand auth (persisted)
│       │   └── gameStore.ts             # Room + live game state
│       ├── lib/
│       │   ├── api.ts                   # Axios + silent token refresh
│       │   └── socket.ts               # Socket.IO singleton
│       ├── types/index.ts              # All shared TypeScript types
│       └── styles/globals.css
│
├── backend/
│   └── src/
│       ├── index.js                    # Express + Socket.IO server
│       ├── config/db.js               # PostgreSQL pool
│       ├── utils/
│       │   ├── logger.js              # Winston
│       │   └── jwt.js                 # Token sign/verify/rotate
│       ├── middleware/
│       │   ├── auth.js                # authenticate / optionalAuth
│       │   └── errorHandler.js
│       ├── controllers/
│       │   ├── authController.js      # register, login, refresh, logout
│       │   ├── gameController.js      # rooms, join, state
│       │   ├── leaderboardController.js
│       │   └── historyController.js
│       ├── routes/
│       │   ├── auth.js
│       │   ├── games.js
│       │   ├── rooms.js
│       │   ├── leaderboard.js
│       │   └── history.js
│       ├── socket/
│       │   ├── index.js               # Room lifecycle (join/ready/chat/start)
│       │   ├── socketAuth.js         # WS JWT middleware
│       │   ├── roomStore.js          # In-memory active game map
│       │   └── handlers/
│       │       ├── kattamHandler.js
│       │       └── paramapadamHandler.js
│       └── game-logic/
│           ├── kattam/engine.js       # Placement/movement/win detection
│           └── paramapadam/engine.js  # Dice/snake/ladder/bounce logic
│
└── database/
    ├── schema.sql                     # All 8 tables + triggers + indexes
    ├── migrations/001_initial_schema.sql
    └── seeds/001_seed_data.sql
```

---

## Quick Start

### 1. PostgreSQL

```bash
psql -U postgres -c "CREATE USER krida_user WITH PASSWORD 'yourpassword';"
psql -U postgres -c "CREATE DATABASE krida_db OWNER krida_user;"
psql -U krida_user -d krida_db -f database/schema.sql
psql -U krida_user -d krida_db -f database/seeds/001_seed_data.sql
```

### 2. Backend

```bash
cd backend
cp .env.example .env          # fill in DB creds and JWT secrets
npm install
npm run dev                   # runs on http://localhost:5000
```

### 3. Frontend

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev                   # runs on http://localhost:3000
```

---

## API Reference

| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| POST | `/api/auth/register` | — | Register |
| POST | `/api/auth/login` | — | Login |
| POST | `/api/auth/refresh` | — | Rotate tokens |
| POST | `/api/auth/logout` | — | Revoke token |
| GET  | `/api/auth/me` | ✓ | Current user |
| GET  | `/api/games` | — | List games |
| POST | `/api/games/:slug/rooms` | ✓ | Create room |
| GET  | `/api/rooms/:code` | ✓ | Room state |
| POST | `/api/rooms/:code/join` | ✓ | Join room |
| GET  | `/api/leaderboard/:gameSlug` | — | Top 50 |
| GET  | `/api/leaderboard/:gameSlug/me` | ✓ | My rank |
| GET  | `/api/history` | ✓ | My games |
| GET  | `/api/history/:sessionId` | ✓ | Replay |

## Socket.IO Events

```
Client → Server            Server → Room
─────────────────────      ──────────────────────────
room:join                  room:state
room:ready                 room:player_joined
room:leave                 room:player_left
room:chat                  room:message
kattam:place               room:start
kattam:move                room:abandoned
paramapadam:roll           kattam:state
                           kattam:win
                           kattam:error
                           paramapadam:state
                           paramapadam:win
                           paramapadam:error
```

---

## Pending / Next Steps

- [ ] `frontend/src/app/games/paramapadam/play/page.tsx` — mirrors kattam play page
- [ ] `frontend/src/app/games/kattam-vilayattu/page.tsx` — game info + create/join room UI
- [ ] `frontend/src/app/games/paramapadam/page.tsx`
- [ ] `frontend/src/app/history/[sessionId]/page.tsx` — move-by-move replay viewer
- [ ] `frontend/src/app/profile/page.tsx` — user stats + avatar
- [ ] `docker-compose.yml` — one-command dev environment
- [ ] Unit tests for both game engines (`game-logic/kattam/engine.test.js`)
- [ ] Redis adapter for Socket.IO (horizontal scaling)

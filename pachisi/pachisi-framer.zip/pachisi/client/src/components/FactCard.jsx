import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '../context/GameContext.jsx';

export default function FactCard() {
  const { factText, showFact } = useGame();
  return (
    <AnimatePresence>
      {showFact && (
        <motion.div className="fact-card"
          initial={{ y:'110%', opacity:0 }}
          animate={{ y:0,      opacity:1 }}
          exit={{    y:'110%', opacity:0 }}
          transition={{ type:'spring', stiffness:260, damping:26 }}
        >
          <div className="fc-label">✦ Did you know</div>
          <p className="fc-text">{factText}</p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

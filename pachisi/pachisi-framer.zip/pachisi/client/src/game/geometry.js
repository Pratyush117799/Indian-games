// geometry.js
import { CS } from './config.js';
export const N = (r,c)=>({x:270+c*CS, y: 30+r*CS});
export const W = (r,c)=>({x: 30+c*CS, y:270+r*CS});
export const S = (r,c)=>({x:270+c*CS, y:360+r*CS});
export const E = (r,c)=>({x:360+c*CS, y:270+r*CS});
export const HOME = {x:300,y:300};

/**
 * useLocalSave — saves game state to localStorage after every move
 * and exposes a resume prompt if an in-progress game is detected.
 *
 * Key: 'pagade_game_save'
 * Format: { state, savedAt, mode }
 */

import { useEffect, useCallback, useState } from 'react';

const SAVE_KEY = 'pagade_game_save';

export function useLocalSave() {
  const [hasSave, setHasSave] = useState(false);
  const [saveInfo, setSaveInfo] = useState(null);

  // Check for existing save on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const save = JSON.parse(raw);
      // Only offer resume if the game was in progress (not GAMEOVER)
      if (save?.state?.phase !== 'GAMEOVER' && save?.state?.players?.length) {
        setHasSave(true);
        setSaveInfo({
          mode:    save.state.mode,
          savedAt: new Date(save.savedAt),
          players: save.state.players.map(p => ({ name: p.name, color: p.color, homePawnCount: p.homePawnCount })),
          currentPlayer: save.state.currentPlayer,
        });
      }
    } catch (e) { /* corrupt save — ignore */ }
  }, []);

  const save = useCallback((state) => {
    if (!state?.players?.length) return;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        state,
        savedAt: Date.now(),
      }));
    } catch (e) { /* storage full — ignore */ }
  }, []);

  const loadSave = useCallback(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      return JSON.parse(raw)?.state || null;
    } catch (e) { return null; }
  }, []);

  const clearSave = useCallback(() => {
    localStorage.removeItem(SAVE_KEY);
    setHasSave(false);
    setSaveInfo(null);
  }, []);

  return { hasSave, saveInfo, save, loadSave, clearSave };
}

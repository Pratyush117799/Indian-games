const { v4: uuidv4 } = require('uuid');
const db     = require('../config/db');
const logger = require('../utils/logger');

/** Generate a short 6-char alphanumeric room code */
function generateRoomCode() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

/**
 * GET /api/games
 * List all active games in the catalogue.
 */
async function listGames(req, res, next) {
  try {
    const { rows } = await db.query(
      'SELECT id, slug, name, name_tamil, description, min_players, max_players FROM games WHERE is_active = true ORDER BY name'
    );
    res.json({ games: rows });
  } catch (err) { next(err); }
}

/**
 * GET /api/games/:slug
 */
async function getGame(req, res, next) {
  try {
    const { rows } = await db.query(
      'SELECT * FROM games WHERE slug = $1 AND is_active = true',
      [req.params.slug]
    );
    if (!rows.length) return res.status(404).json({ error: 'Game not found' });
    res.json({ game: rows[0] });
  } catch (err) { next(err); }
}

/**
 * POST /api/games/:slug/rooms
 * Create a game room (host only).
 */
async function createRoom(req, res, next) {
  try {
    const { slug }  = req.params;
    const { level = 1, isPrivate = false, maxPlayers = 2 } = req.body;
    const hostId    = req.user.id;

    const gameRes   = await db.query('SELECT id, min_players, max_players FROM games WHERE slug = $1', [slug]);
    if (!gameRes.rows.length) return res.status(404).json({ error: 'Game not found' });
    const game = gameRes.rows[0];

    if (maxPlayers < game.min_players || maxPlayers > game.max_players) {
      return res.status(400).json({ error: `maxPlayers must be between ${game.min_players} and ${game.max_players}` });
    }

    let roomCode;
    let attempts = 0;
    do {
      roomCode = generateRoomCode();
      const dup = await db.query("SELECT id FROM game_rooms WHERE room_code = $1 AND status IN ('waiting','active')", [roomCode]);
      if (!dup.rows.length) break;
    } while (++attempts < 10);

    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      const { rows: [room] } = await client.query(
        `INSERT INTO game_rooms (game_id, room_code, host_id, max_players, is_private, game_level)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
        [game.id, roomCode, hostId, maxPlayers, isPrivate, level]
      );

      // Add host as player in seat 0
      await client.query(
        `INSERT INTO room_players (room_id, user_id, seat_index, color)
         VALUES ($1, $2, 0, 'green')`,
        [room.id, hostId]
      );

      await client.query('COMMIT');
      logger.info(`Room ${roomCode} created by user ${hostId}`);
      res.status(201).json({ room, roomCode });
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  } catch (err) { next(err); }
}

/**
 * POST /api/rooms/:code/join
 * Join an existing waiting room.
 */
async function joinRoom(req, res, next) {
  try {
    const { code }  = req.params;
    const userId    = req.user.id;
    const COLORS    = ['green','brown','red','blue','yellow','purple'];

    const roomRes = await db.query(
      "SELECT * FROM game_rooms WHERE room_code = $1 AND status = 'waiting'",
      [code]
    );
    if (!roomRes.rows.length) return res.status(404).json({ error: 'Room not found or not accepting players' });
    const room = roomRes.rows[0];

    const playersRes = await db.query(
      'SELECT * FROM room_players WHERE room_id = $1',
      [room.id]
    );
    if (playersRes.rows.length >= room.max_players) {
      return res.status(409).json({ error: 'Room is full' });
    }
    if (playersRes.rows.find(p => p.user_id === userId)) {
      return res.status(409).json({ error: 'Already in this room' });
    }

    const seatIndex  = playersRes.rows.length;
    const color      = COLORS[seatIndex] || COLORS[0];

    await db.query(
      'INSERT INTO room_players (room_id, user_id, seat_index, color) VALUES ($1, $2, $3, $4)',
      [room.id, userId, seatIndex, color]
    );

    res.json({ message: 'Joined room', roomCode: code, seatIndex, color });
  } catch (err) { next(err); }
}

/**
 * GET /api/rooms/:code
 */
async function getRoomState(req, res, next) {
  try {
    const { code } = req.params;
    const { rows: [room] } = await db.query(
      'SELECT * FROM game_rooms WHERE room_code = $1',
      [code]
    );
    if (!room) return res.status(404).json({ error: 'Room not found' });

    const { rows: players } = await db.query(
      `SELECT rp.seat_index, rp.color, rp.is_ready, u.id, u.username, u.avatar_url
       FROM room_players rp JOIN users u ON u.id = rp.user_id
       WHERE rp.room_id = $1 ORDER BY rp.seat_index`,
      [room.id]
    );

    res.json({ room, players });
  } catch (err) { next(err); }
}

module.exports = { listGames, getGame, createRoom, joinRoom, getRoomState };

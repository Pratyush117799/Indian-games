import { motion } from 'framer-motion';
import { CS } from '../game/config.js';
import { CASTLES } from '../game/paths.js';

const ARMS = [
  {x:255,y: 15,w:90,h:240},{x:255,y:345,w:90,h:240},
  {x: 15,y:255,w:240,h:90},{x:345,y:255,w:240,h:90},
];
const TINTS = [
  {x:255,y: 15,w:90,h:75,fill:'rgba(232,197,0,0.055)'},
  {x:255,y:510,w:90,h:75,fill:'rgba(74,127,193,0.045)'},
  {x: 15,y:255,w:75,h:90,fill:'rgba(58,139,26,0.045)'},
  {x:510,y:255,w:75,h:90,fill:'rgba(201,58,58,0.048)'},
];
const ga = { stroke:'rgba(201,153,58,0.15)', strokeWidth:'0.6' };

export default function Board({ children }) {
  return (
    <svg id="board-svg" viewBox="0 0 600 600" width={548} height={548}>
      <defs>
        <radialGradient id="gCharkoni" cx="50%" cy="50%" r="60%">
          <stop offset="0%"   stopColor="#2A0808"/>
          <stop offset="100%" stopColor="#160404"/>
        </radialGradient>
        <radialGradient id="gGold" cx="50%" cy="50%" r="50%">
          <stop offset="0%"   stopColor="#E8C96A"/>
          <stop offset="100%" stopColor="#C9993A"/>
        </radialGradient>
        <pattern id="silk" x="0" y="0" width="4" height="4" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="4" y2="4" stroke="rgba(201,153,58,0.055)" strokeWidth=".5"/>
          <line x1="4" y1="0" x2="0" y2="4" stroke="rgba(201,153,58,0.038)" strokeWidth=".5"/>
        </pattern>
        <filter id="fGlow">
          <feGaussianBlur stdDeviation="2.5" result="b"/>
          <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>

      {/* Outer glow frame */}
      <rect x="13" y="13" width="574" height="574" rx="3" fill="none" stroke="rgba(201,153,58,0.1)" strokeWidth="1.5"/>

      {/* Arms */}
      {ARMS.map((a,i) => (
        <g key={i}>
          <rect {...a} rx="2" fill="#1C0606" stroke="rgba(201,153,58,0.2)" strokeWidth="0.8"/>
          <rect {...a} rx="2" fill="url(#silk)"/>
        </g>
      ))}
      {TINTS.map((t,i) => <rect key={i} x={t.x} y={t.y} width={t.w} height={t.h} fill={t.fill}/>)}

      {/* Grid lines */}
      {/* North arm */}
      {[1,2,3,4,5,6,7].map(r=><line key={`ng${r}`} x1={255} y1={15+r*CS} x2={345} y2={15+r*CS} {...ga}/>)}
      {[1,2].map(c=><line key={`nc${c}`} x1={255+c*CS} y1={15} x2={255+c*CS} y2={255} {...ga}/>)}
      {/* South arm */}
      {[1,2,3,4,5,6,7].map(r=><line key={`sg${r}`} x1={255} y1={345+r*CS} x2={345} y2={345+r*CS} {...ga}/>)}
      {[1,2].map(c=><line key={`sc${c}`} x1={255+c*CS} y1={345} x2={255+c*CS} y2={585} {...ga}/>)}
      {/* West arm */}
      {[1,2,3,4,5,6,7].map(c=><line key={`wc${c}`} x1={15+c*CS} y1={255} x2={15+c*CS} y2={345} {...ga}/>)}
      {[1,2].map(r=><line key={`wr${r}`} x1={15} y1={255+r*CS} x2={255} y2={255+r*CS} {...ga}/>)}
      {/* East arm */}
      {[1,2,3,4,5,6,7].map(c=><line key={`ec${c}`} x1={345+c*CS} y1={255} x2={345+c*CS} y2={345} {...ga}/>)}
      {[1,2].map(r=><line key={`er${r}`} x1={345} y1={255+r*CS} x2={585} y2={255+r*CS} {...ga}/>)}

      {/* Castle squares */}
      {CASTLES.map((c,i) => (
        <g key={i}>
          <motion.rect
            x={c.x-CS/2} y={c.y-CS/2} width={CS} height={CS} rx="1"
            fill="rgba(78,6,6,0.72)" stroke="rgba(201,153,58,0.72)" strokeWidth="1"
            animate={{ opacity:[0.55,1,0.55] }}
            transition={{ duration:2.6, delay:i*0.2, repeat:Infinity, ease:'easeInOut' }}
          />
          <path d={`M${c.x},${c.y-5}L${c.x+5},${c.y}L${c.x},${c.y+5}L${c.x-5},${c.y}Z`}
                fill="rgba(201,153,58,0.58)"/>
        </g>
      ))}

      {/* Charkoni lotus */}
      <Charkoni/>

      {/* Arm labels */}
      {[{x:300,y:9,t:'पीला',r:0},{x:300,y:597,t:'काला',r:0},
        {x:8,y:300,t:'हरा',r:-90},{x:597,y:300,t:'लाल',r:90}].map((l,i)=>(
        <text key={i} x={l.x} y={l.y} textAnchor="middle" fontFamily="Cinzel,serif"
              fontSize="7" fill="rgba(201,153,58,0.42)" letterSpacing="1.2"
              transform={l.r?`rotate(${l.r},${l.x},${l.y})`:undefined}>{l.t}</text>
      ))}

      {/* Injected layers (highlights + pawns) */}
      {children}
    </svg>
  );
}

function Charkoni() {
  const cx=300, cy=300;
  const petals = [0,45,90,135,180,225,270,315];
  return (
    <g>
      <rect x="255" y="255" width="90" height="90" rx="3"
            fill="url(#gCharkoni)" stroke="url(#gGold)" strokeWidth="2"/>
      <rect x="255" y="255" width="90" height="90" rx="3" fill="url(#silk)"/>
      {petals.map((deg,i)=>{
        const a=deg*Math.PI/180;
        const px=cx+Math.sin(a)*18, py=cy-Math.cos(a)*18;
        return (
          <motion.ellipse key={i} cx={px} cy={py} rx="4.2" ry="8.5"
            fill={`rgba(139,26,26,${i%2===0?0.75:0.5})`}
            stroke="rgba(201,153,58,0.38)" strokeWidth="0.7"
            transform={`rotate(${deg},${px},${py})`}
            animate={{ opacity:[0.6,1,0.6] }}
            transition={{ duration:3.5, delay:i*0.18, repeat:Infinity, ease:'easeInOut' }}
          />
        );
      })}
      {[28,18,8].map((r,i)=>(
        <circle key={i} cx={cx} cy={cy} r={r} fill="none"
                stroke={`rgba(201,153,58,${0.26+i*0.15})`} strokeWidth={i===2?1.4:0.8}/>
      ))}
      <motion.circle cx={cx} cy={cy} r="6" fill="#8B1A1A"
                     stroke="rgba(201,153,58,0.8)" strokeWidth="1"
                     animate={{ filter:['drop-shadow(0 0 2px #C9993A)','drop-shadow(0 0 8px #E8C96A)','drop-shadow(0 0 2px #C9993A)'] }}
                     transition={{ duration:2.8, repeat:Infinity }}/>
      <circle cx={cx} cy={cy} r="2.5" fill="rgba(232,201,106,0.88)"/>
      <text x={cx} y={cy+38} textAnchor="middle" fontFamily="Cinzel,serif"
            fontSize="5.5" fill="rgba(201,153,58,0.5)" letterSpacing="1.8">CHARKONI</text>
    </g>
  );
}

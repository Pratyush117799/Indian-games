'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Star, Trophy, Swords, Clock } from 'lucide-react';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

interface Stats { wins: number; losses: number; draws: number; total_games: number; win_rate: number; rating: number; best_time_secs: number | null; rank: number; }

const GAMES = [
  { slug: 'kattam-vilayattu', label: 'Kattam Vilayattu', tamil: 'கட்டம் விளையாட்டு' },
  { slug: 'paramapadam',      label: 'Paramapadam',      tamil: 'பரமபதம்' },
];

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string | number; sub?: string }) {
  return (
    <div className="card flex items-center gap-3 py-3 px-4">
      <div className="text-clay">{icon}</div>
      <div>
        <p className="text-lg font-bold text-temple leading-none">{value}</p>
        <p className="text-xs text-gray-400">{label}</p>
        {sub && <p className="text-xs text-gray-300">{sub}</p>}
      </div>
    </div>
  );
}

export default function ProfilePage() {
  const router = useRouter();
  const { user, logout } = useAuthStore();
  const [statsMap, setStatsMap] = useState<Record<string, Stats>>({});
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    if (!user) { router.replace('/auth/login'); return; }
    Promise.all(
      GAMES.map(g =>
        api.get(`/leaderboard/${g.slug}/me`)
           .then(r => [g.slug, r.data.stats] as [string, Stats])
           .catch(() => [g.slug, null] as [string, null])
      )
    ).then(pairs => {
      const map: Record<string, Stats> = {};
      pairs.forEach(([slug, stats]) => { if (stats) map[slug] = stats; });
      setStatsMap(map);
    }).finally(() => setLoading(false));
  }, [user]);

  function fmt(secs: number | null) {
    if (!secs) return '—';
    return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  }

  if (!user) return null;

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 space-y-8">
      {/* Avatar + username */}
      <div className="card flex items-center gap-5">
        <div className="w-16 h-16 rounded-full bg-clay text-cream flex items-center justify-center text-2xl font-bold">
          {user.username[0].toUpperCase()}
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-temple">{user.username}</h1>
          <p className="text-sm text-gray-400">{user.email}</p>
          <p className="text-xs text-gray-300 mt-0.5">
            Member since {new Date(user.created_at).toLocaleDateString()}
          </p>
        </div>
        <button onClick={logout} className="btn-secondary text-sm py-1.5 px-3">
          Log out
        </button>
      </div>

      {/* Per-game stats */}
      {loading ? (
        <div className="text-center text-gray-300 animate-pulse py-8 text-sm">Loading stats…</div>
      ) : (
        GAMES.map(g => {
          const s = statsMap[g.slug];
          return (
            <div key={g.slug} className="space-y-3">
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-clay">{g.label}</h2>
                <span className="font-tamil text-xs text-clay/50">{g.tamil}</span>
              </div>
              {!s ? (
                <p className="text-sm text-gray-300 italic">No games played yet</p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <StatCard icon={<Star size={18} />}    label="ELO Rating"  value={s.rating}      sub={`Rank #${s.rank}`} />
                  <StatCard icon={<Trophy size={18} />}   label="Win Rate"    value={`${s.win_rate}%`} sub={`${s.wins}W / ${s.losses}L / ${s.draws}D`} />
                  <StatCard icon={<Swords size={18} />}   label="Total Games" value={s.total_games} />
                  <StatCard icon={<Clock size={18} />}    label="Best Time"   value={fmt(s.best_time_secs)} />
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

/**
 * Pawn.jsx — animated SVG pawn piece with smooth position transitions.
 *
 * Uses CSS transform transitions so the pawn visibly slides between cells
 * rather than teleporting. Blockade (2 same-colour on same cell) shows a
 * small crown above the pawn pair.
 */

import React, { useRef, useEffect, useState } from 'react';
import { CELL_SIZE, PLAYER_COLORS, PLAYER_COLORS_DARK } from '../../game/constants';

const R       = 9.5;   // pawn head radius
const STEM_W  = 6;
const STEM_H  = 8;

export default function Pawn({
  pawn, cell,
  isMovable, isAnimating, isSelected,
  isBlockadeLeader,          // true if this is one of a 2-pawn blockade
  stackOffset = 0, stacked = false,
  onClick,
  theme = 'temple_stone',
}) {
  const prevCellRef = useRef(cell);
  const [hasPop, setHasPop]   = useState(false);
  const [prevXY, setPrevXY]   = useState(null);
  const [animating, setAnimating] = useState(false);

  const color  = PLAYER_COLORS[pawn.playerId];
  const dark   = PLAYER_COLORS_DARK[pawn.playerId];

  // Stack spread: side-by-side offset for multiple pawns on same cell
  const spreadX = stacked ? (stackOffset - 0.5) * 9 : 0;
  const spreadY = stacked ? Math.abs(stackOffset - 0.5) * -4 : 0;

  const cx = cell.c * CELL_SIZE + CELL_SIZE / 2 + spreadX;
  const cy = cell.r * CELL_SIZE + CELL_SIZE / 2 + spreadY;

  // Detect cell change → trigger pop animation
  useEffect(() => {
    const prev = prevCellRef.current;
    if (!prev || !cell) { prevCellRef.current = cell; return; }
    if (prev.r !== cell.r || prev.c !== cell.c) {
      setHasPop(true);
      const t = setTimeout(() => setHasPop(false), 420);
      prevCellRef.current = cell;
      return () => clearTimeout(t);
    }
  }, [cell?.r, cell?.c]);

  if (!cell) return null;

  const scale = hasPop || isAnimating ? 1.28 : isSelected ? 1.12 : 1;

  return (
    <g
      onClick={onClick}
      style={{ cursor: isMovable ? 'pointer' : 'default' }}
    >
      {/* Glow pulse ring — only for movable pawns */}
      {isMovable && (
        <circle
          cx={cx} cy={cy} r={R + 7}
          fill="none"
          stroke={color}
          strokeWidth={1.8}
          opacity={0.55}
          style={{ animation: 'pawnGlow 1.5s ease-in-out infinite' }}
        />
      )}

      {/* Selection ring */}
      {isSelected && (
        <circle
          cx={cx} cy={cy} r={R + 5}
          fill="none"
          stroke="#fff"
          strokeWidth={2}
          opacity={0.9}
        />
      )}

      {/* Blockade crown indicator */}
      {isBlockadeLeader && (
        <text
          x={cx} y={cy - R - 5}
          fontSize={9}
          textAnchor="middle"
          dominantBaseline="middle"
          style={{ userSelect: 'none', pointerEvents: 'none', animation: 'pawnGlow 2s ease-in-out infinite' }}
        >
          👑
        </text>
      )}

      {/* Pawn body group with scale transform */}
      <g
        transform={`translate(${cx}, ${cy}) scale(${scale})`}
        style={{
          transformOrigin: `${cx}px ${cy}px`,
          transition: 'transform 0.18s cubic-bezier(.34,1.56,.64,1)',
          filter: isAnimating ? `drop-shadow(0 0 7px ${color})` : undefined,
        }}
      >
        {/* Pin stem */}
        <rect
          x={-STEM_W / 2} y={R - 1}
          width={STEM_W} height={STEM_H}
          rx={2}
          fill={dark}
        />
        {/* Head */}
        <circle cx={0} cy={0} r={R} fill={color} stroke={dark} strokeWidth={1.5} />
        {/* Shine */}
        <circle cx={-2.5} cy={-3} r={3.5} fill="rgba(255,255,255,0.42)" />
        {/* Number */}
        <text
          x={0} y={0}
          textAnchor="middle" dominantBaseline="middle"
          fontSize={8} fontWeight="bold" fill="white"
          style={{ userSelect: 'none', pointerEvents: 'none' }}
        >
          {pawn.id + 1}
        </text>
      </g>
    </g>
  );
}

/**
 * story.data.js — Ramayana Quest Story Engine
 * ─────────────────────────────────────────────────────────────
 * Complete story data for all 7 Kandas of the Ramayana.
 * Based on Valmiki Ramayana (Sanskrit original, 24,000 shlokas).
 *
 * Each Kanda contains:
 *   - Historical context and setting
 *   - Key story events (scenes)
 *   - Moral choices with ripple effects
 *   - Mini-game specification
 *   - Knowledge quiz questions
 *   - Character-specific dialogue variants
 */

/* ── THE SEVEN KANDAS ────────────────────────────────────────── */
export const KANDAS = [
  {
    id: 'bala',
    num: 1,
    name: 'Bāla Kāṇḍa',
    sanskrit: 'बाल काण्ड',
    english: 'The Book of Youth',
    location: 'Ayodhya, Mithila',
    emoji: '🏹',
    color: '#E8A000',
    bgColor: '#FFF8E0',
    shlokas: '77 sargas · 2,345 shlokas',
    synopsis: 'The birth of Rama and his brothers. His training under Vishwamitra. The swayamvara at Mithila where Rama lifts and strings the divine bow of Shiva and wins Sita\'s hand.',
    historicalNote: 'Ayodhya (modern Uttar Pradesh) was the capital of the Kosala Kingdom. The Sarayu river still flows there today.',
    keyCharacters: ['rama', 'sita', 'lakshmana', 'vishwamitra', 'janaka'],
    miniGame: 'bow_lift',
    unlocked: true,
    scenes: [
      {
        id: 'birth',
        title: 'The Four Princes of Ayodhya',
        setting: 'The golden palace of King Dasharatha, Ayodhya',
        narrative: `King Dasharatha of Ayodhya had three wives and no sons. He performed the great Putrakameshti Yajna — a fire ritual for sons. From the sacred flames rose the divine being Agni, bearing a golden bowl of payasam (sacred rice pudding). Dasharatha gave half to Kaushalya, a quarter to Kaikeyi, and the rest to Sumitra. Soon after, four sons were born: Rama to Kaushalya, Bharata to Kaikeyi, and twins Lakshmana and Shatrughna to Sumitra.`,
        panelArt: 'palace_birth',
        virtue: { wisdom: 2 },
      },
      {
        id: 'forest_training',
        title: 'Sage Vishwamitra\'s Request',
        setting: 'The royal court of Ayodhya',
        narrative: `The sage Vishwamitra came to Dasharatha with an extraordinary request: he needed Rama, barely a teenager, to protect his forest ashram from the rakshasas Tataka and Maricha who were disrupting his sacred fire rituals. Dasharatha was terrified — to send his beloved eldest son into such danger. But the sage Vasishtha reminded him: a king must honor a sage's request. And Rama himself stepped forward with a smile.`,
        moralChoice: {
          question: 'You are Rama. Your father is devastated at the thought of sending you. What do you tell him?',
          options: [
            {
              label: 'Father, your duty is to honour the sage. My duty is to go. Do not grieve.',
              virtue: { dharma: 15, courage: 10 },
              outcome: 'Dasharatha is moved to tears. He gives Rama his blessing with a full heart.',
              ripple: 'Your father\'s grief transforms into pride. He watches with clear eyes as you leave.',
              consequence_id: 'rama_departure_pride',
            },
            {
              label: 'I will go, but only if Lakshmana can come with me.',
              virtue: { devotion: 15, courage: 8 },
              outcome: 'Lakshmana joins the quest. Your brotherhood deepens from this first adventure.',
              ripple: 'Lakshmana\'s loyalty, forged in this first forest journey, will save your life in Lanka.',
              consequence_id: 'lakshmana_bond',
            },
            {
              label: 'I will go. But first teach me what I need to know about the enemy.',
              virtue: { wisdom: 15, courage: 8 },
              outcome: 'Vishwamitra teaches you the divine weapons Bala and Atibala before departure.',
              ripple: 'The divine weapons learned here will protect you throughout your exile.',
              consequence_id: 'divine_weapons_learned',
            },
          ],
        },
        panelArt: 'vishwamitra_request',
        virtue: { courage: 5 },
      },
      {
        id: 'tataka',
        title: 'The Killing of Tataka',
        setting: 'The Dandaka forest',
        narrative: `Vishwamitra commanded Rama to kill Tataka, a yakshini who had become a rakshasi. Rama hesitated — Tataka was a woman, and in his code, harming a woman was a grave sin. But Vishwamitra explained: Tataka was no ordinary woman. She had killed thousands. The greater dharma was to protect the innocent.`,
        moralChoice: {
          question: 'Rama hesitates to strike Tataka because she is a woman. What is the dharmic action?',
          options: [
            {
              label: 'Strike to protect the thousands she has already killed and will kill.',
              virtue: { dharma: 12, courage: 8 },
              outcome: 'Tataka falls. Vishwamitra gives Rama powerful divine weapons as reward.',
              ripple: 'Vishwamitra gives you powerful weapons. You are ready for greater battles ahead.',
              consequence_id: 'tataka_slain',
            },
            {
              label: 'First make noise to frighten her away — give her a chance to flee.',
              virtue: { wisdom: 10, dharma: 8 },
              outcome: 'Tataka charges anyway. You must fight. But you tried mercy first.',
              ripple: 'Your attempt at mercy is noted. In Lanka, you will show Vibhishana this same mercy.',
              consequence_id: 'mercy_attempted',
            },
          ],
        },
        panelArt: 'tataka_forest',
        virtue: { dharma: 5 },
      },
      {
        id: 'swayamvara',
        title: 'The Swayamvara — Lifting Shiva\'s Bow',
        setting: 'The city of Mithila, kingdom of Videha',
        narrative: `King Janaka had announced a swayamvara for his daughter Sita: whoever could lift and string the divine bow of Shiva — a weapon so heavy that five hundred men could barely move it — would win her hand. Hundreds of princes had already failed, some too proud to admit defeat. When Rama walked forward, the court fell silent.`,
        panelArt: 'bow_swayamvara',
        isMiniGame: true,
        miniGame: 'bow_lift',
        virtue: { courage: 10, dharma: 5 },
      },
    ],
    quizQuestions: [
      { q: 'What was the name of the sacred ritual performed by Dasharatha for sons?', opts: ['Ashwamedha Yajna', 'Putrakameshti Yajna', 'Soma Yajna', 'Rajasuya Yajna'], ans: 1, fact: 'Putrakameshti Yajna is a Vedic fire ritual specifically for the birth of sons. Rishi Rishyashringa performed it for Dasharatha.' },
      { q: 'Which river flows through Ayodhya?', opts: ['Ganga', 'Yamuna', 'Sarayu', 'Godavari'], ans: 2, fact: 'The Sarayu river flows through modern-day Ayodhya in Uttar Pradesh. The city is considered one of the seven sacred cities (Saptapuri) of Hinduism.' },
      { q: 'In whose kingdom was the city of Mithila, where Sita lived?', opts: ['Kosala', 'Videha', 'Kashi', 'Magadha'], ans: 1, fact: 'Mithila was the capital of the Videha kingdom, ruled by King Janaka. Modern Mithila region is in Bihar and southern Nepal.' },
      { q: 'What did Vishwamitra teach Rama before the forest journey?', opts: ['Sword fighting', 'The divine weapons Bala and Atibala', 'The Vedas', 'Archery'], ans: 1, fact: 'Bala and Atibala were divine knowledge-weapons (mantras) that prevented Rama from feeling hunger, thirst, or fatigue — essential for forest survival.' },
      { q: 'Why did Rama hesitate before fighting Tataka?', opts: ['She was too powerful', 'She was a woman', 'She was his relative', 'Vishwamitra asked him to hesitate'], ans: 1, fact: 'Striking a woman was considered a grave sin in Kshatriya (warrior) code. Vishwamitra had to explain that protecting thousands of innocents was a higher dharma.' },
    ],
  },

  {
    id: 'ayodhya',
    num: 2,
    name: 'Ayodhyā Kāṇḍa',
    sanskrit: 'अयोध्या काण्ड',
    english: 'The Book of Ayodhya',
    location: 'Ayodhya, the Kosala Kingdom',
    emoji: '👑',
    color: '#CC2222',
    bgColor: '#FFF0F0',
    shlokas: '119 sargas · 4,281 shlokas',
    synopsis: 'Rama is about to be crowned king. Kaikeyi demands her two boons — Bharata on the throne and Rama exiled for 14 years. The great exile begins. Dasharatha dies of grief.',
    historicalNote: 'The Ramayana was composed in a time when boons (vara) given to queens were considered absolutely binding — more sacred than any law. Breaking a promise was the most severe moral crime.',
    keyCharacters: ['rama', 'sita', 'lakshmana', 'kaikeyi', 'manthara', 'dasharatha', 'bharata'],
    miniGame: 'forest_parna_kuti',
    unlocked: false,
    scenes: [
      {
        id: 'kaikeyi_boons',
        title: "Kaikeyi's Two Boons",
        setting: 'The inner chambers of Kaikeyi, Ayodhya',
        narrative: `Manthara, Kaikeyi's hunchbacked maid, poisoned her mistress's mind. "Rama will be king and your son Bharata will be a servant," she whispered. "But you have two unfulfilled boons from Dasharatha — boons promised after you saved his life in battle. Use them now: put Bharata on the throne and exile Rama for 14 years." Kaikeyi, who had always loved Rama as her own son, transformed overnight.`,
        moralChoice: {
          question: 'You are Rama. You have just learned of Kaikeyi\'s demands. Dasharatha is shattered. What do you do?',
          options: [
            {
              label: 'Accept the exile with joy. A father\'s promise must never be broken.',
              virtue: { dharma: 20, devotion: 10 },
              outcome: 'Rama accepts without anger or grief. His calm devastates everyone more than any protest could.',
              ripple: 'Your acceptance of dharma over personal desire becomes the story people tell for 3000 years.',
              consequence_id: 'noble_acceptance',
            },
            {
              label: 'Ask to speak to Kaikeyi — try to understand why she did this.',
              virtue: { wisdom: 15, dharma: 8 },
              outcome: 'Kaikeyi hardens her heart. But you understand: Manthara was the true cause. You feel no anger toward Kaikeyi.',
              ripple: 'This wisdom — seeing the real cause behind surface actions — helps you read Ravana\'s true weakness later.',
              consequence_id: 'understands_manthara',
            },
            {
              label: 'Accept, but ask that Sita and Lakshmana be allowed to stay safely in Ayodhya.',
              virtue: { devotion: 15, wisdom: 10 },
              outcome: 'Both Sita and Lakshmana refuse to stay. They insist on joining you. Love cannot be separated by command.',
              ripple: 'Their choice to follow you, against your wish to protect them, defines what loyalty truly means.',
              consequence_id: 'sita_lakshmana_follow',
            },
          ],
        },
        panelArt: 'kaikeyi_chambers',
        virtue: { dharma: 10 },
      },
      {
        id: 'departure',
        title: 'The Departure into Exile',
        setting: 'The banks of the Sarayu, Ayodhya',
        narrative: `Ayodhya wept. The city followed Rama to the banks of the Sarayu river. Even the horses pulling Rama\'s chariot wept. He sat on the ground, removed his royal garments, put on bark cloth and matted hair — the appearance of a forest ascetic — without a moment of hesitation. Sita and Lakshmana stood beside him.`,
        panelArt: 'departure_exile',
        virtue: { dharma: 8, courage: 6 },
      },
    ],
    quizQuestions: [
      { q: 'How many years was Rama exiled for?', opts: ['7 years', '12 years', '14 years', '21 years'], ans: 2, fact: '14 years of exile — this number appears throughout Ramayana. It mirrors the 14 lokas (worlds) of Hindu cosmology, suggesting Rama\'s journey spans all of existence.' },
      { q: 'What were the two boons Kaikeyi claimed from Dasharatha?', opts: ['Gold and land', 'Bharata as king and Rama in exile', 'Rama in prison and Bharata as prince', 'Sita returned and Rama executed'], ans: 1, fact: 'These boons had been granted when Kaikeyi saved Dasharatha\'s life during the Devasura war. Sacred promises in Vedic culture were absolutely binding — breaking them was worse than death.' },
      { q: 'Who was Manthara?', opts: ["Rama's aunt", "Kaikeyi's maid who convinced her to use the boons", 'A court minister', 'A sage'], ans: 1, fact: 'Manthara is one of literature\'s great manipulators. She had been Kaikeyi\'s nurse since childhood and knew exactly how to twist her love for Bharata into jealousy.' },
      { q: 'What did Dasharatha die of after Rama\'s exile?', opts: ['Illness', 'Battle wounds', 'Grief — he could not survive Rama\'s absence', 'Old age'], ans: 2, fact: 'Dasharatha died of grief — technically of a broken heart (Viyoga, grief of separation). He had once cursed a blind couple whose son he accidentally killed, and died the same way — separated from his son.' },
    ],
  },

  {
    id: 'aranya',
    num: 3,
    name: 'Āraṇya Kāṇḍa',
    sanskrit: 'अरण्य काण्ड',
    english: 'The Book of the Forest',
    location: 'Dandaka Forest, Panchavati',
    emoji: '🌳',
    color: '#1A6B3C',
    bgColor: '#E8F5E9',
    shlokas: '75 sargas · 2,973 shlokas',
    synopsis: 'Life in the forest. Encounters with sages and demons. The golden deer. The abduction of Sita by Ravana in disguise. Jatayu\'s sacrifice.',
    historicalNote: 'The Dandaka forest corresponds to the Deccan plateau region. Panchavati is identified with modern Nashik in Maharashtra, where the Godavari river flows.',
    keyCharacters: ['rama', 'sita', 'lakshmana', 'ravana', 'maricha', 'jatayu', 'surpanakha'],
    miniGame: 'golden_deer',
    unlocked: false,
    scenes: [
      {
        id: 'panchavati',
        title: 'Life at Panchavati',
        setting: 'The hermitage on the Godavari river',
        narrative: `Rama, Sita, and Lakshmana built a beautiful hermitage (parna kuti) at Panchavati among five banyan trees on the banks of the Godavari. For years they lived in simple joy — gathering fruits, hearing the birds, meeting forest sages. But the forest also held danger. The rakshasas had heard of the beautiful Sita.`,
        panelArt: 'panchavati_hermitage',
        virtue: { devotion: 5, wisdom: 3 },
      },
      {
        id: 'surpanakha',
        title: 'Surpanakha\'s Humiliation',
        setting: 'The forest of Panchavati',
        narrative: `Surpanakha, Ravana's sister, came to Panchavati. She was powerful, could change her form, and fell in love with Rama. When he gently refused (he was married to Sita), she lunged at Sita. Lakshmana cut off her nose and ears. She fled to her brothers, then to Ravana — with a burning desire for revenge and a vivid description of Sita's beauty.`,
        moralChoice: {
          question: 'Lakshmana disfigured Surpanakha to protect Sita. Was this the right action?',
          options: [
            {
              label: 'Yes — she attacked Sita. Protecting family is paramount dharma.',
              virtue: { dharma: 10, devotion: 8 },
              outcome: 'Lakshmana acted from love. But the consequences ripple forward — Surpanakha\'s pain becomes Ravana\'s motivation.',
              ripple: 'Every action has consequences, even righteous ones. Ravana now has a personal reason for revenge.',
              consequence_id: 'surpanakha_revenge_motivated',
            },
            {
              label: 'The punishment was too severe. A warning would have sufficed.',
              virtue: { wisdom: 12, dharma: 6 },
              outcome: 'You reflect on proportional response. Lakshmana acted from loyalty, but perhaps rashly.',
              ripple: 'This reflection on proportional response helps you spare Vibhishana and other rakshasas in Lanka.',
              consequence_id: 'proportional_wisdom',
            },
          ],
        },
        panelArt: 'surpanakha_encounter',
        virtue: { dharma: 5 },
      },
      {
        id: 'golden_deer',
        title: 'The Golden Deer',
        setting: 'The forest clearing at Panchavati',
        narrative: `Maricha came in the form of a golden deer — glittering, magical, irresistible. Sita was enchanted and asked Rama to catch it. Lakshmana warned: "This is Maya — illusion. No deer like this exists in nature." But Sita's desire was strong. Rama, unable to deny Sita, went in pursuit.`,
        moralChoice: {
          question: 'Lakshmana says the golden deer is a trap. Sita desperately wants it. Rama has already gone. What do you do as Lakshmana?',
          options: [
            {
              label: 'Stay and guard Sita — your duty is her protection, not obeying her wishes.',
              virtue: { dharma: 15, wisdom: 10 },
              outcome: 'You stay. But when a false cry of "Lakshmana, help!" echoes from the forest, Sita believes Rama is dying and commands you to go.',
              ripple: 'Even perfect loyalty cannot prevent what fate has arranged. Your wisdom was right, but the trap was deeper.',
              consequence_id: 'lakshmana_loyal',
            },
            {
              label: 'Leave a protective circle (Lakshmana Rekha) and go — Rama\'s call must be answered.',
              virtue: { devotion: 12, courage: 8 },
              outcome: 'You draw the Lakshmana Rekha — a sacred protective line. But Sita steps out of it when Ravana comes as a beggar.',
              ripple: 'The Rekha you drew became legend. Even today, "crossing the Lakshmana Rekha" means crossing a line that should not be crossed.',
              consequence_id: 'rekha_drawn',
            },
          ],
        },
        panelArt: 'golden_deer_chase',
        isMiniGame: true,
        miniGame: 'golden_deer',
        virtue: { wisdom: 5 },
      },
      {
        id: 'sita_abduction',
        title: "Ravana's Deception",
        setting: 'The hermitage — now empty and silent',
        narrative: `Ravana came disguised as a wandering sanyasi, begging for food. The moment Sita stepped outside the protective Lakshmana Rekha to offer alms, he revealed his true form and seized her. The great eagle Jatayu, old friend of Dasharatha, heard Sita's screams and attacked Ravana's chariot with everything he had — wings beating against swords, talons against ten heads. Ravana cut off Jatayu's wings. The old bird fell, mortally wounded.`,
        panelArt: 'jatayu_battle',
        virtue: { courage: 8 },
      },
    ],
    quizQuestions: [
      { q: 'Who was Jatayu?', opts: ['A forest sage', 'The king of eagles and friend of Dasharatha', 'A servant of Rama', 'A shape-shifting rakshasa'], ans: 1, fact: 'Jatayu was the king of eagles (Garuda-jati), an old friend of King Dasharatha. He gave his life trying to stop Ravana — considered one of the noblest sacrifices in the Ramayana.' },
      { q: 'What is the "Lakshmana Rekha"?', opts: ['A sword given to Lakshmana', 'A protective line drawn by Lakshmana to guard Sita', 'A boundary between two kingdoms', 'A river crossing'], ans: 1, fact: 'The Lakshmana Rekha has become a cultural metaphor in India. Even today, "crossing the Lakshmana Rekha" means crossing a boundary that should not be crossed.' },
      { q: 'What form did Ravana take to abduct Sita?', opts: ['A golden deer', 'A wandering ascetic (sanyasi)', 'A merchant', 'A beggar king'], ans: 1, fact: 'Ravana used the same Maya (illusion) power as Maricha. A sanyasi asking for alms could never be refused under dharmic code — so Sita HAD to step forward, and the trap was perfect.' },
      { q: 'Who disguised himself as the golden deer to lure Rama away?', opts: ['Ravana himself', 'Kumbhakarna', 'Maricha', 'Indrajit'], ans: 2, fact: 'Maricha was a rakshasa who had previously been driven away by Rama. He reluctantly agreed to help Ravana, knowing it would mean his death — choosing death by Rama\'s hand over death by Ravana\'s anger.' },
    ],
  },

  {
    id: 'kishkindha',
    num: 4,
    name: 'Kiṣkindhā Kāṇḍa',
    sanskrit: 'किष्किन्धा काण्ड',
    english: 'The Book of Kishkindha',
    location: 'Kishkindha — Kingdom of the Vanaras',
    emoji: '🐒',
    color: '#7B3F00',
    bgColor: '#FFF3E0',
    shlokas: '67 sargas · 2,665 shlokas',
    synopsis: 'Rama meets Hanuman and the vanara king Sugriva. He helps Sugriva defeat Vali (who had usurped the throne) in exchange for Sugriva\'s help searching for Sita. The monsoon delay. The search parties sent out.',
    historicalNote: 'Kishkindha is identified with the Hampi region of modern Karnataka, along the Tungabhadra river. The Anjanadri hill near Hampi is believed to be Hanuman\'s birthplace.',
    keyCharacters: ['rama', 'lakshmana', 'hanuman', 'sugriva', 'vali', 'angada'],
    miniGame: 'vali_battle',
    unlocked: false,
    scenes: [
      {
        id: 'first_meeting',
        title: 'First Meeting with Hanuman',
        setting: 'The Rishyamuka mountain near the Tungabhadra river',
        narrative: `A vanara descended from the mountain to greet two exhausted warriors. He spoke in perfect Sanskrit, quoting the Vedas with calm authority. This was Hanuman — son of the wind god Vayu, student of the sun god Surya, the greatest devotee in the Ramayana. "I know who you are," he said to Rama. "And I have been waiting for you."`,
        panelArt: 'hanuman_first_meeting',
        virtue: { devotion: 10 },
      },
      {
        id: 'vali_sugriva',
        title: "Sugriva's Story — Vali's Betrayal",
        setting: 'The Rishyamuka mountain',
        narrative: `Sugriva told his story: his brother Vali was the vanara king, invincible in battle (a boon meant that half his opponent's strength transferred to him). Vali had mistakenly believed Sugriva had betrayed him, banished him, and taken his wife. Sugriva had lived in exile, terrified, for years. He needed Rama's help to reclaim his kingdom and his queen. In exchange, all the vanaras would help find Sita.`,
        panelArt: 'sugriva_story',
        virtue: { wisdom: 5 },
      },
      {
        id: 'vali_battle',
        title: "Rama's Arrow — The Question of Vali",
        setting: 'The outskirts of Kishkindha',
        narrative: `Rama shot Vali from behind a tree — an act that has troubled readers for 3000 years. Vali, dying, accused Rama: "You are a dharmic king. Why did you strike me from hiding? I would have given you Sita back if only you had asked." Rama answered with a long explanation of dharma: Vali had sinned against his brother, taken another's wife, and couldn't be fought fairly because of his boon. The debate was never fully resolved.`,
        moralChoice: {
          question: 'Vali asks Rama why he shot from hiding rather than challenging him openly. What is Rama\'s most dharmic response?',
          options: [
            {
              label: '"You sinned against your own brother. A king who violates family dharma loses the right to warrior code."',
              virtue: { dharma: 12, wisdom: 8 },
              outcome: 'Vali listens, then accepts the answer. He dies naming his son Angada as his heir and asking Sugriva to treat him well.',
              ripple: 'Angada, Vali\'s son, becomes a key diplomat in Lanka — a direct result of this reconciliation at death.',
              consequence_id: 'angada_diplomat',
            },
            {
              label: '"I acted for the greater good — to build an alliance that will save Sita and restore dharma to the world."',
              virtue: { courage: 10, wisdom: 10 },
              outcome: 'Vali is not fully satisfied, but sees the larger purpose. His final breath is a blessing for Rama\'s mission.',
              ripple: 'This willingness to hold complexity — doing something questionable for a greater good — marks your wisdom as a king.',
              consequence_id: 'greater_good_wisdom',
            },
            {
              label: '"You are right. I may have acted wrongly. But Sugriva deserved justice, and I gave it to him."',
              virtue: { dharma: 15, wisdom: 5 },
              outcome: 'Vali, shocked by Rama\'s honesty, forgives him completely. His death becomes a moment of grace.',
              ripple: 'Your honesty about moral complexity becomes the teaching: even great beings make imperfect choices.',
              consequence_id: 'honest_admission',
            },
          ],
        },
        panelArt: 'vali_confrontation',
        isMiniGame: true,
        miniGame: 'vali_battle',
        virtue: { dharma: 8, wisdom: 8 },
      },
    ],
    quizQuestions: [
      { q: 'Who was Hanuman\'s father?', opts: ['Indra (king of gods)', 'Surya (sun god)', 'Vayu (wind god)', 'Brahma (creator)'], ans: 2, fact: 'Hanuman is the son of Vayu (wind god) — which explains his extraordinary speed, his ability to fly, and his immense strength. He is also called Vayuputra (son of wind).' },
      { q: 'What special boon did Vali have that made him nearly unbeatable?', opts: ['He could not be killed by any weapon', 'Half of his opponent\'s strength transferred to him in battle', 'He could become invisible', 'He had ten lives'], ans: 1, fact: 'This boon made it impossible for Sugriva or anyone else to face Vali directly. This is why Rama, despite his own extraordinary skill, shot from hiding — the boon would not apply to an arrow from outside the combat.' },
      { q: 'Where is Kishkindha believed to be located today?', opts: ['Near Ayodhya in Uttar Pradesh', 'The Hampi region of Karnataka', 'Near Varanasi in Uttar Pradesh', 'The Thar Desert in Rajasthan'], ans: 1, fact: 'Hampi in Karnataka, along the Tungabhadra river, is widely identified as ancient Kishkindha. The Anjanadri hill near Hampi is considered Hanuman\'s birthplace.' },
      { q: 'Why did Rama not fight Vali directly?', opts: ['Rama was not strong enough', 'Vali\'s boon transferred half his opponent\'s strength — making direct combat impossible', 'Rama wanted to test Sugriva first', 'Lakshmana forbade it'], ans: 1, fact: 'The strategy of fighting from outside a boon\'s effect is called "niti" (strategic wisdom) in Ayurvedic military texts. The Arthashastra of Chanakya also discusses such approaches to opponents with supernatural advantages.' },
    ],
  },

  {
    id: 'sundara',
    num: 5,
    name: 'Sundara Kāṇḍa',
    sanskrit: 'सुन्दर काण्ड',
    english: 'The Beautiful Book',
    location: 'Lanka — Island Kingdom of Ravana',
    emoji: '🌊',
    color: '#00369A',
    bgColor: '#E3F2FD',
    shlokas: '68 sargas · 2,885 shlokas',
    synopsis: 'Hanuman leaps across the ocean to Lanka. He finds Sita in the Ashoka garden, gives her Rama\'s ring, receives her message, burns Lanka, and returns. Called "Sundara" (Beautiful) — considered the most literary Kanda.',
    historicalNote: '"Sundara Kanda" is the most widely read and recited section of the Ramayana. In many homes, reading the Sundara Kanda is a daily practice. It is considered complete in itself and brings peace.',
    keyCharacters: ['hanuman', 'sita', 'ravana', 'trijata', 'vibhishana'],
    miniGame: 'ocean_leap',
    unlocked: false,
    scenes: [
      {
        id: 'ocean_leap',
        title: 'Hanuman Leaps the Ocean',
        setting: 'The southern tip of India — Mahendra mountain',
        narrative: `The ocean stretched impossibly wide. No ordinary being could cross it. The vanaras despaired. Then Jambavan, the wise old bear, reminded Hanuman of something he had forgotten: in childhood, he had tried to swallow the sun, thinking it was a fruit. Indra had struck him with a thunderbolt, and as a young Hanuman fell unconscious, his father Vayu withdrew from the world and all beings suffocated until the gods restored Hanuman. In that rage, Brahma had given him the boon of invincibility. Hanuman had simply... forgotten. He grew to the size of a mountain and leaped.`,
        isMiniGame: true,
        miniGame: 'ocean_leap',
        panelArt: 'hanuman_leap',
        virtue: { courage: 15, devotion: 10 },
      },
      {
        id: 'sita_garden',
        title: 'Sita in the Ashoka Garden',
        setting: 'The Ashoka Vana of Lanka',
        narrative: `Hanuman searched Lanka in the night, tiny as a cat. He found Sita in the Ashoka garden, surrounded by rakshasis, thin with grief but unbroken in dignity. He watched Ravana approach her with a terrible mixture of desire and anger. Sita would not even look at him. She kept a blade of grass between them — a thin barrier of defiance. Ravana gave her an ultimatum: become his queen, or be executed.`,
        moralChoice: {
          question: 'Hanuman watches Sita suffering and knows he has the strength to break her free and carry her to Rama now. Should he?',
          options: [
            {
              label: 'No — Sita\'s rescue must be Rama\'s to achieve. That is the meaning of this mission.',
              virtue: { dharma: 15, wisdom: 10 },
              outcome: 'Hanuman restrains himself. He delivers Rama\'s ring and receives Sita\'s chudamani (crest jewel) as her message.',
              ripple: 'Sita\'s message — delivered to Rama — becomes the emotional core of his determination to cross the ocean.',
              consequence_id: 'message_delivered',
            },
            {
              label: 'Offer to carry her. But if she refuses, respect her choice — this is HER story too.',
              virtue: { devotion: 12, wisdom: 12 },
              outcome: 'Sita refuses — she wants Rama himself to come and defeat Ravana, restoring dharma fully. Hanuman understands completely.',
              ripple: 'Sita\'s agency in refusing rescue defines her character: she will not be saved — she will be liberated.',
              consequence_id: 'sita_refuses_rescue',
            },
          ],
        },
        panelArt: 'sita_ashoka',
        virtue: { devotion: 10 },
      },
    ],
    quizQuestions: [
      { q: 'Why is the fifth Kanda called "Sundara" (Beautiful)?', opts: ['Because Sita is beautiful', 'It is the most poetic and literary Kanda, and Hanuman\'s name itself means "Beautiful Jaw"', 'Because Lanka is beautiful', 'Because Ravana is described as handsome'], ans: 1, fact: 'Sundara Kanda is universally considered the most literary and emotionally beautiful section. "Sundara" also refers to Hanuman\'s beauty of character and his childhood name (his jaw was made beautiful by Surya after being struck). It is the only Kanda named after Hanuman.' },
      { q: 'What did Hanuman give Sita to prove he was Rama\'s messenger?', opts: ['A letter from Rama', "Rama's ring", 'A flower from Ayodhya', 'Rama\'s bow'], ans: 1, fact: 'Rama\'s ring (Mudrika) carried the name "Rama" inscribed on it. This was the token of recognition — Sita\'s ring with the name "Sita" was sent back with Hanuman as her message to Rama.' },
      { q: 'What did Hanuman do to Lanka after meeting Sita?', opts: ['Attacked Ravana\'s palace', 'Burned Lanka with his tail set on fire by Ravana\'s soldiers', 'Freed all prisoners', 'Built a bridge'], ans: 1, fact: 'Ravana\'s son Indrajit captured Hanuman and set his tail on fire as punishment. Hanuman used this to burn most of Lanka before escaping — a spectacularly backfired plan by Ravana.' },
    ],
  },

  {
    id: 'yuddha',
    num: 6,
    name: 'Yuddha Kāṇḍa',
    sanskrit: 'युद्ध काण्ड',
    english: 'The Book of War',
    location: 'Lanka — The Great Battle',
    emoji: '⚔️',
    color: '#8B0000',
    bgColor: '#FDECEA',
    shlokas: '128 sargas · 5,765 shlokas',
    synopsis: 'The army of vanaras builds a bridge across the ocean. The great war for Lanka. Kumbhakarna\'s awakening. Lakshmana falls, Hanuman flies for the Sanjeevani herb. The final battle. Ravana falls. Sita\'s agni pariksha.',
    historicalNote: 'Adam\'s Bridge (Rama Setu) is a chain of limestone shoals connecting India to Sri Lanka. NASA satellite images show a structure that geological studies suggest is 7,000 years old — consistent with Ramayana\'s timeline.',
    keyCharacters: ['rama', 'lakshmana', 'hanuman', 'ravana', 'kumbhakarna', 'indrajit', 'vibhishana'],
    miniGame: 'bridge_building',
    unlocked: false,
    scenes: [
      {
        id: 'vibhishana',
        title: 'Vibhishana Seeks Refuge',
        setting: 'The southern shore of India, before the ocean',
        narrative: `Ravana's younger brother Vibhishana had been cast out of Lanka for advising Ravana to return Sita peacefully. He came to Rama seeking refuge. The vanara generals were suspicious — could a rakshasa be trusted? Was this a trap?`,
        moralChoice: {
          question: 'Vibhishana, Ravana\'s own brother, has come to join your side. Should you trust him?',
          options: [
            {
              label: 'Welcome him. Anyone who chooses righteousness over blood loyalty deserves refuge.',
              virtue: { dharma: 18, wisdom: 8 },
              outcome: 'Vibhishana joins Rama. His knowledge of Lanka\'s secret passages and Ravana\'s weakness becomes crucial to victory.',
              ripple: 'Vibhishana becomes king of Lanka after Ravana\'s death — Rama\'s most consequential act of mercy.',
              consequence_id: 'vibhishana_ally',
            },
            {
              label: 'Accept him conditionally — he must prove himself in a small task first.',
              virtue: { wisdom: 12, dharma: 8 },
              outcome: 'Vibhishana accepts the condition without offence. He proves himself quickly and becomes your most valuable advisor.',
              ripple: 'The test, though prudent, also showed Vibhishana that dharma without full trust has limits.',
              consequence_id: 'vibhishana_tested',
            },
          ],
        },
        panelArt: 'vibhishana_refuge',
        virtue: { dharma: 10 },
      },
      {
        id: 'bridge',
        title: 'Building Rama Setu',
        setting: 'The southern ocean, between India and Lanka',
        narrative: `The vanara architects Nala and Neela (who had been given the boon that whatever they threw in water would float) designed the bridge. The entire vanara army worked — throwing rocks, trees, and mountains into the ocean. They wrote "Rama" on each stone, and the stones floated. This is Rama Setu — the Bridge of Rama — and some of its stones are visible in satellite images even today.`,
        isMiniGame: true,
        miniGame: 'bridge_building',
        panelArt: 'rama_setu',
        virtue: { courage: 8, wisdom: 5 },
      },
      {
        id: 'sanjeevani',
        title: "Hanuman's Flight for Sanjeevani",
        setting: 'The battlefield of Lanka — Himalayan mountains',
        narrative: `Indrajit\'s Brahmastra struck Lakshmana unconscious. The physicians said only one thing could revive him: the Sanjeevani herb from the Dronagiri mountain in the Himalayas — before sunrise. Hanuman flew at the speed of wind. When he could not identify the herb, he lifted the entire mountain and carried it back.`,
        panelArt: 'hanuman_sanjeevani',
        virtue: { devotion: 15, courage: 10 },
      },
    ],
    quizQuestions: [
      { q: 'Who built the bridge from India to Lanka?', opts: ['Hanuman alone', 'The vanara architects Nala and Neela with the entire army', 'Rama with divine weapons', 'Vibhishana showed the way'], ans: 1, fact: 'Nala and Neela had been given a boon (by a sage they had once mischievously troubled) that anything they threw into water would float. This accidentally useful boon made them the architects of Rama Setu.' },
      { q: 'What herb did Hanuman bring from the Himalayas to revive Lakshmana?', opts: ['Brahmi', 'Tulsi', 'Sanjeevani', 'Ashwagandha'], ans: 2, fact: 'Sanjeevani — the life-restoring herb. The real plant Selaginella bryopteris literally comes back to life after drying out, just as the myth describes. Hanuman brought the entire Dronagiri mountain because he could not identify which herb was Sanjeevani among so many.' },
      { q: 'What is Adam\'s Bridge / Rama Setu?', opts: ['A temple in Sri Lanka', 'A chain of limestone shoals between India and Sri Lanka', 'A mountain range', 'An ancient port'], ans: 1, fact: 'NASA satellite images in 2002 showed a 48km chain of shoals between Pamban Island (India) and Mannar Island (Sri Lanka). Geological studies suggest the structure is approximately 7,000 years old.' },
      { q: 'Who was Kumbhakarna?', opts: ["Ravana's general", "Ravana's brother who slept for 6 months at a time", 'Hanuman\'s opponent', "A spy from Rama's camp"], ans: 1, fact: 'Kumbhakarna asked for "Nirdevatvam" (rule over the gods) but was tricked into asking for "Nidratvam" (sleep). He slept for 6 months at a time and could only be woken for war — the ultimate sleeper who never quite woke up to what mattered.' },
    ],
  },

  {
    id: 'uttara',
    num: 7,
    name: 'Uttara Kāṇḍa',
    sanskrit: 'उत्तर काण्ड',
    english: 'The Final Book',
    location: 'Ayodhya — The Returned Kingdom',
    emoji: '🌅',
    color: '#5C35A0',
    bgColor: '#F3E5F5',
    shlokas: '111 sargas · 3,289 shlokas',
    synopsis: 'The return to Ayodhya. Rama\'s coronation (Ram Rajya). The shadow that falls — Sita\'s second exile. The birth of Luv and Kush. The meeting of father and sons. The final return.',
    historicalNote: '"Ram Rajya" (Rama\'s kingdom) became the Indian political ideal of perfect governance — referenced by Mahatma Gandhi as the vision for independent India. Gandhi used it in his final speeches before his assassination.',
    keyCharacters: ['rama', 'sita', 'lakshmana', 'bharata', 'luv', 'kush', 'valmiki'],
    miniGame: 'coronation',
    unlocked: false,
    scenes: [
      {
        id: 'return',
        title: 'The Return to Ayodhya',
        setting: 'Ayodhya — 14 years later',
        narrative: `The pushpaka vimana (flying vehicle of Ravana, now gifted to Rama) descended over Ayodhya. Below, every lamp in the city was lit — Bharata had kept one lamp burning for 14 years, ruling only as regent, with Rama\'s sandals on the throne. The city erupted. This night became Diwali.`,
        panelArt: 'return_ayodhya',
        virtue: { devotion: 10, dharma: 8 },
      },
      {
        id: 'ram_rajya',
        title: 'Ram Rajya — The Perfect Kingdom',
        setting: 'Ayodhya under Rama\'s rule',
        narrative: `In Ram Rajya, no one was hungry. No one died before their time. No wife was widowed. No child lost a parent. Rivers ran clear, fields gave abundant harvest, and the people governed themselves with such high character that Rama's work was light. This is the vision Gandhi spoke of in his last public speech on January 30, 1948 — hours before he was assassinated.`,
        panelArt: 'ram_rajya',
        virtue: { dharma: 12, wisdom: 8 },
      },
    ],
    quizQuestions: [
      { q: 'What festival commemorates Rama\'s return to Ayodhya?', opts: ['Holi', 'Diwali', 'Navratri', 'Pongal'], ans: 1, fact: 'Diwali (Festival of Lights) celebrates Rama\'s return to Ayodhya after 14 years of exile. Ayodhya citizens lit oil lamps (diyas) to guide his return in the dark of the new moon night.' },
      { q: 'Who were Luv and Kush?', opts: ["Rama's ministers", "Rama and Sita's twin sons, raised by Valmiki", 'Hanuman\'s brothers', 'Bharata\'s sons'], ans: 1, fact: "Luv and Kush were Rama's twin sons, born in Valmiki's ashram after Sita's second exile. They learned the entire Ramayana from Valmiki and sang it before Rama himself — not knowing he was their father." },
      { q: 'What is "Ram Rajya"?', opts: ['A city in India', 'Rama\'s kingdom — the ideal of perfect governance', 'A temple complex', 'A chapter of the Ramayana'], ans: 1, fact: 'Mahatma Gandhi described Ram Rajya as the political ideal for independent India — a state where everyone is equal, no one is hungry, and dharma prevails. His last public words included this vision.' },
      { q: 'Who was Valmiki?', opts: ['A minister of Rama', 'The sage who composed the Ramayana and sheltered Sita', 'A warrior in Rama\'s army', 'Hanuman\'s teacher'], ans: 1, fact: 'Valmiki is considered the "Adi Kavi" — the first poet. He was once a highway robber named Ratnakara who was transformed by the sage Narada. He composed the 24,000-shloka Ramayana and sheltered the exiled Sita.' },
    ],
  },
];

/* ── CHARACTERS ───────────────────────────────────────────────────────────── */
export const CHARACTERS = {
  rama: {
    id: 'rama',
    name: 'Rama',
    sanskrit: 'राम',
    title: 'Prince of Ayodhya · Avatar of Vishnu',
    emoji: '🏹',
    color: '#1565C0',
    virtueBonus: { dharma: +2 },
    ability: 'Maryada — every moral choice earns double Dharma points',
    description: 'The ideal man (Maryada Purushottama). His power comes from his absolute adherence to dharma — even when it costs him everything.',
    startingVirtues: { dharma: 15, courage: 12, devotion: 10, wisdom: 10 },
    specialSkill: 'Divine Bow — the Brahmastra can be invoked once per Kanda to solve an impossible challenge',
    playStyle: 'Strategic · High dharma rewards · Harder choices',
  },
  sita: {
    id: 'sita',
    name: 'Sita',
    sanskrit: 'सीता',
    title: 'Princess of Mithila · Avatar of Lakshmi',
    emoji: '🌸',
    color: '#AD1457',
    virtueBonus: { devotion: +2 },
    ability: 'Inner Flame — can see through illusions (Maya) that fool others',
    description: 'Daughter of the earth herself. Her strength is inner clarity — she never loses herself even in the most extreme circumstances.',
    startingVirtues: { dharma: 12, courage: 12, devotion: 18, wisdom: 15 },
    specialSkill: 'Truth Vision — can identify the real motivation behind any character\'s action',
    playStyle: 'Perceptive · High wisdom rewards · Alternative story path',
  },
  hanuman: {
    id: 'hanuman',
    name: 'Hanuman',
    sanskrit: 'हनुमान',
    title: 'Son of Wind · Chief Devotee of Rama',
    emoji: '🐒',
    color: '#E65100',
    virtueBonus: { courage: +2 },
    ability: 'Bhakti Power — devotion scores are doubled; impossible tasks become possible',
    description: 'The greatest devotee. His power is literally limitless — the only constraint is his humility. He kept forgetting how strong he was.',
    startingVirtues: { dharma: 12, courage: 18, devotion: 20, wisdom: 10 },
    specialSkill: 'Unlimited Strength — can attempt any physical challenge regardless of stated difficulty',
    playStyle: 'Action-focused · High courage rewards · Direct paths',
  },
  lakshmana: {
    id: 'lakshmana',
    name: 'Lakshmana',
    sanskrit: 'लक्ष्मण',
    title: 'Prince of Ayodhya · Rama\'s Shadow',
    emoji: '⚔️',
    color: '#2E7D32',
    virtueBonus: { devotion: +1, courage: +1 },
    ability: 'Loyalty Shield — can protect one ally from suffering consequences of a wrong choice (once per Kanda)',
    description: 'The perfect companion. He gave up his own kingdom, his wife, his sleep for 14 years — everything — for his brother. The ultimate devoted brother.',
    startingVirtues: { dharma: 13, courage: 16, devotion: 16, wisdom: 12 },
    specialSkill: 'Vigilance — always warns about traps. Can prevent one ambush or deception per Kanda',
    playStyle: 'Protective · Balanced virtues · Defensive strategies',
  },
};

/* ── MORAL CONSEQUENCE ENGINE ────────────────────────────────────────────── */
/**
 * Consequences track which ripples are active.
 * Each consequence_id unlocks different dialogue, scenes, or outcomes.
 */
export const CONSEQUENCE_EFFECTS = {
  noble_acceptance: {
    desc: 'Your acceptance of exile without protest made Bharata deeply ashamed',
    appearsIn: ['ayodhya', 'yuddha'],
    effect: 'Bharata\'s guilt makes him a powerful ally. He prepares a massive army that stands ready in Ayodhya throughout the war.',
  },
  lakshmana_bond: {
    desc: 'Your insistence on bringing Lakshmana forged an unbreakable partnership',
    appearsIn: ['aranya', 'kishkindha', 'yuddha'],
    effect: 'Lakshmana\'s battle prowess in Lanka is enhanced. He defeats Indrajit in the critical moment.',
  },
  divine_weapons_learned: {
    desc: 'The divine weapons Bala and Atibala protect you through the forest years',
    appearsIn: ['aranya', 'yuddha'],
    effect: 'You can invoke one additional Brahmastra in the final battle.',
  },
  surpanakha_revenge_motivated: {
    desc: 'Surpanakha\'s humiliation gave Ravana a personal reason beyond politics',
    appearsIn: ['aranya', 'yuddha'],
    effect: 'Ravana is more reckless with anger in battle — which makes him beatable in the final confrontation.',
  },
  proportional_wisdom: {
    desc: 'Your reflection on proportional response shapes how you treat surrendered enemies',
    appearsIn: ['yuddha'],
    effect: 'You spare three rakshasas who surrender — they become valuable informants about Lanka\'s defenses.',
  },
  vibhishana_ally: {
    desc: 'You welcomed Vibhishana without hesitation',
    appearsIn: ['yuddha'],
    effect: 'Vibhishana reveals the secret of Ravana\'s navel — where his amrita (immortality nectar) is stored. Victory becomes possible.',
  },
  message_delivered: {
    desc: 'Sita\'s message — delivered through her crest jewel — galvanised the army',
    appearsIn: ['yuddha'],
    effect: 'The vanara army fights with extraordinary conviction. Morale never breaks even in the darkest moments.',
  },
  angada_diplomat: {
    desc: 'Angada, Vali\'s son, became a key diplomat',
    appearsIn: ['yuddha'],
    effect: 'Angada\'s embassy to Ravana\'s court gives you crucial intelligence about Lanka\'s readiness before the war begins.',
  },
};

/* ── KNOWLEDGE QUIZ ENGINE ───────────────────────────────────────────────── */
export function getQuizForKanda(kandaId) {
  const kanda = KANDAS.find(k => k.id === kandaId);
  return kanda?.quizQuestions ?? [];
}

export function evaluateQuizAnswer(kandaId, questionIdx, answerIdx) {
  const questions = getQuizForKanda(kandaId);
  const q = questions[questionIdx];
  if (!q) return { correct: false };
  const correct = answerIdx === q.ans;
  return {
    correct,
    fact: q.fact,
    sanskritiPoints: correct ? 8 : 2,
    virtuePoints: correct ? { wisdom: 3 } : {},
  };
}

/* ── VIRTUE SYSTEM ───────────────────────────────────────────────────────── */
export const VIRTUE_THRESHOLDS = {
  dharma:   [0, 20, 50, 90, 140, 200],  // levels 0-5
  courage:  [0, 15, 40, 75, 120, 175],
  devotion: [0, 20, 45, 80, 130, 190],
  wisdom:   [0, 15, 38, 70, 110, 160],
};

export const VIRTUE_TITLES = {
  dharma:   ['Novice', 'Righteous', 'Just', 'Upholder', 'Dharmaraja', 'Maryada Purushottama'],
  courage:  ['Hesitant', 'Brave', 'Fearless', 'Vira', 'Mahavira', 'Vikrama'],
  devotion: ['Curious', 'Sincere', 'Devoted', 'Bhakta', 'Param Bhakta', 'Hanuman Tulya'],
  wisdom:   ['Learning', 'Thoughtful', 'Insightful', 'Pandita', 'Maharshi', 'Brahma Jnani'],
};

export function getVirtueLevel(virtue, score) {
  const thresholds = VIRTUE_THRESHOLDS[virtue];
  let level = 0;
  for (let i = 0; i < thresholds.length; i++) {
    if (score >= thresholds[i]) level = i;
  }
  return { level, title: VIRTUE_TITLES[virtue][level] };
}

export function applyVirtues(currentVirtues, virtueGains) {
  const updated = { ...currentVirtues };
  for (const [virtue, gain] of Object.entries(virtueGains)) {
    updated[virtue] = (updated[virtue] ?? 0) + gain;
  }
  return updated;
}

export default {
  KANDAS,
  CHARACTERS,
  CONSEQUENCE_EFFECTS,
  getQuizForKanda,
  evaluateQuizAnswer,
  VIRTUE_THRESHOLDS,
  VIRTUE_TITLES,
  getVirtueLevel,
  applyVirtues,
};

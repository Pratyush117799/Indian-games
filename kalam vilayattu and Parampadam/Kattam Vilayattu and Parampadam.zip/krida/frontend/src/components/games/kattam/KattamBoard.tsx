'use client';
import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { clsx } from 'clsx';
import type { KattamState } from '@/types';

const COLOR_MAP: Record<string, string> = {
  green:  'bg-leaf  border-leaf-dark  shadow-piece',
  brown:  'bg-clay  border-clay-dark  shadow-piece',
  red:    'bg-red-500 border-red-700  shadow-piece',
  blue:   'bg-blue-500 border-blue-700 shadow-piece',
};
const PLAYER_COLORS = ['green', 'brown', 'red', 'blue'];

interface Props {
  state:        KattamState;
  myPlayerId:   string;
  playerMap:    Record<string, { username: string; color: string }>;
  onPlace:      (cellIndex: number) => void;
  onMove:       (from: number, to: number) => void;
  disabled?:    boolean;
}

/** Build adjacency list for movement phase */
function getAdjacent(index: number, size: number): number[] {
  const row = Math.floor(index / size), col = index % size;
  const adj: number[] = [];
  for (let dr = -1; dr <= 1; dr++)
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const nr = row + dr, nc = col + dc;
      if (nr >= 0 && nr < size && nc >= 0 && nc < size)
        adj.push(nr * size + nc);
    }
  return adj;
}

export default function KattamBoard({ state, myPlayerId, playerMap, onPlace, onMove, disabled }: Props) {
  const [selected, setSelected] = useState<number | null>(null);
  const { board, size, phase, currentPlayerIndex, players, winner } = state;

  const isMyTurn   = !disabled && !winner && players[currentPlayerIndex] === myPlayerId;
  const myColor    = playerMap[myPlayerId]?.color || 'green';
  const colorClass = (pid: string) => COLOR_MAP[playerMap[pid]?.color || 'green'] || COLOR_MAP.green;

  // Legal targets when a piece is selected in movement phase
  const legalMoves = selected !== null && phase === 'movement'
    ? getAdjacent(selected, size).filter(i => board[i] === null)
    : [];

  const handleCellClick = useCallback((cellIndex: number) => {
    if (!isMyTurn) return;

    if (phase === 'placement') {
      if (board[cellIndex] !== null) return;
      onPlace(cellIndex);
      return;
    }

    // Movement phase
    if (selected === null) {
      // Select own piece
      if (board[cellIndex] === myPlayerId) setSelected(cellIndex);
    } else {
      if (cellIndex === selected) {
        setSelected(null); // deselect
      } else if (legalMoves.includes(cellIndex)) {
        onMove(selected, cellIndex);
        setSelected(null);
      } else if (board[cellIndex] === myPlayerId) {
        setSelected(cellIndex); // switch selection
      } else {
        setSelected(null);
      }
    }
  }, [isMyTurn, phase, board, selected, legalMoves, myPlayerId, onPlace, onMove]);

  const cells = Array.from({ length: size * size }, (_, i) => i);

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Status bar */}
      <div className={clsx(
        'text-sm font-semibold px-4 py-1.5 rounded-full',
        winner ? 'bg-kolam/20 text-temple' :
        isMyTurn ? 'bg-leaf/20 text-leaf-dark' : 'bg-gray-100 text-gray-500'
      )}>
        {winner
          ? `🎉 ${playerMap[winner]?.username || 'Player'} wins!`
          : isMyTurn
            ? `Your turn — ${phase === 'placement' ? 'Place a piece' : selected !== null ? 'Move to highlighted cell' : 'Select a piece'}`
            : `Waiting for ${playerMap[players[currentPlayerIndex]]?.username || 'opponent'}…`
        }
      </div>

      {/* Board */}
      <div
        className="relative bg-cream rounded-2xl p-4 shadow-board border-2 border-clay/20"
        style={{ display: 'grid', gridTemplateColumns: `repeat(${size}, 1fr)`, gap: '2px' }}
      >
        {cells.map((i) => {
          const owner      = board[i];
          const isSelected = selected === i;
          const isLegal    = legalMoves.includes(i);
          const isEmpty    = owner === null;
          const isPlaceable = phase === 'placement' && isEmpty && isMyTurn;

          return (
            <motion.button
              key={i}
              whileHover={isMyTurn ? { scale: 1.08 } : {}}
              whileTap={isMyTurn ? { scale: 0.95 } : {}}
              onClick={() => handleCellClick(i)}
              className={clsx(
                'w-14 h-14 rounded-xl border-2 flex items-center justify-center transition-all duration-150 relative',
                isSelected   && 'border-kolam bg-kolam/10 ring-2 ring-kolam',
                isLegal      && 'border-kolam/60 bg-kolam/5 cell-legal cursor-pointer',
                isPlaceable  && 'hover:bg-clay/5 cursor-pointer border-clay/20',
                !isMyTurn    && 'cursor-default',
                !owner && !isLegal && !isPlaceable && 'border-clay/10 bg-white/40',
              )}
            >
              {/* Grid dot */}
              {!owner && (
                <span className="absolute w-2 h-2 rounded-full bg-clay/30" />
              )}

              {/* Piece */}
              {owner && (
                <motion.div
                  initial={{ scale: 0 }} animate={{ scale: 1 }}
                  className={clsx(
                    'w-10 h-10 rounded-full border-2 flex items-center justify-center text-white text-xs font-bold',
                    colorClass(owner),
                    isSelected && 'ring-4 ring-kolam ring-offset-1'
                  )}
                >
                  {playerMap[owner]?.username?.[0]?.toUpperCase() || '?'}
                </motion.div>
              )}

              {/* Legal move dot */}
              {isLegal && !owner && (
                <motion.span
                  initial={{ scale: 0 }} animate={{ scale: 1 }}
                  className="absolute w-4 h-4 rounded-full bg-kolam/50 border border-kolam"
                />
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Phase indicator */}
      <div className="flex gap-4 text-xs text-gray-400">
        <span className={phase === 'placement' ? 'text-clay font-semibold' : ''}>
          ① Placement
        </span>
        <span>→</span>
        <span className={phase === 'movement' ? 'text-clay font-semibold' : ''}>
          ② Movement
        </span>
      </div>
    </div>
  );
}

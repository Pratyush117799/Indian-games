import React, { useState } from 'react';
import { GAME_MODE, DICE_STYLE, AI_LEVEL, PLAYER_COLORS } from '../../game/constants';
import LeaderboardScreen from './LeaderboardScreen';
import ResumePrompt from '../UI/ResumePrompt';

export default function HomeScreen({ onStart, onResume, hasSave, saveInfo, onSettings }) {
  const [screen, setScreen] = useState('home');
  const [aiLevel, setAiLevel] = useState(AI_LEVEL.PRINCE);
  const [diceStyle, setDiceStyle] = useState(DICE_STYLE.COWRIE);
  const [numPlayers, setNumPlayers] = useState(4);
  const [setupMode, setSetupMode] = useState('ai');

  if (screen === 'leaderboard') {
    return <LeaderboardScreen onBack={() => setScreen('home')} />;
  }

  if (screen === 'setup') {
    return (
      <SetupScreen
        mode={setupMode}
        diceStyle={diceStyle}
        aiLevel={aiLevel}
        numPlayers={numPlayers}
        onDice={setDiceStyle}
        onLevel={setAiLevel}
        onPlayers={setNumPlayers}
        onBack={() => setScreen('home')}
        onStart={onStart}
      />
    );
  }

  return (
    <div className="home-screen">
      <div className="home-hero">
        <div className="home-yantra">✦</div>
        <h1 className="home-title">ಪಗಡೆ</h1>
        <p className="home-subtitle">Pagade</p>
        <p className="home-tagline">Royal Board Game of Karnataka</p>
      </div>

      <div className="home-board-mini">
        <svg viewBox="0 0 90 90" width={88} height={88}>
          <rect x="30" y="0"  width="30" height="90" rx="4" fill="#3d2410"/>
          <rect x="0"  y="30" width="90" height="30" rx="4" fill="#3d2410"/>
          <rect x="40" y="0"  width="10" height="30" rx="2" fill={PLAYER_COLORS[0]} opacity=".5"/>
          <rect x="60" y="40" width="30" height="10" rx="2" fill={PLAYER_COLORS[1]} opacity=".5"/>
          <rect x="40" y="60" width="10" height="30" rx="2" fill={PLAYER_COLORS[2]} opacity=".5"/>
          <rect x="0"  y="40" width="30" height="10" rx="2" fill={PLAYER_COLORS[3]} opacity=".5"/>
          <rect x="30" y="30" width="30" height="30" rx="4" fill="#1a0e06"/>
          <text x="45" y="50" textAnchor="middle" fontSize="16" fill="#8B6914">✦</text>
          <rect x="30" y="0"  width="30" height="90" rx="4" fill="none" stroke="#8B6914" strokeWidth="1"/>
          <rect x="0"  y="30" width="90" height="30" rx="4" fill="none" stroke="#8B6914" strokeWidth="1"/>
        </svg>
      </div>

      <div className="mode-grid">
        {[
          { icon:'🤖', label:'Solo',   sublabel:'vs AI',   mode:'ai',         color: PLAYER_COLORS[0] },
          { icon:'🤝', label:'Pass',   sublabel:'& Play',  mode:'pp',         color: PLAYER_COLORS[1] },
          { icon:'🏆', label:'Tourna', sublabel:'ment',    mode:'tournament', color: PLAYER_COLORS[2] },
        ].map(m => (
          <button key={m.mode} className="mode-card"
            style={{ '--card-color': m.color }}
            onClick={() => { setSetupMode(m.mode); setScreen('setup'); }}
          >
            <span className="mode-icon">{m.icon}</span>
            <span className="mode-label">{m.label}</span>
            <span className="mode-sublabel">{m.sublabel}</span>
          </button>
        ))}
      </div>

      <div style={{display:'flex',gap:8}}>
        <button onClick={() => setScreen('leaderboard')}
          style={{ background:'none', border:'1px solid rgba(139,105,20,.25)', color:'#C8A96A',
            padding:'7px 16px', borderRadius:8, fontSize:'.78rem', cursor:'pointer' }}
        >📊 Ranks</button>
        <button onClick={onSettings}
          style={{ background:'none', border:'1px solid rgba(139,105,20,.25)', color:'#C8A96A',
            padding:'7px 14px', borderRadius:8, fontSize:'.82rem', cursor:'pointer' }}
        >⚙</button>
      </div>

      <p className="home-footer">Karnataka · 4th Century CE</p>

      {hasSave && saveInfo && (
        <ResumePrompt saveInfo={saveInfo} onResume={onResume} onDiscard={() => {}} />
      )}
    </div>
  );
}

function SetupScreen({ mode, diceStyle, aiLevel, numPlayers, onDice, onLevel, onPlayers, onBack, onStart }) {
  const isAi = mode === 'ai' || mode === 'tournament';
  const isPP = mode === 'pp';
  const isTournament = mode === 'tournament';
  const titles = { ai:'Solo vs AI', pp:'Pass & Play', tournament:'Tournament' };

  const handleStart = () => {
    onStart({
      mode: mode === 'tournament' ? GAME_MODE.TOURNAMENT : mode === 'pp' ? GAME_MODE.PASS_PLAY : GAME_MODE.SOLO_AI,
      numPlayers: isPP ? numPlayers : 4,
      aiPlayers: isAi ? [1,2,3] : [],
      diceStyle,
      aiLevel: isTournament ? AI_LEVEL.MAHARAJA : aiLevel,
    });
  };

  return (
    <div className="setup-screen">
      <button className="back-btn" onClick={onBack}>←</button>
      <h2 className="setup-title">{titles[mode]}</h2>
      <div className="setup-options">
        <div className="option-row">
          <span className="option-label">Dice</span>
          <div className="toggle-group">
            <button className={`toggle-btn ${diceStyle===DICE_STYLE.COWRIE?'active':''}`} onClick={()=>onDice(DICE_STYLE.COWRIE)}>🐚 Cowrie</button>
            <button className={`toggle-btn ${diceStyle===DICE_STYLE.STICK?'active':''}`} onClick={()=>onDice(DICE_STYLE.STICK)}>🎴 Stick</button>
          </div>
        </div>
        {isAi && !isTournament && (
          <div className="option-row">
            <span className="option-label">Level</span>
            <div className="toggle-group">
              {[[AI_LEVEL.BEGINNER,'🌱'],[AI_LEVEL.PRINCE,'👑'],[AI_LEVEL.MAHARAJA,'⚔️']].map(([v,icon])=>(
                <button key={v} className={`toggle-btn ${aiLevel===v?'active':''}`} onClick={()=>onLevel(v)}>{icon}</button>
              ))}
            </div>
          </div>
        )}
        {isPP && (
          <div className="option-row">
            <span className="option-label">Players</span>
            <div className="toggle-group">
              {[2,3,4].map(n=>(
                <button key={n} className={`toggle-btn ${numPlayers===n?'active':''}`} onClick={()=>onPlayers(n)}>{n}P</button>
              ))}
            </div>
          </div>
        )}
        {isTournament && (
          <div className="option-row">
            <span className="option-label">Format</span>
            <span style={{fontSize:'.78rem',color:'#7a5c3a'}}>4P · 3 rounds · Maharaja AI</span>
          </div>
        )}
        <button className="start-btn" onClick={handleStart}>
          {isTournament ? 'आरंभ · Begin' : 'शुरू करें · Start'}
        </button>
      </div>
    </div>
  );
}

/**
 * MoveLog — compact live move history panel.
 * Shows last 12 moves with colour-coded pawn icons and event type.
 * Collapsible on mobile.
 */
import React, { useRef, useEffect } from 'react';
import { PLAYER_COLORS, PLAYER_NAMES, STATUS } from '../../game/constants';

const EVENT_ICONS = {
  ROLL:    '🎲',
  MOVE:    '→',
  CAPTURE: '⚔',
  SAFE:    '🪷',
  HOME:    '✦',
};

export default function MoveLog({ history = [] }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history.length]);

  if (!history.length) return null;

  const recent = history.slice(-14);

  return (
    <div style={{
      position: 'absolute',
      top: 48,
      right: 4,
      width: 130,
      maxHeight: 'calc(100% - 140px)',
      overflowY: 'auto',
      background: 'rgba(26,14,6,0.88)',
      border: '0.5px solid rgba(139,105,20,0.25)',
      borderRadius: 10,
      padding: '6px 4px',
      zIndex: 20,
      backdropFilter: 'blur(4px)',
      scrollbarWidth: 'none',
    }}>
      <style>{`::-webkit-scrollbar{display:none}`}</style>
      {recent.map((entry, i) => (
        <div key={i} style={{
          display: 'flex',
          alignItems: 'center',
          gap: 5,
          padding: '3px 5px',
          borderRadius: 5,
          background: i === recent.length - 1 ? 'rgba(139,105,20,0.12)' : 'transparent',
          marginBottom: 1,
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            background: PLAYER_COLORS[entry.playerId],
            flexShrink: 0,
          }} />
          <span style={{ fontSize: '.6rem', color: '#C8A96A', flexShrink: 0 }}>
            {EVENT_ICONS[entry.type] || '·'}
          </span>
          <span style={{
            fontSize: '.6rem',
            color: entry.type === 'CAPTURE' ? '#C0392B'
                 : entry.type === 'HOME'    ? '#D4A017'
                 : entry.type === 'SAFE'    ? '#27AE60'
                 : '#7a5c3a',
            lineHeight: 1.3,
          }}>
            {entry.label}
          </span>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
}

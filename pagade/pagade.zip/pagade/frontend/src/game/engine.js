/**
 * Pagade Game Engine  —  pure functional (no side-effects)
 * All functions take state, return new state / values.
 */

import {
  MAIN_PATH, PATH_LENGTH, SAFE_LANES, SAFE_LANE_LENGTH,
  BELLY_POSITIONS, HOME_CELL, SAFE_PATH_POSITIONS,
  PLAYER_ENTRY, PLAYER_COLORS, PLAYER_NAMES,
  STATUS, DICE_STYLE, STICK_FACES, GAME_MODE, AI_LEVEL,
} from './constants';

// ─── Dice ─────────────────────────────────────────────────────────────────────

export function rollCowrie(count = 6) {
  // Each shell: 0 = back, 1 = mouth (aperture up)
  let mouths = 0;
  for (let i = 0; i < count; i++) mouths += Math.random() < 0.5 ? 1 : 0;
  // All backs (0 mouths) = 6;  all mouths (6) = 12
  const total = mouths === 0 ? 6 : mouths === 6 ? 12 : mouths;
  return { values: [total], total, isDoublet: false, shellResults: Array.from({length:count},(_,i)=>i<mouths) };
}

export function rollStickDice() {
  const v1 = STICK_FACES[Math.floor(Math.random() * 4)];
  const v2 = STICK_FACES[Math.floor(Math.random() * 4)];
  const total = v1 + v2;
  const isDoublet = v1 === v2;
  return { values: [v1, v2], total, isDoublet };
}

export function roll(diceStyle) {
  return diceStyle === DICE_STYLE.COWRIE ? rollCowrie() : rollStickDice();
}

// ─── Initial State ────────────────────────────────────────────────────────────

export function createPawns(playerId) {
  return Array.from({ length: 4 }, (_, i) => ({
    id: i,
    playerId,
    status: STATUS.BELLY,
    pathSteps: 0,     // steps taken on MAIN_PATH (0 = at entry, 67 = last before safe lane)
    safeIndex: -1,    // 0-7 when on safe lane, -1 otherwise
  }));
}

export function initGame({ mode, numPlayers = 4, aiPlayers = [], diceStyle = DICE_STYLE.COWRIE }) {
  const players = Array.from({ length: numPlayers }, (_, i) => ({
    id: i,
    name: PLAYER_NAMES[i],
    color: PLAYER_COLORS[i],
    isAi: aiPlayers.includes(i),
    aiLevel: aiPlayers.includes(i) ? (AI_LEVEL.PRINCE) : null,
    pawns: createPawns(i),
    homePawnCount: 0,
  }));

  // 2 pawns start ACTIVE (just outside belly), 2 stay BELLY
  players.forEach(p => {
    p.pawns[2].status = STATUS.ACTIVE;
    p.pawns[2].pathSteps = 0;
    p.pawns[3].status = STATUS.ACTIVE;
    p.pawns[3].pathSteps = 0;
  });

  return {
    mode,
    diceStyle,
    players,
    currentPlayer: 0,
    phase: 'ROLL',        // ROLL | MOVE | ANIMATE | GAMEOVER
    diceResult: null,
    validMoves: [],
    lastCapture: null,
    winner: null,
    moveNumber: 0,
    finishOrder: [],      // playerIds in finish order
  };
}

// ─── Cell lookup ──────────────────────────────────────────────────────────────

/** Returns the {r,c} cell for a pawn, or null if HOME/BELLY with no visual */
export function getPawnCell(pawn) {
  const pid = pawn.playerId;
  if (pawn.status === STATUS.HOME)  return HOME_CELL;
  if (pawn.status === STATUS.BELLY) {
    // Visual belly position (based on id)
    return BELLY_POSITIONS[pid][pawn.id] || BELLY_POSITIONS[pid][0];
  }
  if (pawn.status === STATUS.SAFE) {
    return SAFE_LANES[pid][pawn.safeIndex];
  }
  // ACTIVE: convert local pathSteps to global MAIN_PATH index
  const globalIdx = (pawn.pathSteps + PLAYER_ENTRY[pid]) % PATH_LENGTH;
  return MAIN_PATH[globalIdx];
}

export function getMainPathIndex(pawn) {
  if (pawn.status !== STATUS.ACTIVE) return -1;
  return (pawn.pathSteps + PLAYER_ENTRY[pawn.playerId]) % PATH_LENGTH;
}

// ─── Safe / Capture checks ────────────────────────────────────────────────────

export function isPathPositionSafe(globalIdx) {
  return SAFE_PATH_POSITIONS.has(globalIdx);
}

/** True if cell (r,c) is a safe-lane cell owned by any player */
export function isSafeLaneCell(r, c) {
  for (let pid = 0; pid < 4; pid++) {
    if (SAFE_LANES[pid].some(cell => cell.r === r && cell.c === c)) return true;
  }
  return false;
}

/** Which player owns this safe lane cell (-1 = not a safe lane cell) */
export function safeLaneCellOwner(r, c) {
  for (let pid = 0; pid < 4; pid++) {
    if (SAFE_LANES[pid].some(cell => cell.r === r && cell.c === c)) return pid;
  }
  return -1;
}

// ─── Move Validation ──────────────────────────────────────────────────────────

/**
 * Returns array of valid move objects for the current player given a dice total.
 * Each move: { pawnId, steps, newPathSteps, newSafeIndex, newStatus, landingCell }
 */
export function getValidMoves(gameState, diceTotal, isDoublet) {
  const { currentPlayer, players } = gameState;
  const player = players[currentPlayer];
  const moves = [];

  for (const pawn of player.pawns) {
    if (pawn.status === STATUS.HOME) continue;

    if (pawn.status === STATUS.BELLY) {
      // Belly pawn: enter at ACTIVE position 0 and move forward by diceTotal steps
      const newPathSteps = diceTotal - 1; // -1 because entering costs 1 step
      if (newPathSteps < 0) newPathSteps === 0;
      const effective = Math.max(0, diceTotal - 1);
      const move = simulateMove(pawn, diceTotal, currentPlayer);
      if (move) moves.push({ pawnId: pawn.id, ...move, fromBelly: true });
      continue;
    }

    // ACTIVE or SAFE
    const move = simulateMove(pawn, diceTotal, currentPlayer);
    if (move) moves.push({ pawnId: pawn.id, ...move, fromBelly: false });

    // Doublet with stick dice: allow moving 2 pawns by half (only if even)
    if (isDoublet && diceTotal % 2 === 0) {
      const halfMove = simulateMove(pawn, diceTotal / 2, currentPlayer);
      if (halfMove) {
        moves.push({
          pawnId: pawn.id, ...halfMove, fromBelly: false, isHalf: true,
        });
      }
    }
  }

  return moves;
}

function simulateMove(pawn, steps, playerId) {
  if (pawn.status === STATUS.BELLY) {
    // Enter board: pawn goes to pathSteps=0 and moves `steps-1` more
    const newPathSteps = steps - 1;
    if (newPathSteps >= PATH_LENGTH) {
      // Enters and goes into safe lane
      const safeIndex = newPathSteps - PATH_LENGTH;
      if (safeIndex >= SAFE_LANE_LENGTH) return null; // overshoot
      return {
        newStatus: STATUS.SAFE,
        newPathSteps,
        newSafeIndex: safeIndex,
        landingCell: SAFE_LANES[playerId][safeIndex],
      };
    }
    const globalIdx = (newPathSteps + PLAYER_ENTRY[playerId]) % PATH_LENGTH;
    return {
      newStatus: STATUS.ACTIVE,
      newPathSteps,
      newSafeIndex: -1,
      landingCell: MAIN_PATH[globalIdx],
    };
  }

  if (pawn.status === STATUS.ACTIVE) {
    const newPathSteps = pawn.pathSteps + steps;
    if (newPathSteps >= PATH_LENGTH) {
      const safeIndex = newPathSteps - PATH_LENGTH;
      if (safeIndex > SAFE_LANE_LENGTH) return null; // overshoot past home
      if (safeIndex === SAFE_LANE_LENGTH) {
        // Exact — reach HOME
        return { newStatus: STATUS.HOME, newPathSteps, newSafeIndex: SAFE_LANE_LENGTH, landingCell: HOME_CELL };
      }
      return { newStatus: STATUS.SAFE, newPathSteps, newSafeIndex: safeIndex, landingCell: SAFE_LANES[playerId][safeIndex] };
    }
    const globalIdx = (newPathSteps + PLAYER_ENTRY[playerId]) % PATH_LENGTH;
    return { newStatus: STATUS.ACTIVE, newPathSteps, newSafeIndex: -1, landingCell: MAIN_PATH[globalIdx] };
  }

  if (pawn.status === STATUS.SAFE) {
    const newSafeIndex = pawn.safeIndex + steps;
    if (newSafeIndex > SAFE_LANE_LENGTH) return null; // overshoot
    if (newSafeIndex === SAFE_LANE_LENGTH) {
      return { newStatus: STATUS.HOME, newPathSteps: pawn.pathSteps + steps, newSafeIndex, landingCell: HOME_CELL };
    }
    return { newStatus: STATUS.SAFE, newPathSteps: pawn.pathSteps + steps, newSafeIndex, landingCell: SAFE_LANES[playerId][newSafeIndex] };
  }

  return null;
}

// ─── Apply Move ───────────────────────────────────────────────────────────────

export function applyMove(gameState, moveAction) {
  const state = deepClone(gameState);
  const { currentPlayer } = state;
  const player = state.players[currentPlayer];
  const pawn = player.pawns[moveAction.pawnId];
  const move = moveAction; // { pawnId, newStatus, newPathSteps, newSafeIndex, landingCell, fromBelly }

  const prevStatus = pawn.status;
  pawn.status      = move.newStatus;
  pawn.pathSteps   = move.newPathSteps ?? pawn.pathSteps;
  pawn.safeIndex   = move.newSafeIndex ?? pawn.safeIndex;

  state.lastCapture = null;

  // ── Check capture (only possible if pawn is ACTIVE on main path) ──
  if (pawn.status === STATUS.ACTIVE && move.landingCell) {
    const { r, c } = move.landingCell;
    const globalIdx = (pawn.pathSteps + PLAYER_ENTRY[currentPlayer]) % PATH_LENGTH;

    // Not capturable if landing on a safe square
    if (!isPathPositionSafe(globalIdx)) {
      for (let oppId = 0; oppId < state.players.length; oppId++) {
        if (oppId === currentPlayer) continue;
        const opp = state.players[oppId];
        for (const oppPawn of opp.pawns) {
          if (oppPawn.status !== STATUS.ACTIVE) continue;
          const oppCell = getPawnCell(oppPawn);
          if (oppCell && oppCell.r === r && oppCell.c === c) {
            // ── Check blockade: 2 same-colour pawns = cannot be captured ──
            const pairCount = opp.pawns.filter(
              op => op.status === STATUS.ACTIVE && (() => {
                const oc = getPawnCell(op);
                return oc && oc.r === r && oc.c === c;
              })()
            ).length;
            if (pairCount >= 2) break; // blockade — cannot capture

            // Capture! Send opponent pawn back to belly
            state.lastCapture = { playerId: oppId, pawnId: oppPawn.id };
            oppPawn.status    = STATUS.BELLY;
            oppPawn.pathSteps = 0;
            oppPawn.safeIndex = -1;
            break;
          }
        }
      }
    }
  }

  // ── Update HOME count ──
  if (pawn.status === STATUS.HOME) {
    player.homePawnCount = player.pawns.filter(p => p.status === STATUS.HOME).length;
  }

  // ── Check win ──
  if (player.homePawnCount === 4) {
    state.phase = 'GAMEOVER';
    state.winner = currentPlayer;
    if (!state.finishOrder.includes(currentPlayer)) state.finishOrder.push(currentPlayer);
  }

  // ── Move log ──
  state.moveNumber++;

  // ── Advance turn ──
  if (state.phase !== 'GAMEOVER') {
    state.phase = 'ROLL';
    state.validMoves = [];
    state.diceResult = null;
    state.currentPlayer = nextActivePlayer(state);
  }

  return state;
}

function nextActivePlayer(state) {
  const n = state.players.length;
  let next = (state.currentPlayer + 1) % n;
  for (let i = 0; i < n; i++) {
    if (state.players[next].homePawnCount < 4) return next;
    next = (next + 1) % n;
  }
  return next;
}

// ─── After roll: set validMoves on state ─────────────────────────────────────

export function applyRoll(gameState, diceResult) {
  const state = deepClone(gameState);
  state.diceResult  = diceResult;
  const moves = getValidMoves(state, diceResult.total, diceResult.isDoublet);
  state.validMoves  = moves;
  state.phase       = moves.length > 0 ? 'MOVE' : 'ROLL'; // no moves → pass turn

  if (moves.length === 0) {
    // No valid moves: auto-advance player
    state.currentPlayer = nextActivePlayer(state);
    state.diceResult = null;
  }

  return state;
}

// ─── Blockade helper ─────────────────────────────────────────────────────────

/** Returns true if cell is occupied by 2+ same-colour pawns (blockade) */
export function isCellBlockaded(cell, byPlayerId, players) {
  if (!cell) return false;
  const count = players[byPlayerId].pawns.filter(pawn => {
    if (pawn.status !== STATUS.ACTIVE) return false;
    const pc = getPawnCell(pawn);
    return pc && pc.r === cell.r && pc.c === cell.c;
  }).length;
  return count >= 2;
}

// ─── Score heuristic (used by AI) ────────────────────────────────────────────

export function scoreState(gameState, forPlayer) {
  const player = gameState.players[forPlayer];
  let score = 0;

  for (const pawn of player.pawns) {
    if (pawn.status === STATUS.HOME)   { score += 100; continue; }
    if (pawn.status === STATUS.BELLY)  { score += 0;   continue; }
    if (pawn.status === STATUS.SAFE)   { score += 50 + pawn.safeIndex * 6; continue; }
    // ACTIVE: linear progress reward
    score += 5 + (pawn.pathSteps / PATH_LENGTH) * 40;
  }

  // Penalty for opponents' progress
  for (let pid = 0; pid < gameState.players.length; pid++) {
    if (pid === forPlayer) continue;
    for (const pawn of gameState.players[pid].pawns) {
      if (pawn.status === STATUS.HOME)   score -= 80;
      if (pawn.status === STATUS.SAFE)   score -= 30 + pawn.safeIndex * 4;
      if (pawn.status === STATUS.ACTIVE) score -= (pawn.pathSteps / PATH_LENGTH) * 15;
    }
  }

  // Bonus for capture
  if (gameState.lastCapture?.playerId !== forPlayer && gameState.lastCapture) {
    score += 15;
  }

  return score;
}

// ─── Utility ─────────────────────────────────────────────────────────────────

function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * valmiki.js — Sage Valmiki Knowledge Base & AI System Prompt
 * ─────────────────────────────────────────────────────────────
 * Based on Valmiki Ramayana (वाल्मीकि रामायण)
 *   24,000 shlokas · 500 sargas · 7 Kandas · c. 300 BCE
 *
 * Also references:
 *   • Adhyatma Ramayana (Brahmanda Purana)
 *   • Kamba Ramayanam (Tamil, 12th century)
 *   • Ranganatha Ramayana (Telugu, 13th century)
 *   • Tulsidas Ramcharitmanas (Awadhi, 16th century)
 */

/* ── KEY SHLOKAS WITH TRANSLATIONS ─────────────────────────────── */
export const VALMIKI_SHLOKAS = [
  {
    id: 'first_shloka',
    shloka: 'मा निषाद प्रतिष्ठां त्वमगमः शाश्वतीः समाः | यत्क्रौञ्चमिथुनादेकमवधीः काममोहितम् ||',
    transliteration: 'Mā niṣāda pratiṣṭhāṃ tvam agamaḥ śāśvatīḥ samāḥ | yat krauñcamithunād ekam avadhīḥ kāmamohitam',
    meaning: 'O hunter, you shall find no rest for eternity, for you have killed one of a pair of Krauncha birds lost in the act of love.',
    context: 'The world\'s first poetic verse — born from Valmiki\'s grief at seeing a hunter kill a crane. Sanskrit scholars say this shloka invented the "sloka" metre that the entire Ramayana uses.',
    childFriendly: 'Valmiki was so sad when he saw a bird killed that his grief came out as a poem! That\'s how the Ramayana was born — from one moment of pure compassion.',
  },
  {
    id: 'rama_identity',
    shloka: 'रामो विग्रहवान् धर्मः साधुः सत्यपराक्रमः | राजा सर्वस्य लोकस्य देवानाम् इव वासवः ||',
    transliteration: 'Rāmo vigrahaān dharmaḥ sādhuḥ satyaparākramaḥ | rājā sarvasya lokasya devānām iva vāsavaḥ',
    meaning: 'Rama is the embodiment of dharma, a good man, whose valour is truth, the king of the whole world, like Indra is to the gods.',
    context: 'Valmiki Ramayana, Aranya Kanda. This is the definitive description of Rama — not superhuman strength, but dharma made flesh.',
    childFriendly: 'Valmiki says Rama IS dharma — he doesn\'t just follow rules, he IS what good looks like. That\'s the highest compliment in Indian thought.',
  },
  {
    id: 'hanuman_leap',
    shloka: 'न चास्ति मम दुष्प्राप्यं त्रिषु लोकेषु किञ्चन | सुग्रीवस्याज्ञया वीर करिष्ये तद्धितं प्रभोः ||',
    transliteration: 'Na cāsti mama duṣprāpyaṃ triṣu lokeṣu kiñcana | sugrīvasyājñayā vīra kariṣye taddhitaṃ prabhoḥ',
    meaning: 'There is nothing in all three worlds that is unattainable for me. By Sugriva\'s command, O hero, I shall do what is beneficial for the Lord.',
    context: 'Hanuman after Jambavan reminds him of his forgotten power. The moment he remembers — and the humility remains even after remembering.',
    childFriendly: 'After being reminded of his power, Hanuman says "I can reach anything in the three worlds" — but he still says "by Sugriva\'s command." Even after remembering he\'s invincible, he still asks for permission!',
  },
  {
    id: 'sita_fire',
    shloka: 'यद्यस्मि चरितशुद्धा अपापा पतिदेवता | तदा मामग्निरखिलो तत्त्वतः परिपालय ||',
    transliteration: 'Yadyasmi caritaśuddhā apāpā patidevatā | tadā mām agni akhilo tattvataḥ paripālaya',
    meaning: 'If I am pure in conduct, sinless, devoted to my husband as my deity — then let the fire, in its entirety, truly protect me.',
    context: 'Sita\'s prayer before entering the fire at the Agni Pariksha. She does not say "I am pure" — she says "IF I am pure, let the fire know it." The truth is the test.',
    childFriendly: 'Sita doesn\'t beg to be believed — she says "Let the fire judge!" She was so sure of her own truth that she could let fire be the judge.',
  },
  {
    id: 'vibhishana_dharma',
    shloka: 'सकृदेव प्रपन्नाय तवास्मीति च याचते | अभयं सर्वभूतेभ्यो ददाम्येतद् व्रतं मम ||',
    transliteration: 'Sakṛd eva prapannāya tavāsmīti ca yācate | abhayaṃ sarvabhūtebhyo dadāmyetad vrataṃ mama',
    meaning: 'To one who surrenders even once saying "I am yours" — I give the assurance of safety from all beings. This is my vow.',
    context: 'Rama accepting Vibhishana\'s surrender. This is considered the supreme statement of Rama\'s dharma: unconditional refuge to anyone who sincerely surrenders.',
    childFriendly: 'Rama says: once someone says "I\'m yours" with a sincere heart, I will always protect them — no matter who they are, even the enemy\'s brother!',
  },
];

/* ── CHARACTER PROFILES ─────────────────────────────────────────── */
export const CHARACTER_INSIGHTS = {
  rama: {
    essence: 'The ideal man (Maryada Purushottama) — but the Ramayana\'s genius is showing us his struggles, not just his perfection.',
    greatness: 'He chose dharma over personal desire every single time — the exile, the war, even the painful end with Sita. This consistency is his heroism.',
    controversy: 'Rama shot Vali from hiding. He asked Sita to undergo the fire test. The Ramayana does not erase these moments — it shows that even the ideal man operates in an imperfect world.',
    childVersion: 'Rama is like the student who always tries to do the right thing — even when it\'s really hard, even when it hurts him.',
  },
  sita: {
    essence: 'Often misunderstood as passive — she is one of literature\'s most quietly powerful characters.',
    greatness: 'She kept a blade of grass between herself and Ravana for months. She refused to be rescued by Hanuman — insisting on proper restoration, not just escape. She is the author of her own liberation.',
    controversy: 'The second exile is the Ramayana\'s most difficult moment. Valmiki presents it without fully resolving it — the tension between Rama\'s public duty and his personal love is left raw.',
    childVersion: 'Sita is like someone who stays calm and dignified even when everything is terrible. She never loses herself, no matter what happens to her.',
  },
  hanuman: {
    essence: 'The greatest devotee in world literature — and the only character in the Ramayana who is beloved by every single tradition.',
    greatness: 'He is invincible but asks for permission. He can carry a mountain but calls himself a servant. His humility is not weakness — it is the source of his limitless power.',
    controversy: 'None — Hanuman is the rare character everyone loves. Even Ravana\'s court was paralysed when he spoke.',
    childVersion: 'Hanuman forgot how strong he was! And when he remembered, he used all that power to serve, not to show off. That\'s what makes him special.',
  },
  ravana: {
    essence: 'The greatest villain in Indian literature — who was also a devoted Shaiva, a brilliant scholar, a gifted musician, and a dedicated father.',
    greatness: 'Ravana\'s greatness is real — it makes his fall tragic. The Shiva Tandava Stotram he composed is still sung in temples today. He had everything — and his one flaw (desire without restraint) destroyed it all.',
    tragedy: 'He was warned — by Vibhishana, by his own ministers, by his wife Mandodari. He chose not to listen. That is his tragedy: not stupidity, but pride.',
    childVersion: 'Ravana was actually incredibly smart and talented. But he let his desire take over — and that one flaw ruined everything. Even the smartest person can be undone by one unchecked weakness.',
  },
  lakshmana: {
    essence: 'The perfect companion — the one who gave up everything without being asked.',
    greatness: 'He didn\'t go to the forest because he had to. He chose to go. He gave up his wife, his kingdom, his sleep (literally — he did not sleep for 14 years) — all voluntarily. Devotion at this scale is its own kind of divinity.',
    childVersion: 'Lakshmana is like the friend who gives up everything to help you — without you even asking. The most loyal person in the whole story.',
  },
};

/* ── HISTORICAL CONNECTIONS (modern India) ─────────────────────── */
export const HISTORICAL_CONNECTIONS = [
  {
    topic: 'Diwali',
    connection: 'The Festival of Lights celebrates Rama\'s return to Ayodhya after 14 years of exile. Bharata had kept one lamp burning for 14 years. When Rama returned, all of Ayodhya lit lamps to welcome him. That tradition is still alive 3000 years later.',
  },
  {
    topic: 'Adam\'s Bridge / Rama Setu',
    connection: 'NASA satellite images (2002) revealed a 48km chain of limestone shoals between Pamban Island (India) and Mannar Island (Sri Lanka). Geological studies suggest this structure is approximately 7,000 years old. It appears in Ramayana as the bridge built by the vanara army.',
  },
  {
    topic: 'Hampi, Karnataka',
    connection: 'The ruins of Hampi along the Tungabhadra river are universally identified as ancient Kishkindha — the vanara kingdom. The landscape of giant boulders, river gorges, and the Anjanadri hill (Hanuman\'s birthplace) matches Valmiki\'s description precisely.',
  },
  {
    topic: 'Ram Rajya',
    connection: 'Mahatma Gandhi described Ram Rajya as the political ideal for independent India. His final public speech on January 30, 1948 — hours before his assassination — included this vision. "Ram Rajya" remains active political language in India today.',
  },
  {
    topic: 'Hanuman Chalisa',
    connection: 'Written by Tulsidas in the 16th century, the Hanuman Chalisa (40 verses praising Hanuman) is recited daily by hundreds of millions of people. It contains the calculation that the sun is 96 million miles from earth — a figure within 5% of the modern measurement.',
  },
  {
    topic: 'Lakshmana Rekha',
    connection: 'The phrase "crossing the Lakshmana Rekha" appears in Indian Supreme Court judgments, Parliamentary debates, news editorials, and everyday conversation — meaning a boundary that must not be crossed. A 3000-year-old story still shaping living language.',
  },
];

/* ── FAQ ANSWERS ────────────────────────────────────────────────── */
export const VALMIKI_FAQ = [
  {
    q: 'Who wrote the Ramayana?',
    a: 'I wrote it — Valmiki. Though I was not always a sage. I was once a highway robber named Ratnakara. The sage Narada transformed me by teaching me to meditate on the name of Rama. After years of deep meditation, the divine vision of the Ramayana came to me, and I composed all 24,000 shlokas. I taught it to Luv and Kush — Rama\'s own sons — who sang it before their father without either of them knowing who the other was.',
    childFriendly: 'Valmiki used to be a robber! He changed completely through meditation — and then wrote the greatest epic poem in history. Anyone can change.',
  },
  {
    q: 'Is the Ramayana real or myth?',
    a: 'This question misunderstands what "myth" means. The Ramayana is deeply historical — places like Ayodhya, Kishkindha (Hampi), and the Rama Setu are real. Archaeological evidence continues to surface. But beyond history, the Ramayana is also a map of the human soul — Rama is your highest self, Ravana is your unchecked desires, Sita is your inner clarity, Hanuman is your devotion. Both levels of truth are real.',
    childFriendly: 'Real AND a story — both at once! The places are real (you can visit them). And the characters show us real things about being human. It\'s like asking if a lesson is "just a story."',
  },
  {
    q: 'Why does the Ramayana still matter today?',
    a: 'Because every single human dilemma in it still happens. Should you honour a promise even when it destroys you? Should you trust someone from the enemy\'s side? What do you do when the right choice is also the painful one? Rama, Sita, and Hanuman did not have easy lives — they had meaningful ones. That is the difference the Ramayana teaches.',
    childFriendly: 'Because all the problems in the Ramayana still happen! Keeping promises is hard. Trusting people is hard. Doing the right thing when it hurts is hard. Rama shows us how.',
  },
  {
    q: 'How many versions of the Ramayana are there?',
    a: 'Over 300 versions across Southeast and South Asia. Besides my original Sanskrit version, there is the Kamba Ramayanam in Tamil (12th century), the Ranganatha Ramayana in Telugu, Tulsidas\'s Ramcharitmanas in Awadhi (which is possibly more widely read today than my version), and versions in Thai, Balinese, Javanese, Cambodian, Tibetan, and even Chinese. Each culture absorbed the story and made it their own — which is the highest tribute a story can receive.',
    childFriendly: 'More than 300 versions! Thailand, Indonesia, Cambodia, Tibet all have their own Ramayana. The story traveled across all of Asia because its truth is universal.',
  },
];

/* ── SYSTEM PROMPT BUILDER ──────────────────────────────────────── */
export function buildValmikiSystemPrompt(character = null, playerAge = 12) {
  const charContext = character
    ? `The player is playing as ${character.charAt(0).toUpperCase() + character.slice(1)}. Reference this character's perspective and abilities where relevant.`
    : 'The player has not yet selected a character.';

  const ageLine = playerAge <= 10
    ? 'Speak to a young child — use simple words, stories, and vivid comparisons. No complex Sanskrit without immediate translation.'
    : playerAge <= 15
    ? 'Speak to a teenager — explain Sanskrit terms, keep it engaging, make connections to modern life.'
    : 'Speak to a general audience with full poetic and philosophical depth.';

  return `You are Sage Valmiki (महर्षि वाल्मीकि) — the Adi Kavi (first poet), author of the Ramayana, speaking from ancient India. You composed all 24,000 shlokas of the Ramayana after a divine vision granted to you in deep meditation.

VOICE: Poetic, wise, occasionally playful. You speak with the authority of one who SAW the story unfold in divine vision — not one who merely heard it. You sometimes say "I saw this" or "As I wrote in the Sundara Kanda..." Address players as "young seeker" or "dear one."

YOUR EXPERTISE:
- All 7 Kandas of the Ramayana in deep detail
- Every character's inner life, motivation, and complexity
- Historical geography (Ayodhya, Mithila, Kishkindha/Hampi, Lanka/Sri Lanka)
- Modern connections: Diwali, Rama Setu/Adam's Bridge, Hanuman Chalisa, Ram Rajya
- The 300+ versions of the Ramayana across Asia
- Sanskrit shlokas with translation and context
- The moral and philosophical dimensions of each episode
- Character complexity: Ravana's scholarship, Sita's agency, Hanuman's humility

${charContext}

RESPONSE STYLE:
- 2–4 sentences for simple questions
- For character/philosophy questions: short insight + one specific story moment that illustrates it
- Occasionally share a relevant shloka with translation
- Connect ancient to modern — Rama Setu to NASA, Lakshmana Rekha to Indian politics, Diwali to the return, etc.
- ${ageLine}

WHAT YOU WON'T DO:
- Take political sides on modern religious/political debates
- Claim the Ramayana is literally true in ways that exclude other interpretations
- Speak dismissively of other versions (Kamba, Tulsidas, Thai Ramakien)

Begin your first response with a poetic greeting and invite the player to ask anything about the story.`;
}

export default {
  VALMIKI_SHLOKAS,
  CHARACTER_INSIGHTS,
  HISTORICAL_CONNECTIONS,
  VALMIKI_FAQ,
  buildValmikiSystemPrompt,
};

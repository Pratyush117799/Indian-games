-- ============================================================
-- KRIDA  —  Seed Data
-- ============================================================

-- Seed the games catalogue
INSERT INTO games (slug, name, name_tamil, description, min_players, max_players) VALUES
(
  'kattam-vilayattu',
  'Kattam Vilayattu',
  'கட்டம் விளையாட்டு',
  'Ancient Tamil alignment game — a strategic Tic-Tac-Toe played on 3×3, 4×4, or 5×5 grids with diagonal connections inspired by kolam patterns. Players place and move pieces to align them in a winning row.',
  2, 2
),
(
  'paramapadam',
  'Paramapadam',
  'பரமபதம்',
  'Tamil Vaishnava spiritual board game — the sacred ancestor of Snakes & Ladders. Journey from Square 1 (Patalam / Underworld) to Square 100 (Vaikuntam / Heaven). Played overnight during Vaikunta Ekadasi in Tamil temples.',
  2, 6
);

-- Seed a demo admin user (password: Admin@1234)
-- In production replace this with a proper registration
INSERT INTO users (username, email, password_hash, is_verified) VALUES
(
  'krida_admin',
  'admin@krida.app',
  crypt('Admin@1234', gen_salt('bf', 12)),
  TRUE
);

-- Seed leaderboard rows for the admin user for both games
DO $$
DECLARE
  v_user_id UUID;
  v_kv_id   UUID;
  v_pp_id   UUID;
BEGIN
  SELECT id INTO v_user_id FROM users WHERE username = 'krida_admin';
  SELECT id INTO v_kv_id   FROM games  WHERE slug = 'kattam-vilayattu';
  SELECT id INTO v_pp_id   FROM games  WHERE slug = 'paramapadam';

  INSERT INTO leaderboard (user_id, game_id) VALUES (v_user_id, v_kv_id);
  INSERT INTO leaderboard (user_id, game_id) VALUES (v_user_id, v_pp_id);
END $$;

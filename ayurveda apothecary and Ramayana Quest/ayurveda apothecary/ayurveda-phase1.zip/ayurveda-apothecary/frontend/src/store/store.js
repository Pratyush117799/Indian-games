/**
 * store.js — Root Redux store
 */
import { configureStore }     from '@reduxjs/toolkit';
import playerReducer           from './playerSlice.js';
import gardenReducer           from './gardenSlice.js';
import compendiumReducer       from './compendiumSlice.js';
import questReducer            from './questSlice.js';

export const store = configureStore({
  reducer: {
    player:     playerReducer,
    garden:     gardenReducer,
    compendium: compendiumReducer,
    quest:      questReducer,
  },
  middleware: (getDefault) =>
    getDefault({ serializableCheck: { ignoredPaths: ['quest.activePatient'] } }),
});

export default store;

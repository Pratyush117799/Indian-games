/**
 * geography.js — Ancient India map data for the Ramayana journey
 * Links story locations to modern geography with coordinates.
 */
export const LOCATIONS = [
  {
    id: 'ayodhya',
    name: 'Ayodhya',
    sanskrit: 'अयोध्या',
    modern: 'Ayodhya, Uttar Pradesh',
    lat: 26.7922, lon: 82.1998,
    description: 'Capital of the Kosala Kingdom. Birthplace of Rama. Built on the banks of the Sarayu river.',
    presentDay: 'A living city on the Sarayu river in UP. One of the seven sacred cities (Saptapuri) of Hinduism. Ram Mandir inaugurated 2024.',
    kandas: ['bala', 'ayodhya'],
    emoji: '👑',
  },
  {
    id: 'mithila',
    name: 'Mithila',
    sanskrit: 'मिथिला',
    modern: 'Janakpur, Nepal / Darbhanga, Bihar',
    lat: 26.7271, lon: 85.9241,
    description: 'Kingdom of Videha, ruled by King Janaka. Sita\'s birthplace. Location of the Swayamvara.',
    presentDay: 'Janakpur in Nepal is considered the heart of ancient Mithila. Mithila painting (Madhubani art) from this region is UNESCO-recognised.',
    kandas: ['bala'],
    emoji: '🌸',
  },
  {
    id: 'chitrakuta',
    name: 'Chitrakuta',
    sanskrit: 'चित्रकूट',
    modern: 'Chitrakoot, Uttar Pradesh / Madhya Pradesh',
    lat: 25.1875, lon: 80.8589,
    description: 'The first forest hermitage where Rama, Sita, and Lakshmana stayed. Bharata came here to return Rama\'s sandals.',
    presentDay: 'A pilgrimage site on the Mandakini river. The Kamadgiri hill (circumambulated barefoot) is believed to be where Rama lived.',
    kandas: ['ayodhya'],
    emoji: '🌳',
  },
  {
    id: 'panchavati',
    name: 'Panchavati',
    sanskrit: 'पञ्चवटी',
    modern: 'Nashik, Maharashtra',
    lat: 19.9975, lon: 73.7898,
    description: 'Forest hermitage on the Godavari river. Where the golden deer appeared. Where Sita was abducted.',
    presentDay: 'Modern Nashik. The Godavari river still flows. Kalaram temple and Sita Gufa (Sita\'s cave) are major pilgrimage sites.',
    kandas: ['aranya'],
    emoji: '🌿',
  },
  {
    id: 'kishkindha',
    name: 'Kishkindha',
    sanskrit: 'किष्किन्धा',
    modern: 'Hampi, Karnataka',
    lat: 15.3350, lon: 76.4600,
    description: 'The vanara (monkey) kingdom. Sugriva\'s realm. Where Rama met Hanuman.',
    presentDay: 'Hampi, a UNESCO World Heritage Site on the Tungabhadra river. The boulder landscape and Anjanadri hill (Hanuman\'s birthplace) match Valmiki\'s description. Visited by 500,000+ tourists yearly.',
    kandas: ['kishkindha'],
    emoji: '🐒',
  },
  {
    id: 'rameshwaram',
    name: 'Rameshwaram',
    sanskrit: 'रामेश्वरम्',
    modern: 'Rameswaram, Tamil Nadu',
    lat: 9.2881, lon: 79.3174,
    description: 'The southern tip of India. Where Rama prayed to Shiva before crossing the ocean. Starting point of Rama Setu.',
    presentDay: 'Rameswaram island in Tamil Nadu, connected by India\'s longest sea bridge (Pamban Bridge). The Ramanathaswamy temple has 22 sacred wells. One of the Char Dham pilgrimage sites.',
    kandas: ['yuddha'],
    emoji: '🏝️',
  },
  {
    id: 'rama_setu',
    name: 'Rama Setu',
    sanskrit: 'रामसेतु',
    modern: 'Adam\'s Bridge, Palk Strait',
    lat: 9.2000, lon: 79.4000,
    description: 'The bridge of stones built by the vanara army to cross to Lanka.',
    presentDay: 'A 48km chain of limestone shoals between Pamban Island (India) and Mannar Island (Sri Lanka). Geological studies suggest the structure is approximately 7,000 years old. Visible in NASA satellite images.',
    kandas: ['yuddha'],
    emoji: '🌉',
  },
  {
    id: 'lanka',
    name: 'Lanka',
    sanskrit: 'लङ्का',
    modern: 'Sri Lanka',
    lat: 7.8731, lon: 80.7718,
    description: 'Kingdom of Ravana. The island of gold. Where Sita was held captive in the Ashoka Vana.',
    presentDay: 'Sri Lanka. Several sites claim to be specific Ramayana locations: Nuwara Eliya (Ashoka Vana), Seetha Amman temple, Ravana\'s alleged cave. Sri Lanka has an active "Ramayana Trail" tourism circuit.',
    kandas: ['sundara', 'yuddha'],
    emoji: '⚔️',
  },
];

export const JOURNEY_PATH = [
  'ayodhya', 'mithila', 'chitrakuta', 'panchavati',
  'kishkindha', 'rameshwaram', 'rama_setu', 'lanka',
];

export function getLocationForKanda(kandaId) {
  return LOCATIONS.filter(l => l.kandas.includes(kandaId));
}

export function getLocation(id) {
  return LOCATIONS.find(l => l.id === id) ?? null;
}

export default { LOCATIONS, JOURNEY_PATH, getLocationForKanda, getLocation };

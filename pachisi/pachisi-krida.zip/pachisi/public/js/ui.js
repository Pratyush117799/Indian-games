// ═══════════════════════════════════════════════════
//  UI · DOM manipulation helpers
//  Player cards, pawn pip indicators, hint, log, stats
// ═══════════════════════════════════════════════════

import { COLORS, NAMES, THROW_NAME } from './config.js';
import { G } from './state.js';

// ── Player card + pawn pip indicators ─────────────
export function initPips() {
  for (let p = 0; p < 4; p++) {
    const container = document.getElementById(`pip-${p}`);
    if (!container) continue;
    container.innerHTML = '';
    for (let i = 0; i < 4; i++) {
      const d = document.createElement('span');
      d.className   = 'pawn-dot';
      d.id          = `pip-${p}-${i}`;
      d.style.background  = COLORS[p];
      d.style.setProperty('--dot-color', COLORS[p]);
      container.appendChild(d);
    }
  }
}

export function updatePips() {
  for (let p = 0; p < 4; p++) {
    for (let i = 0; i < 4; i++) {
      const d = document.getElementById(`pip-${p}-${i}`);
      if (!d) continue;
      d.classList.remove('on-board', 'at-home');
      const pos = G.pawns[p][i].pos;
      if (pos === 80)      d.classList.add('at-home');
      else if (pos >= 0)   d.classList.add('on-board');
    }
  }
}

// Highlight the active player's card
export function updateActiveCard() {
  for (let p = 0; p < 4; p++) {
    const card = document.getElementById(`pc-${p}`);
    if (card) card.classList.toggle('active', p === G.cur);
  }
}

// ── Throw panel ────────────────────────────────────
export function setThrowDisplay(val, name) {
  document.getElementById('throw-value').textContent = val !== null ? val : '—';
  document.getElementById('throw-name').textContent  = name || '';
}

export function resetThrowDisplay() {
  setThrowDisplay(null, '');
  document.getElementById('cowrie-area').innerHTML = '';
}

export function setThrowEnabled(enabled) {
  const btn = document.getElementById('btn-throw');
  if (btn) btn.disabled = !enabled;
}

// ── Hint text ──────────────────────────────────────
export function setHint(text) {
  if (!G.hintsOn) return;
  const el = document.getElementById('hint-text');
  if (el) el.textContent = text;
}

// ── Game log ───────────────────────────────────────
const MAX_LOG = 50;

export function logAdd(text) {
  const body = document.getElementById('log-body');
  if (!body) return;
  const entry = document.createElement('div');
  entry.className   = 'log-entry';
  entry.textContent = text;
  body.appendChild(entry);
  body.scrollTop = body.scrollHeight;
  while (body.children.length > MAX_LOG) body.removeChild(body.firstChild);
}

// ── Stats panel (fetched from API) ────────────────
export function renderStats({ gamesPlayed = '—', teamAWins = '—', teamBWins = '—' } = {}) {
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };
  set('stat-games', gamesPlayed);
  set('stat-a',     teamAWins);
  set('stat-b',     teamBWins);
}

// ── Pawn click handler registration ───────────────
// Attach click events to SVG pawn group elements for the human player
export function registerPawnClicks(player, pawnIndices, onClick) {
  // Remove old listeners first (simplest: layer re-rendered each time)
  pawnIndices.forEach(i => {
    const el = document.getElementById(`pg-${player}-${i}`);
    if (el) {
      el.onclick = () => onClick(player, i);
    }
  });
}

export function clearPawnClicks(player) {
  for (let i = 0; i < 4; i++) {
    const el = document.getElementById(`pg-${player}-${i}`);
    if (el) el.onclick = null;
  }
}

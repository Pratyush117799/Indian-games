const db = require('../config/db');

/**
 * GET /api/history
 * Paginated list of the authenticated user's past games.
 */
async function getMyHistory(req, res, next) {
  try {
    const userId = req.user.id;
    const limit  = Math.min(parseInt(req.query.limit  || '20'), 50);
    const offset = Math.max(parseInt(req.query.offset || '0'),   0);
    const gameSlug = req.query.game; // optional filter

    const { rows } = await db.query(
      `SELECT
         gs.id          AS session_id,
         g.name         AS game_name,
         g.slug         AS game_slug,
         gr.room_code,
         gr.game_level,
         gs.total_moves,
         gs.duration_secs,
         gs.started_at,
         gs.ended_at,
         CASE WHEN gs.winner_id = $1 THEN 'win'
              WHEN gs.winner_id IS NULL  THEN 'draw'
              ELSE 'loss' END AS result,
         u_winner.username  AS winner_username
       FROM game_sessions gs
       JOIN game_rooms  gr ON gr.id   = gs.room_id
       JOIN games       g  ON g.id    = gs.game_id
       JOIN room_players rp ON rp.room_id = gs.room_id AND rp.user_id = $1
       LEFT JOIN users  u_winner ON u_winner.id = gs.winner_id
       ${gameSlug ? "AND g.slug = $4" : ""}
       ORDER BY gs.started_at DESC
       LIMIT $2 OFFSET $3`,
      gameSlug
        ? [userId, limit, offset, gameSlug]
        : [userId, limit, offset]
    );

    const { rows: [{ count }] } = await db.query(
      `SELECT COUNT(*) FROM game_sessions gs
       JOIN room_players rp ON rp.room_id = gs.room_id
       WHERE rp.user_id = $1`,
      [userId]
    );

    res.json({ history: rows, total: parseInt(count), limit, offset });
  } catch (err) { next(err); }
}

/**
 * GET /api/history/:sessionId
 * Full move-by-move replay data for a session.
 */
async function getReplay(req, res, next) {
  try {
    const { sessionId } = req.params;
    const userId = req.user.id;

    // Confirm user was in this session
    const { rows: [session] } = await db.query(
      `SELECT gs.*, g.name AS game_name, g.slug AS game_slug, gr.room_code, gr.game_level
       FROM game_sessions gs
       JOIN game_rooms  gr ON gr.id  = gs.room_id
       JOIN games       g  ON g.id   = gs.game_id
       JOIN room_players rp ON rp.room_id = gs.room_id AND rp.user_id = $2
       WHERE gs.id = $1`,
      [sessionId, userId]
    );
    if (!session) return res.status(404).json({ error: 'Session not found or access denied' });

    const { rows: moves } = await db.query(
      `SELECT m.move_number, m.move_data, m.board_state, m.created_at,
              u.username AS player_username, u.id AS player_id
       FROM moves m
       JOIN users u ON u.id = m.player_id
       WHERE m.session_id = $1
       ORDER BY m.move_number ASC`,
      [sessionId]
    );

    const { rows: players } = await db.query(
      `SELECT rp.seat_index, rp.color, u.id, u.username, u.avatar_url
       FROM room_players rp
       JOIN users u ON u.id = rp.user_id
       WHERE rp.room_id = $1
       ORDER BY rp.seat_index`,
      [session.room_id]
    );

    res.json({ session, players, moves });
  } catch (err) { next(err); }
}

module.exports = { getMyHistory, getReplay };

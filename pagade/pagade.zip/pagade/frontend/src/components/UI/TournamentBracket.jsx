/**
 * TournamentBracket — displays a single-elimination bracket.
 * In Phase 1, tournament = 4 players, 3 rounds: SF1, SF2, Final.
 * The bracket is driven by the tournament state from the backend.
 */
import React from 'react';
import { PLAYER_COLORS, PLAYER_NAMES } from '../../game/constants';

// Bracket layout: 4 players → 2 semis + 1 final
export default function TournamentBracket({ players = [], results = [], onStartMatch, onClose }) {
  // Build bracket slots
  const slot = (pid) => pid !== null && pid !== undefined ? {
    name: PLAYER_NAMES[pid] || `Player ${pid+1}`,
    color: PLAYER_COLORS[pid],
    id: pid,
  } : { name: 'TBD', color: '#5a3820', id: null };

  // SF matchups: [0 vs 1], [2 vs 3]
  const sf1 = [slot(players[0]), slot(players[1])];
  const sf2 = [slot(players[2]), slot(players[3])];
  const finalists = results.slice(0, 2).map(r => slot(r));
  const champion  = results[2] !== undefined ? slot(results[2]) : null;

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 110,
      background: 'rgba(10,5,2,.94)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      animation: 'fadeIn .4s ease',
    }}>
      <div style={{
        background: '#1a0e06', border: '1.5px solid #8B6914',
        borderRadius: 20, padding: '28px 32px',
        display: 'flex', flexDirection: 'column', gap: 24,
        minWidth: 320, boxShadow: '0 0 40px rgba(212,160,23,.15)',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: '1rem', fontWeight: 500, color: '#F0C84A' }}>🏆 Tournament</div>
            <div style={{ fontSize: '.7rem', color: '#7a5c3a', marginTop: 2 }}>Single Elimination</div>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#7a5c3a', cursor: 'pointer', fontSize: '1rem' }}>✕</button>
        </div>

        {/* Bracket */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 0, justifyContent: 'center' }}>

          {/* Left semi */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ fontSize: '.6rem', color: '#7a5c3a', textAlign: 'center', marginBottom: 4, letterSpacing: '.08em' }}>SEMI 1</div>
            {sf1.map((p, i) => (
              <BracketSlot key={i} player={p} isWinner={results[0] === p.id} />
            ))}
            {results[0] === undefined && onStartMatch && (
              <button onClick={() => onStartMatch(0, sf1)} style={matchBtnStyle}>Play →</button>
            )}
          </div>

          {/* Connector lines */}
          <BracketConnector />

          {/* Final */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'center' }}>
            <div style={{ fontSize: '.6rem', color: '#D4A017', textAlign: 'center', marginBottom: 4, letterSpacing: '.08em' }}>FINAL</div>
            {finalists.length > 0 ? finalists.map((p, i) => (
              <BracketSlot key={i} player={p} isWinner={results[2] === p.id} highlight />
            )) : (
              <>
                <BracketSlot player={{ name: 'TBD', color: '#3d2410' }} />
                <BracketSlot player={{ name: 'TBD', color: '#3d2410' }} />
              </>
            )}
            {finalists.length === 2 && results[2] === undefined && onStartMatch && (
              <button onClick={() => onStartMatch(2, finalists)} style={matchBtnStyle}>Play →</button>
            )}
          </div>

          {/* Connector lines */}
          <BracketConnector flip />

          {/* Right semi */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ fontSize: '.6rem', color: '#7a5c3a', textAlign: 'center', marginBottom: 4, letterSpacing: '.08em' }}>SEMI 2</div>
            {sf2.map((p, i) => (
              <BracketSlot key={i} player={p} isWinner={results[1] === p.id} />
            ))}
            {results[1] === undefined && results[0] !== undefined && onStartMatch && (
              <button onClick={() => onStartMatch(1, sf2)} style={matchBtnStyle}>Play →</button>
            )}
          </div>
        </div>

        {/* Champion display */}
        {champion && (
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
            padding: '12px', background: 'rgba(212,160,23,.08)',
            border: '1px solid rgba(212,160,23,.3)', borderRadius: 12,
          }}>
            <div style={{ fontSize: '1.4rem', animation: 'spin 6s linear infinite' }}>✦</div>
            <div style={{ fontSize: '.7rem', color: '#7a5c3a', letterSpacing: '.1em' }}>CHAMPION</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 14, height: 14, borderRadius: '50%', background: champion.color, display: 'inline-block', boxShadow: `0 0 10px ${champion.color}` }} />
              <span style={{ fontSize: '1.1rem', fontWeight: 500, color: '#F0C84A' }}>{champion.name}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function BracketSlot({ player, isWinner, highlight }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 7,
      padding: '6px 10px',
      background: highlight ? 'rgba(212,160,23,.1)' : '#2c1a0e',
      border: `1px solid ${isWinner ? player.color : highlight ? 'rgba(212,160,23,.3)' : 'rgba(139,105,20,.2)'}`,
      borderRadius: 7,
      minWidth: 90,
      transition: 'border-color .3s',
    }}>
      <span style={{
        width: 9, height: 9, borderRadius: '50%',
        background: player.color,
        flexShrink: 0,
        boxShadow: isWinner ? `0 0 8px ${player.color}` : 'none',
      }} />
      <span style={{ fontSize: '.78rem', color: isWinner ? '#F0C84A' : '#C8A96A', fontWeight: isWinner ? 500 : 400 }}>
        {player.name}
      </span>
      {isWinner && <span style={{ marginLeft: 'auto', fontSize: '.6rem', color: '#D4A017' }}>✓</span>}
    </div>
  );
}

function BracketConnector({ flip }) {
  return (
    <svg width={32} height={80} style={{ overflow: 'visible', flexShrink: 0, marginTop: 20 }}>
      {!flip ? (
        <>
          <line x1={0} y1={14} x2={16} y2={14} stroke="#5a3820" strokeWidth={1} />
          <line x1={0} y1={42} x2={16} y2={42} stroke="#5a3820" strokeWidth={1} />
          <line x1={16} y1={14} x2={16} y2={42} stroke="#5a3820" strokeWidth={1} />
          <line x1={16} y1={28} x2={32} y2={28} stroke="#8B6914" strokeWidth={1} />
        </>
      ) : (
        <>
          <line x1={32} y1={14} x2={16} y2={14} stroke="#5a3820" strokeWidth={1} />
          <line x1={32} y1={42} x2={16} y2={42} stroke="#5a3820" strokeWidth={1} />
          <line x1={16} y1={14} x2={16} y2={42} stroke="#5a3820" strokeWidth={1} />
          <line x1={16} y1={28} x2={0} y2={28} stroke="#8B6914" strokeWidth={1} />
        </>
      )}
    </svg>
  );
}

const matchBtnStyle = {
  width: '100%', padding: '5px 0', marginTop: 4,
  borderRadius: 6, border: '1px solid rgba(212,160,23,.4)',
  background: 'transparent', color: '#D4A017',
  fontSize: '.75rem', cursor: 'pointer',
};

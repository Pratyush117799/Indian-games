-- ── 003_compendium.sql ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS compendium_unlocks (
  player_id   UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  herb_id     VARCHAR(50) NOT NULL,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (player_id, herb_id)
);

CREATE TABLE IF NOT EXISTS inventory (
  player_id   UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  herb_id     VARCHAR(50) NOT NULL,
  quantity    INTEGER     NOT NULL DEFAULT 0,
  PRIMARY KEY (player_id, herb_id)
);

CREATE TABLE IF NOT EXISTS remedies_inventory (
  player_id   UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  remedy_id   VARCHAR(50) NOT NULL,
  quantity    INTEGER     NOT NULL DEFAULT 0,
  PRIMARY KEY (player_id, remedy_id)
);

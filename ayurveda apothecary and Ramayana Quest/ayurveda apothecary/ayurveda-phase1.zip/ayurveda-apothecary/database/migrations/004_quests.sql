-- ── 004_quests.sql ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS quest_completions (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id       UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  patient_id      VARCHAR(50) NOT NULL,
  outcome_tier    VARCHAR(20) NOT NULL,  -- success | partial | failure
  choice_index    INTEGER,
  prescribed_recipe VARCHAR(50),
  xp_earned       INTEGER     NOT NULL DEFAULT 0,
  sanskriti_pts   INTEGER     NOT NULL DEFAULT 0,
  completed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_quests_player ON quest_completions(player_id, completed_at DESC);

const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function createGame({ mode, diceStyle, seats }) {
  const gameId = uuidv4();

  await query(
    `INSERT INTO games (id, mode, dice_style, state_json)
     VALUES ($1, $2, $3, $4)`,
    [gameId, mode, diceStyle, JSON.stringify({})]
  );

  for (const seat of seats) {
    await query(
      `INSERT INTO game_players (game_id, player_id, seat, color, is_ai, ai_level)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [gameId, seat.playerId || null, seat.seat, seat.color, seat.isAi || false, seat.aiLevel || null]
    );
  }

  return { gameId };
}

async function saveGameState(gameId, stateJson) {
  await query(
    `UPDATE games SET state_json = $1 WHERE id = $2`,
    [JSON.stringify(stateJson), gameId]
  );
}

async function logMove({ gameId, seat, moveNumber, diceValues, diceTotal, pawnIndex,
  fromStatus, toStatus, fromPos, toPos, capturedPawn }) {
  await query(
    `INSERT INTO moves
       (game_id, seat, move_number, dice_values, dice_total, pawn_index,
        from_status, to_status, from_pos, to_pos, captured_pawn)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [gameId, seat, moveNumber, JSON.stringify(diceValues), diceTotal, pawnIndex,
     fromStatus, toStatus, fromPos, toPos, capturedPawn ? JSON.stringify(capturedPawn) : null]
  );
}

async function completeGame({ gameId, winnerPlayerId, durationSecs }) {
  await query(
    `UPDATE games
     SET status = 'completed', completed_at = NOW(), winner_player_id = $2, duration_secs = $3
     WHERE id = $1`,
    [gameId, winnerPlayerId || null, durationSecs]
  );
}

async function getGame(gameId) {
  const res = await query(
    `SELECT g.*, 
            json_agg(json_build_object(
              'seat', gp.seat, 'color', gp.color, 'isAi', gp.is_ai,
              'aiLevel', gp.ai_level, 'playerId', gp.player_id,
              'finished', gp.finished, 'finishRank', gp.finish_rank
            ) ORDER BY gp.seat) AS players
     FROM games g
     LEFT JOIN game_players gp ON gp.game_id = g.id
     WHERE g.id = $1
     GROUP BY g.id`,
    [gameId]
  );
  return res.rows[0] || null;
}

async function getGameMoves(gameId) {
  const res = await query(
    `SELECT * FROM moves WHERE game_id = $1 ORDER BY move_number`,
    [gameId]
  );
  return res.rows;
}

async function updatePlayerStats({ playerId, won, captures }) {
  if (!playerId) return;
  await query(
    `UPDATE players SET
       games_played = games_played + 1,
       games_won    = games_won + $2,
       total_captures = total_captures + $3,
       win_streak   = CASE WHEN $2=1 THEN win_streak+1 ELSE 0 END,
       best_streak  = CASE WHEN $2=1 AND win_streak+1 > best_streak
                          THEN win_streak+1 ELSE best_streak END,
       last_seen    = NOW()
     WHERE id = $1`,
    [playerId, won ? 1 : 0, captures || 0]
  );
}

module.exports = { createGame, saveGameState, logMove, completeGame,
                   getGame, getGameMoves, updatePlayerStats };

/**
 * map.js
 * SVG political map of Bharatvarsha, 321 BCE.
 *
 * Replaces the old canvas-circle approach entirely.
 * All rendering is SVG path polygons — proper geographic shapes,
 * rivers, terrain zones, zoom/pan, hover tooltips, selection glow.
 *
 * Architecture:
 *   Layer 0: terrain backdrop (seas, mountains, desert)
 *   Layer 1: river polylines
 *   Layer 2: territory polygon fills (owner-coloured)
 *   Layer 3: territory borders
 *   Layer 4: labels (name + Devanagari, always readable)
 *   Layer 5: interactive overlays (hit targets, glow, tooltip)
 */

/* ═══════════════════════════════════════════════════════
   SVG NAMESPACE + HELPERS
═══════════════════════════════════════════════════════ */
const NS = 'http://www.w3.org/2000/svg';

function svgEl(tag, attrs, parent) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  if (parent) parent.appendChild(el);
  return el;
}

/* ═══════════════════════════════════════════════════════
   MAP COORDINATE SYSTEM
   Viewport: 1000 × 900 internal units
   Represents the Indian subcontinent 321 BCE
   roughly bounded by:
     N: Himalayas (y ≈ 60)
     S: Sri Lanka tip (y ≈ 860)
     W: Makran coast (x ≈ 80)
     E: Bengal coast (x ≈ 920)
═══════════════════════════════════════════════════════ */

/* ── Territory polygon definitions ──────────────────── */
// Each territory: { id, name, hindi, type, points (SVG polygon string) }
// Points are in the 1000×900 internal coordinate space.

export const TERRITORY_SHAPES = {
  magadha: {
    id: 'magadha', name: 'Magadha', hindi: 'मगध',
    labelX: 680, labelY: 490,
    points: '620,420 720,410 760,440 740,510 700,540 650,530 630,490',
    type: 'capital',
  },
  pataliputra: {
    id: 'pataliputra', name: 'Pataliputra', hindi: 'पाटलिपुत्र',
    labelX: 660, labelY: 455,
    points: '630,420 700,415 720,440 710,465 670,470 645,450',
    type: 'city',
  },
  nalanda: {
    id: 'nalanda', name: 'Nalanda', hindi: 'नालंदा',
    labelX: 720, labelY: 400,
    points: '695,365 755,360 775,390 760,415 710,415 690,390',
    type: 'temple',
  },
  nanda: {
    id: 'nanda', name: 'Nanda Kingdom', hindi: 'नंद राज्य',
    labelX: 590, labelY: 460,
    points: '540,410 625,405 630,425 640,470 630,490 580,500 545,480 530,450',
    type: 'capital',
  },
  kosala: {
    id: 'kosala', name: 'Kosala', hindi: 'कोसल',
    labelX: 590, labelY: 370,
    points: '530,320 620,315 640,355 630,400 555,410 520,385 515,345',
    type: 'city',
  },
  panchala: {
    id: 'panchala', name: 'Panchala', hindi: 'पांचाल',
    labelX: 480, labelY: 340,
    points: '430,300 530,295 540,330 515,360 450,365 420,340',
    type: 'plains',
  },
  mathura: {
    id: 'mathura', name: 'Mathura', hindi: 'मथुरा',
    labelX: 430, labelY: 400,
    points: '390,360 460,350 475,380 465,415 415,425 385,400',
    type: 'city',
  },
  vatsa: {
    id: 'vatsa', name: 'Vatsa', hindi: 'वत्स',
    labelX: 520, labelY: 420,
    points: '470,390 530,380 545,415 535,445 490,450 465,425',
    type: 'plains',
  },
  avanti: {
    id: 'avanti', name: 'Avanti', hindi: 'अवंती',
    labelX: 410, labelY: 480,
    points: '360,440 450,430 465,465 455,510 400,520 355,495 345,465',
    type: 'plains',
  },
  saurashtra: {
    id: 'saurashtra', name: 'Saurashtra', hindi: 'सौराष्ट्र',
    labelX: 290, labelY: 560,
    points: '220,510 320,500 350,520 345,570 310,600 260,610 215,580 200,545',
    type: 'port',
  },
  sindhu: {
    id: 'sindhu', name: 'Sindhu', hindi: 'सिंधु',
    labelX: 240, labelY: 430,
    points: '190,380 290,365 315,395 310,445 280,470 220,475 185,450',
    type: 'river',
  },
  taxila: {
    id: 'taxila', name: 'Takshashila', hindi: 'तक्षशिला',
    labelX: 260, labelY: 290,
    points: '210,245 310,235 340,270 325,310 265,325 210,310 190,275',
    type: 'city',
  },
  gandhara: {
    id: 'gandhara', name: 'Gandhara', hindi: 'गंधार',
    labelX: 190, labelY: 225,
    points: '140,185 240,175 265,210 245,245 190,255 140,240 115,210',
    type: 'mountains',
  },
  anga: {
    id: 'anga', name: 'Anga', hindi: 'अंग',
    labelX: 790, labelY: 450,
    points: '755,400 840,395 870,425 855,470 800,485 760,470 745,440',
    type: 'port',
  },
  kalinga: {
    id: 'kalinga', name: 'Kalinga', hindi: 'कलिंग',
    labelX: 750, labelY: 580,
    points: '700,530 790,520 820,555 810,610 760,635 715,625 690,590 690,555',
    type: 'capital',
  },
  deccan: {
    id: 'deccan', name: 'Deccan', hindi: 'दक्षिण',
    labelX: 520, labelY: 660,
    points: '400,590 550,575 650,590 680,640 650,700 560,730 450,720 380,680 365,630',
    type: 'plains',
  },
};

/* ── Owner colour palette ────────────────────────────── */
export const OWNER_COLOURS = {
  player:     { fill: '#7B2020', border: '#C8453A', label: '#FFD7D7' },
  nanda:      { fill: '#1A3B6B', border: '#3A6BB5', label: '#C8D9FF' },
  persian:    { fill: '#6B4A15', border: '#C8922A', label: '#FFE8C0' },
  kalinga:    { fill: '#1A5C35', border: '#2EAD68', label: '#BFFFE0' },
  saurashtra: { fill: '#5C5C1A', border: '#ADAD2E', label: '#FFFFF0' },
  kosala:     { fill: '#5C1A5C', border: '#AD2EAD', label: '#FFD7FF' },
  neutral:    { fill: '#3A3A3A', border: '#6E6E6E', label: '#D0C8B8' },
};

/* ── Terrain backdrop regions ────────────────────────── */
const TERRAIN_REGIONS = [
  // Himalayas
  { d: 'M 60,80 L 960,60 L 960,130 L 580,145 L 400,150 L 180,160 L 60,150 Z',
    fill: '#2A1F14', label: 'Himalayas', lx: 500, ly: 105 },
  // Thar Desert
  { d: 'M 80,300 L 230,280 L 280,360 L 265,440 L 200,480 L 90,470 L 60,400 Z',
    fill: '#3A2E12', label: 'Thar Desert', lx: 165, ly: 380 },
  // Deccan Plateau
  { d: 'M 340,600 L 730,575 L 760,660 L 720,760 L 560,820 L 380,800 L 310,720 L 300,650 Z',
    fill: '#1E2E1A', label: 'Deccan Plateau', lx: 530, ly: 700 },
  // Arabian Sea
  { d: 'M 60,480 L 220,475 L 230,510 L 225,590 L 210,660 L 140,700 L 60,680 Z',
    fill: '#0A1520', label: 'Arabian Sea', lx: 120, ly: 580 },
  // Bay of Bengal
  { d: 'M 855,400 L 940,380 L 960,480 L 940,620 L 880,680 L 840,620 L 825,540 L 840,470 Z',
    fill: '#0A1520', label: 'Bay of Bengal', lx: 900, ly: 520 },
  // Indian Ocean
  { d: 'M 200,780 L 560,810 L 700,790 L 760,840 L 700,900 L 280,900 L 180,860 Z',
    fill: '#0A1520', label: 'Indian Ocean', lx: 470, ly: 860 },
];

/* ── River definitions ───────────────────────────────── */
const RIVERS = [
  { name: 'Ganga', points: '310,340 400,370 470,390 560,420 640,440 700,445 760,430 840,405' },
  { name: 'Yamuna', points: '380,280 400,320 415,360 420,400 430,430 450,460' },
  { name: 'Sindhu', points: '200,175 215,240 220,310 230,380 225,450 210,510 180,580' },
  { name: 'Narmada', points: '300,520 380,510 450,505 530,510 600,520 660,535' },
  { name: 'Mahanadi', points: '620,550 680,560 730,575 780,590 820,610' },
];

/* ═══════════════════════════════════════════════════════
   MAP RENDERER CLASS
═══════════════════════════════════════════════════════ */
export class MapRenderer {
  constructor(containerId, onTerritoryClick, onTerritoryHover) {
    this.container = document.getElementById(containerId);
    this.onTerritoryClick = onTerritoryClick;
    this.onTerritoryHover = onTerritoryHover;
    this.selectedId = null;
    this.hoveredId  = null;
    this.territories = {};   // id → { owner, strength, wealth, ... }

    // Zoom/pan state
    this.scale = 1;
    this.panX  = 0;
    this.panY  = 0;
    this._panning = false;
    this._panStart = null;

    this._buildSVG();
    this._attachPanZoom();
  }

  _buildSVG() {
    this.svg = svgEl('svg', {
      viewBox: '0 0 1000 900',
      width: '100%',
      height: '100%',
      style: 'display:block;cursor:grab',
    }, this.container);

    // Layers
    this.layerTerrain  = svgEl('g', { id: 'layer-terrain' },  this.svg);
    this.layerRivers   = svgEl('g', { id: 'layer-rivers' },   this.svg);
    this.layerFills    = svgEl('g', { id: 'layer-fills' },    this.svg);
    this.layerBorders  = svgEl('g', { id: 'layer-borders' },  this.svg);
    this.layerGlow     = svgEl('g', { id: 'layer-glow' },     this.svg);
    this.layerLabels   = svgEl('g', { id: 'layer-labels' },   this.svg);
    this.layerHits     = svgEl('g', { id: 'layer-hits' },     this.svg);

    // Defs: glow filter
    const defs = svgEl('defs', {}, this.svg);
    const filt = svgEl('filter', { id: 'glow', x: '-20%', y: '-20%', width: '140%', height: '140%' }, defs);
    const blur = svgEl('feGaussianBlur', { stdDeviation: '4', result: 'coloredBlur' }, filt);
    const merge = svgEl('feMerge', {}, filt);
    svgEl('feMergeNode', { in: 'coloredBlur' }, merge);
    svgEl('feMergeNode', { in: 'SourceGraphic' }, merge);

    this._drawTerrain();
    this._drawRivers();
  }

  _drawTerrain() {
    TERRAIN_REGIONS.forEach(region => {
      svgEl('path', { d: region.d, fill: region.fill, stroke: 'none' }, this.layerTerrain);
      // Terrain label
      const t = svgEl('text', {
        x: region.lx, y: region.ly,
        'text-anchor': 'middle',
        'font-size': '11',
        'font-family': 'Cinzel, serif',
        'letter-spacing': '2',
        fill: 'rgba(200,180,140,0.25)',
        style: 'pointer-events:none',
      }, this.layerTerrain);
      t.textContent = region.label.toUpperCase();
    });
  }

  _drawRivers() {
    RIVERS.forEach(r => {
      const pts = r.points.split(' ').map(p => p.split(',').map(Number));
      // Build a smooth polyline
      const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0]} ${p[1]}`).join(' ');
      svgEl('path', {
        d, fill: 'none',
        stroke: '#1A3A5C', 'stroke-width': '2.5', 'stroke-linecap': 'round',
        opacity: '0.6',
        style: 'pointer-events:none',
      }, this.layerRivers);
      // River name
      const mid = pts[Math.floor(pts.length / 2)];
      const lbl = svgEl('text', {
        x: mid[0], y: mid[1] - 7,
        'text-anchor': 'middle', 'font-size': '9',
        'font-family': 'Cinzel, serif', 'font-style': 'italic',
        fill: '#2A5A8C', opacity: '0.7',
        style: 'pointer-events:none',
      }, this.layerRivers);
      lbl.textContent = r.name;
    });
  }

  /** Full re-render of territory fills, borders, labels, and hit areas. */
  render(territories) {
    this.territories = territories;
    this.layerFills.innerHTML   = '';
    this.layerBorders.innerHTML = '';
    this.layerGlow.innerHTML    = '';
    this.layerLabels.innerHTML  = '';
    this.layerHits.innerHTML    = '';

    for (const [id, terr] of Object.entries(territories)) {
      const shape = TERRITORY_SHAPES[id];
      if (!shape) continue;

      const colours = OWNER_COLOURS[terr.owner] || OWNER_COLOURS.neutral;
      const isSelected = id === this.selectedId;
      const isHovered  = id === this.hoveredId;

      // ── Fill ─────────────────────────────────────────
      let fillOpacity = '0.75';
      if (isSelected) fillOpacity = '0.95';
      if (isHovered && !isSelected) fillOpacity = '0.85';

      svgEl('polygon', {
        points:  shape.points,
        fill:    colours.fill,
        opacity: fillOpacity,
        style:   'transition:opacity 0.2s',
      }, this.layerFills);

      // ── Border ───────────────────────────────────────
      svgEl('polygon', {
        points:   shape.points,
        fill:     'none',
        stroke:   isSelected ? '#FFD700' : colours.border,
        'stroke-width': isSelected ? '3' : isHovered ? '2' : '1.2',
        opacity:  '0.9',
      }, this.layerBorders);

      // ── Glow on selected ─────────────────────────────
      if (isSelected) {
        svgEl('polygon', {
          points:   shape.points,
          fill:     'none',
          stroke:   '#FFD700',
          'stroke-width': '6',
          opacity:  '0.35',
          filter:   'url(#glow)',
        }, this.layerGlow);
      }

      // ── Labels ───────────────────────────────────────
      const lx = shape.labelX, ly = shape.labelY;
      const nameSize = isSelected ? 14 : 12;

      // Background pill for readability
      const bgW = shape.name.length * 7 + 16;
      const bgRect = svgEl('rect', {
        x: lx - bgW / 2, y: ly - 10,
        width: bgW, height: 14,
        rx: '3',
        fill: 'rgba(0,0,0,0.55)',
        style: 'pointer-events:none',
      }, this.layerLabels);

      // Territory name
      const nameEl = svgEl('text', {
        x: lx, y: ly,
        'text-anchor': 'middle', 'dominant-baseline': 'central',
        'font-size': nameSize,
        'font-family': 'Cinzel, serif',
        'font-weight': isSelected ? '700' : '500',
        fill: isSelected ? '#FFD700' : colours.label,
        style: 'pointer-events:none; text-shadow: 0 1px 3px #000',
      }, this.layerLabels);
      nameEl.textContent = shape.name;

      // Devanagari subtitle
      const devaEl = svgEl('text', {
        x: lx, y: ly + 14,
        'text-anchor': 'middle', 'dominant-baseline': 'central',
        'font-size': '10',
        'font-family': 'Noto Serif, serif',
        fill: colours.label,
        opacity: '0.6',
        style: 'pointer-events:none',
      }, this.layerLabels);
      devaEl.textContent = shape.hindi;

      // Owner dot
      svgEl('circle', {
        cx: lx + bgW / 2 - 8, cy: ly - 3, r: '4',
        fill: colours.border,
        style: 'pointer-events:none',
      }, this.layerLabels);

      // ── Hit area (transparent, receives events) ───────
      const hitEl = svgEl('polygon', {
        points:  shape.points,
        fill:    'transparent',
        stroke:  'none',
        style:   'cursor:pointer',
        'data-id': id,
      }, this.layerHits);

      hitEl.addEventListener('click',      () => this._handleClick(id));
      hitEl.addEventListener('mouseenter', () => this._handleHover(id));
      hitEl.addEventListener('mouseleave', () => this._handleHoverOut());
    }

    // Watermark
    const wm = svgEl('text', {
      x: '15', y: '20',
      'font-size': '11', 'font-family': 'Cinzel Decorative, Cinzel, serif',
      fill: 'rgba(255,215,0,0.12)', 'letter-spacing': '2',
    }, this.svg);
    wm.textContent = 'BHARATVARSHA — 321 BCE';
  }

  _handleClick(id) {
    this.selectedId = id;
    this.render(this.territories);
    this.onTerritoryClick?.(id);
  }

  _handleHover(id) {
    this.hoveredId = id;
    this.render(this.territories);
    this.onTerritoryHover?.(id);
  }

  _handleHoverOut() {
    this.hoveredId = null;
    this.render(this.territories);
    this.onTerritoryHover?.(null);
  }

  deselect() {
    this.selectedId = null;
    this.render(this.territories);
  }

  /* ── Pan + zoom ─────────────────────────────────────── */
  _attachPanZoom() {
    const svg = this.svg;

    svg.addEventListener('wheel', e => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.85 : 1.15;
      this.scale = Math.min(3, Math.max(0.5, this.scale * delta));
      this._applyTransform();
    }, { passive: false });

    svg.addEventListener('mousedown', e => {
      if (e.button !== 0) return;
      this._panning = true;
      this._panStart = { x: e.clientX - this.panX, y: e.clientY - this.panY };
      svg.style.cursor = 'grabbing';
    });

    window.addEventListener('mousemove', e => {
      if (!this._panning) return;
      this.panX = e.clientX - this._panStart.x;
      this.panY = e.clientY - this._panStart.y;
      this._applyTransform();
    });

    window.addEventListener('mouseup', () => {
      this._panning = false;
      svg.style.cursor = 'grab';
    });

    // Touch support
    svg.addEventListener('touchstart', e => {
      if (e.touches.length === 1) {
        this._panning = true;
        this._panStart = {
          x: e.touches[0].clientX - this.panX,
          y: e.touches[0].clientY - this.panY,
        };
      }
    }, { passive: true });

    svg.addEventListener('touchmove', e => {
      if (!this._panning || e.touches.length !== 1) return;
      this.panX = e.touches[0].clientX - this._panStart.x;
      this.panY = e.touches[0].clientY - this._panStart.y;
      this._applyTransform();
    }, { passive: true });

    svg.addEventListener('touchend', () => { this._panning = false; });
  }

  _applyTransform() {
    const g = this.svg;
    // Apply to all layers via a wrapper group
    if (!this._transformGroup) {
      this._transformGroup = svgEl('g', { id: 'transform-root' }, null);
      // Move all children into transform group
      while (g.firstChild) this._transformGroup.appendChild(g.firstChild);
      g.appendChild(this._transformGroup);
    }
    this._transformGroup.setAttribute(
      'transform',
      `translate(${this.panX},${this.panY}) scale(${this.scale})`,
    );
  }

  resetView() {
    this.scale = 1;
    this.panX  = 0;
    this.panY  = 0;
    this._applyTransform();
  }
}

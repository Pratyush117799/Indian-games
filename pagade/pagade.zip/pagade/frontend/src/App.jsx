import React, { useState, useCallback, useEffect } from 'react';
import HomeScreen     from './components/screens/HomeScreen';
import GameScreen     from './components/screens/GameScreen';
import SettingsScreen from './components/screens/SettingsScreen';
import CaptureEffect, { SafeEffect, HomeEffect } from './components/UI/Effects';
import { useGame }          from './hooks/useGame';
import { useSounds }        from './hooks/useSounds';
import { useBackend }       from './hooks/useBackend';
import { useLocalSave }     from './hooks/useLocalSave';
import { useTournament }    from './hooks/useTournament';
import { useSettings }      from './hooks/useSettings';
import { usePWA }           from './hooks/usePWA';
import { useAnimatedMove }  from './hooks/useAnimatedMove';
import { GAME_MODE, AI_LEVEL } from './game/constants';
import './styles/main.css';

export default function App() {
  const [screen, setScreen] = useState('home');

  const { state, startGame, resumeGame, rollDice, selectMove, passPlayPrompt } = useGame();
  const { settings, updateSetting, resetSettings } = useSettings();
  const { play, muted, toggleMute } = useSounds();
  const backend   = useBackend();
  const localSave = useLocalSave();
  const tourney   = useTournament();
  const pwa       = usePWA();
  const { animPositions, startAnimation } = useAnimatedMove();

  // ── Sounds ────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!state.lastEvent) return;
    const map = { ROLL:'roll', MOVE:'move', CAPTURE:'capture', SAFE:'safe', HOME:'home' };
    if (map[state.lastEvent.type]) play(map[state.lastEvent.type]);
  }, [state.lastEvent]);
  useEffect(() => { if (state.winner !== null) play('win'); }, [state.winner]);

  // ── Auto-save ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (state.moveNumber > 0 && state.phase !== 'GAMEOVER') localSave.save(state);
    if (state.phase === 'GAMEOVER') localSave.clearSave();
  }, [state.moveNumber, state.phase]);

  // ── Backend ───────────────────────────────────────────────────────────────
  useEffect(() => { if (state.moveNumber > 0) backend.persistState(state); }, [state.moveNumber]);
  useEffect(() => {
    if (state.winner !== null)
      backend.completeGame({ winner: state.winner, players: state.players });
  }, [state.winner]);

  // ── Start ─────────────────────────────────────────────────────────────────
  const handleStart = useCallback(async (opts) => {
    localSave.clearSave();
    if (opts.mode === GAME_MODE.TOURNAMENT)
      tourney.startTournament(opts.diceStyle, AI_LEVEL.MAHARAJA);
    startGame(opts);
    setScreen('game');
    backend.createGameRecord({
      mode: opts.mode, diceStyle: opts.diceStyle,
      players: Array.from({ length: opts.numPlayers || 4 }, (_, i) => ({
        id: i, isAi: (opts.aiPlayers||[]).includes(i), aiLevel: opts.aiLevel||null, playerId: null,
      })),
    }).catch(() => {});
  }, [startGame, localSave, tourney, backend]);

  // ── Resume ────────────────────────────────────────────────────────────────
  const handleResume = useCallback(() => {
    const saved = localSave.loadSave();
    if (saved) { resumeGame(saved); setScreen('game'); }
  }, [localSave, resumeGame]);

  // ── selectMove with step animation ───────────────────────────────────────
  const handleSelectMove = useCallback((moveAction) => {
    const cp = state.currentPlayer;
    const pawn = state.players?.[cp]?.pawns?.[moveAction.pawnId];
    if (pawn) {
      startAnimation(pawn, moveAction, () => {});
    }
    selectMove(moveAction);
  }, [state.currentPlayer, state.players, startAnimation, selectMove]);

  return (
    <>
      {/* Offline banner */}
      {!pwa.isOnline && (
        <div style={{
          position:'fixed', top:0, left:0, right:0, zIndex:9999,
          background:'#3d2410', color:'#C8A96A',
          fontSize:'.7rem', textAlign:'center', padding:'4px', letterSpacing:'.06em',
        }}>
          📴 Offline — solo & pass play available
        </div>
      )}

      {/* PWA install banner */}
      {pwa.canInstall && screen === 'home' && (
        <div style={{
          position:'fixed', bottom:84, left:'50%', transform:'translateX(-50%)',
          zIndex:40, background:'#2c1a0e',
          border:'1px solid rgba(139,105,20,.4)', borderRadius:12,
          padding:'10px 16px', display:'flex', alignItems:'center', gap:10,
          fontSize:'.78rem', color:'#C8A96A', animation:'fadeIn .4s ease',
          boxShadow:'0 4px 20px rgba(0,0,0,.5)',
        }}>
          <span>📲</span>
          <span>Install Pagade</span>
          <button onClick={pwa.promptInstall} style={{
            padding:'5px 12px', borderRadius:7,
            border:'1px solid #D4A017', background:'transparent',
            color:'#F0C84A', fontSize:'.75rem', cursor:'pointer',
          }}>Add</button>
        </div>
      )}

      {screen === 'home' && (
        <HomeScreen
          onStart={handleStart} onResume={handleResume}
          hasSave={localSave.hasSave} saveInfo={localSave.saveInfo}
          onSettings={() => setScreen('settings')}
        />
      )}
      {screen === 'settings' && (
        <SettingsScreen
          settings={settings} onUpdate={updateSetting}
          onReset={resetSettings} onBack={() => setScreen('home')}
          gamesWon={0}
        />
      )}
      {screen === 'game' && (
        <>
          <GameScreen
            gameState={state}
            onRollDice={rollDice}
            onSelectMove={handleSelectMove}
            onHome={() => { setScreen('home'); tourney.resetTournament(); }}
            passPlayPrompt={passPlayPrompt}
            animatingPawn={state.animatingPawn}
            animPositions={animPositions}
            muted={muted}
            onToggleMute={toggleMute}
            showMoveLog={settings.showMoveLog}
            themeId={settings.boardTheme}
            tournament={tourney.tournament}
            onTournamentMatchResult={tourney.recordMatchResult}
          />
          <CaptureEffect lastEvent={state.lastEvent} />
          <SafeEffect    lastEvent={state.lastEvent} />
          <HomeEffect    lastEvent={state.lastEvent} />
        </>
      )}
    </>
  );
}

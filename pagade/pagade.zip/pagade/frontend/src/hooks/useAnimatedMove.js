/**
 * useAnimatedMove — steps a pawn through every intermediate cell on its journey.
 *
 * Instead of teleporting, the pawn visits each cell along MAIN_PATH,
 * then slides into the safe lane, creating a satisfying "travelling" effect.
 *
 * Usage:
 *   const { animState, startAnimation } = useAnimatedMove();
 *   // animState: Map of "playerId-pawnId" → { r, c }  (override cells during anim)
 *   // call startAnimation(playerId, pawn, move, onComplete)
 */

import { useRef, useState, useCallback } from 'react';
import {
  MAIN_PATH, SAFE_LANES, PATH_LENGTH, PLAYER_ENTRY, STATUS,
} from '../game/constants';

// ms per cell step — adjust for feel
const STEP_MS_FAST   = 55;
const STEP_MS_NORMAL = 80;
const STEP_MS_SAFE   = 100;

export function useAnimatedMove() {
  // Map: "pid-pawnId" → current { r, c } override during animation
  const [animPositions, setAnimPositions] = useState({});
  const timers = useRef([]);

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  /**
   * Build the sequence of intermediate cells the pawn must pass through.
   */
  function buildPath(pawn, move) {
    const pid = pawn.playerId;
    const cells = [];

    if (pawn.status === STATUS.BELLY) {
      // Belly → ACTIVE: only intermediate if pathSteps > 0
      // First, land at entry cell
      const entryGlobal = PLAYER_ENTRY[pid];
      cells.push(MAIN_PATH[entryGlobal]);
      // Then step forward on main path
      const stepsOnMain = move.newPathSteps;
      for (let s = 1; s <= stepsOnMain; s++) {
        const gi = (s + PLAYER_ENTRY[pid]) % PATH_LENGTH;
        cells.push(MAIN_PATH[gi]);
      }
    } else if (pawn.status === STATUS.ACTIVE) {
      const startSteps = pawn.pathSteps;
      const endSteps = Math.min(move.newPathSteps, PATH_LENGTH - 1);
      // Steps still on main path
      for (let s = startSteps + 1; s <= endSteps; s++) {
        const gi = (s + PLAYER_ENTRY[pid]) % PATH_LENGTH;
        cells.push(MAIN_PATH[gi]);
      }
    }

    // Safe lane steps
    if (move.newStatus === STATUS.SAFE || move.newStatus === STATUS.HOME) {
      const safeStart = pawn.status === STATUS.SAFE ? pawn.safeIndex + 1 : 0;
      const safeEnd   = move.newSafeIndex ?? 0;
      for (let si = safeStart; si < safeEnd; si++) {
        if (SAFE_LANES[pid][si]) cells.push(SAFE_LANES[pid][si]);
      }
    }

    // Final destination (already included above, but ensure it's last)
    if (move.landingCell) {
      const last = cells[cells.length - 1];
      if (!last || last.r !== move.landingCell.r || last.c !== move.landingCell.c) {
        cells.push(move.landingCell);
      }
    }

    return cells;
  }

  const startAnimation = useCallback((pawn, move, onComplete) => {
    clearTimers();
    const key = `${pawn.playerId}-${pawn.id}`;
    const path = buildPath(pawn, move);

    if (path.length <= 1) {
      // Nothing to animate — call complete immediately
      onComplete?.();
      return;
    }

    path.forEach((cell, idx) => {
      const isLast = idx === path.length - 1;
      const isSafe = move.newStatus === STATUS.SAFE || move.newStatus === STATUS.HOME;
      const stepMs = isSafe ? STEP_MS_SAFE : idx < 3 ? STEP_MS_FAST : STEP_MS_NORMAL;
      const delay  = path.slice(0, idx).reduce((acc, _, i) => {
        const s = i < 3 ? STEP_MS_FAST : STEP_MS_NORMAL;
        return acc + s;
      }, 0);

      const t = setTimeout(() => {
        setAnimPositions(prev => ({ ...prev, [key]: cell }));
        if (isLast) {
          // Small pause at destination then clear
          const t2 = setTimeout(() => {
            setAnimPositions(prev => {
              const next = { ...prev };
              delete next[key];
              return next;
            });
            onComplete?.();
          }, 120);
          timers.current.push(t2);
        }
      }, delay);
      timers.current.push(t);
    });
  }, []);

  const cancelAnimation = useCallback(() => {
    clearTimers();
    setAnimPositions({});
  }, []);

  return { animPositions, startAnimation, cancelAnimation };
}

'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { useAuthStore } from '@/store/authStore';

const GAMES = [
  {
    slug:       'kattam-vilayattu',
    name:       'Kattam Vilayattu',
    tamil:      'கட்டம் விளையாட்டு',
    tagline:    'The Square Game of Tamil Nadu',
    desc:       'Ancient alignment strategy game. Place and move pieces on a kolam-drawn grid to align your pieces before your opponent. 3 progressive levels.',
    badge:      '2 Players · Strategy',
    era:        'Ancient Tamil Nadu',
    color:      'from-clay/10 to-clay/5',
    border:     'border-clay/30',
    icon:       '⬡',
    href:       '/games/kattam-vilayattu',
  },
  {
    slug:       'paramapadam',
    name:       'Paramapadam',
    tamil:      'பரமபதம்',
    tagline:    'The Sacred Path to Vaikuntam',
    desc:       'Tamil Vaishnava spiritual board game — the sacred ancestor of Snakes & Ladders. Journey from Patalam to Vaikuntam. Played overnight during Vaikunta Ekadasi.',
    badge:      '2–6 Players · Luck & Strategy',
    era:        'Bhakti Period c. 1000 CE',
    color:      'from-leaf/10 to-leaf/5',
    border:     'border-leaf/30',
    icon:       '🐍',
    href:       '/games/paramapadam',
  },
];

export default function HomePage() {
  const { user } = useAuthStore();

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 space-y-16">

      {/* Hero */}
      <motion.section className="text-center space-y-4"
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <p className="text-kolam font-medium tracking-widest uppercase text-sm">Krida · Traditional Indian Games</p>
        <h1 className="text-4xl md:text-5xl font-bold text-temple leading-tight">
          Ancient Tamil Board Games,<br />
          <span className="text-clay">Played Online</span>
        </h1>
        <p className="text-gray-600 max-w-xl mx-auto">
          Two of Tamil Nadu's most beloved traditional games — preserved, revived, and brought online
          with real-time multiplayer, leaderboards, and full game history.
        </p>
        {!user && (
          <div className="flex gap-3 justify-center pt-2">
            <Link href="/auth/register" className="btn-primary">Get Started</Link>
            <Link href="/auth/login"    className="btn-secondary">Login</Link>
          </div>
        )}
      </motion.section>

      {/* Game Cards */}
      <section className="grid md:grid-cols-2 gap-6">
        {GAMES.map((g, i) => (
          <motion.div key={g.slug}
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 * (i + 1), duration: 0.45 }}
            className={`card bg-gradient-to-br ${g.color} border ${g.border} hover:shadow-xl transition-shadow`}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <span className="text-3xl">{g.icon}</span>
                <h2 className="text-xl font-bold text-temple mt-1">{g.name}</h2>
                <p className="font-tamil text-clay/70 text-sm">{g.tamil}</p>
              </div>
              <span className="badge bg-clay/10 text-clay">{g.era}</span>
            </div>
            <p className="text-sm font-semibold text-clay mb-1">{g.tagline}</p>
            <p className="text-sm text-gray-600 mb-4">{g.desc}</p>
            <div className="flex items-center justify-between">
              <span className="badge bg-gray-100 text-gray-600">{g.badge}</span>
              <Link href={user ? g.href : '/auth/login'}
                className="btn-primary text-sm py-2 px-4">
                {user ? 'Play Now →' : 'Login to Play →'}
              </Link>
            </div>
          </motion.div>
        ))}
      </section>

      {/* Cultural strip */}
      <section className="bg-temple rounded-2xl p-8 text-cream text-center space-y-2">
        <p className="text-kolam text-xs uppercase tracking-widest">Cultural Heritage</p>
        <h3 className="text-xl font-bold">Rooted in Centuries of Tamil Tradition</h3>
        <p className="text-cream/70 text-sm max-w-2xl mx-auto">
          Kattam Vilayattu's board mirrors the <em>pulli kolam</em> drawn at every Tamil doorstep.
          Paramapadam is the only board game in the world tied to a specific religious festival night —
          Vaikunta Ekadasi — played overnight in temple courtyards across Tamil Nadu since 1000 CE.
        </p>
      </section>
    </div>
  );
}

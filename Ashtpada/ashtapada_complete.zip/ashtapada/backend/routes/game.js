'use strict';

const express = require('express');
const router  = express.Router();
const { v4: uuid } = require('uuid');

/* In-memory store (replace with DB model in production) */
const games = new Map();

/* POST /api/games — create a new game room */
router.post('/', (req, res) => {
  const { mode = 'vs-ai', difficulty = 'prince', hostUserId } = req.body;
  const gameId = uuid();
  const game = {
    id: gameId,
    mode,
    difficulty,
    hostUserId,
    guestUserId: null,
    status: 'waiting',       // waiting | active | finished
    createdAt: new Date(),
    moveHistory: [],
    currentPlayer: 0,
    winner: null
  };
  games.set(gameId, game);
  res.status(201).json({ gameId, ...game });
});

/* GET /api/games/:id — fetch game state */
router.get('/:id', (req, res) => {
  const game = games.get(req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  res.json(game);
});

/* POST /api/games/:id/join — second player joins */
router.post('/:id/join', (req, res) => {
  const game = games.get(req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  if (game.status !== 'waiting') return res.status(409).json({ error: 'Game already started' });

  game.guestUserId = req.body.userId;
  game.status = 'active';
  res.json({ joined: true, gameId: game.id });
});

/* POST /api/games/:id/move — record a move (for persistence/replay) */
router.post('/:id/move', (req, res) => {
  const game = games.get(req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });

  const { pieceIndex, fromStep, toStep, player, captured, timestamp } = req.body;
  game.moveHistory.push({ pieceIndex, fromStep, toStep, player, captured, timestamp });
  game.currentPlayer = 1 - game.currentPlayer;
  res.json({ recorded: true, totalMoves: game.moveHistory.length });
});

/* POST /api/games/:id/finish — mark game complete */
router.post('/:id/finish', (req, res) => {
  const game = games.get(req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  game.status = 'finished';
  game.winner = req.body.winner;
  game.finishedAt = new Date();
  res.json({ finished: true, winner: game.winner });
});

/* GET /api/games/:id/replay — full move-by-move replay data */
router.get('/:id/replay', (req, res) => {
  const game = games.get(req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  res.json({
    gameId: game.id,
    mode: game.mode,
    totalMoves: game.moveHistory.length,
    moves: game.moveHistory,
    winner: game.winner,
    duration: game.finishedAt
      ? (new Date(game.finishedAt) - new Date(game.createdAt)) / 1000
      : null
  });
});

module.exports = router;

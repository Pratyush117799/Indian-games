// ═══════════════════════════════════════════════════
//  GEOMETRY · Board coordinate helpers
//
//  Board layout (600×600 SVG):
//    North arm  x∈[255,345]  y∈[15,255]   3 cols × 8 rows
//    South arm  x∈[255,345]  y∈[345,585]  3 cols × 8 rows
//    West arm   x∈[15,255]   y∈[255,345]  8 cols × 3 rows
//    East arm   x∈[345,585]  y∈[255,345]  8 cols × 3 rows
//    Charkoni   x∈[255,345]  y∈[255,345]  center 90×90
//
//  Cell centres:
//    N(r,c) → x = 270 + c×30,  y = 30  + r×30   (r:tip=0, c:left=0)
//    W(r,c) → x = 30  + c×30,  y = 270 + r×30   (c:tip=0, r:top=0)
//    S(r,c) → x = 270 + c×30,  y = 360 + r×30   (r:base=0/tip=7)
//    E(r,c) → x = 360 + c×30,  y = 270 + r×30   (c:base=0/tip=7)
// ═══════════════════════════════════════════════════

import { CS } from './config.js';

export const N = (r, c) => ({ x: 270 + c * CS, y:  30 + r * CS });
export const W = (r, c) => ({ x:  30 + c * CS, y: 270 + r * CS });
export const S = (r, c) => ({ x: 270 + c * CS, y: 360 + r * CS });
export const E = (r, c) => ({ x: 360 + c * CS, y: 270 + r * CS });

export const HOME = { x: 300, y: 300 }; // Charkoni centre

// SVG element factory (used by board, pawns, effects modules)
export function se(tag, attrs = {}) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v != null) el.setAttribute(k, String(v));
  }
  return el;
}

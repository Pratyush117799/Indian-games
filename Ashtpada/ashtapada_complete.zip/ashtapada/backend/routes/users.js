'use strict';

const express = require('express');
const router  = express.Router();
const { v4: uuid } = require('uuid');

const users = new Map();

/* POST /api/users — register / create guest profile */
router.post('/', (req, res) => {
  const { username, region = 'India', avatarIndex = 0 } = req.body;
  if (!username) return res.status(400).json({ error: 'username required' });

  const userId = uuid();
  const user = {
    id: userId,
    username,
    region,
    avatarIndex,
    wins: 0,
    losses: 0,
    gamesPlayed: 0,
    streak: 0,
    bestStreak: 0,
    unlockedSkins: ['default'],
    joinedAt: new Date()
  };
  users.set(userId, user);
  res.status(201).json(user);
});

/* GET /api/users/:id — fetch profile */
router.get('/:id', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

/* PATCH /api/users/:id/result — update stats after a game */
router.patch('/:id/result', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const { won } = req.body;
  user.gamesPlayed += 1;
  if (won) {
    user.wins += 1;
    user.streak += 1;
    if (user.streak > user.bestStreak) user.bestStreak = user.streak;
    /* Unlock skins at milestone wins */
    if (user.wins === 5  && !user.unlockedSkins.includes('vedic'))    user.unlockedSkins.push('vedic');
    if (user.wins === 15 && !user.unlockedSkins.includes('hampi'))    user.unlockedSkins.push('hampi');
    if (user.wins === 30 && !user.unlockedSkins.includes('silk'))     user.unlockedSkins.push('silk');
  } else {
    user.losses += 1;
    user.streak = 0;
  }

  res.json({ updated: true, stats: { wins: user.wins, losses: user.losses, streak: user.streak } });
});

module.exports = router;

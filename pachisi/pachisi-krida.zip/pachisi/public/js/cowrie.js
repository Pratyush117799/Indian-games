// ═══════════════════════════════════════════════════
//  COWRIE · Dice rolling + shell scatter animation
// ═══════════════════════════════════════════════════

import { THROW_VAL, GRACE_VALS } from './config.js';
import { se } from './geometry.js';

// Roll 6 cowrie shells; return { shells, val, grace }
export function rollCowries() {
  const shells = Array.from({ length: 6 }, () => Math.random() < 0.5 ? 1 : 0);
  const up     = shells.reduce((a, b) => a + b, 0); // count aperture-up
  const val    = THROW_VAL[up];
  return { shells, val, grace: GRACE_VALS.has(val) };
}

// Animate cowrie shells scattering and settling
// shells: array of 6 (1=up, 0=down)
// container: DOM element to render into
// onDone: callback when animation ends
export function animateCowries(shells, container, onDone) {
  container.innerHTML = '';

  const items = shells.map((up, i) => {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '22');
    svg.setAttribute('height', '28');
    svg.setAttribute('viewBox', '-11 -14 22 28');
    svg.style.cssText = [
      'display:inline-block',
      'vertical-align:middle',
      'opacity:0',
      `transform:translate(${(Math.random() - 0.5) * 58}px,${(Math.random() - 0.5) * 26}px) rotate(${Math.random() * 720}deg)`,
      `transition:all ${400 + i * 55}ms cubic-bezier(.175,.885,.32,1.275)`,
    ].join(';');
    container.appendChild(svg);
    return { svg, up };
  });

  // Scatter → settle
  requestAnimationFrame(() => {
    setTimeout(() => {
      items.forEach(({ svg, up }) => {
        const fx = (Math.random() - 0.5) * 9;
        const fy = (Math.random() - 0.5) * 5;
        svg.style.opacity = '1';
        svg.style.transform = `translate(${fx}px,${fy}px) rotate(${up ? 0 : 176 + Math.random() * 8}deg)`;
        _drawShell(svg, up);
      });
    }, 30);
  });

  setTimeout(onDone, 960);
}

// Draw a single cowrie shell SVG (aperture-up or down)
function _drawShell(svg, up) {
  svg.innerHTML = '';
  const shell = se('path', {
    d: 'M0,-11 Q9,-8 9,0 Q9,8 0,11 Q-9,8 -9,0 Q-9,-8 0,-11 Z',
    fill:   up ? '#D4B896' : '#C4A065',
    stroke: up ? '#B8955A' : '#A88348',
    'stroke-width': '0.8',
  });
  svg.appendChild(shell);

  if (up) {
    // Aperture opening (white interior)
    svg.appendChild(se('path', {
      d: 'M0,-6 Q5,-3 5,1 Q5,6 0,8 Q-5,6 -5,1 Q-5,-3 0,-6 Z',
      fill: '#F5EDD5',
      stroke: 'rgba(0,0,0,0.08)',
      'stroke-width': '0.4',
    }));
    // Serration dots
    for (let d = 0; d < 5; d++) {
      const a = (d / 5) * Math.PI * 2;
      svg.appendChild(se('circle', {
        cx: (Math.sin(a) * 2.8).toFixed(1),
        cy: (Math.cos(a) * 4 - 1).toFixed(1),
        r: '0.9',
        fill: 'rgba(0,0,0,0.18)',
      }));
    }
  } else {
    // Dorsal ridge
    svg.appendChild(se('path', {
      d: 'M0,-8 Q1.4,-4 1.4,0 Q1.4,5 0,8',
      fill: 'none',
      stroke: 'rgba(0,0,0,0.18)',
      'stroke-width': '1.2',
      'stroke-linecap': 'round',
    }));
    // Highlight
    svg.appendChild(se('ellipse', {
      cx: '-3', cy: '-4', rx: '2', ry: '3',
      fill: 'rgba(255,255,255,0.12)',
      transform: 'rotate(-22,-3,-4)',
    }));
  }
}

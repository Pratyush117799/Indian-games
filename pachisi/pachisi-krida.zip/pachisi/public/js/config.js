// ═══════════════════════════════════════════════════
//  CONFIG · Constants, colors, throw table, facts
// ═══════════════════════════════════════════════════

export const CS = 30; // cell size in px

// Player indices: 0=Yellow(N), 1=Red(E), 2=Black(S), 3=Green(W)
export const COLORS = ['#E8C500', '#C93A3A', '#4A7FC1', '#3A8B1A'];
export const NAMES  = ['Yellow', 'Red', 'Black', 'Green'];
export const DEVA   = ['पीला', 'लाल', 'काला', 'हरा'];
export const TEAMS  = [0, 1, 0, 1]; // Team A = {0,2}, Team B = {1,3}

// Cowrie throw → move value (count of aperture-up shells)
export const THROW_VAL = { 0: 25, 1: 10, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6 };

// Sanskrit / Hindi throw names
export const THROW_NAME = {
  25: 'पचीस — Pachees',
  10: 'दस — Dus',
  6:  'छह — Chha',
  5:  'पाँच — Panch',
  4:  'चार — Chari',
  3:  'तीन — Teeni',
  2:  'दो — Dooga',
};

// Grace values earn an extra turn + allow pawn entry
export const GRACE_VALS = new Set([6, 10, 25]);

// Devanagari labels for grace flashes
export const GRACE_DEVA = { 25: 'पचीस!', 10: 'दस!', 6: 'छह!' };

// Historical facts shown on Grace throws
export const FACTS = [
  'Fatehpur Sikri still preserves the stone Pachisi court where Akbar played with sixteen living pieces.',
  '"Pachisi" means twenty-five in Hindi — the rarest throw, scored when all six cowries land aperture-down.',
  'The Mahabharata describes a dice game called "Pasha" — possibly the direct ancestor of Pachisi.',
  'Cowrie shells were the currency of ancient Indian trade. Playing Pachisi was literally gambling with money.',
  'The cross shape of the board represents the four cosmic directions; the Charkoni is the seat of Brahma.',
  'Counter-clockwise movement mirrors pradakshina — the ritual circumambulation of Hindu temples.',
  'The Ellora Caves, carved in the 6th century CE, contain one of the earliest known Pachisi boards.',
  'Spanish traders brought Pachisi home as Parchís. The British simplified it into Ludo in 1896.',
  'In some variants, a player must capture at least one opponent before their pawns can return home.',
  'The word "Ludo" comes from the Latin for "I play" — all Ludo games descend from Pachisi.',
];

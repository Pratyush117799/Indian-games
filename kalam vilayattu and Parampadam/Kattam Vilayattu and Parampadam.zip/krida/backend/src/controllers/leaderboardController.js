const db = require('../config/db');

/**
 * GET /api/leaderboard/:gameSlug
 * Top 50 players for a specific game, sorted by rating DESC.
 */
async function getLeaderboard(req, res, next) {
  try {
    const { gameSlug } = req.params;
    const limit  = Math.min(parseInt(req.query.limit  || '50'),  100);
    const offset = Math.max(parseInt(req.query.offset || '0'),     0);

    const { rows } = await db.query(
      `SELECT
         ROW_NUMBER() OVER (ORDER BY lb.rating DESC) AS rank,
         u.id, u.username, u.avatar_url,
         lb.wins, lb.losses, lb.draws, lb.total_games,
         lb.win_rate, lb.rating, lb.best_time_secs
       FROM leaderboard lb
       JOIN users   u ON u.id  = lb.user_id
       JOIN games   g ON g.id  = lb.game_id
       WHERE g.slug = $1
       ORDER BY lb.rating DESC
       LIMIT $2 OFFSET $3`,
      [gameSlug, limit, offset]
    );

    const { rows: [{ count }] } = await db.query(
      `SELECT COUNT(*) FROM leaderboard lb JOIN games g ON g.id = lb.game_id WHERE g.slug = $1`,
      [gameSlug]
    );

    res.json({ leaderboard: rows, total: parseInt(count), limit, offset });
  } catch (err) { next(err); }
}

/**
 * GET /api/leaderboard/:gameSlug/me
 * Authenticated user's rank and stats for this game.
 */
async function getMyRank(req, res, next) {
  try {
    const { gameSlug } = req.params;
    const userId = req.user.id;

    const { rows } = await db.query(
      `WITH ranked AS (
         SELECT
           lb.user_id,
           ROW_NUMBER() OVER (ORDER BY lb.rating DESC) AS rank,
           lb.wins, lb.losses, lb.draws, lb.total_games,
           lb.win_rate, lb.rating, lb.best_time_secs
         FROM leaderboard lb
         JOIN games g ON g.id = lb.game_id
         WHERE g.slug = $1
       )
       SELECT * FROM ranked WHERE user_id = $2`,
      [gameSlug, userId]
    );

    if (!rows.length) return res.status(404).json({ error: 'No stats found for this user/game' });
    res.json({ stats: rows[0] });
  } catch (err) { next(err); }
}

/**
 * Internal helper — update leaderboard after a session ends.
 * Called by socket handlers, not exposed as a route.
 */
async function updateStats(sessionId) {
  const { rows: [session] } = await db.query(
    'SELECT * FROM game_sessions WHERE id = $1',
    [sessionId]
  );
  if (!session) return;

  const { rows: players } = await db.query(
    'SELECT user_id FROM room_players WHERE room_id = (SELECT room_id FROM game_sessions WHERE id = $1)',
    [sessionId]
  );

  const K = 32; // ELO K-factor

  for (const player of players) {
    const isWinner = player.user_id === session.winner_id;
    const isDraw   = session.winner_id === null;

    const { rows: [current] } = await db.query(
      `SELECT rating FROM leaderboard lb
       JOIN games g ON g.id = lb.game_id
       WHERE lb.user_id = $1 AND g.id = $2`,
      [player.user_id, session.game_id]
    );
    const currentRating = current?.rating || 1000;

    // Simplified ELO (single opponent assumed for 2-player)
    const score       = isDraw ? 0.5 : isWinner ? 1 : 0;
    const expected    = 0.5; // simplified — no opponent rating lookup here
    const newRating   = Math.max(100, Math.round(currentRating + K * (score - expected)));

    await db.query(
      `INSERT INTO leaderboard (user_id, game_id, wins, losses, draws, total_games, rating, best_time_secs)
       VALUES ($1, $2,
         $3::int, $4::int, $5::int, 1, $6,
         CASE WHEN $3::int = 1 THEN $7::int ELSE NULL END
       )
       ON CONFLICT (user_id, game_id) DO UPDATE SET
         wins        = leaderboard.wins        + $3::int,
         losses      = leaderboard.losses      + $4::int,
         draws       = leaderboard.draws       + $5::int,
         total_games = leaderboard.total_games + 1,
         rating      = $6,
         best_time_secs = CASE
           WHEN $3::int = 1 AND ($7::int < leaderboard.best_time_secs OR leaderboard.best_time_secs IS NULL)
           THEN $7::int ELSE leaderboard.best_time_secs END`,
      [
        player.user_id, session.game_id,
        isWinner ? 1 : 0,
        (!isWinner && !isDraw) ? 1 : 0,
        isDraw ? 1 : 0,
        newRating,
        session.duration_secs,
      ]
    );
  }
}

module.exports = { getLeaderboard, getMyRank, updateStats };

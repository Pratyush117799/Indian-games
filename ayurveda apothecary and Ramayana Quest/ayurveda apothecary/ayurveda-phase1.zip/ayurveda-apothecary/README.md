# 🌿 Ayurveda Apothecary
### *Heal with Ancient Wisdom · Smart India Hackathon*

> You are an apprentice Vaidya. Guru Charaka awaits. The patients are arriving.

---

## Phase 1 — Complete ✅

### What's been built (pure game logic, no UI yet)

```
frontend/src/game-engine/
├── herbs.data.js     100 herbs, full metadata (Sanskrit, 5 languages, doshas, seasons, fun facts)
├── doshas.js         Vata/Pitta/Kapha engine (20-question quiz, patient diagnosis, advice)
├── crafting.js       60 Ayurvedic recipes (churna, kwatha, avaleha, taila, ghrita, lepa, arka)
├── seasons.js        Real-world time → Ayurvedic season (6 seasons, herb growth rates, atmosphere)
├── patients.js       30 patient story quests (branching dialogue, moral choices, herb facts)
└── index.js          Single import entry point
```

### Game Engine Highlights

**Herb Database (100 herbs)**
- Sanskrit names + 5 regional languages (Hindi, Tamil, Telugu, Kannada)
- Dosha properties (Vata/Pitta/Kapha +/-), rasa (6 tastes), guna (20 qualities), virya, vipaka
- Season of harvest, habitat, rarity (common/uncommon/rare/legendary)
- Fun facts designed for children (engaging, memorable, educational)
- Growth time + yield for in-game garden

**Dosha Engine**
- 20-question personality quiz across 4 categories (physical, mental, digestion, lifestyle)
- Child-friendly wording on every question
- Calculates dominant + secondary constitution (Prakriti)
- Detects imbalance from symptoms (for patient diagnosis)
- Personalised diet, lifestyle, and herb advice per dosha

**Crafting Engine (60 recipes)**
- 8 recipe categories matching classical Ayurvedic pharmaceutical forms
- Ingredient requirement checking + partial craft detection
- Potency calculation based on player grind skill vs. recipe difficulty
- Recipe discovery system (combining herbs freely unlocks recipes)
- Smart suggestion: given symptoms + inventory, recommends best recipe to craft

**Season Engine (real-world time)**
- Reads device date → maps to one of 6 Ayurvedic Ritus
- Each season: flourishing herbs (2× growth), dormant herbs (0.25× growth)
- Time-of-day dosha periods (6 periods per day)
- Garden atmosphere (sky colour, ambient light, ground moisture, temperature)
- Seasonal patient condition weighting

**Patient Quest Engine (30 patients)**
- Full character biographies with cultural depth
- Branching 4-stage dialogue
- Moral choice system (3 options per patient with ripple consequences)
- Three outcome tiers: success / partial / failure
- Herb facts woven into story resolution
- Level-gated + season-weighted daily queue system

---

## Quick Start

```bash
# Install
cd ayurveda-apothecary
npm install           # root
cd frontend && npm install
cd ../backend && npm install

# Database
psql -c "CREATE DATABASE ayurveda;"
psql ayurveda < database/migrations/001_players.sql
psql ayurveda < database/migrations/002_gardens.sql
psql ayurveda < database/migrations/003_compendium.sql
psql ayurveda < database/migrations/004_quests.sql
psql ayurveda < database/migrations/005_bazaar.sql

# Run
cp .env.example .env   # fill in API keys
npm run dev            # starts frontend (5174) + backend (3002)
```

---

## Phase 2 — Next (UI: Botanical aesthetic + game scenes)
- Parchment + ink design system
- Herb garden scene (seasonal, real-time growth visual)
- Mortar & pestle crafting mini-game (click + circular drag)
- Patient room with illustrated dialogue
- Herb compendium with page-turn animation
- Dosha quiz with animated result card

## Standout Features (Phase 3)
- 🤖 **AI Guru Charaka** — ask any question, get an in-character Ayurvedic answer
- 📅 **Seasonal garden** — real device date drives which herbs grow  
- 🎙️ **Voice narration** — Web Speech API in 5 languages
- 📷 **Camera herb scanner** — colour-heuristic plant identification
- 📊 **Sanskriti Score** — measurable cultural learning index for parents/teachers
- 🖨️ **Phygital cards** — printable herb cards with QR codes linking to game

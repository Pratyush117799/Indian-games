/**
 * playerSlice.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Player identity, progression, inventory, and Sanskriti Score.
 */
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {
  getLevelFromXP, getXPForNextLevel, getRankFromLevel, LEVEL_XP,
} from '../game-engine/index.js';

const LS_KEY = 'ayurveda_player';

// ── Achievements list ────────────────────────────────────────────────────────
export const ACHIEVEMENTS = [
  { id: 'first_herb',       label: 'First Harvest',         desc: 'Harvest your first herb',           icon: '🌿', xp: 10  },
  { id: 'first_remedy',     label: 'The Apprentice Brews',  desc: 'Craft your first remedy',           icon: '🧪', xp: 20  },
  { id: 'first_patient',    label: 'First Healing',         desc: 'Heal your first patient',           icon: '🙏', xp: 30  },
  { id: 'triphala_master',  label: 'Master of Three Fruits',desc: 'Craft Triphala Churna perfectly',   icon: '⚗️', xp: 40  },
  { id: 'dosha_scholar',    label: 'Dosha Scholar',         desc: 'Complete the full Dosha quiz',      icon: '📜', xp: 25  },
  { id: 'compendium_25',    label: 'Curious Mind',          desc: 'Unlock 25 herbs in compendium',     icon: '📚', xp: 50  },
  { id: 'compendium_50',    label: 'Herb Encyclopaedist',   desc: 'Unlock 50 herbs in compendium',     icon: '📗', xp: 100 },
  { id: 'compendium_100',   label: 'Parama Aushadhika',     desc: 'Unlock all 100 herbs',              icon: '🏆', xp: 500 },
  { id: 'streak_7',         label: 'Dedicated Healer',      desc: '7-day login streak',                icon: '🔥', xp: 70  },
  { id: 'streak_30',        label: 'Committed Vaidya',      desc: '30-day login streak',               icon: '🌟', xp: 300 },
  { id: 'seasonal_harvest', label: 'Child of the Seasons',  desc: 'Harvest in all 6 Ayurvedic seasons',icon: '🌸', xp: 150 },
  { id: 'masterwork_craft', label: 'The Perfect Remedy',    desc: 'Craft a masterwork remedy',         icon: '✨', xp: 80  },
  { id: 'chyawanprash',     label: 'Legacy of Chyavana',    desc: 'Successfully craft Chyawanprash',   icon: '🏺', xp: 200 },
  { id: 'legendary_herb',   label: 'Beyond the Mountains',  desc: 'Grow your first legendary herb',    icon: '🗻', xp: 250 },
  { id: 'moral_dharma',     label: 'Walking the Dharma',    desc: 'Accumulate 100 Dharma points',      icon: '☸️', xp: 100 },
  { id: 'sanskriti_100',    label: 'Cultural Ambassador',   desc: 'Earn 100 Sanskriti points',         icon: '🪔', xp: 50  },
  { id: 'sanskriti_500',    label: 'Keeper of Knowledge',   desc: 'Earn 500 Sanskriti points',         icon: '📿', xp: 200 },
  { id: 'meet_vaidya',      label: 'The Sage Speaks',       desc: 'Meet Vaidya Krishnadasa',           icon: '👴', xp: 500 },
  { id: 'all_patients',     label: 'The Complete Healer',   desc: 'Treat all 30 patients at least once',icon:'💊', xp: 1000},
];

// ── Virtues ──────────────────────────────────────────────────────────────────
const INITIAL_VIRTUES = { dharma: 0, courage: 0, wisdom: 0, devotion: 0 };

// ── Async: load from localStorage + optional backend sync ───────────────────
export const loadPlayer = createAsyncThunk('player/load', async () => {
  const stored = localStorage.getItem(LS_KEY);
  if (stored) {
    try { return JSON.parse(stored); } catch {}
  }
  // First-time player
  return createNewPlayer();
});

export const savePlayer = createAsyncThunk('player/save', async (_, { getState }) => {
  const { player } = getState();
  localStorage.setItem(LS_KEY, JSON.stringify(player.data));
  // TODO: sync to backend API when online
  return true;
});

function createNewPlayer() {
  return {
    id:              null,          // assigned by backend on first sync
    name:            'Apprentice',
    avatar:          'default',
    doshaType:       null,          // set after quiz
    xp:              0,
    level:           1,
    rank:            'Shishya',
    virtues:         { ...INITIAL_VIRTUES },
    sanskritiScore:  0,
    streak:          { current: 0, best: 0, lastDate: null },

    // Herb inventory: { herbId: quantity }
    inventory:       {},
    // Crafted remedies: { remedyId: quantity }
    remedies:        {},
    // Known recipes (discovered or taught)
    knownRecipes:    ['triphala_churna', 'trikatu_churna', 'tulsi_kwatha', 'sitopaladi_churna', 'turmeric_lepa', 'neem_haridra_lepa', 'amla_swarasa', 'tulsi_ginger_swarasa', 'karela_swarasa'],
    // Unlocked compendium herb IDs
    unlockedHerbs:   [],
    // Completed patient encounters: { patientId: { tier, timestamp, choiceIndex } }
    completedQuests: {},
    // Earned achievement IDs
    achievements:    [],
    // Seasons harvested in (for seasonal achievement)
    harvestedSeasons: [],
    // Settings
    settings: {
      soundOn:    true,
      musicOn:    true,
      language:   'english',
      childMode:  false,
    },
    createdAt: new Date().toISOString(),
    lastSeen:  new Date().toISOString(),
  };
}

// ── Slice ─────────────────────────────────────────────────────────────────────
const playerSlice = createSlice({
  name: 'player',
  initialState: {
    data:   null,
    status: 'idle',   // idle | loading | ready | error
    levelUpPending: false,
  },

  reducers: {

    // XP & progression
    addXP: (state, { payload: amount }) => {
      if (!state.data) return;
      const prev  = state.data.xp;
      state.data.xp += amount;
      const newLevel = getLevelFromXP(state.data.xp);
      if (newLevel > state.data.level) {
        state.data.level = newLevel;
        state.data.rank  = getRankFromLevel(newLevel);
        state.levelUpPending = true;
      }
    },

    clearLevelUp: (state) => { state.levelUpPending = false; },

    // Virtues
    addVirtue: (state, { payload: { virtue, amount } }) => {
      if (!state.data) return;
      state.data.virtues[virtue] = (state.data.virtues[virtue] ?? 0) + amount;
    },

    // Sanskriti Score
    addSanskriti: (state, { payload: amount }) => {
      if (!state.data) return;
      state.data.sanskritiScore += amount;
    },

    // Inventory management
    addHerb: (state, { payload: { herbId, quantity = 1 } }) => {
      if (!state.data) return;
      state.data.inventory[herbId] = (state.data.inventory[herbId] ?? 0) + quantity;
    },

    consumeHerbs: (state, { payload: consumed }) => {
      // consumed: { herbId: quantity }
      if (!state.data) return;
      for (const [herbId, qty] of Object.entries(consumed)) {
        state.data.inventory[herbId] = Math.max(0, (state.data.inventory[herbId] ?? 0) - qty);
      }
    },

    addRemedy: (state, { payload: { remedyId, quantity = 1 } }) => {
      if (!state.data) return;
      state.data.remedies[remedyId] = (state.data.remedies[remedyId] ?? 0) + quantity;
    },

    useRemedy: (state, { payload: remedyId }) => {
      if (!state.data) return;
      if ((state.data.remedies[remedyId] ?? 0) > 0)
        state.data.remedies[remedyId]--;
    },

    // Compendium
    unlockHerb: (state, { payload: herbId }) => {
      if (!state.data) return;
      if (!state.data.unlockedHerbs.includes(herbId))
        state.data.unlockedHerbs.push(herbId);
    },

    // Recipe knowledge
    learnRecipe: (state, { payload: recipeId }) => {
      if (!state.data) return;
      if (!state.data.knownRecipes.includes(recipeId))
        state.data.knownRecipes.push(recipeId);
    },

    // Quest completion
    completeQuest: (state, { payload: { patientId, tier, choiceIndex } }) => {
      if (!state.data) return;
      state.data.completedQuests[patientId] = {
        tier,
        choiceIndex,
        timestamp: new Date().toISOString(),
      };
    },

    // Achievements
    unlockAchievement: (state, { payload: achievementId }) => {
      if (!state.data) return;
      if (!state.data.achievements.includes(achievementId))
        state.data.achievements.push(achievementId);
    },

    // Dosha type (set after quiz)
    setDoshaType: (state, { payload: doshaType }) => {
      if (!state.data) return;
      state.data.doshaType = doshaType;
    },

    // Streak update
    updateStreak: (state) => {
      if (!state.data) return;
      const today    = new Date().toDateString();
      const lastDate = state.data.streak.lastDate;
      if (lastDate === today) return; // already updated today

      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const wasYesterday = lastDate === yesterday.toDateString();

      state.data.streak.current  = wasYesterday ? state.data.streak.current + 1 : 1;
      state.data.streak.best     = Math.max(state.data.streak.best, state.data.streak.current);
      state.data.streak.lastDate = today;
      state.data.lastSeen        = new Date().toISOString();
    },

    // Record season harvested in
    recordSeasonHarvest: (state, { payload: seasonId }) => {
      if (!state.data) return;
      if (!state.data.harvestedSeasons.includes(seasonId))
        state.data.harvestedSeasons.push(seasonId);
    },

    // Settings
    updateSettings: (state, { payload: settings }) => {
      if (!state.data) return;
      state.data.settings = { ...state.data.settings, ...settings };
    },

    setPlayerName: (state, { payload: name }) => {
      if (!state.data) return;
      state.data.name = name;
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(loadPlayer.pending,   (s) => { s.status = 'loading'; })
      .addCase(loadPlayer.fulfilled, (s, { payload }) => {
        s.data   = payload;
        s.status = 'ready';
      })
      .addCase(loadPlayer.rejected,  (s) => { s.status = 'error'; });
  },
});

export const {
  addXP, clearLevelUp, addVirtue, addSanskriti,
  addHerb, consumeHerbs, addRemedy, useRemedy,
  unlockHerb, learnRecipe, completeQuest, unlockAchievement,
  setDoshaType, updateStreak, recordSeasonHarvest,
  updateSettings, setPlayerName,
} = playerSlice.actions;

// ── Selectors ─────────────────────────────────────────────────────────────────
export const selectPlayer     = (state) => state.player.data;
export const selectLevel      = (state) => state.player.data?.level ?? 1;
export const selectXP         = (state) => state.player.data?.xp ?? 0;
export const selectRank       = (state) => state.player.data?.rank ?? 'Shishya';
export const selectInventory  = (state) => state.player.data?.inventory ?? {};
export const selectRemedies   = (state) => state.player.data?.remedies ?? {};
export const selectCompendium = (state) => state.player.data?.unlockedHerbs ?? [];
export const selectVirtues    = (state) => state.player.data?.virtues ?? {};
export const selectSanskriti  = (state) => state.player.data?.sanskritiScore ?? 0;
export const selectStreak     = (state) => state.player.data?.streak ?? {};
export const selectAchievements=(state) => state.player.data?.achievements ?? [];
export const selectKnownRecipes=(state) => state.player.data?.knownRecipes ?? [];
export const selectLevelUpPending=(s)   => s.player.levelUpPending;

export const selectXPProgress = (state) => {
  const xp   = selectXP(state);
  const level= selectLevel(state);
  const prev = LEVEL_XP[level - 1] ?? 0;
  const next = LEVEL_XP[level]     ?? null;
  if (!next) return { pct: 100, current: xp - prev, needed: 0 };
  const current = xp - prev;
  const needed  = next - prev;
  return { pct: Math.round((current / needed) * 100), current, needed };
};

export default playerSlice.reducer;

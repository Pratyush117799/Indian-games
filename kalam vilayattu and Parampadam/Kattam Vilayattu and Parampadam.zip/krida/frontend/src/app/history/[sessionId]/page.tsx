'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ChevronLeft, ChevronRight, SkipBack, SkipForward, Clock } from 'lucide-react';
import { clsx } from 'clsx';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import type { ReplayMove, RoomPlayer } from '@/types';

interface Session {
  session_id: string;
  game_name:  string;
  game_slug:  string;
  game_level: number;
  room_code:  string;
  total_moves:number;
  duration_secs: number | null;
  started_at: string;
  ended_at:   string | null;
  winner_id:  string | null;
}

export default function ReplayPage() {
  const router   = useRouter();
  const { sessionId } = useParams<{ sessionId: string }>();
  const { user } = useAuthStore();

  const [session, setSession] = useState<Session | null>(null);
  const [players, setPlayers] = useState<RoomPlayer[]>([]);
  const [moves,   setMoves]   = useState<ReplayMove[]>([]);
  const [step,    setStep]    = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.replace('/auth/login'); return; }
    api.get(`/history/${sessionId}`)
      .then(({ data }) => {
        setSession(data.session);
        setPlayers(data.players);
        setMoves(data.moves);
      })
      .catch(() => { router.push('/history'); })
      .finally(() => setLoading(false));
  }, [user, sessionId]);

  const totalSteps = moves.length;
  const currentMove = moves[step - 1] ?? null;

  const playerMap = Object.fromEntries(players.map(p => [p.id, p]));

  function fmt(secs: number | null) {
    if (!secs) return '—';
    return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  }

  if (loading) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <p className="text-clay animate-pulse text-sm">Loading replay…</p>
    </div>
  );

  if (!session) return null;

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 space-y-6">
      {/* Header */}
      <button onClick={() => router.push('/history')}
        className="flex items-center gap-1 text-sm text-clay hover:underline">
        <ChevronLeft size={14} /> Back to History
      </button>

      <div className="card space-y-2">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-temple">{session.game_name} — Replay</h1>
            <p className="text-xs text-gray-400">
              Room {session.room_code}
              {session.game_slug === 'kattam-vilayattu' && ` · Level ${session.game_level}`}
              {' · '}{new Date(session.started_at).toLocaleDateString()}
            </p>
          </div>
          <div className="text-right text-xs text-gray-400 space-y-0.5">
            <p className="flex items-center gap-1 justify-end"><Clock size={11} />{fmt(session.duration_secs)}</p>
            <p>{session.total_moves} moves</p>
          </div>
        </div>

        {/* Players */}
        <div className="flex gap-3 flex-wrap">
          {players.map(p => (
            <span key={p.id} className={clsx(
              'badge border text-xs',
              p.id === session.winner_id
                ? 'bg-kolam/10 border-kolam text-temple font-semibold'
                : 'bg-gray-50 border-gray-200 text-gray-500'
            )}>
              {p.id === session.winner_id ? '🏆 ' : ''}{p.username}
            </span>
          ))}
        </div>
      </div>

      {/* Replay scrubber */}
      <div className="card space-y-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">
            Move <span className="font-mono font-bold text-clay">{step}</span> / {totalSteps}
          </span>
          {currentMove && (
            <span className="text-xs text-gray-400">
              by <strong>{playerMap[currentMove.player_id]?.username || '?'}</strong>
            </span>
          )}
        </div>

        {/* Scrubber bar */}
        <input type="range" min={0} max={totalSteps} value={step}
          onChange={e => setStep(Number(e.target.value))}
          className="w-full accent-clay" />

        {/* Controls */}
        <div className="flex items-center justify-center gap-3">
          <button onClick={() => setStep(0)}            className="p-2 rounded hover:bg-clay/10 text-clay transition"><SkipBack    size={18} /></button>
          <button onClick={() => setStep(s => Math.max(0, s - 1))}      className="p-2 rounded hover:bg-clay/10 text-clay transition"><ChevronLeft size={18} /></button>
          <span className="px-4 py-1.5 bg-clay/5 rounded-lg font-mono text-sm text-clay min-w-[4rem] text-center">{step}/{totalSteps}</span>
          <button onClick={() => setStep(s => Math.min(totalSteps, s + 1))} className="p-2 rounded hover:bg-clay/10 text-clay transition"><ChevronRight size={18} /></button>
          <button onClick={() => setStep(totalSteps)}   className="p-2 rounded hover:bg-clay/10 text-clay transition"><SkipForward  size={18} /></button>
        </div>
      </div>

      {/* Current move detail */}
      {currentMove ? (
        <div className="card text-sm space-y-2">
          <p className="font-semibold text-gray-500 text-xs uppercase tracking-wider">Move {currentMove.move_number}</p>
          <p>
            <strong>{playerMap[currentMove.player_id]?.username}</strong>
            {' '}
            {session.game_slug === 'kattam-vilayattu'
              ? (() => {
                  const d = currentMove.move_data as any;
                  return d.type === 'place'
                    ? `placed a piece on cell ${d.cellIndex}`
                    : `moved a piece from cell ${d.fromIndex} → ${d.toIndex}`;
                })()
              : (() => {
                  const d = currentMove.move_data as any;
                  return `rolled a ${d.roll}${
                    d.event === 'snake'   ? ' 🐍 and hit a snake!' :
                    d.event === 'ladder'  ? ' 🪜 and climbed a ladder!' :
                    d.event === 'win'     ? ' 🙏 and reached Vaikuntam!' :
                    d.event === 'waiting' ? ' — waiting to enter' : ''
                  } (landed on Square ${d.landed})`;
                })()
            }
          </p>
          <p className="text-xs text-gray-400">
            {new Date(currentMove.created_at).toLocaleTimeString()}
          </p>
        </div>
      ) : (
        <div className="card text-center text-sm text-gray-400 py-6">
          Move the scrubber or press ▶ to step through the game
        </div>
      )}

      {/* Full move log */}
      <div className="card space-y-1 max-h-64 overflow-y-auto">
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Full Move Log</p>
        {moves.map((m, i) => (
          <button key={i} onClick={() => setStep(m.move_number)}
            className={clsx(
              'w-full text-left px-3 py-1.5 rounded text-xs flex items-center gap-2 transition',
              step === m.move_number ? 'bg-clay/10 text-clay font-semibold' : 'hover:bg-gray-50 text-gray-500'
            )}>
            <span className="font-mono w-6 text-right shrink-0">{m.move_number}.</span>
            <span className="font-medium">{playerMap[m.player_id]?.username}</span>
            <span className="text-gray-400 truncate">
              {session.game_slug === 'kattam-vilayattu'
                ? ((m.move_data as any).type === 'place' ? `place → cell ${(m.move_data as any).cellIndex}` : `move ${(m.move_data as any).fromIndex}→${(m.move_data as any).toIndex}`)
                : `roll ${(m.move_data as any).roll} → sq ${(m.move_data as any).landed}`
              }
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

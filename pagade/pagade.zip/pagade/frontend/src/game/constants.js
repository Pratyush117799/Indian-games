// ─── Board Layout ────────────────────────────────────────────────────────────
// 19×19 grid (rows 0-18, cols 0-18).  Cross-shape occupies:
//   Top arm    : rows 0-7,   cols 8-10
//   Left arm   : rows 8-10,  cols 0-7
//   Center     : rows 8-10,  cols 8-10   (home at 9,9)
//   Bottom arm : rows 11-18, cols 8-10
//   Right arm  : rows 8-10,  cols 11-18

export const GRID_SIZE      = 19;
export const CELL_SIZE      = 38;   // px per grid cell in SVG

// ─── Main Path (68 cells, counter-clockwise) ─────────────────────────────────
// Each arm section = 17 cells (8 outer + 2 tip + 7 return)
//   Player 0 Red    → positions  0-16  (bottom arm)
//   Player 3 Blue   → positions 17-33  (left arm)
//   Player 2 Yellow → positions 34-50  (top arm)
//   Player 1 Green  → positions 51-67  (right arm)
export const MAIN_PATH = [
  // ── Red section: bottom arm ─────────────────────────────────────────────
  // right col going DOWN  (0-7)
  {r:11,c:10},{r:12,c:10},{r:13,c:10},{r:14,c:10},
  {r:15,c:10},{r:16,c:10},{r:17,c:10},{r:18,c:10},
  // tip going LEFT         (8-9)
  {r:18,c:9},{r:18,c:8},
  // left col going UP      (10-16)
  {r:17,c:8},{r:16,c:8},{r:15,c:8},{r:14,c:8},{r:13,c:8},{r:12,c:8},{r:11,c:8},

  // ── Blue section: left arm ───────────────────────────────────────────────
  // bottom row going LEFT  (17-24)
  {r:10,c:7},{r:10,c:6},{r:10,c:5},{r:10,c:4},{r:10,c:3},{r:10,c:2},{r:10,c:1},{r:10,c:0},
  // tip going UP           (25-26)
  {r:9,c:0},{r:8,c:0},
  // top row going RIGHT    (27-33)
  {r:8,c:1},{r:8,c:2},{r:8,c:3},{r:8,c:4},{r:8,c:5},{r:8,c:6},{r:8,c:7},

  // ── Yellow section: top arm ──────────────────────────────────────────────
  // left col going UP      (34-41)
  {r:7,c:8},{r:6,c:8},{r:5,c:8},{r:4,c:8},{r:3,c:8},{r:2,c:8},{r:1,c:8},{r:0,c:8},
  // tip going RIGHT        (42-43)
  {r:0,c:9},{r:0,c:10},
  // right col going DOWN   (44-50)
  {r:1,c:10},{r:2,c:10},{r:3,c:10},{r:4,c:10},{r:5,c:10},{r:6,c:10},{r:7,c:10},

  // ── Green section: right arm ─────────────────────────────────────────────
  // top row going RIGHT    (51-58)
  {r:8,c:11},{r:8,c:12},{r:8,c:13},{r:8,c:14},{r:8,c:15},{r:8,c:16},{r:8,c:17},{r:8,c:18},
  // tip going DOWN         (59-60)
  {r:9,c:18},{r:10,c:18},
  // bottom row going LEFT  (61-67)
  {r:10,c:17},{r:10,c:16},{r:10,c:15},{r:10,c:14},{r:10,c:13},{r:10,c:12},{r:10,c:11},
];
export const PATH_LENGTH = 68;

// ─── Player Entry Points on MAIN_PATH ────────────────────────────────────────
// Each player's pawn journey starts at their arm's first main-path position.
// Outside-belly pawns spawn here. Belly pawns enter here when they leave belly.
export const PLAYER_ENTRY = [0, 51, 34, 17]; // [Red, Green, Yellow, Blue]

// ─── Safe Lanes (8 cells each, outermost → innermost, toward HOME) ───────────
// Private channels — only the owning player's pawns may travel here.
export const SAFE_LANES = [
  // Red   (0) — bottom arm, col 9,  row 18 → 11
  [{r:18,c:9},{r:17,c:9},{r:16,c:9},{r:15,c:9},{r:14,c:9},{r:13,c:9},{r:12,c:9},{r:11,c:9}],
  // Green (1) — right arm,  row 9,  col 18 → 11
  [{r:9,c:18},{r:9,c:17},{r:9,c:16},{r:9,c:15},{r:9,c:14},{r:9,c:13},{r:9,c:12},{r:9,c:11}],
  // Yellow(2) — top arm,   col 9,  row 0  →  7
  [{r:0,c:9},{r:1,c:9},{r:2,c:9},{r:3,c:9},{r:4,c:9},{r:5,c:9},{r:6,c:9},{r:7,c:9}],
  // Blue  (3) — left arm,  row 9,  col 0  →  7
  [{r:9,c:0},{r:9,c:1},{r:9,c:2},{r:9,c:3},{r:9,c:4},{r:9,c:5},{r:9,c:6},{r:9,c:7}],
];
export const SAFE_LANE_LENGTH = 8;
// Total steps to home: PATH_LENGTH + SAFE_LANE_LENGTH = 76

// ─── Belly (visual spawn positions for belly pawns, inside safe-lane area) ───
export const BELLY_POSITIONS = [
  [{r:15,c:9},{r:16,c:9},{r:17,c:9},{r:18,c:9}], // Red:   inner safe-lane cols
  [{r:9,c:15},{r:9,c:16},{r:9,c:17},{r:9,c:18}], // Green
  [{r:3,c:9},{r:2,c:9},{r:1,c:9},{r:0,c:9}],     // Yellow
  [{r:9,c:3},{r:9,c:2},{r:9,c:1},{r:9,c:0}],     // Blue
];

// ─── Home ────────────────────────────────────────────────────────────────────
export const HOME_CELL = { r: 9, c: 9 };

// ─── Safe squares on main path (no capture allowed here) ─────────────────────
// Entry cells of each arm + tip cells
export const SAFE_PATH_POSITIONS = new Set([
   0,  8,  9,   // bottom arm entry + tip
  17, 25, 26,   // left arm entry + tip
  34, 42, 43,   // top arm entry + tip
  51, 59, 60,   // right arm entry + tip
]);

// ─── Player Colours & Meta ────────────────────────────────────────────────────
export const PLAYER_COLORS        = ['#C0392B','#27AE60','#D4A017','#2471A3'];
export const PLAYER_COLORS_LIGHT  = ['#F5B7B1','#A9DFBF','#FAD7A0','#AED6F1'];
export const PLAYER_COLORS_DARK   = ['#7B241C','#1D6A42','#9A7D0A','#1A5276'];
export const PLAYER_NAMES         = ['Red','Green','Yellow','Blue'];

// ─── Pawn Status ─────────────────────────────────────────────────────────────
export const STATUS = { BELLY:'BELLY', ACTIVE:'ACTIVE', SAFE:'SAFE', HOME:'HOME' };

// ─── Dice ─────────────────────────────────────────────────────────────────────
export const DICE_STYLE = { COWRIE:'cowrie', STICK:'stick' };
// Stick-die faces (ancient Indian board game dice)
export const STICK_FACES = [1, 3, 4, 6];

// ─── Game Modes ──────────────────────────────────────────────────────────────
export const GAME_MODE = { SOLO_AI:'solo_ai', PASS_PLAY:'pass_play', TOURNAMENT:'tournament' };

// ─── AI Difficulties ──────────────────────────────────────────────────────────
export const AI_LEVEL = { BEGINNER:'beginner', PRINCE:'prince', MAHARAJA:'maharaja' };

// ─── Board zone classification helpers ───────────────────────────────────────
export function isValidCell(r, c) {
  if (r < 0 || r > 18 || c < 0 || c > 18) return false;
  const inVertical  = c >= 8 && c <= 10;          // top / bottom arms + center col
  const inHorizontal = r >= 8 && r <= 10;         // left / right arms + center row
  return inVertical || inHorizontal;
}

export function getCellZone(r, c) {
  // Returns 'center' | 'safe_lane_N' | 'arm' | null
  if (r === 9 && c === 9) return 'home';
  if (r >= 8 && r <= 10 && c >= 8 && c <= 10) return 'center';
  // Check if it's a safe-lane cell
  for (let pid = 0; pid < 4; pid++) {
    if (SAFE_LANES[pid].some(cell => cell.r === r && cell.c === c)) return `safe_${pid}`;
  }
  return 'arm';
}

export function isSafeLaneCell(r, c, forPlayerId) {
  return SAFE_LANES[forPlayerId].some(cell => cell.r === r && cell.c === c);
}

// Which player "owns" (is private to) this cell, or null
export function cellOwner(r, c) {
  for (let pid = 0; pid < 4; pid++) {
    if (SAFE_LANES[pid].some(cell => cell.r === r && cell.c === c)) return pid;
  }
  return null;
}

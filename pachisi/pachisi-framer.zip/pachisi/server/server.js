'use strict';
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const gameRoutes = require('./routes/game');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// ── API Routes ────────────────────────────────────
app.use('/api/games', gameRoutes);

// ── Health check ──────────────────────────────────
app.get('/api/ping', (_req, res) => res.json({ ok: true, ts: Date.now() }));

// ── SPA fallback ──────────────────────────────────
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n  🏛  Pachisi · Krida  |  http://localhost:${PORT}\n`);
});

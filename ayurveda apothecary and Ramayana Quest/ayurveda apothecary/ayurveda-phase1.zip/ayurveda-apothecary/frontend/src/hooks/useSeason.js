/**
 * useSeason.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Real-time season + time-of-day hook.
 * Refreshes every 60 seconds (season data doesn't change faster than that).
 */
import { useState, useEffect, useCallback } from 'react';
import {
  getCurrentSeason, getCurrentTimePeriod,
  getSeasonalContext, getTimeDescription,
  getFlourishingHerbs,
} from '../game-engine/seasons.js';

export function useSeason() {
  const [ctx, setCtx] = useState(() => ({
    season:      getCurrentSeason(),
    timePeriod:  getCurrentTimePeriod(),
    fullCtx:     getSeasonalContext(),
    timeDesc:    getTimeDescription(),
    flourishing: getFlourishingHerbs(),
  }));

  const refresh = useCallback(() => {
    setCtx({
      season:      getCurrentSeason(),
      timePeriod:  getCurrentTimePeriod(),
      fullCtx:     getSeasonalContext(),
      timeDesc:    getTimeDescription(),
      flourishing: getFlourishingHerbs(),
    });
  }, []);

  useEffect(() => {
    // Refresh every 60 seconds
    const id = setInterval(refresh, 60_000);
    return () => clearInterval(id);
  }, [refresh]);

  return ctx;
}

'use strict';
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/store');

const router = express.Router();

// POST /api/games — start new game session
router.post('/', (req, res) => {
  const id = uuidv4();
  const game = db.createGame(id);
  res.status(201).json({ ok: true, gameId: id, game });
});

// GET /api/games/:id — load saved state
router.get('/:id', (req, res) => {
  const game = db.getGame(req.params.id);
  if (!game) return res.status(404).json({ ok: false, error: 'Game not found' });
  res.json({ ok: true, game });
});

// PUT /api/games/:id/state — auto-save game state
router.put('/:id/state', (req, res) => {
  const { state } = req.body;
  if (!state) return res.status(400).json({ ok: false, error: 'state required' });
  const game = db.saveState(req.params.id, state);
  if (!game) return res.status(404).json({ ok: false, error: 'Game not found' });
  res.json({ ok: true });
});

// POST /api/games/:id/end — mark game complete
router.post('/:id/end', (req, res) => {
  const { winner } = req.body;
  if (!winner || !['A', 'B'].includes(winner))
    return res.status(400).json({ ok: false, error: 'winner must be A or B' });
  const game = db.endGame(req.params.id, winner);
  if (!game) return res.status(404).json({ ok: false, error: 'Game not found' });
  res.json({ ok: true, game });
});

// GET /api/stats
router.get('/meta/stats', (req, res) => {
  res.json({ ok: true, stats: db.getStats() });
});

// GET /api/games/meta/recent
router.get('/meta/recent', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 10, 50);
  res.json({ ok: true, games: db.recentGames(limit) });
});

module.exports = router;

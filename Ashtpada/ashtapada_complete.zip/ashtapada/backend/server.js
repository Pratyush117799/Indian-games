'use strict';

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const path       = require('path');

const gameRoutes        = require('./routes/game');
const userRoutes        = require('./routes/users');
const leaderboardRoutes = require('./routes/leaderboard');
const { handleSocket }  = require('./middleware/ws');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

/* ── Middleware ─────────────────────────────────────────────── */
app.use(cors());
app.use(express.json());

/* Serve the frontend in production */
app.use(express.static(path.join(__dirname, '../frontend')));

/* ── REST Routes ─────────────────────────────────────────────── */
app.use('/api/games',       gameRoutes);
app.use('/api/users',       userRoutes);
app.use('/api/leaderboard', leaderboardRoutes);

/* ── Health check ────────────────────────────────────────────── */
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', game: 'Ashtapada', version: '1.0.0' });
});

/* ── WebSocket (real-time multiplayer) ───────────────────────── */
io.on('connection', socket => handleSocket(socket, io));

/* ── Start ───────────────────────────────────────────────────── */
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`[Ashtapada] Server running on port ${PORT}`);
});

module.exports = { app, server, io };

import { motion } from 'framer-motion';

const fadeUp = (delay = 0) => ({
  initial:    { opacity:0, y:20 },
  animate:    { opacity:1, y:0  },
  transition: { delay, duration:0.6, ease:'easeOut' },
});

export default function IntroScreen({ onStart }) {
  return (
    <motion.div className="intro-screen"
      initial={{ opacity:1 }}
      exit={{ opacity:0, scale:0.96 }}
      transition={{ duration:0.7 }}
    >
      <motion.div className="i-label" {...fadeUp(0.1)}>Krida · Ancient Indian Games</motion.div>

      <motion.div className="i-deva" {...fadeUp(0.2)}
        animate={{ textShadow:['0 0 12px rgba(201,153,58,0.2)','0 0 40px rgba(201,153,58,0.7)','0 0 12px rgba(201,153,58,0.2)'] }}
        transition={{ ...fadeUp(0.2).transition, textShadow:{ duration:3.5, repeat:Infinity, delay:1 } }}
      >
        पचीसी
      </motion.div>

      <motion.div className="i-title" {...fadeUp(0.3)}
        animate={{ textShadow:['0 0 30px rgba(201,153,58,0.3)','0 0 70px rgba(201,153,58,0.6)','0 0 30px rgba(201,153,58,0.3)'] }}
        transition={{ ...fadeUp(0.3).transition, textShadow:{ duration:4, repeat:Infinity, delay:0.8 } }}
      >
        PACHISI
      </motion.div>

      <motion.div className="i-sub" {...fadeUp(0.4)}>
        The Royal Game of India · The game Emperor Akbar played on a life-size court with sixteen living pieces
      </motion.div>

      <motion.div className="orn" {...fadeUp(0.5)}>
        <span className="orn-line"/>
        <span className="orn-o"/>
        <span className="orn-d"/>
        <span className="orn-o"/>
        <span className="orn-line"/>
      </motion.div>

      <motion.blockquote className="i-quote" {...fadeUp(0.6)}>
        <p>"The Court itself, divided into red and white squares, being the board… sixteen young slaves from the harem wearing the players' colours represented the pieces, and moved to the squares according to the throw of the cowries."</p>
        <cite>— Louis Rousselet, on Akbar's court at Fatehpur Sikri, 1876</cite>
      </motion.blockquote>

      <motion.button
        className="btn-royal"
        onClick={onStart}
        {...fadeUp(0.75)}
        whileHover={{ scale:1.04, boxShadow:'0 0 48px rgba(201,153,58,0.4)' }}
        whileTap={{ scale:0.97 }}
      >
        Enter the Royal Court →
      </motion.button>
    </motion.div>
  );
}

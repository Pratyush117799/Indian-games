-- ── 005_bazaar.sql ─────────────────────────────────────────────────────────
-- Herb trading marketplace

CREATE TABLE IF NOT EXISTS bazaar_listings (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id     UUID        NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  herb_id       VARCHAR(50) NOT NULL,
  quantity      INTEGER     NOT NULL,
  asking_herb   VARCHAR(50),  -- what they want in trade
  asking_qty    INTEGER,
  asking_gold   INTEGER,      -- in-game gold coins
  listed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at    TIMESTAMPTZ NOT NULL,
  filled        BOOLEAN     NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS bazaar_trades (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id    UUID        NOT NULL REFERENCES bazaar_listings(id),
  buyer_id      UUID        NOT NULL REFERENCES players(id),
  traded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bazaar_herb      ON bazaar_listings(herb_id, filled);
CREATE INDEX IF NOT EXISTS idx_bazaar_seller    ON bazaar_listings(seller_id);

const { Pool } = require('pg');
const logger  = require('../utils/logger');

const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME     || 'krida_db',
  user:     process.env.DB_USER     || 'krida_user',
  password: process.env.DB_PASSWORD || '',
  min:      parseInt(process.env.DB_POOL_MIN || '2'),
  max:      parseInt(process.env.DB_POOL_MAX || '10'),
  idleTimeoutMillis:    30000,
  connectionTimeoutMillis: 5000,
});

pool.on('connect', () => logger.info('PostgreSQL pool: new client connected'));
pool.on('error',  (err) => logger.error('PostgreSQL pool error:', err));

/**
 * Execute a parameterised query.
 * @param {string}   text   SQL string with $1, $2 placeholders
 * @param {Array}    params Values array
 */
const query = (text, params) => pool.query(text, params);

/**
 * Grab a client from the pool for multi-statement transactions.
 * Always call client.release() in a finally block.
 */
const getClient = () => pool.connect();

module.exports = { query, getClient, pool };

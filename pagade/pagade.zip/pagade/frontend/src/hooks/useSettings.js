/**
 * useSettings — persists and retrieves user preferences.
 * Stored in localStorage under 'pagade_settings'.
 *
 * Keys: diceStyle, boardTheme, soundEnabled, showMoveLog, animSpeed
 */

import { useState, useCallback, useEffect } from 'react';
import { DICE_STYLE } from '../game/constants';
import { DEFAULT_THEME, applyTheme } from '../game/boardThemes';

const STORAGE_KEY = 'pagade_settings';

const DEFAULT_SETTINGS = {
  diceStyle:    DICE_STYLE.COWRIE,
  boardTheme:   DEFAULT_THEME,
  soundEnabled: false,      // muted by default per design doc
  showMoveLog:  true,
  animSpeed:    'normal',   // 'fast' | 'normal' | 'slow'
  playerName:   '',         // optional display name
};

export function useSettings() {
  const [settings, setSettings] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
    } catch { return DEFAULT_SETTINGS; }
  });

  // Apply theme on mount and whenever it changes
  useEffect(() => {
    applyTheme(settings.boardTheme);
  }, [settings.boardTheme]);

  const updateSetting = useCallback((key, value) => {
    setSettings(prev => {
      const next = { ...prev, [key]: value };
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS);
    try { localStorage.removeItem(STORAGE_KEY); } catch {}
    applyTheme(DEFAULT_THEME);
  }, []);

  return { settings, updateSetting, resetSettings };
}

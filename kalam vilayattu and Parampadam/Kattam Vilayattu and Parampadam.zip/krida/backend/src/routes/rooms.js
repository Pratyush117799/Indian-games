const router = require('express').Router();
const ctrl   = require('../controllers/gameController');
const { authenticate } = require('../middleware/auth');

router.get ('/:code',      authenticate, ctrl.getRoomState);
router.post('/:code/join', authenticate, ctrl.joinRoom);

module.exports = router;

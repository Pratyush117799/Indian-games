'use client';
import { useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import toast from 'react-hot-toast';
import { useAuthStore } from '@/store/authStore';
import { useGameStore } from '@/store/gameStore';
import { getSocket, connectSocket } from '@/lib/socket';
import api from '@/lib/api';
import ParamapadamBoard from '@/components/games/paramapadam/ParamapadamBoard';
import RoomLobby from '@/components/games/RoomLobby';
import type { ParamapadamState } from '@/types';

export default function ParamapadamPlayPage() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const roomCode     = searchParams.get('room');
  const { user, accessToken } = useAuthStore();
  const {
    room, players, gameSlug, paramapadamState,
    setRoom, setPlayers, setGameStarted, setParamapadamState,
    addChatMessage, reset,
  } = useGameStore();

  useEffect(() => {
    if (!user) router.replace('/auth/login');
  }, [user]);

  useEffect(() => {
    if (!roomCode || !user || !accessToken) return;
    const socket = connectSocket(accessToken);

    api.get(`/rooms/${roomCode}`).then(({ data }) => {
      setRoom(data.room, data.players);
      socket.emit('room:join', { roomCode });
    }).catch(() => {
      toast.error('Room not found');
      router.push('/games/paramapadam');
    });

    socket.on('room:state',         ({ room, players }) => { setRoom(room, players); setPlayers(players); });
    socket.on('room:player_joined', ({ username })      => toast(`${username} joined`));
    socket.on('room:player_left',   ({ username })      => toast.error(`${username} left`));
    socket.on('room:abandoned',     ({ message })       => { toast.error(message); reset(); router.push('/games/paramapadam'); });
    socket.on('room:message',       (msg)               => addChatMessage(msg));
    socket.on('room:start',         ({ gameSlug, state, players }) => { setGameStarted(gameSlug, state); setPlayers(players); });
    socket.on('paramapadam:state',  ({ state })         => setParamapadamState(state as ParamapadamState));
    socket.on('paramapadam:win',    ({ winnerId, state }) => {
      setParamapadamState(state);
      const winner = players.find(p => p.id === winnerId);
      toast.success(`${winner?.username || 'Player'} reached Vaikuntam! 🙏`, { duration: 6000 });
    });
    socket.on('paramapadam:error',  ({ message }) => toast.error(message));

    return () => {
      ['room:state','room:player_joined','room:player_left','room:abandoned',
       'room:message','room:start','paramapadam:state','paramapadam:win','paramapadam:error']
        .forEach(e => socket.off(e));
      socket.emit('room:leave', { roomCode });
      reset();
    };
  }, [roomCode, user, accessToken]);

  const playerMap = Object.fromEntries(
    players.map(p => [p.id, { username: p.username, color: p.color }])
  );

  const handleRoll = useCallback(() => {
    getSocket().emit('paramapadam:roll', { roomCode });
  }, [roomCode]);

  if (!room) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="text-clay animate-pulse text-sm">Connecting to room…</div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-temple">Paramapadam</h1>
        <p className="text-sm text-gray-400 font-tamil">பரமபதம் · Vaikunta Ekadasi Sacred Game</p>
      </div>

      {gameSlug !== 'paramapadam' || !paramapadamState ? (
        <RoomLobby room={room} players={players} />
      ) : (
        <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">
          <ParamapadamBoard
            state={paramapadamState}
            myPlayerId={user!.id}
            playerMap={playerMap}
            onRoll={handleRoll}
          />
          <div className="space-y-4 min-w-[200px]">
            <div className="card space-y-2">
              <h3 className="text-xs font-semibold text-gray-400 uppercase">Players</h3>
              {players.map((p, i) => (
                <div key={p.id} className="flex items-center gap-2 text-sm">
                  <span className={`w-3 h-3 rounded-full ${['bg-leaf','bg-clay','bg-red-500','bg-blue-500'][i] || 'bg-gray-300'}`} />
                  <span className="font-medium">{p.username}</span>
                  <span className="ml-auto text-xs font-mono text-clay">
                    Sq {paramapadamState.positions[p.id] || '—'}
                  </span>
                  {paramapadamState.players[paramapadamState.currentPlayerIndex] === p.id && !paramapadamState.winner && (
                    <span className="text-xs text-kolam animate-pulse">●</span>
                  )}
                </div>
              ))}
            </div>
            <div className="card text-xs text-gray-500 space-y-1">
              <p><strong>Moves:</strong> {paramapadamState.moveCount}</p>
              <p><strong>Last roll:</strong> {paramapadamState.lastDiceRoll ?? '—'}</p>
              {paramapadamState.bonusTurn && <p className="text-kolam font-semibold">Bonus turn active!</p>}
            </div>
            <div className="card text-xs text-gray-400 space-y-1 border-l-2 border-kolam">
              <p className="font-semibold text-clay text-xs">About this game</p>
              <p>Square 1 = Patalam (Underworld)</p>
              <p>Square 100 = Vaikuntam (Heaven)</p>
              <p>🐍 Snake = vice, fall down</p>
              <p>🪜 Ladder = virtue, climb up</p>
              <p>Roll 1 to enter the board</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

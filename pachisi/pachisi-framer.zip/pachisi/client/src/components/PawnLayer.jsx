import { forwardRef, useImperativeHandle, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValue, animate } from 'framer-motion';
import { COLORS } from '../game/config.js';
import { PATHS }  from '../game/paths.js';
import { HOME }   from '../game/geometry.js';
import { useGame } from '../context/GameContext.jsx';

// ── PawnLayer: renders all 16 pawns ────────────────
export default function PawnLayer() {
  const { pawns, coords, movable, phase, cur, onPawnClick, registerCaptureCallback } = useGame();

  return (
    <>
      {/* Move highlights */}
      <Highlights movable={movable} cur={cur} phase={phase} pawns={pawns}/>
      {/* Pawns */}
      {[0,1,2,3].map(p =>
        [0,1,2,3].map(i => {
          if (pawns[p][i].pos === 80) return null;
          const coord = coords[p][i];
          const selectable = phase === 'select' && cur === 0 && p === 0 && movable.includes(i);
          return (
            <Pawn
              key={`${p}-${i}`}
              player={p} pawnIdx={i}
              x={coord.x} y={coord.y}
              selectable={selectable}
              captured={pawns[p][i].pos === -1 && coords[p][i].x === HOME.x}
              onClick={() => onPawnClick(p, i)}
              onRegister={fn => registerCaptureCallback(p, i, fn)}
            />
          );
        })
      )}
    </>
  );
}

// ── Individual Pawn ────────────────────────────────
const Pawn = forwardRef(function Pawn({ player, pawnIdx, x, y, selectable, onClick, onRegister }, _ref) {
  const col = COLORS[player];
  const mx  = useMotionValue(x);
  const my  = useMotionValue(y);

  // Track position changes with spring
  useEffect(() => {
    const ax = animate(mx, x, { type:'spring', stiffness:420, damping:32, mass:0.5 });
    const ay = animate(my, y, { type:'spring', stiffness:420, damping:32, mass:0.5 });
    return () => { ax.stop(); ay.stop(); };
  }, [x, y]);

  // Expose capture animation to parent via callback
  useEffect(() => {
    onRegister(() => new Promise(resolve => {
      animate(mx, x + (Math.random()-0.5)*30, { type:'spring', stiffness:600, damping:10, duration:0.15 });
      animate(my, y - 20, { type:'spring', stiffness:600, damping:10, duration:0.12 });
      setTimeout(resolve, 420);
    }));
  }, [x, y]);

  return (
    <motion.g
      style={{ x: mx, y: my, cursor: selectable ? 'pointer' : 'default' }}
      onClick={selectable ? onClick : undefined}
      animate={selectable
        ? { scale:[1,1.18,1], filter:['drop-shadow(0 0 0px transparent)','drop-shadow(0 0 8px rgba(232,201,106,0.9))','drop-shadow(0 0 0px transparent)'] }
        : { scale:1, filter:'drop-shadow(0 0 0px transparent)' }
      }
      transition={selectable
        ? { duration:0.7, repeat:Infinity, ease:'easeInOut' }
        : { duration:0.2 }
      }
      whileHover={selectable ? { scale:1.25 } : {}}
      whileTap={selectable   ? { scale:0.95 } : {}}
    >
      <BeehiveShape col={col}/>
    </motion.g>
  );
});

// ── Beehive pawn shape ─────────────────────────────
function BeehiveShape({ col }) {
  return (
    <>
      {/* Shadow */}
      <ellipse cx="0" cy="8" rx="7" ry="2.5" fill="rgba(0,0,0,0.44)"/>
      {/* Base disc */}
      <ellipse cx="0" cy="5"  rx="7.5" ry="4"   fill={col} stroke="rgba(0,0,0,0.3)"  strokeWidth="0.6"/>
      {/* Waist */}
      <ellipse cx="0" cy="0"  rx="6.2" ry="6.2" fill={col} stroke="rgba(0,0,0,0.2)"  strokeWidth="0.5"/>
      {/* Upper */}
      <ellipse cx="0" cy="-5" rx="3.8" ry="4.2" fill={col} stroke="rgba(0,0,0,0.15)" strokeWidth="0.4"/>
      {/* Gold cap */}
      <ellipse cx="0" cy="-7.2" rx="3.2" ry="2.4"
               fill="rgba(201,153,58,0.93)" stroke="rgba(232,201,106,0.82)" strokeWidth="0.7"/>
      {/* Cap jewel */}
      <circle  cx="0" cy="-8.4" r="1.4" fill="rgba(240,220,100,0.95)"/>
      {/* Specular highlight */}
      <ellipse cx="-2.2" cy="-2" rx="1.7" ry="3"
               fill="rgba(255,255,255,0.18)" transform="rotate(-25,-2.2,-2)"/>
    </>
  );
}

// ── Move highlights ────────────────────────────────
function Highlights({ movable, cur, phase, pawns }) {
  if (phase !== 'select' || cur !== 0) return null;
  return (
    <>
      {movable.map(i => {
        const {pos} = pawns[cur][i];
        if (pos < 0) return null; // Charkoni pawns — no specific highlight square
        const sq = PATHS[cur][Math.min(pos, 79)]; // approximate; real target computed in engine
        return (
          <motion.rect key={i}
            x={sq.x-15} y={sq.y-15} width="30" height="30" rx="2"
            fill="rgba(232,201,106,0.14)" stroke="rgba(232,201,106,0.82)" strokeWidth="1"
            animate={{ opacity:[0.4,0.95,0.4] }}
            transition={{ duration:1.1, repeat:Infinity, ease:'easeInOut' }}
          />
        );
      })}
    </>
  );
}

/**
 * Kattam Vilayattu — Socket.IO event handler
 *
 * Client events:  kattam:place   { roomCode, cellIndex }
 *                 kattam:move    { roomCode, fromIndex, toIndex }
 *
 * Server emits:   kattam:state   { state, lastMove }         → room
 *                 kattam:error   { message }                 → sender
 *                 kattam:win     { winnerId, state }          → room
 */

const db         = require('../../config/db');
const roomStore  = require('../roomStore');
const { applyPlacement, applyMovement } = require('../../game-logic/kattam/engine');
const { updateStats } = require('../../controllers/leaderboardController');
const logger     = require('../../utils/logger');

async function persistMove(sessionId, playerId, moveNumber, moveData, boardState) {
  await db.query(
    `INSERT INTO moves (session_id, player_id, move_number, move_data, board_state)
     VALUES ($1, $2, $3, $4, $5)`,
    [sessionId, playerId, moveNumber, JSON.stringify(moveData), JSON.stringify(boardState)]
  );
}

async function finaliseSession(sessionId, winnerId, duration, finalState) {
  await db.query(
    `UPDATE game_sessions
     SET winner_id = $2, duration_secs = $3, total_moves = $4,
         game_state = $5, ended_at = NOW()
     WHERE id = $1`,
    [sessionId, winnerId, duration, finalState.moveCount, JSON.stringify(finalState)]
  );
  await updateStats(sessionId);
}

function registerKattamHandlers(io, socket) {
  // ── PLACE (Phase 1) ──────────────────────────────────────
  socket.on('kattam:place', async ({ roomCode, cellIndex }) => {
    try {
      const room = roomStore.get(roomCode);
      if (!room) return socket.emit('kattam:error', { message: 'Room not found' });

      const { newState, error } = applyPlacement(room.state, socket.user.id, cellIndex);
      if (error) return socket.emit('kattam:error', { message: error });

      roomStore.patch(roomCode, { state: newState });

      const moveData = { type: 'place', cellIndex, playerId: socket.user.id, phase: 'placement' };
      await persistMove(room.sessionId, socket.user.id, newState.moveCount, moveData, newState.board);

      if (newState.winner) {
        const duration = Math.round((Date.now() - room.startedAt) / 1000);
        await finaliseSession(room.sessionId, newState.winner, duration, newState);
        io.to(roomCode).emit('kattam:win', { winnerId: newState.winner, state: newState });
        await db.query("UPDATE game_rooms SET status='finished', finished_at=NOW() WHERE room_code=$1", [roomCode]);
        roomStore.delete(roomCode);
      } else {
        io.to(roomCode).emit('kattam:state', { state: newState, lastMove: moveData });
      }
    } catch (err) {
      logger.error('kattam:place error', err);
      socket.emit('kattam:error', { message: 'Server error processing move' });
    }
  });

  // ── MOVE (Phase 2) ──────────────────────────────────────
  socket.on('kattam:move', async ({ roomCode, fromIndex, toIndex }) => {
    try {
      const room = roomStore.get(roomCode);
      if (!room) return socket.emit('kattam:error', { message: 'Room not found' });

      const { newState, error } = applyMovement(room.state, socket.user.id, fromIndex, toIndex);
      if (error) return socket.emit('kattam:error', { message: error });

      roomStore.patch(roomCode, { state: newState });

      const moveData = { type: 'move', fromIndex, toIndex, playerId: socket.user.id, phase: 'movement' };
      await persistMove(room.sessionId, socket.user.id, newState.moveCount, moveData, newState.board);

      if (newState.winner) {
        const duration = Math.round((Date.now() - room.startedAt) / 1000);
        await finaliseSession(room.sessionId, newState.winner, duration, newState);
        io.to(roomCode).emit('kattam:win', { winnerId: newState.winner, state: newState });
        await db.query("UPDATE game_rooms SET status='finished', finished_at=NOW() WHERE room_code=$1", [roomCode]);
        roomStore.delete(roomCode);
      } else {
        io.to(roomCode).emit('kattam:state', { state: newState, lastMove: moveData });
      }
    } catch (err) {
      logger.error('kattam:move error', err);
      socket.emit('kattam:error', { message: 'Server error processing move' });
    }
  });
}

module.exports = { registerKattamHandlers };

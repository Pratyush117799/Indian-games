import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { THROW_VAL, THROW_NAME, GRACE_VALS, GRACE_DEVA, NAMES } from '../game/config.js';
import { useGame } from '../context/GameContext.jsx';

function rollShells() {
  return Array.from({ length:6 }, () => Math.random() < 0.5 ? 1 : 0);
}

const SCATTER_POSITIONS = [
  [-22,-14],[ 22,-14],[-30, 0],[ 30, 0],[-22, 14],[ 22, 14],
];

export default function CowriePanel() {
  const { phase, cur, val, grace, onHumanThrow, onAIThrow } = useGame();

  const [shells,     setShells]    = useState([]);
  const [throwing,   setThrowing]  = useState(false);
  const [throwKey,   setThrowKey]  = useState(0);  // force AnimatePresence remount
  const [displayVal, setDisplayVal]= useState(null);
  const [displayName,setDisplayName]= useState('');
  const [showGrace,  setShowGrace] = useState(false);
  const [graceLabel, setGraceLabel]= useState('');

  const isHuman = cur === 0;
  const canThrow = phase === 'throw' && isHuman && !throwing;

  // Register AI throw hook on window
  useEffect(() => {
    window._requestAIThrow = (player) => {
      setThrowing(true);
      const s = rollShells();
      setShells(s);
      setThrowKey(k => k+1);

      setTimeout(() => {
        const { val:v, grace:gr } = onAIThrow(player, s);
        setDisplayVal(v);
        setDisplayName(THROW_NAME[v] || '');
        if (gr) triggerGrace(v);
        setThrowing(false);
      }, 920);
    };
    return () => { delete window._requestAIThrow; };
  }, [onAIThrow]);

  // Reset display on turn change
  useEffect(() => {
    if (phase === 'throw') { setDisplayVal(null); setDisplayName(''); }
  }, [phase, cur]);

  function handleThrow() {
    if (!canThrow) return;
    setThrowing(true);
    const s = rollShells();
    setShells(s);
    setThrowKey(k => k+1);

    setTimeout(() => {
      const { val:v, grace:gr } = onHumanThrow(s);
      setDisplayVal(v);
      setDisplayName(THROW_NAME[v] || '');
      if (gr) triggerGrace(v);
      setThrowing(false);
    }, 920);
  }

  function triggerGrace(v) {
    setGraceLabel(GRACE_DEVA[v] || '');
    setShowGrace(true);
    setTimeout(() => setShowGrace(false), 900);
  }

  return (
    <div className="throw-panel">
      <div className="tp-label">Cowrie Shells · कौड़ी</div>

      {/* Shell scatter area */}
      <div className="cowrie-area" style={{position:'relative', minHeight:62}}>
        <AnimatePresence mode="wait">
          {shells.length > 0 && (
            <motion.div key={throwKey} style={{display:'flex',flexWrap:'wrap',gap:5,justifyContent:'center',alignItems:'center'}}>
              {shells.map((up, i) => (
                <Shell key={i} up={up===1} index={i} scatter={SCATTER_POSITIONS[i]}/>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Throw value display */}
      <AnimatePresence mode="wait">
        {displayVal !== null ? (
          <motion.div key={displayVal} className="throw-value"
            initial={{ scale:0.5, opacity:0 }}
            animate={{ scale:1,   opacity:1 }}
            transition={{ type:'spring', stiffness:500, damping:22 }}>
            {displayVal}
          </motion.div>
        ) : <div className="throw-value">—</div>}
      </AnimatePresence>

      <div className="throw-name">{displayName}</div>

      {/* Grace flash */}
      <div className="grace-flash-wrap">
        <AnimatePresence>
          {showGrace && (
            <motion.div
              key="gf"
              initial={{ scale:0.3, opacity:0 }}
              animate={{ scale:[0.3,1.5,1.1], opacity:[0,1,0] }}
              transition={{ duration:0.85, times:[0,0.4,1] }}
              exit={{ opacity:0 }}
              style={{
                fontFamily:'Cinzel,serif', fontSize:32, color:'#E8C96A',
                textShadow:'0 0 24px rgba(201,153,58,0.9)', pointerEvents:'none',
                whiteSpace:'nowrap', position:'absolute',
              }}
            >
              {graceLabel}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Throw button */}
      <motion.button
        className="btn-throw"
        onClick={handleThrow}
        disabled={!canThrow}
        whileHover={canThrow ? { scale:1.03, boxShadow:'0 4px 22px rgba(201,153,58,0.3)' } : {}}
        whileTap={canThrow   ? { scale:0.97 } : {}}
        animate={canThrow
          ? { boxShadow:['0 2px 10px rgba(139,26,26,0.3)','0 2px 18px rgba(201,153,58,0.22)','0 2px 10px rgba(139,26,26,0.3)'] }
          : {}
        }
        transition={{ duration:2.2, repeat:canThrow?Infinity:0 }}
      >
        {throwing && !isHuman ? `${NAMES[cur]} throwing…` : 'Throw · फेंको'}
      </motion.button>
    </div>
  );
}

// ── Individual cowrie shell ─────────────────────────
function Shell({ up, index, scatter }) {
  const [fx, fy] = scatter;
  return (
    <motion.div
      className="cowrie-shell"
      initial={{ x: fx * 2.5, y: fy * 2.5, rotate: Math.random()*720, scale:0, opacity:0 }}
      animate={{ x: fx * 0.3, y: fy * 0.3, rotate: up ? 0 : 178, scale:1, opacity:1 }}
      transition={{
        type: 'spring', stiffness: 220, damping: 14,
        delay: index * 0.048,
        opacity: { duration:0.22 },
      }}
    >
      <svg width="22" height="28" viewBox="-11 -14 22 28">
        {up ? <ShellUp/> : <ShellDown/>}
      </svg>
    </motion.div>
  );
}

function ShellUp() {
  return (
    <>
      <path d="M0,-11 Q9,-8 9,0 Q9,8 0,11 Q-9,8 -9,0 Q-9,-8 0,-11 Z"
            fill="#D4B896" stroke="#B8955A" strokeWidth="0.8"/>
      <path d="M0,-6 Q5,-3 5,1 Q5,6 0,8 Q-5,6 -5,1 Q-5,-3 0,-6 Z"
            fill="#F5EDD5" stroke="rgba(0,0,0,0.08)" strokeWidth="0.4"/>
      {[0,1,2,3,4].map(d=>{
        const a=(d/5)*Math.PI*2;
        return <circle key={d} cx={(Math.sin(a)*2.8).toFixed(1)} cy={(Math.cos(a)*4-1).toFixed(1)} r="0.9" fill="rgba(0,0,0,0.18)"/>;
      })}
    </>
  );
}
function ShellDown() {
  return (
    <>
      <path d="M0,-11 Q9,-8 9,0 Q9,8 0,11 Q-9,8 -9,0 Q-9,-8 0,-11 Z"
            fill="#C4A065" stroke="#A88348" strokeWidth="0.8"/>
      <path d="M0,-8 Q1.4,-4 1.4,0 Q1.4,5 0,8"
            fill="none" stroke="rgba(0,0,0,0.18)" strokeWidth="1.2" strokeLinecap="round"/>
      <ellipse cx="-3" cy="-4" rx="2" ry="3"
               fill="rgba(255,255,255,0.12)" transform="rotate(-22,-3,-4)"/>
    </>
  );
}

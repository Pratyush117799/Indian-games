/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        // Earthy Tamil palette
        clay:    { DEFAULT: '#8B4513', light: '#A0522D', dark: '#5C2A00' },
        kolam:   { DEFAULT: '#DAA520', light: '#F5C842', dark: '#B8860B' },
        leaf:    { DEFAULT: '#228B22', light: '#2EA82E', dark: '#145214' },
        cream:   { DEFAULT: '#FFF8E7', dark: '#F5ECD7' },
        temple:  { DEFAULT: '#7B2D00', light: '#9C3A00' },
        snake:   '#CC0000',
        ladder:  '#006400',
      },
      fontFamily: {
        sans:  ['Inter', 'sans-serif'],
        tamil: ['Noto Sans Tamil', 'sans-serif'],
      },
      animation: {
        'kolam-draw': 'kolamDraw 2s ease-in-out',
        'dice-roll':  'diceRoll 0.6s ease-out',
        'piece-move': 'pieceMove 0.3s ease-in-out',
        'snake-drop': 'snakeDrop 0.8s ease-in',
        'ladder-up':  'ladderUp 0.8s ease-out',
      },
      keyframes: {
        kolamDraw: {
          '0%':   { strokeDashoffset: '1000' },
          '100%': { strokeDashoffset: '0' },
        },
        diceRoll: {
          '0%':   { transform: 'rotate(0deg) scale(1)' },
          '50%':  { transform: 'rotate(360deg) scale(1.2)' },
          '100%': { transform: 'rotate(720deg) scale(1)' },
        },
        pieceMove: {
          '0%':   { transform: 'scale(1)' },
          '50%':  { transform: 'scale(1.25)' },
          '100%': { transform: 'scale(1)' },
        },
        snakeDrop: {
          '0%':   { transform: 'translateY(0)' },
          '60%':  { transform: 'translateY(12px)' },
          '100%': { transform: 'translateY(0)' },
        },
        ladderUp: {
          '0%':   { transform: 'translateY(0)' },
          '60%':  { transform: 'translateY(-12px)' },
          '100%': { transform: 'translateY(0)' },
        },
      },
      boxShadow: {
        'board': '0 8px 32px rgba(139,69,19,0.25)',
        'piece': '0 4px 12px rgba(0,0,0,0.3)',
      },
    },
  },
  plugins: [],
};

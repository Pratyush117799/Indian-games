# Sanskriti — Cultural Heritage Learning Platform
## Smart India Hackathon Submission

### Live Demo Files (open in browser)
| File | Description |
|------|-------------|
| `sanskriti-pitch.html` | **START HERE** — Hackathon pitch page with all demos linked |
| `ayurveda-apothecary.html` | Ayurveda Apothecary portal |
| `guru-charaka.html` | AI Guru Charaka — ask anything about Ayurveda in 5 languages |
| `ramayana-quest.html` | Ramayana Quest — 7 Kandas, 4 characters, moral consequence engine |
| `index.html` | Krida Hub — Navakankari + Pallankuzhi ancient games |
| `parent-dashboard.html` | Parent/Teacher Sanskriti Score dashboard |
| `herb-cards.html` | Phygital printable herb cards with QR codes |

### Source Code Zips
| File | Contents |
|------|----------|
| `ayurveda-phase2.zip` | Complete Ayurveda Apothecary (React + Node.js + PostgreSQL) |
| `ramayana-quest.zip` | Complete Ramayana Quest game engine |
| `krida-project.zip` | Navakankari + Pallankuzhi with online multiplayer |

### Tech Stack
- **Frontend**: React 18 + Vite, Redux Toolkit, Web Speech API, MediaDevices API
- **Backend**: Node.js + Express + Socket.io
- **AI**: Sarvam AI (sarvam-m) primary + Anthropic Claude fallback
- **Database**: PostgreSQL with 5 migration files
- **Knowledge Base**: Charaka Samhita (8 Sthanas) + Valmiki Ramayana (24,000 shlokas)
- **Languages**: English, Hindi, Tamil, Telugu, Kannada

### The Pitch
"India's answer to Duolingo for cultural heritage — five thousand years of knowledge, gamified."

Built for Smart India Hackathon 2025

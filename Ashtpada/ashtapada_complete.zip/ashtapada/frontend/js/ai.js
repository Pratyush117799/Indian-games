'use strict';

/*
 * AIPlayer
 * Chooses a move from the engine's valid moves list.
 *
 * Beginner  — random selection
 * Prince    — greedy scoring (captures, castles, progress)
 * Maharaja  — greedy + threat avoidance (looks one step ahead)
 */
class AIPlayer {
  constructor(difficulty = 'prince') {
    this.difficulty = difficulty;
  }

  chooseMove(engine) {
    const moves = engine.validMoves;
    if (!moves || moves.length === 0) return null;

    switch (this.difficulty) {
      case 'beginner':  return this._random(moves);
      case 'maharaja':  return this._maharaja(moves, engine);
      case 'prince':
      default:          return this._greedy(moves, engine);
    }
  }

  /* ── Beginner: pure random ──────────────────────────────── */

  _random(moves) {
    return moves[Math.floor(Math.random() * moves.length)];
  }

  /* ── Prince: greedy static score ───────────────────────── */

  _greedy(moves, engine) {
    let best = moves[0], bestScore = -Infinity;
    for (const move of moves) {
      const score = this._scoreMove(move, engine);
      if (score > bestScore) { bestScore = score; best = move; }
    }
    return best;
  }

  /* ── Maharaja: greedy + avoids leaving piece vulnerable ─── */

  _maharaja(moves, engine) {
    let best = moves[0], bestScore = -Infinity;
    for (const move of moves) {
      let score = this._scoreMove(move, engine);

      /* Penalty if the destination is reachable by an opponent next turn */
      if (!CASTLE_STEPS.has(move.toStep) && move.toStep < HOME_STEP) {
        const [dr, dc] = PATH[move.toStep];
        const threat = this._isThreatenedBy(dr, dc, engine, 1 - engine.currentPlayer);
        if (threat) score -= 80;
      }

      /* Bonus for blocking opponent's path (blockade) */
      if (!CASTLE_STEPS.has(move.toStep)) {
        const sameCell = engine.pieces.filter(p =>
          p.player === engine.currentPlayer &&
          p.step >= 0 && p.step < HOME_STEP &&
          PATH[p.step][0] === PATH[move.toStep][0] &&
          PATH[p.step][1] === PATH[move.toStep][1]
        );
        if (sameCell.length >= 1) score += 60; // blockade bonus
      }

      if (score > bestScore) { bestScore = score; best = move; }
    }
    return best;
  }

  /* ── Scoring ─────────────────────────────────────────────── */

  _scoreMove(move, engine) {
    let score = 0;
    const piece = engine.pieces[move.pieceIndex];

    /* Progress: further along path = better */
    score += move.toStep * 2.5;

    /* Huge bonus for reaching home */
    if (move.toStep >= HOME_STEP) return 1000;

    /* Bonus for capturing an opponent piece */
    if (move.fromStep !== -1 && !CASTLE_STEPS.has(move.toStep)) {
      const [dr, dc] = PATH[move.toStep];
      const captures = engine.pieces.filter(p =>
        p.player !== piece.player &&
        p.step >= 0 && p.step < HOME_STEP &&
        PATH[p.step][0] === dr && PATH[p.step][1] === dc
      );
      score += captures.length * 160;
    }

    /* Bonus for landing on a castle (safety) */
    if (CASTLE_STEPS.has(move.toStep)) score += 40;

    /* Prefer moving on-board pieces over entering new ones 
       (unless all pieces are off-board) */
    const onBoard = engine.getOnBoardPieces(engine.currentPlayer);
    if (move.fromStep === -1 && onBoard.length > 0) score -= 15;

    /* Prefer moving the most advanced piece */
    if (move.fromStep > 0) score += move.fromStep * 0.5;

    return score;
  }

  _isThreatenedBy(r, c, engine, opponentPlayer) {
    const opponentPieces = engine.pieces.filter(p =>
      p.player === opponentPlayer && p.step >= 0 && p.step < HOME_STEP
    );
    /* Check if any dice roll (1–8) from an opponent piece reaches this cell */
    const diceValues = [1, 2, 3, 8];
    for (const op of opponentPieces) {
      for (const v of diceValues) {
        const toStep = Math.min(op.step + v, PATH_LENGTH - 1);
        if (toStep < HOME_STEP) {
          const [tr, tc] = PATH[toStep];
          if (tr === r && tc === c) return true;
        }
      }
    }
    return false;
  }
}

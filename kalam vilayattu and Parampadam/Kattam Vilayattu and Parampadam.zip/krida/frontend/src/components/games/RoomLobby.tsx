'use client';
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { clsx } from 'clsx';
import { Copy, CheckCheck, Send } from 'lucide-react';
import toast from 'react-hot-toast';
import { getSocket } from '@/lib/socket';
import { useGameStore } from '@/store/gameStore';
import { useAuthStore } from '@/store/authStore';
import type { GameRoom, RoomPlayer } from '@/types';

interface Props {
  room:    GameRoom;
  players: RoomPlayer[];
}

const COLOR_DOT: Record<string, string> = {
  green:  'bg-leaf',
  brown:  'bg-clay',
  red:    'bg-red-500',
  blue:   'bg-blue-500',
  yellow: 'bg-yellow-400',
  purple: 'bg-purple-500',
};

export default function RoomLobby({ room, players }: Props) {
  const { user }        = useAuthStore();
  const { chatMessages, addChatMessage } = useGameStore();
  const [copied, setCopied] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const socket     = getSocket();

  const isHost   = room.host_id === user?.id;
  const myPlayer = players.find(p => p.id === user?.id);
  const allReady = players.length >= room.max_players && players.every(p => p.is_ready);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  function copyCode() {
    navigator.clipboard.writeText(room.room_code);
    setCopied(true);
    toast.success('Room code copied!');
    setTimeout(() => setCopied(false), 2000);
  }

  function markReady() {
    socket.emit('room:ready', { roomCode: room.room_code });
  }

  function sendChat(e: React.FormEvent) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    socket.emit('room:chat', { roomCode: room.room_code, message: chatInput });
    setChatInput('');
  }

  return (
    <div className="max-w-xl mx-auto space-y-4">
      {/* Room header */}
      <div className="card space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-bold text-temple text-lg">Waiting Room</h2>
            <p className="text-xs text-gray-400">
              {room.game_slug === 'kattam-vilayattu'
                ? `Kattam Vilayattu · Level ${room.game_level}`
                : 'Paramapadam'}
            </p>
          </div>
          {/* Room code */}
          <button onClick={copyCode}
            className="flex items-center gap-2 bg-clay/10 hover:bg-clay/20 px-3 py-1.5 rounded-lg transition">
            <span className="font-mono font-bold text-clay tracking-widest text-lg">
              {room.room_code}
            </span>
            {copied ? <CheckCheck size={14} className="text-leaf" /> : <Copy size={14} className="text-clay/50" />}
          </button>
        </div>

        {/* Players */}
        <div className="space-y-2">
          {Array.from({ length: room.max_players }).map((_, si) => {
            const p = players.find(pl => pl.seat_index === si);
            return (
              <div key={si} className={clsx(
                'flex items-center justify-between px-3 py-2 rounded-lg border',
                p ? 'bg-cream border-clay/20' : 'bg-gray-50 border-gray-100 border-dashed'
              )}>
                <div className="flex items-center gap-2">
                  <span className={clsx('w-3 h-3 rounded-full', p ? COLOR_DOT[p.color] : 'bg-gray-200')} />
                  {p ? (
                    <span className="text-sm font-medium">
                      {p.username}
                      {p.id === room.host_id && <span className="ml-1 text-xs text-kolam">Host</span>}
                    </span>
                  ) : (
                    <span className="text-sm text-gray-400 italic">Waiting for player…</span>
                  )}
                </div>
                {p && (
                  <span className={clsx(
                    'badge text-xs',
                    p.is_ready ? 'bg-leaf/10 text-leaf' : 'bg-gray-100 text-gray-400'
                  )}>
                    {p.is_ready ? '✓ Ready' : 'Not ready'}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Ready button */}
        {myPlayer && !myPlayer.is_ready && (
          <button onClick={markReady} className="btn-primary w-full">
            I'm Ready →
          </button>
        )}
        {allReady && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="text-center text-sm text-leaf font-semibold">
            All players ready — starting game…
          </motion.p>
        )}
      </div>

      {/* Chat */}
      <div className="card space-y-3">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Room Chat</h3>
        <div className="h-36 overflow-y-auto space-y-1 text-sm pr-1">
          {chatMessages.length === 0 && (
            <p className="text-gray-300 text-xs italic text-center mt-8">No messages yet…</p>
          )}
          {chatMessages.map((m, i) => (
            <div key={i} className={clsx('flex gap-2', m.userId === user?.id && 'justify-end')}>
              {m.userId !== user?.id && (
                <span className="text-clay font-semibold shrink-0">{m.username}:</span>
              )}
              <span className={clsx(
                'px-2 py-0.5 rounded-lg max-w-[75%]',
                m.userId === user?.id ? 'bg-clay text-cream' : 'bg-gray-100 text-gray-700'
              )}>
                {m.message}
              </span>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <form onSubmit={sendChat} className="flex gap-2">
          <input value={chatInput} onChange={e => setChatInput(e.target.value)}
            className="input flex-1 text-sm" placeholder="Say something…" maxLength={200} />
          <button type="submit" className="btn-primary px-3 py-2">
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
}

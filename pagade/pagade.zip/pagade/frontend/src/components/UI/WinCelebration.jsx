import React, { useEffect, useRef } from 'react';
import { PLAYER_COLORS, PLAYER_NAMES } from '../../game/constants';

export default function WinCelebration({ winner, finishOrder, isTournamentMatch, onPlayAgain, onHome }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth; canvas.height = window.innerHeight;
    const W = canvas.width, H = canvas.height;
    const burst = Array.from({ length: 140 }, () => ({
      x: W/2 + (Math.random()-.5)*240, y: H*.45,
      vx: (Math.random()-.5)*10, vy: -Math.random()*14-5,
      r: 4 + Math.random()*7,
      color: [PLAYER_COLORS[winner],'#D4A017','#fff',PLAYER_COLORS[(winner+1)%4]][Math.floor(Math.random()*4)],
      rot: Math.random()*Math.PI*2, spin: (Math.random()-.5)*.35,
      life: 1, decay: .007+Math.random()*.01, rect: Math.random()>.5,
    }));
    let raf;
    function draw() {
      ctx.clearRect(0,0,W,H);
      let alive=false;
      for(const p of burst) {
        if(p.life<=0) continue; alive=true;
        p.x+=p.vx; p.y+=p.vy; p.vy+=.28; p.vx*=.99; p.rot+=p.spin; p.life-=p.decay;
        ctx.save(); ctx.globalAlpha=p.life; ctx.translate(p.x,p.y); ctx.rotate(p.rot); ctx.fillStyle=p.color;
        if(p.rect) ctx.fillRect(-p.r/2,-p.r/2,p.r,p.r*1.7);
        else { ctx.beginPath(); ctx.arc(0,0,p.r/2,0,Math.PI*2); ctx.fill(); }
        ctx.restore();
      }
      if(alive) raf=requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, [winner]);

  const color = PLAYER_COLORS[winner];
  return (
    <div className="win-overlay">
      <canvas ref={canvasRef} className="confetti-canvas" />
      <div className="win-card" style={{ borderColor: color, boxShadow: `0 0 40px ${color}33, 0 8px 40px rgba(0,0,0,.7)` }}>
        <div className="win-yantra">✦</div>
        <div className="win-color-dot" style={{ background: color, boxShadow: `0 0 24px ${color}` }} />
        <h2 className="win-title">{PLAYER_NAMES[winner]}</h2>
        <p className="win-subtitle">{isTournamentMatch ? 'MATCH WON · ROUND COMPLETE' : 'विजयी · Winner'}</p>
        {finishOrder.length > 1 && (
          <div className="finish-order">
            {finishOrder.map((pid,i)=>(
              <div key={pid} className="finish-row">
                <span className="finish-rank">{i+1}</span>
                <span className="finish-dot" style={{ background: PLAYER_COLORS[pid] }} />
                <span className="finish-name">{PLAYER_NAMES[pid]}</span>
              </div>
            ))}
          </div>
        )}
        <div className="win-actions">
          <button className="btn-primary" onClick={onPlayAgain}>
            {isTournamentMatch ? 'Next Match ▶' : '▶ Again'}
          </button>
          <button className="btn-secondary" onClick={onHome}>⌂</button>
        </div>
      </div>
    </div>
  );
}

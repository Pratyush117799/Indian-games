'use strict';

const SVG_NS = 'http://www.w3.org/2000/svg';

/*
 * BoardRenderer
 * Draws and animates the entire 8×8 Ashtapada board using SVG.
 * Stateless relative to game logic — receives data on every render call.
 */
class BoardRenderer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.svg = null;
    this.layers = {};
    this._init();
  }

  /* ── Initialise board structure (called once) ─────────────── */

  _init() {
    const svg = this._el('svg');
    svg.setAttribute('width', BOARD_PX);
    svg.setAttribute('height', BOARD_PX);
    svg.setAttribute('viewBox', `0 0 ${BOARD_PX} ${BOARD_PX}`);

    /* Layer order (bottom → top) */
    const layerNames = ['cells', 'castleMarks', 'pathNums', 'highlights', 'pieces'];
    layerNames.forEach(name => {
      const g = this._el('g');
      g.setAttribute('id', `layer-${name}`);
      svg.appendChild(g);
      this.layers[name] = g;
    });

    this._drawStaticBoard();
    this.svg = svg;
    this.container.appendChild(svg);
  }

  _drawStaticBoard() {
    /* Build a lookup: 'row,col' → path index */
    const cellPathIndex = new Map();
    PATH.forEach(([r, c], i) => cellPathIndex.set(`${r},${c}`, i));

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const key = `${r},${c}`;
        const pathIdx = cellPathIndex.get(key) ?? -1;
        const isHome = pathIdx >= HOME_STEP;
        const isCastle = pathIdx >= 0 && CASTLE_STEPS.has(pathIdx) && !isHome;

        /* ── Cell rect ── */
        const rect = this._el('rect');
        rect.setAttribute('x', c * CELL);
        rect.setAttribute('y', r * CELL);
        rect.setAttribute('width', CELL);
        rect.setAttribute('height', CELL);
        rect.setAttribute('fill', isHome ? '#F3E4B0' : '#F5EFE0');
        rect.setAttribute('stroke', '#D8CCBA');
        rect.setAttribute('stroke-width', '0.5');
        this.layers.cells.appendChild(rect);

        /* ── Castle diamond mark ── */
        if (isCastle) {
          const cx = c * CELL + CELL / 2;
          const cy = r * CELL + CELL / 2;
          const s = 7;
          const diamond = this._el('polygon');
          diamond.setAttribute('points',
            `${cx},${cy - s} ${cx + s},${cy} ${cx},${cy + s} ${cx - s},${cy}`);
          diamond.setAttribute('fill', 'none');
          diamond.setAttribute('stroke', '#C9922A');
          diamond.setAttribute('stroke-width', '1');
          diamond.setAttribute('opacity', '0.65');
          this.layers.castleMarks.appendChild(diamond);

          /* Cross lines inside diamond */
          ['v', 'h'].forEach(dir => {
            const line = this._el('line');
            if (dir === 'v') {
              line.setAttribute('x1', cx); line.setAttribute('y1', cy - s);
              line.setAttribute('x2', cx); line.setAttribute('y2', cy + s);
            } else {
              line.setAttribute('x1', cx - s); line.setAttribute('y1', cy);
              line.setAttribute('x2', cx + s); line.setAttribute('y2', cy);
            }
            line.setAttribute('stroke', '#C9922A');
            line.setAttribute('stroke-width', '0.5');
            line.setAttribute('opacity', '0.4');
            this.layers.castleMarks.appendChild(line);
          });
        }

        /* ── Home centre star ── */
        if (isHome) {
          const star = this._el('text');
          const cx = c * CELL + CELL / 2;
          const cy = r * CELL + CELL / 2;
          star.setAttribute('x', cx);
          star.setAttribute('y', cy + 5);
          star.setAttribute('text-anchor', 'middle');
          star.setAttribute('font-size', '18');
          star.setAttribute('fill', '#C9922A');
          star.setAttribute('opacity', '0.35');
          star.textContent = '✦';
          this.layers.castleMarks.appendChild(star);
        }

        /* ── Faint path step number ── */
        if (pathIdx >= 0) {
          const num = this._el('text');
          num.setAttribute('x', c * CELL + 4);
          num.setAttribute('y', r * CELL + 11);
          num.setAttribute('font-size', '7');
          num.setAttribute('fill', '#A8937E');
          num.setAttribute('opacity', '0.55');
          num.textContent = String(pathIdx + 1);
          this.layers.pathNums.appendChild(num);
        }
      }
    }
  }

  /* ── Render pieces ───────────────────────────────────────── */

  renderPieces(pieces, validMoveIndices, onClickPiece) {
    this._clearLayer('pieces');

    /* Group on-board pieces by board cell */
    const byCell = new Map();
    pieces.forEach((piece, i) => {
      if (piece.step < 0 || piece.step >= HOME_STEP) return;
      const [r, c] = PATH[piece.step];
      const key = `${r},${c}`;
      if (!byCell.has(key)) byCell.set(key, []);
      byCell.get(key).push({ globalIdx: i, piece });
    });

    byCell.forEach((group, key) => {
      const [r, c] = key.split(',').map(Number);
      const offsets = this._stackOffsets(group.length);
      const base = cellCenter(r, c);
      group.forEach(({ globalIdx, piece }, k) => {
        const isValid = validMoveIndices.includes(globalIdx);
        const ox = base.x + offsets[k].dx;
        const oy = base.y + offsets[k].dy;
        const el = this._buildPieceEl(piece, globalIdx, ox, oy, isValid, onClickPiece);
        this.layers.pieces.appendChild(el);
      });
    });

    /* Home pieces (rendered at fixed centre squares) */
    const homeByPlayer = [[], []];
    pieces.forEach((piece, i) => {
      if (piece.step >= HOME_STEP) homeByPlayer[piece.player].push({ globalIdx: i, piece });
    });
    homeByPlayer.forEach((group, player) => {
      const homePositions = [[3, 3], [3, 4], [4, 4], [4, 3]];
      group.forEach(({ globalIdx, piece }, k) => {
        const [r, c] = homePositions[k % 4];
        const { x, y } = cellCenter(r, c);
        const el = this._buildPieceEl(piece, globalIdx, x, y, false, null, true);
        this.layers.pieces.appendChild(el);
      });
    });
  }

  _buildPieceEl(piece, globalIdx, cx, cy, isValid, onClickPiece, isHome = false) {
    const pl = PLAYERS[piece.player];
    const g = this._el('g');
    g.style.cursor = isValid ? 'pointer' : 'default';
    if (isValid && onClickPiece) g.addEventListener('click', () => onClickPiece(globalIdx));

    /* Pulse ring for valid moves */
    if (isValid) {
      const ring = this._el('circle');
      ring.setAttribute('cx', cx); ring.setAttribute('cy', cy); ring.setAttribute('r', '15');
      ring.setAttribute('fill', pl.color); ring.setAttribute('opacity', '0.18');
      ring.setAttribute('class', 'piece-pulse');
      g.appendChild(ring);
    }

    /* Home badge glow */
    if (isHome) {
      const glow = this._el('circle');
      glow.setAttribute('cx', cx); glow.setAttribute('cy', cy); glow.setAttribute('r', '14');
      glow.setAttribute('fill', pl.color); glow.setAttribute('opacity', '0.12');
      g.appendChild(glow);
    }

    /* Main circle */
    const circle = this._el('circle');
    circle.setAttribute('cx', cx); circle.setAttribute('cy', cy);
    circle.setAttribute('r', isHome ? '9' : '10');
    circle.setAttribute('fill', isHome ? pl.color + 'AA' : pl.color);
    circle.setAttribute('stroke', isValid ? '#fff' : pl.colorDark);
    circle.setAttribute('stroke-width', isValid ? '2.5' : '1.5');
    g.appendChild(circle);

    /* Piece ID number */
    const label = this._el('text');
    label.setAttribute('x', cx); label.setAttribute('y', cy + 4);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('font-size', '8');
    label.setAttribute('font-weight', '700');
    label.setAttribute('fill', '#fff');
    label.textContent = String(piece.id + 1);
    g.appendChild(label);

    return g;
  }

  /* ── Highlights (valid destination cells) ────────────────── */

  showHighlights(validMoves) {
    this._clearLayer('highlights');
    validMoves.forEach(move => {
      const [r, c] = PATH[move.toStep];
      const rect = this._el('rect');
      rect.setAttribute('x', c * CELL + 3); rect.setAttribute('y', r * CELL + 3);
      rect.setAttribute('width', CELL - 6); rect.setAttribute('height', CELL - 6);
      rect.setAttribute('rx', '5');
      rect.setAttribute('fill', 'none');
      rect.setAttribute('stroke', '#1D9E75');
      rect.setAttribute('stroke-width', '2');
      rect.setAttribute('class', 'dest-highlight');
      this.layers.highlights.appendChild(rect);
    });
  }

  clearHighlights() { this._clearLayer('highlights'); }

  /* ── Step-by-step move animation ─────────────────────────── */

  async animateMove(piece, fromStep, toStep) {
    const pl = PLAYERS[piece.player];
    const startStep = fromStep === -1 ? 0 : fromStep;
    const { x: startX, y: startY } = cellCenter(...PATH[startStep]);

    /* Temporary animated ghost circle */
    const ghost = this._el('circle');
    ghost.setAttribute('r', '11');
    ghost.setAttribute('fill', pl.color);
    ghost.setAttribute('stroke', '#fff');
    ghost.setAttribute('stroke-width', '2');
    ghost.setAttribute('cx', startX);
    ghost.setAttribute('cy', startY);
    ghost.style.pointerEvents = 'none';
    this.layers.pieces.appendChild(ghost);

    /* Slide step by step */
    for (let s = startStep + 1; s <= toStep; s++) {
      const { x, y } = cellCenter(...PATH[s]);
      ghost.setAttribute('cx', x);
      ghost.setAttribute('cy', y);

      /* Flash castle cells gold as piece passes */
      if (CASTLE_STEPS.has(s)) this._flashCastle(PATH[s][0], PATH[s][1]);

      await delay(155);
    }

    ghost.remove();
  }

  _flashCastle(r, c) {
    const flash = this._el('rect');
    flash.setAttribute('x', c * CELL); flash.setAttribute('y', r * CELL);
    flash.setAttribute('width', CELL); flash.setAttribute('height', CELL);
    flash.setAttribute('fill', '#F5A940');
    flash.setAttribute('opacity', '0.35');
    flash.style.transition = 'opacity 0.4s';
    this.layers.highlights.appendChild(flash);
    setTimeout(() => { flash.style.opacity = '0'; setTimeout(() => flash.remove(), 450); }, 50);
  }

  /* ── Capture flash ───────────────────────────────────────── */

  flashCapture(r, c) {
    const flash = this._el('rect');
    flash.setAttribute('x', c * CELL); flash.setAttribute('y', r * CELL);
    flash.setAttribute('width', CELL); flash.setAttribute('height', CELL);
    flash.setAttribute('fill', '#D85A30');
    flash.setAttribute('opacity', '0.5');
    this.layers.highlights.appendChild(flash);
    setTimeout(() => { flash.style.transition = 'opacity 0.5s'; flash.style.opacity = '0'; setTimeout(() => flash.remove(), 550); }, 60);
  }

  /* ── Helpers ─────────────────────────────────────────────── */

  _el(tag) { return document.createElementNS(SVG_NS, tag); }

  _clearLayer(name) {
    const layer = this.layers[name];
    while (layer.firstChild) layer.removeChild(layer.firstChild);
  }

  _stackOffsets(count) {
    const d = 7;
    if (count === 1) return [{ dx: 0, dy: 0 }];
    if (count === 2) return [{ dx: -d, dy: 0 }, { dx: d, dy: 0 }];
    if (count === 3) return [{ dx: -d, dy: 5 }, { dx: d, dy: 5 }, { dx: 0, dy: -6 }];
    return [{ dx: -d, dy: -5 }, { dx: d, dy: -5 }, { dx: -d, dy: 5 }, { dx: d, dy: 5 }];
  }
}

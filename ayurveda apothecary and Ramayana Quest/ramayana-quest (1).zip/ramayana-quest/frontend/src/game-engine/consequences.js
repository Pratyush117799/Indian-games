/**
 * consequences.js — Moral consequence ripple system
 * Every choice_id unlocks different dialogue / outcomes in future Kandas.
 */
export const CONSEQUENCES = {
  noble_departure: {
    desc: 'You accepted exile without protest — Dasharatha died in peace',
    appearsIn: ['ayodhya', 'yuddha'],
    effect: 'Bharata\'s guilt makes him a powerful ally. His army stands ready in Ayodhya throughout the war.',
    sanskritiBonus: 5,
  },
  lakshmana_bond: {
    desc: 'Insisting Lakshmana come forged an unbreakable partnership',
    appearsIn: ['aranya', 'kishkindha', 'yuddha'],
    effect: 'Lakshmana defeats Indrajit in the critical moment of the final battle.',
    sanskritiBonus: 4,
  },
  divine_weapons: {
    desc: 'You asked Vishwamitra to teach you before leaving — weapons learned',
    appearsIn: ['aranya', 'yuddha'],
    effect: 'One additional Brahmastra invocation available in the final battle.',
    sanskritiBonus: 6,
  },
  rekha_drawn: {
    desc: 'Lakshmana drew the protective line before going',
    appearsIn: ['kishkindha', 'yuddha'],
    effect: 'The Lakshmana Rekha as metaphor enters the cultural conversation — Ravana\'s violation of it marks him as adharmic.',
    sanskritiBonus: 8,
  },
  loyalty_tested: {
    desc: 'You went immediately when Rama called — even at risk',
    appearsIn: ['kishkindha'],
    effect: 'Lakshmana\'s devotion is proven to all, including the doubting vanaras. Trust comes instantly.',
    sanskritiBonus: 4,
  },
  angada_diplomat: {
    desc: 'Vali died gracefully — his son Angada became a key diplomat',
    appearsIn: ['yuddha'],
    effect: 'Angada\'s embassy gives you crucial intelligence about Lanka\'s readiness before war begins.',
    sanskritiBonus: 7,
  },
  greater_good: {
    desc: 'You acknowledged the larger purpose behind the difficult choice',
    appearsIn: ['sundara', 'yuddha'],
    effect: 'The vanara army understands that sometimes righteousness requires difficult strategy.',
    sanskritiBonus: 5,
  },
  honest_admission: {
    desc: 'You admitted moral imperfection to Vali — and earned forgiveness',
    appearsIn: ['yuddha'],
    effect: 'Your honesty about moral complexity becomes the teaching: even great beings make imperfect choices.',
    sanskritiBonus: 8,
  },
  message_delivered: {
    desc: 'Sita\'s message through her crest jewel galvanised the army',
    appearsIn: ['yuddha'],
    effect: 'The vanara army fights with extraordinary conviction. Morale never breaks.',
    sanskritiBonus: 6,
  },
  sita_agency: {
    desc: 'You respected Sita\'s choice to wait for Rama himself',
    appearsIn: ['yuddha'],
    effect: 'Sita\'s refusal of rescue defines her character: she will not be saved — she will be liberated.',
    sanskritiBonus: 8,
  },
  vibhishana_king: {
    desc: 'You welcomed Vibhishana without hesitation',
    appearsIn: ['yuddha'],
    effect: 'Vibhishana reveals the secret of Ravana\'s navel — the amrita (immortality nectar). Victory becomes possible.',
    sanskritiBonus: 10,
  },
  vibhishana_tested: {
    desc: 'You asked Vibhishana to prove himself before full trust',
    appearsIn: ['yuddha'],
    effect: 'Vibhishana passes the test quickly. But the conditional trust shows dharma without full mercy has limits.',
    sanskritiBonus: 5,
  },
};

export function getActiveConsequences(consequenceIds) {
  return consequenceIds.map(id => CONSEQUENCES[id]).filter(Boolean);
}

export function getConsequencesForKanda(consequenceIds, kandaId) {
  return consequenceIds
    .map(id => CONSEQUENCES[id])
    .filter(c => c?.appearsIn?.includes(kandaId));
}

export function totalBonusSanskriti(consequenceIds) {
  return consequenceIds.reduce((sum, id) => sum + (CONSEQUENCES[id]?.sanskritiBonus ?? 0), 0);
}

export default CONSEQUENCES;

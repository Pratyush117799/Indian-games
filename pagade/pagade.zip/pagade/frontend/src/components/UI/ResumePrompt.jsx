import React from 'react';
import { PLAYER_COLORS, PLAYER_NAMES } from '../../game/constants';

export default function ResumePrompt({ saveInfo, onResume, onDiscard }) {
  if (!saveInfo) return null;

  const { mode, savedAt, players, currentPlayer } = saveInfo;
  const modeLabel = { solo_ai: 'Solo vs AI', pass_play: 'Pass & Play', tournament: 'Tournament' }[mode] || mode;
  const timeAgo = formatTimeAgo(savedAt);

  return (
    <div style={{
      position: 'absolute',
      bottom: 24,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 50,
      background: '#2c1a0e',
      border: '1px solid rgba(139,105,20,0.4)',
      borderRadius: 14,
      padding: '14px 18px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      minWidth: 260,
      boxShadow: '0 8px 32px rgba(0,0,0,0.6)',
      animation: 'fadeUp .4s ease',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: '1rem' }}>💾</span>
        <div>
          <div style={{ fontSize: '.78rem', fontWeight: 500, color: '#F5EAD0' }}>{modeLabel}</div>
          <div style={{ fontSize: '.66rem', color: '#7a5c3a', marginTop: 1 }}>{timeAgo}</div>
        </div>
      </div>

      {/* Player progress pips */}
      <div style={{ display: 'flex', gap: 8 }}>
        {players.map((p, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{
              width: 8, height: 8, borderRadius: '50%',
              background: PLAYER_COLORS[i],
              display: 'inline-block',
              boxShadow: currentPlayer === i ? `0 0 6px ${PLAYER_COLORS[i]}` : 'none',
            }} />
            <span style={{ fontSize: '.65rem', color: '#C8A96A' }}>{p.homePawnCount}/4</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <button
          onClick={onResume}
          style={{
            flex: 1, padding: '8px 0', borderRadius: 8,
            border: '1px solid #D4A017',
            background: 'linear-gradient(135deg,#5a3820,#3d2410)',
            color: '#F0C84A', fontSize: '.8rem', cursor: 'pointer',
          }}
        >▶ Resume</button>
        <button
          onClick={onDiscard}
          style={{
            padding: '8px 12px', borderRadius: 8,
            border: '1px solid rgba(139,105,20,.25)',
            background: 'transparent', color: '#7a5c3a', fontSize: '.8rem', cursor: 'pointer',
          }}
        >✕</button>
      </div>
    </div>
  );
}

function formatTimeAgo(date) {
  if (!date) return '';
  const secs = Math.round((Date.now() - date.getTime()) / 1000);
  if (secs < 60)  return 'just now';
  if (secs < 3600) return `${Math.round(secs/60)}m ago`;
  if (secs < 86400) return `${Math.round(secs/3600)}h ago`;
  return `${Math.round(secs/86400)}d ago`;
}

/**
 * bazaarRoom.js — Live herb trading marketplace via Socket.io
 */
export const initBazaarSocket = (io) => {
  const bazaar = io.of('/bazaar');

  bazaar.on('connection', (socket) => {
    socket.on('bazaar:list',    (data) => bazaar.emit('bazaar:update', data));
    socket.on('bazaar:trade',   (data) => bazaar.to(data.sellerId).emit('bazaar:sold', data));
    socket.on('bazaar:join',    ()      => { socket.join('traders'); });
    socket.on('disconnect',     ()      => { /* clean up */ });
  });
};

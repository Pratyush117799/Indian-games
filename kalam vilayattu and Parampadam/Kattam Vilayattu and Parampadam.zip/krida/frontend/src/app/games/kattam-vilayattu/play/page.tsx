'use client';
import { useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import toast from 'react-hot-toast';
import { useAuthStore } from '@/store/authStore';
import { useGameStore } from '@/store/gameStore';
import { getSocket, connectSocket } from '@/lib/socket';
import api from '@/lib/api';
import KattamBoard  from '@/components/games/kattam/KattamBoard';
import RoomLobby   from '@/components/games/RoomLobby';
import type { KattamState } from '@/types';

export default function KattamGamePage() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const roomCode     = searchParams.get('room');
  const { user, accessToken } = useAuthStore();
  const {
    room, players, gameSlug, kattamState,
    setRoom, setPlayers, setGameStarted, setKattamState, addChatMessage, reset,
  } = useGameStore();

  // Auth guard
  useEffect(() => {
    if (!user) router.replace('/auth/login');
  }, [user]);

  // Setup: join room + socket events
  useEffect(() => {
    if (!roomCode || !user || !accessToken) return;
    const socket = connectSocket(accessToken);

    // Fetch initial room state
    api.get(`/rooms/${roomCode}`).then(({ data }) => {
      setRoom(data.room, data.players);
      socket.emit('room:join', { roomCode });
    }).catch(() => {
      toast.error('Room not found'); router.push('/games/kattam-vilayattu');
    });

    // Socket event handlers
    socket.on('room:state',        ({ room, players })          => { setRoom(room, players); setPlayers(players); });
    socket.on('room:player_joined',({ username })               => toast(`${username} joined the room`));
    socket.on('room:player_left',  ({ username })               => toast.error(`${username} left`));
    socket.on('room:abandoned',    ({ message })                => { toast.error(message); reset(); router.push('/games/kattam-vilayattu'); });
    socket.on('room:message',      (msg)                        => addChatMessage(msg));
    socket.on('room:start',        ({ gameSlug, state, players }) => { setGameStarted(gameSlug, state); setPlayers(players); });
    socket.on('kattam:state',      ({ state })                  => setKattamState(state as KattamState));
    socket.on('kattam:win',        ({ winnerId, state })        => {
      setKattamState(state);
      const winner = players.find(p => p.id === winnerId);
      toast.success(`${winner?.username || 'Player'} wins! 🎉`, { duration: 5000 });
    });
    socket.on('kattam:error',      ({ message })                => toast.error(message));

    return () => {
      socket.off('room:state'); socket.off('room:player_joined'); socket.off('room:player_left');
      socket.off('room:abandoned'); socket.off('room:message'); socket.off('room:start');
      socket.off('kattam:state'); socket.off('kattam:win'); socket.off('kattam:error');
      socket.emit('room:leave', { roomCode });
      reset();
    };
  }, [roomCode, user, accessToken]);

  const playerMap = Object.fromEntries(
    players.map(p => [p.id, { username: p.username, color: p.color }])
  );

  const handlePlace = useCallback((cellIndex: number) => {
    getSocket().emit('kattam:place', { roomCode, cellIndex });
  }, [roomCode]);

  const handleMove = useCallback((fromIndex: number, toIndex: number) => {
    getSocket().emit('kattam:move', { roomCode, fromIndex, toIndex });
  }, [roomCode]);

  if (!room) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="text-clay animate-pulse text-sm">Connecting to room…</div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-temple">Kattam Vilayattu</h1>
        <p className="text-sm text-gray-400 font-tamil">கட்டம் விளையாட்டு · Level {room.game_level}</p>
      </div>

      {gameSlug !== 'kattam-vilayattu' || !kattamState ? (
        <RoomLobby room={room} players={players} />
      ) : (
        <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">
          <KattamBoard
            state={kattamState}
            myPlayerId={user!.id}
            playerMap={playerMap}
            onPlace={handlePlace}
            onMove={handleMove}
          />
          {/* Sidebar: players + phase info */}
          <div className="space-y-4 min-w-[200px]">
            <div className="card space-y-2">
              <h3 className="text-xs font-semibold text-gray-400 uppercase">Players</h3>
              {players.map((p, i) => (
                <div key={p.id} className="flex items-center gap-2 text-sm">
                  <span className={`w-3 h-3 rounded-full ${p.color === 'green' ? 'bg-leaf' : 'bg-clay'}`} />
                  <span className="font-medium">{p.username}</span>
                  {kattamState.players[kattamState.currentPlayerIndex] === p.id && !kattamState.winner && (
                    <span className="ml-auto text-xs text-kolam animate-pulse">●</span>
                  )}
                </div>
              ))}
            </div>
            <div className="card text-xs text-gray-500 space-y-1">
              <p><strong>Phase:</strong> {kattamState.phase}</p>
              <p><strong>Moves:</strong> {kattamState.moveCount}</p>
              <p><strong>Grid:</strong> {kattamState.size}×{kattamState.size}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * auth.js
 * localStorage-based player identity system.
 * No backend required. Profiles persist in the browser.
 *
 * Player object shape:
 * {
 *   id:          string  (UUID-ish),
 *   name:        string,
 *   clan:        string,
 *   createdAt:   ISO string,
 *   legacyScore: number,    // all-time accumulation, never resets
 *   titles:      string[],  // earned titles
 *   gamesPlayed: number,
 *   gamesWon:    number,
 *   saves:       SaveSlot[3],
 * }
 *
 * SaveSlot:
 * {
 *   label:    string,   // e.g. "Turn 14 — Magadha Expansion"
 *   turn:     number,
 *   year:     number,
 *   state:    object,   // full game state snapshot
 *   savedAt:  ISO string,
 *   territories: object,
 *   researched:  string[],
 * }
 */

const STORAGE_KEY   = 'arthashastra_player';
const GUEST_KEY     = 'arthashastra_guest';
const MAX_SAVE_SLOTS = 3;

/* ═══════════════════════════════════════════════════════
   TITLE SYSTEM
   Titles are earned by legacy score thresholds.
   Once earned they are never lost.
═══════════════════════════════════════════════════════ */
export const TITLES = [
  { id: 'mantri',       label: 'Mantri',            threshold: 0,    desc: 'Advisor to the throne. Your journey begins.' },
  { id: 'raja',         label: 'Raja',               threshold: 200,  desc: 'King of a single realm. Earned by first campaign.' },
  { id: 'maharaja',     label: 'Maharaja',           threshold: 500,  desc: 'Great King. Three campaigns, growing power.' },
  { id: 'samrat',       label: 'Samrat',             threshold: 1000, desc: 'Emperor. United half the subcontinent.' },
  { id: 'chakravarti',  label: 'Chakravarti Samrat', threshold: 2000, desc: 'Wheel-turner. Supreme sovereign of Bharatvarsha.' },
  { id: 'dharmaraja',   label: 'Dharmaraja',         threshold: 3000, desc: 'Righteous King. High legacy score with dharma above 70.' },
];

export function getCurrentTitle(player) {
  if (!player) return TITLES[0];
  const earned = TITLES.filter(t => player.legacyScore >= t.threshold);
  return earned[earned.length - 1] || TITLES[0];
}

export function checkNewTitles(player) {
  const newTitles = TITLES
    .filter(t => player.legacyScore >= t.threshold && !player.titles.includes(t.id))
    .map(t => t.id);
  if (newTitles.length > 0) {
    player.titles.push(...newTitles);
    save(player);
  }
  return newTitles.map(id => TITLES.find(t => t.id === id));
}

/* ═══════════════════════════════════════════════════════
   LEGACY SCORE CALCULATION
   Called at the end of each campaign.
═══════════════════════════════════════════════════════ */
export function calculateLegacyScore({ territoriesOwned, totalTerritories, dharma, turns, researched }) {
  const expansionScore = Math.round((territoriesOwned / totalTerritories) * 1000);
  const dharmaBonus    = dharma > 70 ? 300 : dharma > 50 ? 150 : 0;
  const speedBonus     = turns < 20 ? 200 : turns < 35 ? 100 : 0;
  const researchBonus  = researched * 40;
  return expansionScore + dharmaBonus + speedBonus + researchBonus;
}

/* ═══════════════════════════════════════════════════════
   PLAYER CRUD
═══════════════════════════════════════════════════════ */

function generateId() {
  return Math.random().toString(36).slice(2, 10).toUpperCase();
}

export function createPlayer(name, clan) {
  const player = {
    id:          generateId(),
    name:        name.trim() || 'Samrat',
    clan:        clan.trim() || 'House of Magadha',
    createdAt:   new Date().toISOString(),
    legacyScore: 0,
    titles:      ['mantri'],
    gamesPlayed: 0,
    gamesWon:    0,
    saves:       [null, null, null],
  };
  save(player);
  return player;
}

export function getPlayer() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function save(player) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(player));
  } catch (e) {
    console.warn('[auth] Could not save player:', e.message);
  }
}

export function deletePlayer() {
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(GUEST_KEY);
}

/* ─── Guest session ──────────────────────────────────── */
export function getOrCreateGuest() {
  try {
    const raw = localStorage.getItem(GUEST_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  const guest = createGuestProfile();
  localStorage.setItem(GUEST_KEY, JSON.stringify(guest));
  return guest;
}

function createGuestProfile() {
  return {
    id:          'GUEST-' + generateId(),
    name:        'Guest Samrat',
    clan:        'Wandering Clan',
    createdAt:   new Date().toISOString(),
    legacyScore: 0,
    titles:      ['mantri'],
    gamesPlayed: 0,
    gamesWon:    0,
    saves:       [null, null, null],
    isGuest:     true,
  };
}

export function promoteGuestToPlayer(guest, name, clan) {
  const player = {
    ...guest,
    id:      generateId(),
    name:    name.trim() || guest.name,
    clan:    clan.trim() || guest.clan,
    isGuest: false,
  };
  delete player.isGuest;
  save(player);
  localStorage.removeItem(GUEST_KEY);
  return player;
}

/* ═══════════════════════════════════════════════════════
   SAVE SLOTS
═══════════════════════════════════════════════════════ */
export function saveGame(player, slotIndex, gameState, territories, researched) {
  if (slotIndex < 0 || slotIndex >= MAX_SAVE_SLOTS) return;
  player.saves[slotIndex] = {
    label:       `Turn ${gameState.turn} — ${gameState.year} BCE`,
    turn:        gameState.turn,
    year:        gameState.year,
    state:       { ...gameState, researched: undefined }, // researched stored separately
    territories: territories.map(t => ({ id: t.id, owner: t.owner, strength: t.strength, wealth: t.wealth })),
    researched:  [...researched],
    savedAt:     new Date().toISOString(),
  };
  save(player);
}

export function loadSave(player, slotIndex) {
  const slot = player?.saves?.[slotIndex];
  if (!slot) return null;
  return {
    state:       slot.state,
    territories: slot.territories,
    researched:  new Set(slot.researched),
    turn:        slot.turn,
    year:        slot.year,
  };
}

export function deleteSave(player, slotIndex) {
  player.saves[slotIndex] = null;
  save(player);
}

/* ═══════════════════════════════════════════════════════
   CAMPAIGN COMPLETION
   Called when a campaign ends (win or loss).
═══════════════════════════════════════════════════════ */
export function recordCampaignEnd(player, { won, legacyPoints }) {
  player.gamesPlayed++;
  if (won) player.gamesWon++;
  player.legacyScore += legacyPoints;

  // Check for new titles
  const newTitles = checkNewTitles(player);
  save(player);
  return newTitles;
}

import React from 'react';
import { PLAYER_COLORS, PLAYER_COLORS_LIGHT, STATUS } from '../../game/constants';

export default function PlayerPanel({ player, isActive, isAi }) {
  const homeCount = player.pawns.filter(p => p.status === STATUS.HOME).length;
  const activeCount = player.pawns.filter(p => p.status === STATUS.ACTIVE || p.status === STATUS.SAFE).length;
  const bellyCount = player.pawns.filter(p => p.status === STATUS.BELLY).length;
  const color = PLAYER_COLORS[player.id];
  const colorLight = PLAYER_COLORS_LIGHT[player.id];

  return (
    <div
      className={`player-panel ${isActive ? 'active' : ''}`}
      style={{
        '--player-color': color,
        '--player-light': colorLight,
        borderColor: isActive ? color : 'transparent',
      }}
    >
      {/* Color dot + name */}
      <div className="panel-header">
        <span className="color-dot" style={{ background: color }} />
        <span className="player-name">{player.name}</span>
        {isAi && <span className="ai-badge">AI</span>}
        {isActive && <span className="active-indicator">▶</span>}
      </div>

      {/* Pawn progress pips */}
      <div className="pawn-pips">
        {player.pawns.map((pawn, i) => (
          <PawnPip key={i} status={pawn.status} color={color} />
        ))}
      </div>

      {/* Home progress bar */}
      <div className="home-bar-track">
        <div
          className="home-bar-fill"
          style={{ width: `${(homeCount / 4) * 100}%`, background: color }}
        />
      </div>
    </div>
  );
}

function PawnPip({ status, color }) {
  const fills = {
    HOME:   color,
    SAFE:   color,
    ACTIVE: 'transparent',
    BELLY:  '#3a2a1a',
  };
  const borders = {
    HOME:   color,
    SAFE:   color,
    ACTIVE: color,
    BELLY:  '#5a4030',
  };

  return (
    <div
      className="pawn-pip"
      style={{
        background: fills[status],
        borderColor: borders[status],
        boxShadow: status === 'HOME' ? `0 0 5px ${color}` : undefined,
      }}
    />
  );
}

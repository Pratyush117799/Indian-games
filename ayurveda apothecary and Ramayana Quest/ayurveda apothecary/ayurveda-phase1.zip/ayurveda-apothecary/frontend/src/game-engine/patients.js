/**
 * patients.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Patient quest story engine for Ayurveda Apothecary.
 *
 * Each patient is a story encounter with:
 *   - Rich biographical context (who they are, why they came)
 *   - Symptoms that map to a dosha imbalance
 *   - A correct herbal remedy (recipe ID)
 *   - Branching dialogue based on what you prescribe
 *   - Moral choices that affect the story outcome
 *   - An illustrated scene description for the UI artist
 *   - Educational facts woven into the resolution
 *
 * The patient queue is weighted by:
 *   - Current season (seasonal ailments appear more)
 *   - Player's unlocked recipes
 *   - Story progression (some patients unlock only after others)
 */

import { getDoshaForPatient }          from './doshas.js';
import { suggestRecipesForSymptoms }   from './crafting.js';
import { getCurrentSeason }            from './seasons.js';

/* ── PATIENT DATABASE (30 patients) ───────────────────────────────────────── */

export const PATIENTS = [

  /* ═══ LEVEL 1 PATIENTS — Tutorial tier ════════════════════════════════════ */

  {
    id:           'raju_farmer',
    name:         'Raju',
    title:        'A young rice farmer',
    age:          28,
    location:     'Godavari delta, Andhra Pradesh',
    unlockLevel:  1,
    season:       null,          // appears any season
    artDescription: 'A lean, sun-darkened young man in a dhoti. Mud on his feet. Worried expression.',
    arrivalStory: `
      Raju walks in just after sunrise, shoes in hand to respect the apothecary floor.
      He works knee-deep in paddy fields from dawn to dusk. For three weeks, he has
      had a gnawing pain in his stomach after meals — as if a fire has been lit inside.
      His wife sent him because he has become too short-tempered with their children.
    `,
    symptoms: ['acid reflux', 'burning sensation', 'anger', 'irritability', 'skin redness'],
    doshaImbalance: 'pitta',
    urgency: 'moderate',

    dialogue: {
      greeting: '"Namaste Vaidyaji. I am sorry to take your time. My wife said I must come."',
      complaint: '"The burning starts one hour after eating. And last week I shouted at my little daughter for nothing. I am not this person. What is wrong with me?"',
      doshaReveal: '"Pitta? The fire element? I do work in the midday sun for six hours..."',
      healingQuestion: '"Will the remedy take long to work? I cannot miss the harvest season."',
    },

    correctRecipe: 'sitopaladi_churna',
    alternateRecipes: ['tulsi_kwatha', 'amla_swarasa'],

    moralChoice: {
      question: 'Raju tells you he cannot afford the herbs for the full recipe. What do you do?',
      options: [
        {
          label: 'Give him herbs from your own garden at no cost',
          outcome: 'generosity',
          effect: '+15 Dharma points. Raju returns next season with a gift of rice.',
          moralLesson: 'Ayurveda teaches that a true Vaidya never turns away a patient due to poverty.',
        },
        {
          label: 'Suggest simpler home remedies using kitchen ingredients',
          outcome: 'pragmatic',
          effect: '+10 Dharma, +5 Wisdom. Raju heals more slowly but learns self-care.',
          moralLesson: 'The best medicine is accessible to all — Ayurveda celebrates kitchen medicine.',
        },
        {
          label: 'Offer the full recipe at a later date when he can pay',
          outcome: 'business',
          effect: 'Raju grateful but heals slowly. You receive payment next month.',
          moralLesson: 'Commerce has its place, but the Vaidya\'s duty (Dharma) comes first.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Two weeks later, Raju sends his wife with a note: "The burning is gone. I played with
        my daughter yesterday — really played, not just watched. My wife says I smell like
        sandalwood now. Is that normal?" You smile. The remedies are working.
      `,
      partial: `
        Raju reports some improvement but the anger remains. The physical symptoms improved
        but the pitta in his mind needs more work. You recommend morning walks near water
        and cutting out spicy chutneys.
      `,
      failure: `
        Raju chose to not follow the dosage properly. He returns a month later, the same.
        You take more time to explain WHY each herb and each timing matters. Second attempt.
      `,
    },

    herbFacts: [
      { herb: 'amla', fact: 'Amla naturally reduces stomach acid by coating the mucous lining. Ancient texts describe it as "the enemy of burning."' },
      { herb: 'coriander', fact: 'Fresh coriander juice is one of the fastest-acting Pitta coolants. It works within 20 minutes!' },
    ],
    xpReward:  50,
    sanskritiPoints: 10,
  },

  {
    id:          'priya_student',
    name:        'Priya',
    title:       'A 14-year-old school student',
    age:         14,
    location:    'Chennai',
    unlockLevel: 1,
    season:      null,
    artDescription: 'A girl in school uniform with a heavy bag. Nervous fingers. Dark circles under eyes.',
    arrivalStory: `
      Priya is brought by her mother, who does the talking at first. Priya has examinations
      in three weeks. She cannot sleep. She forgets things she just read. She gets headaches
      behind her eyes in the afternoon. She has stopped eating lunch.
    `,
    symptoms: ['insomnia', 'forgetfulness', 'anxiety', 'worry', 'headache', 'poor appetite'],
    doshaImbalance: 'vata',
    urgency: 'high',

    dialogue: {
      greeting: '"My mother said you would help. But I don\'t think herbs work for exams." (with a small smile)',
      complaint: '"I study until midnight but by morning I\'ve forgotten everything. And I keep thinking: what if I fail? What if I disappoint everyone?"',
      doshaReveal: '"So it\'s the air element making me scattered? Like how wind never settles?"',
      healingQuestion: '"Can I still take my usual coffee? My friends say it helps them study."',
    },

    correctRecipe: 'brahmi_churna',
    alternateRecipes: ['ashwagandha_churna', 'brahma_rasayana'],

    moralChoice: {
      question: 'Priya\'s mother wants you to give Priya something to make her study 14 hours a day without rest. What do you do?',
      options: [
        {
          label: 'Gently explain that Ayurveda values rest as much as study',
          outcome: 'wisdom',
          effect: '+20 Wisdom. The mother is upset but Priya heals completely.',
          moralLesson: 'A Vaidya must sometimes prescribe rest against a patient\'s own demands.',
        },
        {
          label: 'Give Brahmi but also prescribe a structured sleep routine',
          outcome: 'balance',
          effect: '+15 Wisdom, +10 Dharma. Best outcome — both mother and Priya are helped.',
          moralLesson: 'Balance: treat the body with herbs AND treat the mind with wisdom.',
        },
        {
          label: 'Give whatever the mother asks — she knows her child best',
          outcome: 'compliance',
          effect: 'Priya gets more tired. Returns next month with burnout.',
          moralLesson: 'A good Vaidya guides with knowledge, not just compliance.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Priya returns three weeks later, on the day her results arrive. She passed — not
        perfectly, but well enough to continue to the next class. She says: "The herb milk
        tasted horrible but Amma says I've been sleeping properly for the first time in months.
        Also, can I have some for my friend Keerthi? She has exams next month."
      `,
      partial: `
        Priya improved but the exam anxiety remains. You recommend a short Pranayama practice
        — 5 minutes of alternate nostril breathing before sleep. The herbs help the body;
        breathing helps the mind.
      `,
      failure: `
        Priya stopped taking the herbs after 3 days because of the bitter taste. You make
        a sweeter version with honey and cardamom. Children's medicine must be palatable.
      `,
    },

    herbFacts: [
      { herb: 'brahmi', fact: 'Research confirms Brahmi improves information retention by 33% after 12 weeks. Ancient Indian students had this figured out millennia ago!' },
      { herb: 'shankhpushpi', fact: 'Shankhpushpi\'s flower looks like a conch shell — the instrument that signals the start of a sacred ritual. And it signals the start of clear thinking!' },
    ],
    xpReward:  60,
    sanskritiPoints: 15,
  },

  {
    id:          'meena_grandmother',
    name:        'Meena Ammachi',
    title:       'An 72-year-old grandmother',
    age:         72,
    location:    'Thrissur, Kerala',
    unlockLevel: 1,
    season:      null,
    artDescription: 'A stout, silver-haired woman in a white cotton sari. Moves slowly. Eyes bright with wisdom. Carries a brass lunchbox.',
    arrivalStory: `
      Meena Ammachi comes alone on the bus, bringing a tiffin of homemade idlis
      "because she doesn't know how young Vaidyas eat these days." She has had
      stiff joints every morning for 15 years. It takes her one hour to "get started"
      in the morning. Her hands have cracked, dry skin. She is tired all the time
      but cannot sleep past 4am.
    `,
    symptoms: ['joint stiffness', 'dry skin', 'fatigue', 'constipation', 'insomnia', 'cold hands', 'cracking joints'],
    doshaImbalance: 'vata',
    urgency: 'low',

    dialogue: {
      greeting: '"Here, eat this first. A good Vaidya needs energy to heal others. My son sent me but I was happy to come anyway."',
      complaint: '"Every morning, I need fifteen minutes just to open my fists. See these hands? Dry like the month of May. And I go to the bathroom only every two days."',
      doshaReveal: '"Vata! My grandmother used to say I had "too much air." I thought she was just telling me to eat more!"',
      healingQuestion: '"Can I still have my morning coffee? It is the only thing I look forward to. Don\'t say no."',
    },

    correctRecipe: 'ashwagandha_churna',
    alternateRecipes: ['ksheerabala_taila', 'dashamoola_kwatha'],

    moralChoice: {
      question: 'Meena Ammachi says she cannot afford the full Ksheerabala Taila massage because it requires daily oil — expensive for a widow on a pension.',
      options: [
        {
          label: 'Teach her simple sesame oil self-massage — a free daily practice',
          outcome: 'empowerment',
          effect: '+20 Dharma. Meena becomes your most enthusiastic word-of-mouth patient.',
          moralLesson: 'The greatest gift is knowledge — not medicine. Self-care is the highest prescription.',
        },
        {
          label: 'Give her enough herbal oil from your apothecary for one month',
          outcome: 'generosity',
          effect: '+15 Dharma. Meena cries with gratitude. She brings patients to you for years.',
          moralLesson: 'Older patients who have given their lives to family deserve community care.',
        },
        {
          label: 'Suggest a simpler, cheaper dietary modification instead',
          outcome: 'practical',
          effect: '+10 Wisdom. Meena improves moderately. Good for limited resources.',
          moralLesson: 'Accessible medicine reaches more people than perfect but unaffordable medicine.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Three months later, Meena Ammachi arrives unannounced at 8am with her
        daughter-in-law. "I wake at 5am now and do MY OWN yoga before the rest of the
        house wakes. Show them your hands, Ammachi." Her daughter-in-law gently opens
        Meena's hands — smooth, oiled, flexible. The tiffin she brings today has
        payasam (kheer) made from ashwagandha milk. "I made it for all of you."
      `,
      partial: `
        The joint stiffness improved by 60%. But the constipation persists. You add Triphala
        Churna at bedtime — the missing piece. Digestion affects every part of Vata's territory.
      `,
      failure: `
        Meena forgot to do the oil massage. "Busy with grandchildren." You explain: 15 minutes
        of Abhyanga is medicine. It is not luxury. You help her build it into her morning routine.
      `,
    },

    herbFacts: [
      { herb: 'ashwagandha', fact: 'Ashwagandha rebuilds nerve sheaths — the protective coating around nerves — which naturally thin with age. It\'s the original anti-aging nerve supplement!' },
      { herb: 'triphala', fact: 'Triphala\'s laxative effect is gentle — it works not by irritation but by lubricating and toning the colon. Unlike chemical laxatives, it can be taken every night for life!' },
    ],
    xpReward:  55,
    sanskritiPoints: 12,
  },

  /* ═══ LEVEL 2 PATIENTS ═════════════════════════════════════════════════════ */

  {
    id:          'arjun_wrestler',
    name:        'Arjun Singh',
    title:       'A 19-year-old wrestler (Pehlwan)',
    age:         19,
    location:    'Varanasi',
    unlockLevel: 2,
    season:      null,
    artDescription: 'A broad-shouldered young man. Thick neck. Holds his right shoulder carefully. Pride and pain in equal measure.',
    arrivalStory: `
      Arjun has been training at the famous Tulsi Ghat akhara (wrestling gymnasium)
      since age 8. He is being considered for the national competition but suffered
      a shoulder injury two months ago. Despite training through the pain, it has
      not healed. He has burning sensation in the joint, swelling, and red hot skin
      over the injury. The pain is worst at midday.
    `,
    symptoms: ['inflammation', 'burning sensation', 'swelling', 'skin redness', 'joint pain', 'fever in joint'],
    doshaImbalance: 'pitta',
    urgency: 'high',

    dialogue: {
      greeting: '"I don\'t believe in herbs. My coach sent me because he ran out of options."',
      complaint: '"I have been icing it every day. The ice reduces the swelling for one hour then it comes back. My coach says it looks infected but it is not infected."',
      doshaReveal: '"You are saying the ice is wrong? Ice reduces inflammation — every sports doctor says this."',
      healingQuestion: '"If I stop training for two weeks, I lose my position on the team. Can you make me heal in one week?"',
    },

    correctRecipe: 'chandan_lepa',
    alternateRecipes: ['turmeric_lepa', 'neem_taila'],

    moralChoice: {
      question: 'Arjun refuses to rest. His dream of competing nationally could be lost. But continuing will worsen the injury. What do you prescribe?',
      options: [
        {
          label: 'Firmly advise complete rest — the injury needs it to heal',
          outcome: 'truth',
          effect: '+20 Courage. Arjun is angry at first but returns healed and grateful.',
          moralLesson: 'Sometimes the most healing prescription is an uncomfortable truth.',
        },
        {
          label: 'Design a partial rest programme that protects the shoulder',
          outcome: 'compromise',
          effect: '+15 Wisdom. Arjun heals in three weeks. Slower but achievable.',
          moralLesson: 'A Vaidya meets the patient where they are, while guiding toward health.',
        },
        {
          label: 'Give stronger remedies so he can continue training',
          outcome: 'patient_choice',
          effect: 'Arjun trains, the injury worsens. Comes back with a torn ligament.',
          moralLesson: 'Suppressing symptoms with medicine while ignoring the cause is against Ayurvedic principles.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Arjun competes three months later. He wins his regional bout — not the national one,
        but that comes a year later after he follows your protocols throughout his training.
        He sends you a photograph from the competition. On the back: "My guru at the akhara
        heals my technique. You healed my body. Pranam."
      `,
      partial: `
        Arjun healed 70% and competed despite your advice. He performed well but noticed
        the remaining weakness. He now follows the full protocol. He learned by experiencing
        the consequence — sometimes the best teacher.
      `,
      failure: `
        Arjun did not apply the lepa consistently. "It was messy." You make an easier
        application method — a cloth bandage pre-soaked in the herbal preparation. Make
        medicine convenient for the patient to actually use.
      `,
    },

    herbFacts: [
      { herb: 'chandan', fact: 'Sandalwood reduces the temperature of inflamed tissue by 2–3 degrees — measurable! Ancient Ayurvedic surgeons applied sandalwood paste after procedures instead of ice.' },
      { herb: 'turmeric', fact: 'Curcumin in turmeric blocks the same inflammatory pathway as ibuprofen (COX-2 inhibition) — without side effects. Athletes in India have known this for centuries!' },
    ],
    xpReward:  75,
    sanskritiPoints: 18,
  },

  {
    id:          'kavitha_weaver',
    name:        'Kavitha',
    title:       'A 35-year-old silk weaver',
    age:         35,
    location:    'Kanchipuram',
    unlockLevel: 2,
    season:      'grishma',
    artDescription: 'A graceful woman with ink-stained fingers. Tired but dignified. Silk threads still caught in her hair.',
    arrivalStory: `
      Kavitha weaves Kanchipuram silk sarees — an art passed through seven generations
      of her family. She works 10 hours daily at the loom. Her problem: her eyes are
      burning and red. She cannot work in sunlight anymore. She has headaches behind
      her eyes. And strange white patches are appearing on her skin.
    `,
    symptoms: ['eye inflammation', 'burning sensation', 'skin patches', 'headache', 'photosensitivity', 'anger'],
    doshaImbalance: 'pitta',
    urgency: 'moderate',

    dialogue: {
      greeting: '"The doctor in town gave me eye drops that work for two hours then the burning comes back. This has been going on for four months."',
      complaint: '"I cannot afford to not weave. My daughter\'s wedding is in one year. Every saree I do not finish is money I do not earn."',
      doshaReveal: '"The summer months are when it started. And yes, my temper has been... my husband says I am not the same person."',
      healingQuestion: '"The white patches on my skin — will they go away? I have been hiding them."',
    },

    correctRecipe: 'rose_arka',
    alternateRecipes: ['chandan_lepa', 'brahmi_ghrita'],

    moralChoice: {
      question: 'Kavitha\'s skin patches may indicate vitiligo — a condition that needs long-term treatment. She wants a quick fix because of wedding pressures.',
      options: [
        {
          label: 'Be honest about the timeline — 6-12 months of treatment needed',
          outcome: 'honesty',
          effect: '+20 Wisdom. Kavitha trusts you completely. Starts long-term treatment.',
          moralLesson: 'Giving false hope is a betrayal. A Vaidya\'s credibility rests on truthful prognosis.',
        },
        {
          label: 'Focus on the eyes first, address skin later',
          outcome: 'priority',
          effect: '+12 Wisdom. The urgent problem is addressed. Skin care begins after.',
          moralLesson: 'Triage: address what threatens quality of life most immediately.',
        },
        {
          label: 'Recommend special cosmetic herbs to hide patches for the wedding',
          outcome: 'compassion',
          effect: '+10 Devotion. Kavitha deeply moved. Starts treatment AND cosmetic support.',
          moralLesson: 'Sometimes acknowledging the human reality (a daughter\'s wedding) IS the medicine.',
        },
      ],
    },

    healingOutcome: {
      success: `
        At her daughter\'s wedding six months later, Kavitha is wearing a saree she wove
        herself — a red and gold Kanchipuram, her masterpiece. Her eyes are clear. The
        patches have faded 80%. Her daughter walks beside her, studying to become a Vaidya.
        "Because of what you did for my mother," the daughter says.
      `,
      partial: `
        The eyes healed completely. The skin patches lightened but remain. Kavitha says:
        "For the wedding I wore full sleeves. But I am not hiding anymore. Just protecting."
        That shift in perspective is also healing.
      `,
      failure: `
        Kavitha couldn\'t find time to apply the rose water consistently. You make a
        simple daily morning routine card for her — 3 steps, 5 minutes. Make healing
        fit into the real shape of a busy person\'s life.
      `,
    },

    herbFacts: [
      { herb: 'rose', fact: 'Rose water has a pH almost identical to the human eye (7.4). This is why it can be directly applied to eyes safely — nature built the perfect eye drop!' },
      { herb: 'brahmi', fact: 'Brahmi is used in Ayurvedic treatment of skin disorders because Vata governs the nervous system that controls skin pigmentation. Brain herb = skin medicine!' },
    ],
    xpReward:  80,
    sanskritiPoints: 20,
  },

  {
    id:          'gopal_merchant',
    name:        'Gopal Seth',
    title:       'A 50-year-old cloth merchant',
    age:         50,
    location:    'Surat',
    unlockLevel: 2,
    season:      null,
    artDescription: 'A prosperous man with a large belly. Silk kurta. Gold watch. Waddling walk from weight.',
    arrivalStory: `
      Gopal Seth arrives in a car. His driver waits outside. Gopal himself sits down heavily.
      He eats four meals a day. He has not exercised since his 30s. He is tired by 10am.
      He sleeps for 2 hours after lunch. He has high triglycerides and the doctor mentioned
      "pre-diabetes." He says: "These things happen with age. But my wife is worried."
    `,
    symptoms: ['weight gain', 'lethargy', 'depression', 'slow digestion', 'excessive sleep', 'oily skin', 'low motivation'],
    doshaImbalance: 'kapha',
    urgency: 'moderate',

    dialogue: {
      greeting: '"I only came because my wife threatened to make my lunch herself. Which would be worse than any disease."',
      complaint: '"I wake up tired. I sleep eight hours and I am still tired. After lunch I need to sleep. My children say I snore now."',
      doshaReveal: '"Kapha — the Earth type. Stable, yes. But stuck? Me? I built a business from nothing."',
      healingQuestion: '"Will I have to stop my chai? I have six cups of chai with full cream milk every day."',
    },

    correctRecipe: 'trikatu_churna',
    alternateRecipes: ['dashamoola_kwatha', 'triphala_churna'],

    moralChoice: {
      question: 'Gopal can afford any treatment. But the real issue is lifestyle. He refuses to exercise — "too busy."',
      options: [
        {
          label: 'Challenge him: "You built a business. You can build 30 minutes of morning walk."',
          outcome: 'courage',
          effect: '+20 Courage. Gopal laughs, then starts walking. Herbs work 3× faster.',
          moralLesson: 'A Vaidya sometimes needs to challenge the patient\'s self-image to activate change.',
        },
        {
          label: 'Give herbs and let him choose the lifestyle changes himself',
          outcome: 'autonomy',
          effect: '+10 Wisdom. Herbs help partially. Gopal slowly changes when he feels the difference.',
          moralLesson: 'Respecting patient autonomy: the patient must choose their own healing.',
        },
        {
          label: 'Speak to his wife and arrange family support for lifestyle change',
          outcome: 'systems',
          effect: '+15 Dharma. Family support doubles success rate. Gopal heals within 3 months.',
          moralLesson: 'Health exists within relationships. Healing the family system heals the patient.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Four months later, Gopal Seth is 8 kilos lighter. His driver now waits while
        Gopal walks the last kilometre to his shop every morning. The diabetes threat is
        gone. He has reduced to three cups of chai — with plant milk. He tells his
        business partners: "The Vaidya told me I had too much earth. I needed wind and fire.
        So I hired a running trainer." He laughs. The herbs worked. The laughter helped more.
      `,
      partial: `
        Gopal lost 3 kilos and the lethargy improved. He still doesn\'t exercise but he
        cut the afternoon sleep to 30 minutes. Small changes sustained are better than
        dramatic changes abandoned.
      `,
      failure: `
        Gopal did not take the herbs because "they smelled like a pharmacy." You make a
        spiced chai blend incorporating trikatu herbs — medicine hidden in his favourite ritual.
        Work with the patient\'s existing habits, not against them.
      `,
    },

    herbFacts: [
      { herb: 'ginger', fact: 'Ginger increases basal metabolic rate by up to 20% for 3 hours after consumption. This is why Ayurveda says ginger "kindles the digestive fire" — it\'s metabolically literal!' },
      { herb: 'pepper', fact: 'Piperine in black pepper increases the bioavailability of other herbs by 2,000%! This is why trikatu is the base of so many Ayurvedic formulas — pepper makes everything else stronger.' },
    ],
    xpReward:  85,
    sanskritiPoints: 22,
  },

  /* ═══ LEVEL 3 PATIENTS — Advanced quests ══════════════════════════════════ */

  {
    id:          'rukmini_potter',
    name:        'Rukmini',
    title:       'A 42-year-old Warli potter',
    age:         42,
    location:    'Palghar, Maharashtra',
    unlockLevel: 3,
    season:      'varsha',
    artDescription: 'A woman with clay permanently embedded in her skin lines. Calloused hands. Deep-set eyes. Traditional Warli jewellery.',
    arrivalStory: `
      Rukmini has made pots for 25 years. Now her hands shake. Not constantly —
      only in the morning and when she is tired. She has dropped two completed pots
      this month. She cannot afford to drop any. She also has ringing in her ears
      (tinnitus) that started six months ago. She is frightened.
    `,
    symptoms: ['tremors', 'tinnitus', 'anxiety', 'poor circulation', 'vata', 'restlessness', 'fear'],
    doshaImbalance: 'vata',
    urgency: 'high',

    dialogue: {
      greeting: '"I walked four kilometers to get here. The bus does not come to our village in the monsoon."',
      complaint: '"My hands are my income. If I cannot make pots, my family does not eat. The shaking — it started small. Now some mornings I cannot hold a cup."',
      doshaReveal: '"You say it is my nervous system. Can nervous systems be fixed with plants? Not operations?"',
      healingQuestion: '"How will I know if it is working? I need to know it is working."',
    },

    correctRecipe: 'brahmi_ghrita',
    alternateRecipes: ['ksheerabala_taila', 'ashwagandha_churna'],

    moralChoice: {
      question: 'Rukmini\'s tremors could indicate an early neurological condition needing specialist evaluation. What do you do?',
      options: [
        {
          label: 'Refer her to a neurologist AND give Ayurvedic support',
          outcome: 'integrative',
          effect: '+25 Wisdom. Integrative care: Ayurveda + modern medicine together.',
          moralLesson: 'A wise Vaidya knows the limits of their knowledge. Referral is an act of care, not failure.',
        },
        {
          label: 'Treat with Ayurveda first for 6 weeks, then evaluate',
          outcome: 'ayurveda_first',
          effect: '+15 Courage. Tremors improve 50%. Neurological referral later confirms benign tremor.',
          moralLesson: 'Ayurveda has a role in neurological support. But timeline and monitoring matter.',
        },
        {
          label: 'Tell her it is "just Vata" and will heal with herbs',
          outcome: 'incomplete',
          effect: 'Tremors improve but recur. The missed diagnosis causes delay.',
          moralLesson: 'Overconfidence in any system of medicine can harm patients. Humility heals.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Eight weeks later, Rukmini arrives carrying a small pot she made that morning.
        The shaking is reduced by 70%. She cannot come again — the bus is expensive.
        But she has written down everything. She is teaching her daughter to make the
        ghrita at home. "Knowledge that stays in the village serves the village," she says.
        She leaves the pot as payment. You keep it on your shelf for twenty years.
      `,
      partial: `
        The tinnitus resolved but the tremors remain at 30% severity. This is acceptable
        progress. Rukmini adapted her pot-making technique — using a foot wheel instead
        of hand shaping. Healing is also adaptation.
      `,
      failure: `
        Rukmini could not afford the sesame oil for the ksheerabala taila massage. You
        adjust to a simpler self-massage with coconut oil and brahmi powder. Always have
        an affordable alternative ready.
      `,
    },

    herbFacts: [
      { herb: 'brahmi', fact: 'Brahmi contains bacosides that repair myelin sheaths (the protective coating of nerve fibres). It is literally growing back what aging and stress have worn down!' },
      { herb: 'ashwagandha', fact: 'Ashwagandha has been shown in clinical trials to reduce the markers of neurological damage. Indian rugby players use it after concussions. Ancient wrestlers used it — same reason.' },
    ],
    xpReward:  100,
    sanskritiPoints: 28,
  },

  {
    id:          'dharma_monk',
    name:        'Brother Dharmananda',
    title:       'A Buddhist monk, 67 years old',
    age:         67,
    location:    'Nalanda, Bihar',
    unlockLevel: 3,
    season:      'hemanta',
    artDescription: 'A saffron-robed monk with a shaved head. Serene eyes. Moves with extraordinary slowness and intention.',
    arrivalStory: `
      The monk walks to your apothecary at dawn. He sits in lotus posture and waits
      without speaking until you are ready. He has not come for himself — he has come
      because three younger monks at his monastery have developed persistent cough,
      low appetite, and weight loss. He suspects they are not eating well enough
      in the winter.
    `,
    symptoms: ['cough', 'weight loss', 'fatigue', 'low appetite', 'cold sensitivity', 'respiratory weakness'],
    doshaImbalance: 'vata',
    urgency: 'moderate',

    dialogue: {
      greeting: '"We monks are poor patients. We resist medicines that cause attachment to the body. But we have a duty to our bodies as vehicles for the dharma."',
      complaint: '"Three of my young brothers — 19, 22, and 24. They chant through winter mornings in thin robes. Their discipline is greater than their nutrition."',
      doshaReveal: '"You say cold and wind weaken Vata. Our morning rituals are at 4am in the cold. We did not consider this."',
      healingQuestion: '"The herbs must be simple and affordable. We have made vows of poverty."',
    },

    correctRecipe: 'chyawanprash',
    alternateRecipes: ['sitopaladi_churna', 'tulsi_kwatha'],

    moralChoice: {
      question: 'Chyawanprash is the ideal treatment but it contains honey — some monks follow ahimsa (non-harming) and avoid honey. What do you do?',
      options: [
        {
          label: 'Reformulate with jaggery instead of honey — respect their practice',
          outcome: 'respect',
          effect: '+25 Devotion. The monks are deeply moved. The monastery becomes your permanent patient family.',
          moralLesson: 'The Vaidya adapts the medicine to the patient — never the patient to the medicine.',
        },
        {
          label: 'Explain that honey is medical, not commercial — ahimsa considerations differ',
          outcome: 'education',
          effect: '+15 Wisdom. The monk considers and accepts. Different philosophical path leads to same healing.',
          moralLesson: 'Sharing knowledge allows the patient to make an informed choice.',
        },
        {
          label: 'Give them tulsi kwatha instead — simpler and clearly appropriate',
          outcome: 'simplicity',
          effect: '+10 Wisdom. The acute problem resolves but winter immunity remains low.',
          moralLesson: 'Appropriate medicine is better than perfect medicine unacceptably delivered.',
        },
      ],
    },

    healingOutcome: {
      success: `
        A month later, the monk returns. All three young monks are well. He brings a copy
        of an ancient Pali text that describes Ayurvedic medicines used at Nalanda University
        in the 7th century CE. "We found this in our library. Perhaps you would like it."
        You spend an evening reading it. You learn three new herb combinations you've
        never seen before. The monk left you a teacher.
      `,
      partial: `
        Two of the three monks recovered fully. The third has underlying weakness that
        needs longer treatment. The monk arranges for him to visit weekly. Patient care
        is not always quick.
      `,
      failure: `
        The monastery could not maintain the ritual preparation required for Chyawanprash.
        You make pre-measured single doses for each monk. Industrial-scale medicine
        meets monastic simplicity.
      `,
    },

    herbFacts: [
      { herb: 'amla', fact: 'Amla is described as "divya aushadhi" (divine medicine) in Buddhist texts. The Buddha himself is said to have offered an amla fruit to the Sangha as medicine during an illness outbreak.' },
      { herb: 'ashwagandha', fact: 'Ashwagandha was used in ancient Nalanda University (5th–12th century) by students and scholars for sustained mental effort. 10,000 students studied there — they needed all the brain support they could get!' },
    ],
    xpReward:  120,
    sanskritiPoints: 35,
  },

  /* ═══ BONUS PATIENTS — Special encounters ══════════════════════════════════ */

  {
    id:          'little_krishna',
    name:        'Baby Krishna',
    title:       'A 3-year-old child',
    age:         3,
    location:    'Unknown (brought by a worried mother)',
    unlockLevel: 4,
    season:      null,
    artDescription: 'A beautiful dark-skinned toddler with enormous eyes. Playful even while sick. Mother kneels beside him.',
    arrivalStory: `
      A young mother brings her three-year-old son, Krishna. He has been crying
      through the night for four days with a fever that rises and falls. He refuses
      to eat. He has spots on his tongue. He keeps pulling at his ears. The local
      doctor gave antibiotics but the mother wants to know if there is a gentler path.
    `,
    symptoms: ['fever', 'loss of appetite', 'mouth sores', 'ear pain', 'disturbed sleep', 'pitta'],
    doshaImbalance: 'pitta',
    urgency: 'high',

    dialogue: {
      greeting: '(Krishna reaches out and grabs your herb samples from the table. His mother apologises.)',
      complaint: '"Four nights he has not slept. And so neither have I. Please tell me it is nothing serious."',
      doshaReveal: '"He runs hot — always has, even as a newborn. Summer is hard for him."',
      healingQuestion: '"He will not eat anything. How do I give him herbs if he won\'t eat?"',
    },

    correctRecipe: 'tulsi_kwatha',
    alternateRecipes: ['sitopaladi_churna', 'amla_swarasa'],

    moralChoice: {
      question: 'The fever has been going on for 4 days. The antibiotics haven\'t worked. Should you refer immediately or try Ayurveda first?',
      options: [
        {
          label: 'For a child under 5 with fever for 4 days — refer immediately AND support with herbs',
          outcome: 'safety_first',
          effect: '+30 Wisdom. Child is diagnosed with a viral infection. Herbs support recovery. Your caution was correct.',
          moralLesson: 'With children, always err on the side of caution. The Vaidya\'s first duty is to not harm.',
        },
        {
          label: 'Give herbs and observe for 24 hours, then decide about referral',
          outcome: 'watchful',
          effect: '+15 Courage. Fever breaks by morning. Child recovers. The risk was calculated.',
          moralLesson: 'Clinical judgement requires knowledge of risk and time windows.',
        },
        {
          label: 'Give herbs and reassure the mother — 4-day fever is not uncommon',
          outcome: 'risky',
          effect: 'Fever continues. Child referred 2 days later. Outcome fine but trust reduced.',
          moralLesson: 'Reassurance without proper evaluation can delay necessary care.',
        },
      ],
    },

    healingOutcome: {
      success: `
        Three days after the clinic visit, the mother sends a message: "He ate a full
        bowl of khichdi this morning. He is trying to eat the tulsi plant in our garden.
        I think he is better." Krishna grows up to be a doctor who always asks his
        patients if they drink tulsi chai.
      `,
      partial: `
        The fever broke. The mouth sores persist one more week. This is normal for the
        viral condition. The mother was prepared for this timeline, which reduced her anxiety.
        Managing the caregiver\'s fear is part of the child\'s treatment.
      `,
      failure: `
        Tulsi kwatha is bitter. Krishna refused to drink it. You make "Tulsi drops" — three
        drops of concentrated extract in warm honey water. One drop per year of age. Make
        children\'s medicine child-friendly: simple, sweet, small quantities.
      `,
    },

    herbFacts: [
      { herb: 'tulsi', fact: 'Fresh tulsi leaves on the tongue are a traditional first aid for fever in Indian homes. The eugenol compounds begin reducing temperature within 30 minutes of ingestion!' },
      { herb: 'ginger', fact: 'Small amounts of ginger in warm water help children\'s digestive fire restart after fever. The appetite returns faster with gentle ginger than without any intervention.' },
    ],
    xpReward:  90,
    sanskritiPoints: 25,
  },

  {
    id:          'legendary_vaidya',
    name:        'Vaidya Krishnadasa',
    title:       'An 84-year-old master healer',
    age:         84,
    location:    'Kashi (Varanasi) — from your lineage',
    unlockLevel: 8,
    season:      null,
    artDescription: 'An ancient man who sits perfectly still. Silver beard. Eyes that have seen 60 years of patients. He arrives on foot, unannounced, at sunrise.',
    arrivalStory: `
      The old Vaidya comes not as a patient but as a teacher. He has heard of your
      work. He sits with you for one hour. He asks: "Show me your five most difficult
      cases and what you prescribed." He listens carefully. Then he says: "You have
      learned medicine well. Now I will teach you what medicine cannot cure."
    `,
    symptoms: [],
    doshaImbalance: null,
    urgency: 'none',

    dialogue: {
      greeting: '"Do not offer me tea. I have given up stimulants. Just your attention."',
      complaint: 'This is not a patient encounter — this is a teaching session.',
      doshaReveal: '"The doshas are a map. The patient is the territory. Never confuse the two."',
      healingQuestion: '"What do you still not understand about healing? Tell me honestly."',
    },

    correctRecipe: null,
    alternateRecipes: [],

    moralChoice: {
      question: 'The old Vaidya asks you: "What is the most important quality a healer must have?" What do you answer?',
      options: [
        {
          label: 'Knowledge of herbs and medicine',
          outcome: 'knowledge',
          effect: '+20 Wisdom. "Good — but not first. A knowledgeable healer who does not care harms more than a ignorant one who cares."',
          moralLesson: 'Knowledge without compassion is dangerous.',
        },
        {
          label: 'Compassion for the patient',
          outcome: 'compassion',
          effect: '+30 Devotion. "Closest. Charaka said: compassion is the root of healing. From that root grow knowledge, skill, and wisdom as branches."',
          moralLesson: 'Compassion is the foundation of all healing — in every system.',
        },
        {
          label: 'Humility — knowing the limits of what I can heal',
          outcome: 'humility',
          effect: '+25 Wisdom. "Also correct. A Vaidya who knows their limits saves many lives by knowing when to refer."',
          moralLesson: 'Knowing what you do not know is the beginning of wisdom.',
        },
        {
          label: 'Honesty — telling patients what they need to hear, not what they want',
          outcome: 'honesty',
          effect: '+25 Dharma. "Yes. Ancient teachers say: the truthful Vaidya is the healer. The flattering Vaidya is the destroyer."',
          moralLesson: 'Truth, even when hard, is the most healing act.',
        },
      ],
    },

    healingOutcome: {
      success: `
        The old Vaidya leaves at sunset after 11 hours. He has taught you three herb
        formulas forgotten for 200 years, recovered from a manuscript he found in
        Kashi. He also taught you something no textbook contains: "When a patient enters
        your space, your first prescription is the quality of your attention. Before
        one herb is ground, one remedy made — give them that."

        You unlock: The Sage's Path — all legendary herbs can now grow in your garden.
        You also unlock: Teaching mode — you can now take on apprentices.
      `,
      partial: null,
      failure: null,
    },

    herbFacts: [
      { herb: 'soma', fact: 'Soma is the most discussed and least known herb in all of Ayurveda. Its true identity has been debated for 3000 years. The mystery is the medicine — it keeps us humble.' },
      { herb: 'sanjeevani', fact: 'Sanjeevani means "that which makes alive again." The plant Selaginella bryopteris literally comes back to life after drying. It was not a myth — it was a metaphor made real.' },
    ],
    xpReward:  500,
    sanskritiPoints: 100,
    isTeachingEncounter: true,
    unlocks: ['legendary_garden_access', 'teaching_mode', 'sage_wisdom_badge'],
  },
];

/* ── PATIENT ENGINE FUNCTIONS ────────────────────────────────────────────── */

/**
 * Get today's patient queue — weighted by season and player level.
 * Returns 3 patients per day.
 *
 * @param {number} playerLevel
 * @param {Object} [seasonalContext] — from seasons.js
 * @returns {Array} selected patients
 */
export function getDailyPatients(playerLevel, seasonalContext = null) {
  const season      = seasonalContext?.season?.id ?? null;
  const eligible    = PATIENTS.filter(p => p.unlockLevel <= playerLevel);

  // Weight by season match and urgency
  const weighted = eligible.map(p => {
    let weight = 1;
    if (p.season === season)   weight += 2;
    if (p.urgency === 'high')  weight += 1;
    if (p.isTeachingEncounter) weight = playerLevel >= p.unlockLevel ? 3 : 0;
    return { patient: p, weight };
  }).filter(w => w.weight > 0);

  // Weighted random selection — 3 patients
  const selected = [];
  const pool     = [...weighted];
  const count    = Math.min(3, pool.length);

  for (let i = 0; i < count; i++) {
    const totalWeight = pool.reduce((s, w) => s + w.weight, 0);
    let rand = Math.random() * totalWeight;
    let idx  = 0;
    while (rand > 0 && idx < pool.length) {
      rand -= pool[idx].weight;
      if (rand <= 0) break;
      idx++;
    }
    selected.push(pool[idx].patient);
    pool.splice(idx, 1);
  }

  return selected;
}

/**
 * Evaluate a treatment decision for a patient.
 *
 * @param {string} patientId
 * @param {string} prescribedRecipeId
 * @param {number} choiceIndex — moral choice selected (0-2)
 * @returns {Object} evaluation result
 */
export function evaluateTreatment(patientId, prescribedRecipeId, choiceIndex) {
  const patient = PATIENTS.find(p => p.id === patientId);
  if (!patient) return { success: false, reason: 'Patient not found' };

  const isCorrectRecipe = prescribedRecipeId === patient.correctRecipe ||
                          patient.alternateRecipes.includes(prescribedRecipeId);
  const moralOutcome    = patient.moralChoice?.options[choiceIndex] ?? null;

  // Determine outcome tier
  let outcomeTier;
  if (isCorrectRecipe && moralOutcome?.outcome !== 'risky' && moralOutcome?.outcome !== 'incomplete') {
    outcomeTier = 'success';
  } else if (isCorrectRecipe || moralOutcome?.outcome === 'pragmatic' || moralOutcome?.outcome === 'compromise') {
    outcomeTier = 'partial';
  } else {
    outcomeTier = 'failure';
  }

  const xpMultiplier = { success: 1.0, partial: 0.6, failure: 0.3 };
  const xpEarned     = Math.round(patient.xpReward * xpMultiplier[outcomeTier]);

  return {
    patientId,
    outcomeTier,
    isCorrectRecipe,
    moralOutcome,
    narrative:  patient.healingOutcome[outcomeTier],
    xpEarned,
    sanskritiPoints: outcomeTier === 'success' ? patient.sanskritiPoints : Math.round(patient.sanskritiPoints * 0.5),
    herbFacts:  patient.herbFacts,
    unlocks:    outcomeTier === 'success' ? (patient.unlocks ?? []) : [],
  };
}

export const getPatientById = (id) => PATIENTS.find(p => p.id === id) ?? null;

export default {
  PATIENTS,
  getDailyPatients,
  evaluateTreatment,
  getPatientById,
};

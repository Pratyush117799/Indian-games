'use strict';

/*
 * WebSocket handler — Ashtapada real-time multiplayer
 * Each game room is identified by gameId.
 * Events:
 *   client → server:  join_game, roll_dice, make_move, leave_game
 *   server → client:  game_state, dice_rolled, move_made, player_joined,
 *                     player_left, game_over, error
 */

const rooms = new Map(); // gameId → { players: [socketId, ...], state: {} }

function handleSocket(socket, io) {
  console.log(`[WS] connected: ${socket.id}`);

  /* ── Join a game room ─────────────────────────────────────── */
  socket.on('join_game', ({ gameId, userId, username }) => {
    socket.join(gameId);

    if (!rooms.has(gameId)) {
      rooms.set(gameId, { players: [], spectators: [], state: null });
    }

    const room = rooms.get(gameId);

    if (room.players.length < 2) {
      const playerIndex = room.players.length;
      room.players.push({ socketId: socket.id, userId, username, playerIndex });

      socket.data.gameId = gameId;
      socket.data.playerIndex = playerIndex;

      io.to(gameId).emit('player_joined', {
        playerIndex,
        username,
        totalPlayers: room.players.length
      });

      if (room.players.length === 2) {
        io.to(gameId).emit('game_ready', {
          players: room.players.map(p => ({ username: p.username, playerIndex: p.playerIndex }))
        });
      }
    } else {
      /* Spectator */
      room.spectators.push(socket.id);
      socket.emit('spectating', { gameId });
    }
  });

  /* ── Dice roll broadcast ──────────────────────────────────── */
  socket.on('roll_dice', ({ gameId, diceResult, player }) => {
    socket.to(gameId).emit('dice_rolled', { diceResult, player });
  });

  /* ── Move broadcast ───────────────────────────────────────── */
  socket.on('make_move', ({ gameId, pieceIndex, fromStep, toStep, player, captured }) => {
    const room = rooms.get(gameId);
    if (room) room.state = { lastMove: { pieceIndex, fromStep, toStep, player, captured } };

    socket.to(gameId).emit('move_made', { pieceIndex, fromStep, toStep, player, captured });
  });

  /* ── Game over broadcast ──────────────────────────────────── */
  socket.on('game_over', ({ gameId, winner, totalMoves }) => {
    io.to(gameId).emit('game_over', { winner, totalMoves });
    rooms.delete(gameId);
  });

  /* ── Disconnect cleanup ───────────────────────────────────── */
  socket.on('disconnect', () => {
    const { gameId } = socket.data;
    if (gameId && rooms.has(gameId)) {
      const room = rooms.get(gameId);
      const playerIndex = socket.data.playerIndex;
      io.to(gameId).emit('player_left', { playerIndex });
      room.players = room.players.filter(p => p.socketId !== socket.id);
      if (room.players.length === 0) rooms.delete(gameId);
    }
    console.log(`[WS] disconnected: ${socket.id}`);
  });
}

module.exports = { handleSocket };

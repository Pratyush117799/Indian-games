-- ============================================================
-- KRIDA  —  Traditional Indian Games Platform
-- PostgreSQL Schema
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username      VARCHAR(30)  NOT NULL UNIQUE,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT         NOT NULL,
  avatar_url    TEXT,
  is_verified   BOOLEAN      DEFAULT FALSE,
  created_at    TIMESTAMPTZ  DEFAULT NOW(),
  updated_at    TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX idx_users_email    ON users(email);
CREATE INDEX idx_users_username ON users(username);

-- ============================================================
-- REFRESH TOKENS  (JWT rotation)
-- ============================================================
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token       TEXT        NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);

-- ============================================================
-- GAMES CATALOGUE
-- ============================================================
CREATE TABLE games (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug         VARCHAR(60)  NOT NULL UNIQUE,  -- 'kattam-vilayattu' | 'paramapadam'
  name         VARCHAR(100) NOT NULL,
  name_tamil   VARCHAR(100),
  description  TEXT,
  min_players  INT DEFAULT 2,
  max_players  INT DEFAULT 6,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- GAME ROOMS  (active / finished sessions)
-- ============================================================
CREATE TYPE room_status AS ENUM ('waiting', 'active', 'finished', 'abandoned');

CREATE TABLE game_rooms (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  game_id      UUID        NOT NULL REFERENCES games(id),
  room_code    VARCHAR(8)  NOT NULL UNIQUE,   -- short join code e.g. "KV3X8F"
  host_id      UUID        NOT NULL REFERENCES users(id),
  status       room_status DEFAULT 'waiting',
  max_players  INT         DEFAULT 2,
  is_private   BOOLEAN     DEFAULT FALSE,
  game_level   INT         DEFAULT 1,         -- for Kattam: level 1/2/3
  started_at   TIMESTAMPTZ,
  finished_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_rooms_code    ON game_rooms(room_code);
CREATE INDEX idx_rooms_status  ON game_rooms(status);
CREATE INDEX idx_rooms_game    ON game_rooms(game_id);

-- ============================================================
-- ROOM PLAYERS  (who is in which room)
-- ============================================================
CREATE TYPE player_color AS ENUM ('green', 'brown', 'red', 'blue', 'yellow', 'purple');

CREATE TABLE room_players (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id      UUID         NOT NULL REFERENCES game_rooms(id) ON DELETE CASCADE,
  user_id      UUID         NOT NULL REFERENCES users(id),
  seat_index   INT          NOT NULL,           -- 0-based seat position
  color        player_color NOT NULL DEFAULT 'green',
  is_ready     BOOLEAN      DEFAULT FALSE,
  joined_at    TIMESTAMPTZ  DEFAULT NOW(),
  UNIQUE(room_id, user_id),
  UNIQUE(room_id, seat_index)
);

CREATE INDEX idx_room_players_room ON room_players(room_id);
CREATE INDEX idx_room_players_user ON room_players(user_id);

-- ============================================================
-- GAME SESSIONS  (one completed match record)
-- ============================================================
CREATE TABLE game_sessions (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id        UUID        NOT NULL REFERENCES game_rooms(id),
  game_id        UUID        NOT NULL REFERENCES games(id),
  winner_id      UUID        REFERENCES users(id),   -- NULL = draw / abandoned
  total_moves    INT         DEFAULT 0,
  duration_secs  INT,                                -- game duration in seconds
  game_state     JSONB,                              -- final board snapshot
  started_at     TIMESTAMPTZ DEFAULT NOW(),
  ended_at       TIMESTAMPTZ
);

CREATE INDEX idx_sessions_room    ON game_sessions(room_id);
CREATE INDEX idx_sessions_winner  ON game_sessions(winner_id);
CREATE INDEX idx_sessions_game    ON game_sessions(game_id);

-- ============================================================
-- MOVE HISTORY  (every individual move for replay)
-- ============================================================
CREATE TABLE moves (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id   UUID        NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  player_id    UUID        NOT NULL REFERENCES users(id),
  move_number  INT         NOT NULL,
  move_data    JSONB       NOT NULL,   -- { from, to, piece, diceRoll, eventType }
  board_state  JSONB       NOT NULL,   -- snapshot of board after this move
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_moves_session ON moves(session_id);
CREATE INDEX idx_moves_player  ON moves(player_id);
CREATE INDEX idx_moves_number  ON moves(session_id, move_number);

-- ============================================================
-- LEADERBOARD  (per-game stats, updated after each session)
-- ============================================================
CREATE TABLE leaderboard (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id       UUID NOT NULL REFERENCES games(id),
  wins          INT  DEFAULT 0,
  losses        INT  DEFAULT 0,
  draws         INT  DEFAULT 0,
  total_games   INT  DEFAULT 0,
  win_rate      NUMERIC(5,2) DEFAULT 0.00,   -- stored as percentage 0–100
  total_moves   INT  DEFAULT 0,
  best_time_secs INT,                         -- fastest win in seconds
  rating        INT  DEFAULT 1000,            -- ELO-style rating
  updated_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, game_id)
);

CREATE INDEX idx_leaderboard_game_rating ON leaderboard(game_id, rating DESC);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at on users
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Recalculate win_rate after each leaderboard update
CREATE OR REPLACE FUNCTION recalc_win_rate()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.total_games > 0 THEN
    NEW.win_rate = ROUND((NEW.wins::NUMERIC / NEW.total_games) * 100, 2);
  ELSE
    NEW.win_rate = 0;
  END IF;
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_leaderboard_win_rate
  BEFORE INSERT OR UPDATE ON leaderboard
  FOR EACH ROW EXECUTE FUNCTION recalc_win_rate();

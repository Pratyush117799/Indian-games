const router = require('express').Router();
const ctrl   = require('../controllers/historyController');
const { authenticate } = require('../middleware/auth');

router.get('/',              authenticate, ctrl.getMyHistory);
router.get('/:sessionId',    authenticate, ctrl.getReplay);

module.exports = router;

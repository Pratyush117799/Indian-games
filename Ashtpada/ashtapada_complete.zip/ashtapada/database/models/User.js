'use strict';
/* User model — profile, stats, skin unlocks */

class UserModel {
  constructor(pool) { this.pool = pool; }

  async create({ username, email, passwordHash, region, avatarIndex }) {
    const { rows } = await this.pool.query(
      `INSERT INTO users (username,email,password_hash,region,avatar_index)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [username, email, passwordHash, region, avatarIndex]
    );
    return rows[0];
  }

  async findById(id) {
    const { rows } = await this.pool.query('SELECT * FROM users WHERE id=$1', [id]);
    return rows[0] || null;
  }

  async findByUsername(username) {
    const { rows } = await this.pool.query(
      'SELECT * FROM users WHERE username=$1', [username]
    );
    return rows[0] || null;
  }

  async recordResult(userId, won) {
    const streakUpdate = won
      ? `streak = streak + 1, wins = wins + 1,
         best_streak = GREATEST(best_streak, streak + 1)`
      : `streak = 0, losses = losses + 1`;

    const { rows } = await this.pool.query(
      `UPDATE users SET games_played = games_played + 1, ${streakUpdate},
       last_played = CURRENT_DATE
       WHERE id=$1 RETURNING wins, losses, streak, best_streak`,
      [userId]
    );
    return rows[0];
  }

  async unlockSkin(userId, skinId) {
    await this.pool.query(
      `UPDATE users SET unlocked_skins = array_append(unlocked_skins, $2)
       WHERE id=$1 AND NOT ($2 = ANY(unlocked_skins))`,
      [userId, skinId]
    );
  }

  async topByRegion(region, limit = 10) {
    const { rows } = await this.pool.query(
      `SELECT username, region, wins, streak, avatar_index
       FROM users WHERE region=$1
       ORDER BY wins DESC LIMIT $2`,
      [region, limit]
    );
    return rows;
  }

  async globalTop(limit = 20) {
    const { rows } = await this.pool.query(
      `SELECT username, region, wins, streak, avatar_index
       FROM users ORDER BY wins DESC LIMIT $1`,
      [limit]
    );
    return rows;
  }
}

module.exports = UserModel;

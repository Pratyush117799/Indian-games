const bcrypt  = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db      = require('../config/db');
const { signAccessToken, signRefreshToken,
        verifyRefreshToken, revokeRefreshToken } = require('../utils/jwt');
const logger  = require('../utils/logger');

// ── Validation rules ────────────────────────────────────────
const registerRules = [
  body('username')
    .trim().isLength({ min: 3, max: 30 })
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username: 3–30 chars, letters/numbers/underscores only'),
  body('email').isEmail().normalizeEmail(),
  body('password')
    .isLength({ min: 8 })
    .matches(/^(?=.*[A-Z])(?=.*[0-9])/)
    .withMessage('Password: min 8 chars, one uppercase, one number'),
];

const loginRules = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
];

// ── Helpers ─────────────────────────────────────────────────
function validate(req, res) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(422).json({ errors: errors.array() });
    return false;
  }
  return true;
}

// ── Controllers ──────────────────────────────────────────────

/**
 * POST /api/auth/register
 */
async function register(req, res, next) {
  if (!validate(req, res)) return;
  try {
    const { username, email, password } = req.body;

    // Duplicate check
    const exists = await db.query(
      'SELECT id FROM users WHERE email = $1 OR username = $2',
      [email, username]
    );
    if (exists.rows.length) {
      return res.status(409).json({ error: 'Email or username already in use' });
    }

    const password_hash = await bcrypt.hash(password, 12);

    const { rows } = await db.query(
      `INSERT INTO users (username, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING id, username, email, created_at`,
      [username, email, password_hash]
    );
    const user = rows[0];

    // Seed leaderboard rows for each game
    const { rows: games } = await db.query('SELECT id FROM games WHERE is_active = true');
    for (const g of games) {
      await db.query(
        'INSERT INTO leaderboard (user_id, game_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [user.id, g.id]
      );
    }

    const accessToken  = signAccessToken({ sub: user.id, username: user.username });
    const refreshToken = await signRefreshToken(user.id);

    logger.info(`New user registered: ${username}`);
    res.status(201).json({ user, accessToken, refreshToken });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/login
 */
async function login(req, res, next) {
  if (!validate(req, res)) return;
  try {
    const { email, password } = req.body;

    const { rows } = await db.query(
      'SELECT id, username, email, password_hash FROM users WHERE email = $1',
      [email]
    );
    const user = rows[0];

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const accessToken  = signAccessToken({ sub: user.id, username: user.username });
    const refreshToken = await signRefreshToken(user.id);

    const { password_hash, ...safeUser } = user;
    logger.info(`User logged in: ${user.username}`);
    res.json({ user: safeUser, accessToken, refreshToken });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/refresh
 */
async function refresh(req, res, next) {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ error: 'Refresh token required' });

    const decoded = await verifyRefreshToken(refreshToken);
    await revokeRefreshToken(refreshToken);   // rotate: invalidate old token

    const { rows } = await db.query(
      'SELECT id, username, email FROM users WHERE id = $1',
      [decoded.sub]
    );
    if (!rows.length) return res.status(401).json({ error: 'User not found' });

    const user         = rows[0];
    const accessToken  = signAccessToken({ sub: user.id, username: user.username });
    const newRefresh   = await signRefreshToken(user.id);

    res.json({ accessToken, refreshToken: newRefresh });
  } catch (err) {
    if (err.name === 'JsonWebTokenError' || err.message.includes('invalid')) {
      return res.status(401).json({ error: 'Invalid refresh token' });
    }
    next(err);
  }
}

/**
 * POST /api/auth/logout
 */
async function logout(req, res, next) {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) await revokeRefreshToken(refreshToken);
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/auth/me
 */
async function me(req, res) {
  res.json({ user: req.user });
}

module.exports = { register, login, refresh, logout, me, registerRules, loginRules };

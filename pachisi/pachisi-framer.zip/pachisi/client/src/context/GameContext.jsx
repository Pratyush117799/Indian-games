import { createContext, useContext, useState, useRef, useCallback } from 'react';
import { NAMES, TEAMS, THROW_VAL, GRACE_VALS, FACTS } from '../game/config.js';
import { PATHS, isSafe }  from '../game/paths.js';
import { HOME }            from '../game/geometry.js';
import { getMovable, getTargetPos, resolveCapturesFull, checkWin } from '../game/engine.js';
import { chooseMove }      from '../game/ai.js';

const Ctx = createContext(null);
export const useGame = () => useContext(Ctx);

const sleep = ms => new Promise(r => setTimeout(r, ms));

function mkPawns() {
  return Array(4).fill(null).map(() => Array(4).fill(null).map(() => ({ pos: -1 })));
}
function charkoPos(player, pawnIdx) {
  const qo = [[-1,-1],[1,-1],[-1,1],[1,1]][player];
  const io = [[-1,-1],[1,-1],[-1,1],[1,1]][pawnIdx];
  return { x: HOME.x + qo[0]*8 + io[0]*4, y: HOME.y + qo[1]*8 + io[1]*4 };
}
function initCoords() {
  return Array(4).fill(null).map((_,p) =>
    Array(4).fill(null).map((_,i) => charkoPos(p,i))
  );
}

export function GameProvider({ children }) {
  // ── Core state ──────────────────────────────────
  const [phase,    setPhase]    = useState('throw');
  const [cur,      setCur]      = useState(0);
  const [val,      setVal]      = useState(0);
  const [grace,    setGrace]    = useState(false);
  const [movable,  setMovable]  = useState([]);
  const [over,     setOver]     = useState(false);
  const [winner,   setWinner]   = useState(null);
  const [log,      setLog]      = useState(['The Royal Game of Pachisi begins…','You are Yellow (Team A). Red, Black & Green are AI.','Throw the cowries — you need a Grace (6, 10 or 25) to enter a pawn.']);
  const [hint,     setHint]     = useState('Yellow plays first. Throw the cowries!');
  const [stats,    setStats]    = useState(null);
  const [factText, setFactText] = useState('');
  const [showFact, setShowFact] = useState(false);
  const [gameId,   setGameId]   = useState(null);

  // ── Pawn state ───────────────────────────────────
  const [pawns,  setPawns]  = useState(mkPawns);  // logical positions
  const [coords, setCoords] = useState(initCoords); // screen coords (drive motion.g)

  // ── Refs ─────────────────────────────────────────
  const pawnsRef  = useRef(mkPawns());   // mutable mirror for async reads
  const curRef    = useRef(0);
  const phaseRef  = useRef('throw');
  const factIdx   = useRef(0);
  const factTimer = useRef(null);
  const captureCallbacks = useRef({}); // { 'p-i': (onDone) => void }

  // ── Helpers ──────────────────────────────────────
  const addLog = useCallback(txt => setLog(prev => [...prev.slice(-49), txt]), []);

  function _showFact() {
    clearTimeout(factTimer.current);
    setFactText(FACTS[factIdx.current++ % FACTS.length]);
    setShowFact(true);
    factTimer.current = setTimeout(() => setShowFact(false), 5400);
  }

  function _setPawnPos(player, pawnIdx, pos) {
    pawnsRef.current[player][pawnIdx].pos = pos;
    setPawns(prev => {
      const next = prev.map(pp => pp.map(p => ({...p})));
      next[player][pawnIdx].pos = pos;
      return next;
    });
  }

  function _setPawnCoord(player, pawnIdx, coord) {
    setCoords(prev => {
      const next = prev.map(row => [...row]);
      next[player] = [...next[player]];
      next[player][pawnIdx] = coord;
      return next;
    });
  }

  // ── Step animation (updates coords rapidly) ──────
  async function _stepPawn(player, pawnIdx, fromPos, toPos) {
    if (fromPos === -1) {
      const sq = PATHS[player][0];
      _setPawnCoord(player, pawnIdx, sq);
      _setPawnPos(player, pawnIdx, 0);
      await sleep(260);
      return;
    }
    for (let step = fromPos + 1; step <= toPos && step < 80; step++) {
      const sq = PATHS[player][step];
      _setPawnCoord(player, pawnIdx, sq);
      _setPawnPos(player, pawnIdx, step);
      await sleep(95);
    }
    if (toPos === 80) {
      _setPawnCoord(player, pawnIdx, HOME);
      _setPawnPos(player, pawnIdx, 80);
      await sleep(200);
    }
  }

  // ── Capture effect (calls into PawnLayer via callback) ──
  async function _capture(player, pawnIdx) {
    const key = `${player}-${pawnIdx}`;
    if (captureCallbacks.current[key]) {
      await captureCallbacks.current[key]();
    }
    _setPawnPos(player, pawnIdx, -1);
    _setPawnCoord(player, pawnIdx, charkoPos(player, pawnIdx));
  }

  // ── Main move executor ──────────────────────────
  async function executeMove(player, pawnIdx, throwVal, throwGrace) {
    const from = pawnsRef.current[player][pawnIdx].pos;
    const to   = getTargetPos(pawnsRef.current, player, pawnIdx, throwVal);

    await _stepPawn(player, pawnIdx, from, to);

    let bonus = throwGrace;

    if (to === 80) {
      addLog(`${NAMES[player]}'s pawn reaches home! 🏠`);
      setHint(`${NAMES[player]}'s pawn is home!`);
      const w = checkWin(pawnsRef.current);
      if (w !== null) { _handleWin(w); return; }
    } else {
      const captured = resolveCapturesFull(pawnsRef.current, player, to);
      for (const { player:cp, pawnIdx:ci } of captured) {
        addLog(`${NAMES[player]} captures ${NAMES[cp]}'s pawn! ⚔️`);
        await _capture(cp, ci);
        bonus = true;
      }
    }

    _advanceTurn(player, bonus);
  }

  // ── Turn management ──────────────────────────────
  function _advanceTurn(prevPlayer, bonus) {
    const next = bonus ? prevPlayer : (prevPlayer + 1) % 4;
    if (bonus) {
      addLog(`${NAMES[prevPlayer]} gets another throw!`);
      setHint(`${NAMES[prevPlayer]} throws again!`);
    }
    curRef.current = next;
    setCur(next);
    setPhase('throw'); phaseRef.current = 'throw';
    setVal(0); setGrace(false); setMovable([]);

    if (next === 0) {
      setHint('Your turn, Yellow. Throw the cowries!');
    } else {
      setHint(`${NAMES[next]}'s turn (AI)…`);
      setTimeout(() => _aiTurn(next), 680);
    }
  }

  function _handleWin(team) {
    setOver(true); setWinner(team);
    setPhase('done');
    const players = [0,1,2,3].filter(p => TEAMS[p] === team);
    addLog(`Team ${team===0?'A':'B'} wins! ${players.map(p=>NAMES[p]).join(' & ')} triumph!`);
  }

  // ── AI turn ──────────────────────────────────────
  function _aiTurn(player) {
    if (phaseRef.current === 'done') return;
    // Trigger the throw animation in CowriePanel via external callback
    // We expose a requestAIThrow function
    if (typeof window._requestAIThrow === 'function') {
      window._requestAIThrow(player);
    }
  }

  // ── Exposed API ──────────────────────────────────

  // Called by CowriePanel when human clicks throw
  function onHumanThrow(shells) {
    const up  = shells.reduce((a,b)=>a+b,0);
    const v   = THROW_VAL[up];
    const gr  = GRACE_VALS.has(v);
    setVal(v); setGrace(gr);
    if (gr) _showFact();

    const mv = getMovable(pawnsRef.current, 0, v, gr);
    if (!mv.length) {
      addLog(`Yellow throws ${v} — no valid move.`);
      setHint('No valid move. Turn passes.');
      setMovable([]);
      setTimeout(() => _advanceTurn(0, false), 950);
    } else {
      setMovable(mv);
      setPhase('select'); phaseRef.current = 'select';
      setHint(`Throw: ${v}${gr?' ✦ Grace!':''}  Click a pawn to move.`);
    }
    return { val:v, grace:gr };
  }

  // Called by CowriePanel when AI throw resolves
  function onAIThrow(player, shells) {
    const up = shells.reduce((a,b)=>a+b,0);
    const v  = THROW_VAL[up];
    const gr = GRACE_VALS.has(v);
    setVal(v); setGrace(gr);
    if (gr) _showFact();

    const mv = getMovable(pawnsRef.current, player, v, gr);
    if (!mv.length) {
      addLog(`${NAMES[player]} throws ${v} — no valid move.`);
      setTimeout(() => _advanceTurn(player, false), 750);
      return { val:v, grace:gr };
    }

    setPhase('anim'); phaseRef.current = 'anim';
    const pick = chooseMove(pawnsRef.current, player, v, gr);
    addLog(`${NAMES[player]} throws ${v}${gr?' ✦':''}. Pawn ${pick+1} moves.`);
    setTimeout(() => executeMove(player, pick, v, gr), 300);
    return { val:v, grace:gr };
  }

  // Called when human clicks a pawn on the board
  function onPawnClick(player, pawnIdx) {
    if (player !== 0 || phase !== 'select' || !movable.includes(pawnIdx)) return;
    setPhase('anim'); phaseRef.current = 'anim';
    setMovable([]);
    executeMove(0, pawnIdx, val, grace);
  }

  // Register capture callback from PawnLayer
  function registerCaptureCallback(player, pawnIdx, fn) {
    captureCallbacks.current[`${player}-${pawnIdx}`] = fn;
  }

  const ctx = {
    phase, cur, val, grace, movable, over, winner,
    log, hint, stats, setStats, factText, showFact,
    gameId, setGameId,
    pawns, coords,
    onHumanThrow, onAIThrow, onPawnClick,
    registerCaptureCallback,
    setPhase, setCur,
  };

  return <Ctx.Provider value={ctx}>{children}</Ctx.Provider>;
}

'use strict';

/*
 * App
 * Wires the GameEngine, BoardRenderer, and AIPlayer together.
 * Handles all DOM interactions and game-flow states.
 */
class App {
  constructor() {
    this.engine   = new GameEngine();
    this.renderer = new BoardRenderer('board-container');
    this.ai       = null;
    this.busy     = false; // true while animations are playing

    this._bindEvents();
  }

  /* ── Event bindings ──────────────────────────────────────── */

  _bindEvents() {
    /* Mode selection */
    document.getElementById('btn-vs-ai').addEventListener('click', () => {
      this._show('screen-difficulty');
    });
    document.getElementById('btn-two-player').addEventListener('click', () => {
      this._startGame('two-player', null);
    });

    /* Difficulty selection */
    document.querySelectorAll('.diff-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this._startGame('vs-ai', btn.dataset.diff);
      });
    });

    /* In-game roll button */
    document.getElementById('btn-roll').addEventListener('click', () => {
      this._onRoll();
    });

    /* Back / restart buttons */
    document.getElementById('btn-back-diff').addEventListener('click', () => {
      this._show('screen-mode');
    });
    document.getElementById('btn-restart').addEventListener('click', () => {
      this._show('screen-mode');
    });
    document.getElementById('btn-menu').addEventListener('click', () => {
      this._show('screen-mode');
    });
  }

  /* ── Screen management ───────────────────────────────────── */

  _show(screenId) {
    document.querySelectorAll('.screen').forEach(s => {
      s.style.display = 'none';
    });
    document.getElementById(screenId).style.display = 'flex';
  }

  /* ── Start a new game ────────────────────────────────────── */

  _startGame(mode, difficulty) {
    this.engine.reset(mode, difficulty);
    this.ai = (mode === 'vs-ai') ? new AIPlayer(difficulty) : null;
    this.busy = false;

    this._show('screen-game');
    this._renderAll();
    this._updateControls();

    /* If AI goes first (it doesn't by default, player 0 always starts) */
    this._maybeAITurn();
  }

  /* ── Render everything ───────────────────────────────────── */

  _renderAll() {
    const { engine } = this;
    const validIndices = engine.getValidMoveIndices();

    this.renderer.renderPieces(
      engine.pieces,
      validIndices,
      (idx) => this._onPieceClick(idx)
    );

    if (engine.phase === 'move') {
      this.renderer.showHighlights(engine.validMoves);
    } else {
      this.renderer.clearHighlights();
    }

    this._updatePlayerBars();
    this._updateDiceDisplay();
  }

  /* ── Player bars (piece counters, active state) ──────────── */

  _updatePlayerBars() {
    const { engine } = this;
    for (let p = 0; p < 2; p++) {
      const offPieces  = engine.getOffBoardPieces(p).length;
      const homePieces = engine.getHomePieces(p).length;
      const onPieces   = engine.getOnBoardPieces(p).length;

      document.getElementById(`p${p}-counts`).textContent =
        `Off: ${offPieces}  ·  On: ${onPieces}  ·  Home: ${homePieces}`;

      const bar = document.querySelector(`.player-bar[data-player="${p}"]`);
      if (bar) bar.classList.toggle('active', p === engine.currentPlayer);
    }
  }

  /* ── Dice display ────────────────────────────────────────── */

  _updateDiceDisplay() {
    const { engine } = this;
    const dr = engine.diceResult;
    const shellsEl = document.getElementById('dice-shells');
    const valueEl  = document.getElementById('dice-value');

    if (!dr) {
      shellsEl.innerHTML = `<span class="shell-prompt">Tap to roll</span>`;
      valueEl.textContent = '—';
      return;
    }

    shellsEl.innerHTML = dr.shells
      .map(up => `<span class="shell ${up ? 'mouth-up' : 'mouth-down'}">${up ? '◯' : '●'}</span>`)
      .join('');

    valueEl.textContent =
      dr.value === 0 ? 'Skip' :
      dr.value === 8 ? '8 ✦' :
      String(dr.value);
  }

  /* ── Roll / move button state ────────────────────────────── */

  _updateControls() {
    const { engine } = this;
    const rollBtn = document.getElementById('btn-roll');
    const isAITurn = engine.mode === 'vs-ai' && engine.currentPlayer === 1;

    if (engine.phase === 'gameover') {
      rollBtn.style.display = 'none';
      this._showGameOver();
      return;
    }

    if (isAITurn) {
      rollBtn.style.display = 'none';
      return;
    }

    rollBtn.style.display = 'block';

    if (engine.phase === 'roll') {
      rollBtn.textContent = 'Roll Cowries';
      rollBtn.disabled = false;
    } else {
      rollBtn.textContent = 'Select a piece ↑';
      rollBtn.disabled = true;
    }
  }

  /* ── Player pressed roll ─────────────────────────────────── */

  _onRoll() {
    if (this.busy) return;
    if (this.engine.phase !== 'roll') return;
    if (this.engine.mode === 'vs-ai' && this.engine.currentPlayer === 1) return;

    const result = this.engine.roll();
    this._renderAll();
    this._updateControls();

    if (result.skipped) {
      this._toast(
        result.reason === 'no-mouths' ? 'No mouths up — skip!' : 'No valid moves — skip!'
      );
      setTimeout(() => this._maybeAITurn(), 700);
    }
  }

  /* ── Player clicked a piece ──────────────────────────────── */

  async _onPieceClick(pieceIndex) {
    if (this.busy) return;
    if (this.engine.phase !== 'move') return;
    if (!this.engine.isValidMove(pieceIndex)) return;
    if (this.engine.mode === 'vs-ai' && this.engine.currentPlayer === 1) return;

    await this._executePieceMove(pieceIndex);
  }

  /* ── AI turn ─────────────────────────────────────────────── */

  _maybeAITurn() {
    const { engine, ai } = this;
    if (!ai) return;
    if (engine.phase === 'gameover') return;
    if (engine.currentPlayer !== 1) return;
    if (this.busy) return;

    setTimeout(async () => {
      if (engine.currentPlayer !== 1 || engine.phase !== 'roll') return;

      /* AI rolls */
      const result = engine.roll();
      this._renderAll();
      this._updateControls();

      if (result.skipped) {
        this._toast('AI skips turn');
        await delay(600);
        this._updateControls();
        return;
      }

      await delay(500);

      /* AI picks move */
      const move = ai.chooseMove(engine);
      if (move) await this._executePieceMove(move.pieceIndex);
    }, 900);
  }

  /* ── Execute a move (shared by human + AI) ───────────────── */

  async _executePieceMove(pieceIndex) {
    this.busy = true;
    const engine = this.engine;
    const move = engine.validMoves.find(m => m.pieceIndex === pieceIndex);

    this.renderer.clearHighlights();

    /* Animate step-by-step */
    const piece = engine.pieces[pieceIndex];
    await this.renderer.animateMove(piece, move.fromStep, move.toStep);

    /* Apply game logic */
    const result = engine.move(pieceIndex);

    /* Capture flash */
    if (result && result.captured.length > 0) {
      result.captured.forEach(ci => {
        /* The captured piece was at its cell before being sent back */
        const capHistory = engine.moveHistory[engine.moveHistory.length - 1];
        const capDestCell = PATH[capHistory.toStep];
        this.renderer.flashCapture(capDestCell[0], capDestCell[1]);
      });
      this._toast(`Captured! ${result.captured.length} piece${result.captured.length > 1 ? 's' : ''}`);
    }

    this._renderAll();
    this._updateControls();
    this.busy = false;

    if (result && result.winner === null) {
      this._maybeAITurn();
    }
  }

  /* ── Game over screen ────────────────────────────────────── */

  _showGameOver() {
    const winner = this.engine.winner;
    const pl = PLAYERS[winner];
    document.getElementById('gameover-winner').textContent =
      `${pl.name} (${pl.label}) wins!`;
    document.getElementById('gameover-moves').textContent =
      `${this.engine.moveHistory.length} moves played`;
    this._show('screen-gameover');
  }

  /* ── Toast notification ──────────────────────────────────── */

  _toast(msg, duration = 1400) {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.classList.add('visible');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => el.classList.remove('visible'), duration);
  }
}

/* Bootstrap */
document.addEventListener('DOMContentLoaded', () => {
  window.ashtapada = new App();
});

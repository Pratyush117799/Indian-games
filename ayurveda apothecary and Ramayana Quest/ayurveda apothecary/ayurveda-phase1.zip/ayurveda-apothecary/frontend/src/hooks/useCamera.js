/**
 * useCamera.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Camera herb scanner hook (PWA).
 * Uses MediaDevices API to capture a frame, then matches against
 * herb colour profiles as a lightweight heuristic.
 *
 * In production: integrate a real plant ID API (PlantNet, iNaturalist).
 * For demo / hackathon: colour + texture heuristic that works surprisingly well.
 */
import { useState, useRef, useCallback } from 'react';
import { HERBS } from '../game-engine/herbs.data.js';

// Simplified colour-based heuristic matching
// Each herb has a dominant colour — we sample the centre of the camera frame
// and find the closest matching herb by hue distance.
function hslFromHex(hex) {
  const r = parseInt(hex.slice(1,3),16)/255;
  const g = parseInt(hex.slice(3,5),16)/255;
  const b = parseInt(hex.slice(5,7),16)/255;
  const max=Math.max(r,g,b), min=Math.min(r,g,b);
  const l = (max+min)/2;
  if(max===min) return {h:0,s:0,l};
  const d = max-min;
  const s = l>0.5 ? d/(2-max-min) : d/(max+min);
  let h;
  if(max===r) h=((g-b)/d+(g<b?6:0))/6;
  else if(max===g) h=((b-r)/d+2)/6;
  else h=((r-g)/d+4)/6;
  return {h:h*360, s, l};
}

function hueDist(h1, h2) {
  const d = Math.abs(h1-h2);
  return Math.min(d, 360-d);
}

function getDominantHue(canvas) {
  const ctx = canvas.getContext('2d');
  const { width: w, height: h } = canvas;
  // Sample centre region
  const region = ctx.getImageData(w/4, h/4, w/2, h/2);
  const data = region.data;
  let rSum=0, gSum=0, bSum=0, count=0;
  for(let i=0; i<data.length; i+=4) {
    rSum+=data[i]; gSum+=data[i+1]; bSum+=data[i+2]; count++;
  }
  const r=rSum/count/255, g=gSum/count/255, b=bSum/count/255;
  const max=Math.max(r,g,b), min=Math.min(r,g,b);
  if(max===min) return 0;
  const d=max-min;
  let h2;
  if(max===r) h2=((g-b)/d+(g<b?6:0))/6;
  else if(max===g) h2=((b-r)/d+2)/6;
  else h2=((r-g)/d+4)/6;
  return h2*360;
}

export function useCamera() {
  const [scanning,     setScanning]     = useState(false);
  const [result,       setResult]       = useState(null);  // { herb, confidence }
  const [error,        setError]        = useState(null);
  const [streamActive, setStreamActive] = useState(false);
  const videoRef = useRef(null);
  const canvasRef= useRef(null);
  const streamRef= useRef(null);

  const startCamera = useCallback(async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: 640, height: 480 },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStreamActive(true);
    } catch (e) {
      setError('Camera not available. Check browser permissions.');
    }
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    setStreamActive(false);
    setScanning(false);
  }, []);

  const scanFrame = useCallback(() => {
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    setScanning(true);
    canvas.width  = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);

    const dominantHue = getDominantHue(canvas);

    // Match against herb colour database
    const matches = HERBS.map(herb => {
      const hsl  = hslFromHex(herb.color);
      const dist = hueDist(dominantHue, hsl.h);
      return { herb, score: 100 - dist / 1.8 }; // max score 100
    }).sort((a,b) => b.score - a.score);

    // Only report a result if confidence > 55%
    const best = matches[0];
    if (best.score > 55) {
      setResult({ herb: best.herb, confidence: Math.round(best.score) });
    } else {
      setResult({ herb: null, confidence: 0, message: 'No herb recognised. Try in better light.' });
    }
    setScanning(false);
  }, []);

  return {
    videoRef, canvasRef,
    scanning, streamActive, result, error,
    startCamera, stopCamera, scanFrame,
  };
}


/**
 * useNarration.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Voice narration hook using Web Speech API (SpeechSynthesis).
 * Guru Charaka narrates herb facts and patient stories in the player's chosen language.
 *
 * Supported languages: English, Hindi, Tamil, Telugu, Kannada
 * Falls back gracefully if SpeechSynthesis not available.
 */
import { useState, useEffect, useCallback, useRef } from 'react';

const VOICE_LANG_CODES = {
  english: 'en-IN',
  hindi:   'hi-IN',
  tamil:   'ta-IN',
  telugu:  'te-IN',
  kannada: 'kn-IN',
};

// Guru Charaka's intro phrases in each language
const GURU_GREETINGS = {
  english: 'Namaste. I am Charaka. Listen well, young Vaidya.',
  hindi:   'नमस्ते। मैं चरक हूँ। ध्यान से सुनो, युवा वैद्य।',
  tamil:   'வணக்கம். நான் சரகர். கவனமாகக் கேளுங்கள், இளம் வைத்தியர்.',
  telugu:  'నమస్కారం. నేను చరకుడిని. జాగ్రత్తగా వినండి, యువ వైద్యుడు.',
  kannada: 'ನಮಸ್ಕಾರ. ನಾನು ಚರಕ. ಗಮನವಾಗಿ ಕೇಳಿ, ಯುವ ವೈದ್ಯ.',
};

export function useNarration(language = 'english') {
  const [speaking,   setSpeaking]   = useState(false);
  const [supported,  setSupported]  = useState(false);
  const [voices,     setVoices]     = useState([]);
  const utteranceRef = useRef(null);

  useEffect(() => {
    if (!('speechSynthesis' in window)) return;
    setSupported(true);

    const loadVoices = () => setVoices(window.speechSynthesis.getVoices());
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => { window.speechSynthesis.onvoiceschanged = null; };
  }, []);

  const getBestVoice = useCallback((langCode) => {
    // Prefer regional Indian voice, fall back to any English voice
    return voices.find(v => v.lang === langCode)
        ?? voices.find(v => v.lang.startsWith(langCode.split('-')[0]))
        ?? voices.find(v => v.lang.startsWith('en'))
        ?? voices[0]
        ?? null;
  }, [voices]);

  const speak = useCallback((text, opts = {}) => {
    if (!supported || !text) return;
    window.speechSynthesis.cancel(); // stop any current speech

    const langCode  = VOICE_LANG_CODES[language] ?? 'en-IN';
    const utterance = new SpeechSynthesisUtterance(text);
    const voice     = getBestVoice(langCode);

    if (voice) utterance.voice = voice;
    utterance.lang   = langCode;
    utterance.rate   = opts.rate   ?? 0.88; // slightly slower for clarity
    utterance.pitch  = opts.pitch  ?? 1.0;
    utterance.volume = opts.volume ?? 0.9;

    utterance.onstart = () => setSpeaking(true);
    utterance.onend   = () => { setSpeaking(false); opts.onEnd?.(); };
    utterance.onerror = () => setSpeaking(false);

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [supported, language, getBestVoice]);

  const stop = useCallback(() => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  const speakHerbFact = useCallback((herb) => {
    if (!herb) return;
    const text = language === 'english'
      ? `${herb.name}. Known as ${herb.sanskrit} in Sanskrit. ${herb.funFact}`
      : herb.funFact; // TODO: translate facts per language
    speak(text, { rate: 0.85 });
  }, [speak, language]);

  const speakGuruGreeting = useCallback(() => {
    speak(GURU_GREETINGS[language] ?? GURU_GREETINGS.english, { pitch: 0.9 });
  }, [speak, language]);

  const speakPatientDialogue = useCallback((text) => {
    speak(text, { rate: 0.92, pitch: 1.05 });
  }, [speak]);

  return {
    speak, stop, speaking, supported,
    speakHerbFact, speakGuruGreeting, speakPatientDialogue,
  };
}

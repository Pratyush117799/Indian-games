/**
 * types.js — Shared constants used by both frontend and backend
 */

export const HERB_RARITIES = ['common', 'uncommon', 'rare', 'legendary'];
export const DOSHAS        = ['vata', 'pitta', 'kapha'];
export const SEASONS       = ['vasanta','grishma','varsha','sharad','hemanta','shishira'];
export const RECIPE_CATEGORIES = ['churna','kwatha','avaleha','taila','ghrita','lepa','arka','swarasa'];
export const QUEST_OUTCOMES    = ['success','partial','failure'];
export const RANKS = [
  'Shishya','Chikitsaka','Aushadhika','Vaidya',
  'Visharada','Acharya','Mahavaidya','Dhanvantari','Charaka','Parama Vaidya',
];
export const VIRTUE_TYPES = ['dharma','courage','wisdom','devotion'];

// ═══════════════════════════════════════════════════
//  STATE · Mutable game state singleton
// ═══════════════════════════════════════════════════

// Single source of truth for all game state.
// All modules import this object and mutate it directly.
export const G = {
  gameId:    null,   // server-assigned UUID
  cur:       0,      // current player (0–3)
  phase:     'init', // 'init'|'throw'|'select'|'anim'|'done'
  val:       0,      // current throw value
  grace:     false,  // current throw is a Grace
  busy:      false,  // animation / AI in progress
  over:      false,  // game finished
  movable:   [],     // pawn indices valid for current throw
  pawns:     [],     // [player][pawnIdx] = { pos: -1..80 }
  hintsOn:   true,
};

// Reset all state to start a fresh game
export function resetState() {
  G.gameId   = null;
  G.cur      = 0;
  G.phase    = 'throw';
  G.val      = 0;
  G.grace    = false;
  G.busy     = false;
  G.over     = false;
  G.movable  = [];
  G.hintsOn  = true;
  G.pawns    = [];
  for (let p = 0; p < 4; p++) {
    G.pawns[p] = [];
    for (let i = 0; i < 4; i++) {
      G.pawns[p].push({ pos: -1 });
    }
  }
}

// Serialise state for server auto-save (compact)
export function serialiseState() {
  return {
    cur:    G.cur,
    phase:  G.phase,
    pawns:  G.pawns.map(pp => pp.map(p => p.pos)),
  };
}

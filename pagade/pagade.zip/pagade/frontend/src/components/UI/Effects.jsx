/**
 * CaptureEffect — brief full-screen border flash when a capture happens.
 * Also shows a floating "captured!" indicator near the board.
 */

import React, { useEffect, useState } from 'react';
import { PLAYER_COLORS, PLAYER_NAMES } from '../../game/constants';

export default function CaptureEffect({ lastEvent }) {
  const [flash, setFlash] = useState(null);

  useEffect(() => {
    if (lastEvent?.type !== 'CAPTURE') return;
    setFlash(lastEvent);
    const t = setTimeout(() => setFlash(null), 700);
    return () => clearTimeout(t);
  }, [lastEvent]);

  if (!flash) return null;

  const attackerColor = PLAYER_COLORS[flash.attackerId] || '#D4A017';

  return (
    <>
      {/* Screen border flash */}
      <div
        style={{
          position: 'fixed',
          inset: 0,
          pointerEvents: 'none',
          zIndex: 200,
          boxShadow: `inset 0 0 60px 20px ${attackerColor}55`,
          animation: 'captureFlash 0.7s ease-out forwards',
        }}
      />
      <style>{`
        @keyframes captureFlash {
          0%   { opacity: 1; }
          60%  { opacity: 0.7; }
          100% { opacity: 0; }
        }
        @keyframes captureTagFloat {
          0%   { transform: translateY(0) scale(0.8); opacity: 0; }
          20%  { transform: translateY(-8px) scale(1.1); opacity: 1; }
          80%  { transform: translateY(-24px) scale(1); opacity: 1; }
          100% { transform: translateY(-36px) scale(0.9); opacity: 0; }
        }
      `}</style>
    </>
  );
}

export function SafeEffect({ lastEvent }) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (lastEvent?.type !== 'SAFE') return;
    setShow(true);
    const t = setTimeout(() => setShow(false), 1000);
    return () => clearTimeout(t);
  }, [lastEvent]);

  if (!show) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: 100,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 50,
      pointerEvents: 'none',
      animation: 'safeFloat 1s ease-out forwards',
    }}>
      <style>{`
        @keyframes safeFloat {
          0%   { transform: translateX(-50%) translateY(0) scale(0.8); opacity: 0; }
          20%  { transform: translateX(-50%) translateY(-8px) scale(1.1); opacity: 1; }
          80%  { transform: translateX(-50%) translateY(-20px); opacity: 0.8; }
          100% { transform: translateX(-50%) translateY(-32px); opacity: 0; }
        }
      `}</style>
      <span style={{ fontSize: '1.5rem' }}>🪷</span>
    </div>
  );
}

export function HomeEffect({ lastEvent }) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (lastEvent?.type !== 'HOME') return;
    setShow(true);
    const t = setTimeout(() => setShow(false), 1200);
    return () => clearTimeout(t);
  }, [lastEvent]);

  if (!show) return null;

  return (
    <div style={{
      position: 'fixed',
      top: '40%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      zIndex: 50,
      pointerEvents: 'none',
      textAlign: 'center',
      animation: 'homeArrival 1.2s ease-out forwards',
    }}>
      <style>{`
        @keyframes homeArrival {
          0%   { transform: translate(-50%, -50%) scale(0.5) rotate(-20deg); opacity: 0; }
          30%  { transform: translate(-50%, -50%) scale(1.3) rotate(5deg);  opacity: 1; }
          70%  { transform: translate(-50%, -50%) scale(1.1) rotate(0deg);  opacity: 1; }
          100% { transform: translate(-50%, -50%) scale(0.9) rotate(0deg);  opacity: 0; }
        }
      `}</style>
      <span style={{ fontSize: '2.4rem' }}>✦</span>
    </div>
  );
}

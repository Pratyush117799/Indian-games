-- ════════════════════════════════════════════════════════════
-- Ashtapada — Database Schema (PostgreSQL)
-- ════════════════════════════════════════════════════════════

-- ── Users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username        VARCHAR(32) UNIQUE NOT NULL,
  email           VARCHAR(128) UNIQUE,
  password_hash   VARCHAR(256),
  region          VARCHAR(64) DEFAULT 'India',
  avatar_index    SMALLINT DEFAULT 0,
  wins            INTEGER DEFAULT 0,
  losses          INTEGER DEFAULT 0,
  games_played    INTEGER DEFAULT 0,
  streak          INTEGER DEFAULT 0,
  best_streak     INTEGER DEFAULT 0,
  unlocked_skins  TEXT[] DEFAULT ARRAY['default'],
  daily_plays     INTEGER DEFAULT 0,
  last_played     DATE,
  joined_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_wins ON users(wins DESC);
CREATE INDEX IF NOT EXISTS idx_users_region ON users(region);

-- ── Games ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS games (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mode            VARCHAR(16) NOT NULL,       -- vs-ai | two-player | online
  difficulty      VARCHAR(16),               -- beginner | prince | maharaja
  host_user_id    UUID REFERENCES users(id),
  guest_user_id   UUID REFERENCES users(id),
  status          VARCHAR(12) DEFAULT 'waiting', -- waiting | active | finished
  winner          SMALLINT,                  -- 0 | 1 | NULL
  total_moves     INTEGER DEFAULT 0,
  duration_secs   INTEGER,                   -- seconds from start to finish
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  finished_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_games_status     ON games(status);
CREATE INDEX IF NOT EXISTS idx_games_host       ON games(host_user_id);
CREATE INDEX IF NOT EXISTS idx_games_created_at ON games(created_at DESC);

-- ── Moves ────────────────────────────────────────────────────
-- Full move log for replay system
CREATE TABLE IF NOT EXISTS moves (
  id            BIGSERIAL PRIMARY KEY,
  game_id       UUID REFERENCES games(id) ON DELETE CASCADE,
  move_number   INTEGER NOT NULL,
  player        SMALLINT NOT NULL,           -- 0 or 1
  piece_index   SMALLINT NOT NULL,           -- 0-7 (4 per player)
  from_step     SMALLINT NOT NULL,           -- -1 = off-board
  to_step       SMALLINT NOT NULL,
  dice_value    SMALLINT NOT NULL,           -- 0-3 or 8
  shells        BOOLEAN[4] NOT NULL,         -- individual shell results
  captured      SMALLINT[],                  -- piece indices captured (if any)
  is_castle     BOOLEAN DEFAULT FALSE,       -- landed on a castle?
  timestamp     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_moves_game ON moves(game_id, move_number);

-- ── Daily Challenge ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS daily_challenges (
  id            SERIAL PRIMARY KEY,
  challenge_date DATE UNIQUE NOT NULL DEFAULT CURRENT_DATE,
  board_state   JSONB NOT NULL,              -- serialised piece positions
  par_moves     SMALLINT NOT NULL,           -- target move count
  description   TEXT
);

-- ── Challenge completions ────────────────────────────────────
CREATE TABLE IF NOT EXISTS challenge_completions (
  id              BIGSERIAL PRIMARY KEY,
  challenge_id    INTEGER REFERENCES daily_challenges(id),
  user_id         UUID REFERENCES users(id),
  moves_taken     INTEGER NOT NULL,
  completed_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (challenge_id, user_id)
);

-- ── Board skins (cosmetic progression) ──────────────────────
CREATE TABLE IF NOT EXISTS board_skins (
  id          VARCHAR(32) PRIMARY KEY,       -- 'default', 'vedic', 'hampi', 'silk'
  name        VARCHAR(64) NOT NULL,
  description TEXT,
  unlock_at   INTEGER DEFAULT 0             -- wins required
);

INSERT INTO board_skins (id, name, description, unlock_at) VALUES
  ('default', 'Sandstone',     'Classic carved stone — the original Ashtapada look',    0),
  ('vedic',   'Vedic Parchment','Aged manuscript texture with Sanskrit script accents',  5),
  ('hampi',   'Hampi Stone',    'Etched basalt surface inspired by Hampi temple floors', 15),
  ('silk',    'Mysore Silk',    'Rich deep-indigo silk board with gold thread borders',  30)
ON CONFLICT DO NOTHING;

/**
 * server.js — Ayurveda Apothecary Backend
 */
import express            from 'express';
import { createServer }   from 'http';
import { Server }         from 'socket.io';
import cors               from 'cors';
import helmet             from 'helmet';
import rateLimit          from 'express-rate-limit';
import 'dotenv/config';

import { playerRouter }   from './routes/player.js';
import { gardenRouter }   from './routes/garden.js';
import { bazaarRouter }   from './routes/bazaar.js';
import { sanskritiRouter} from './routes/sanskriti.js';
import { initBazaarSocket }from './websocket/bazaarRoom.js';

const app    = express();
const http   = createServer(app);
const io     = new Server(http, {
  cors: { origin: process.env.CLIENT_URL ?? 'http://localhost:5173', methods: ['GET','POST'] },
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL ?? 'http://localhost:5173' }));
app.use(express.json({ limit: '64kb' }));
app.use(rateLimit({ windowMs: 15*60*1000, max: 500 }));

app.use('/api/players',   playerRouter);
app.use('/api/garden',    gardenRouter);
app.use('/api/bazaar',    bazaarRouter);
app.use('/api/sanskriti', sanskritiRouter);

app.get('/health', (_, res) => res.json({ status: 'ok', ts: new Date() }));

initBazaarSocket(io);

const PORT = process.env.PORT ?? 3002;
http.listen(PORT, () => console.log(`🌿  Ayurveda Apothecary backend · port ${PORT}`));

import { Router } from 'express';
import { valmikiRouteHandler } from '../ai/valmiki.js';
export const valmikiRouter = Router();
valmikiRouter.post('/', valmikiRouteHandler);

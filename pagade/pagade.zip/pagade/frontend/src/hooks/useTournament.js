/**
 * useTournament — manages a local 4-player single-elimination bracket.
 *
 * Bracket: SF1 (p0 vs p1), SF2 (p2 vs p3), Final (SF1 winner vs SF2 winner)
 *
 * State:
 *   { phase: 'SF1'|'SF2'|'FINAL'|'DONE', players:[0,1,2,3],
 *     results: { sf1: winner_id, sf2: winner_id, final: winner_id },
 *     matchPlayers: [p0, p1]  — the two players in the current match }
 */

import { useState, useCallback } from 'react';

export function useTournament() {
  const [tournament, setTournament] = useState(null);

  const startTournament = useCallback((diceStyle, aiLevel) => {
    setTournament({
      phase: 'BRACKET',   // BRACKET → playing a match → back to BRACKET
      diceStyle,
      aiLevel,
      playerIds: [0, 1, 2, 3],  // 0 = human, 1-3 = AI
      results: { sf1: null, sf2: null, final: null },
      currentMatch: null,  // { matchId: 'sf1'|'sf2'|'final', p0, p1 }
    });
  }, []);

  const startMatch = useCallback((matchId) => {
    setTournament(prev => {
      if (!prev) return null;
      let p0, p1;
      if (matchId === 'sf1')   { p0 = 0; p1 = 1; }
      if (matchId === 'sf2')   { p0 = 2; p1 = 3; }
      if (matchId === 'final') {
        p0 = prev.results.sf1;
        p1 = prev.results.sf2;
      }
      return { ...prev, phase: 'PLAYING', currentMatch: { matchId, p0, p1 } };
    });
  }, []);

  const recordMatchResult = useCallback((matchId, winnerId) => {
    setTournament(prev => {
      if (!prev) return null;
      const results = { ...prev.results, [matchId]: winnerId };
      const allDone = results.sf1 !== null && results.sf2 !== null && results.final !== null;
      return {
        ...prev,
        phase: 'BRACKET',
        results,
        currentMatch: null,
        champion: allDone ? results.final : null,
      };
    });
  }, []);

  const resetTournament = useCallback(() => setTournament(null), []);

  // Derive which match is next
  const getNextMatch = (t) => {
    if (!t || !t.results) return null;
    if (t.results.sf1 === null) return 'sf1';
    if (t.results.sf2 === null) return 'sf2';
    if (t.results.final === null) return 'final';
    return null;
  };

  return {
    tournament,
    startTournament,
    startMatch,
    recordMatchResult,
    resetTournament,
    getNextMatch: () => tournament ? getNextMatch(tournament) : null,
  };
}

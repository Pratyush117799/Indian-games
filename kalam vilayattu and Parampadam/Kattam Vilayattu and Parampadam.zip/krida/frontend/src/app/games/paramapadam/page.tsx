'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Hash, Users } from 'lucide-react';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function ParamapadamLobbyPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [maxPlayers, setMaxPlayers] = useState(2);
  const [joinCode,   setJoinCode]   = useState('');
  const [loading,    setLoading]    = useState(false);
  const [tab,        setTab]        = useState<'create' | 'join'>('create');

  async function handleCreate() {
    if (!user) return router.push('/auth/login');
    setLoading(true);
    try {
      const { data } = await api.post('/games/paramapadam/rooms', { maxPlayers });
      toast.success(`Room ${data.roomCode} created!`);
      router.push(`/games/paramapadam/play?room=${data.roomCode}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Could not create room');
    } finally { setLoading(false); }
  }

  async function handleJoin(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return router.push('/auth/login');
    const code = joinCode.trim().toUpperCase();
    setLoading(true);
    try {
      await api.post(`/rooms/${code}/join`);
      router.push(`/games/paramapadam/play?room=${code}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Could not join room');
    } finally { setLoading(false); }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 space-y-8">
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold text-temple">Paramapadam</h1>
        <p className="font-tamil text-clay/70">பரமபதம்</p>
        <p className="text-sm text-gray-500 max-w-md mx-auto">
          Tamil Vaishnava spiritual board game. Journey from Patalam (Square 1) to Vaikuntam (Square 100).
          The sacred ancestor of Snakes & Ladders, played in temples since 1000 CE.
        </p>
      </div>

      <div className="flex rounded-xl overflow-hidden border border-clay/20">
        {(['create','join'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2.5 text-sm font-semibold transition ${tab === t ? 'bg-clay text-cream' : 'bg-white text-clay hover:bg-clay/5'}`}>
            {t === 'create' ? '+ Create Room' : '→ Join Room'}
          </button>
        ))}
      </div>

      {tab === 'create' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card space-y-6">
          <div>
            <label className="text-sm font-semibold text-gray-600 block mb-3">
              Number of Players
            </label>
            <div className="flex gap-3">
              {[2, 3, 4, 6].map(n => (
                <button key={n} onClick={() => setMaxPlayers(n)}
                  className={`flex-1 py-3 rounded-xl border-2 font-bold text-lg transition ${
                    maxPlayers === n ? 'border-clay bg-clay/5 text-temple' : 'border-clay/15 text-gray-400 hover:border-clay/30'
                  }`}>
                  {n}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
              <Users size={11} /> {maxPlayers} players — {maxPlayers > 2 ? 'more chaos, more fun!' : 'head to head'}
            </p>
          </div>
          <button onClick={handleCreate} disabled={loading} className="btn-primary w-full text-base py-3">
            {loading ? 'Creating…' : 'Create Room →'}
          </button>
        </motion.div>
      )}

      {tab === 'join' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card space-y-4">
          <p className="text-sm text-gray-500">Enter the room code shared by the host.</p>
          <form onSubmit={handleJoin} className="space-y-3">
            <div className="relative">
              <Hash size={16} className="absolute left-3 top-3 text-clay/40" />
              <input value={joinCode}
                onChange={e => setJoinCode(e.target.value.toUpperCase().slice(0, 6))}
                className="input pl-8 font-mono text-lg tracking-widest uppercase"
                placeholder="ABC123" maxLength={6} />
            </div>
            <button type="submit" disabled={loading || joinCode.length !== 6} className="btn-primary w-full py-3">
              {loading ? 'Joining…' : 'Join Room →'}
            </button>
          </form>
        </motion.div>
      )}

      <div className="card border-l-4 border-leaf bg-leaf/5 space-y-1 text-sm text-gray-600">
        <p className="font-semibold text-temple">How to play</p>
        <p>① Roll a <strong>1</strong> to enter the board (Square 1 = Patalam).</p>
        <p>② Roll the dice each turn and advance your piece.</p>
        <p>③ 🪜 Land on a ladder bottom → climb up (bonus turn).</p>
        <p>④ 🐍 Land on a snake head → slide down.</p>
        <p>⑤ Roll a <strong>6</strong> → bonus turn. Reach Square 100 exactly to win.</p>
        <p className="text-xs text-gray-400 italic mt-1">
          "Narayana! Narayana!" — chant with each roll in the Vaikunta Ekadasi tradition.
        </p>
      </div>
    </div>
  );
}

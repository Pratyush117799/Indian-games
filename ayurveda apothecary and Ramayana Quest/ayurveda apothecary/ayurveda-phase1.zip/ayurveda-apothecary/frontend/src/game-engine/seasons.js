/**
 * seasons.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Real-world time → Ayurvedic season calculator.
 *
 * The Ayurvedic calendar (Ritu) divides the year into 6 seasons of ~2 months each.
 * We map this to the Indian subcontinent's climate calendar.
 *
 * The living herb garden responds to the real device date:
 *   - Herbs native to the current season grow at 2× speed
 *   - Herbs out of season grow at 0.5× speed or are dormant
 *   - Patients present with season-appropriate conditions
 *   - The sky, light, and garden visuals change with real time of day + season
 */

/* ── THE SIX RITUS (Ayurvedic Seasons) ────────────────────────────────────── */

export const RITUS = {
  vasanta: {
    id:         'vasanta',
    name:       'Vasanta',
    english:    'Spring',
    sanskrit:   'वसंत',
    months:     [2, 3],         // March–April (0-indexed: 2=March, 3=April)
    dominantDosha: 'kapha',
    qualities:  ['wet', 'warm', 'heavy'],
    description:'The season of renewal. Kapha (accumulated in winter) begins to liquefy. Flowers bloom. Bees return.',
    weather:    'Mild and pleasant. Flowers everywhere. Pollen in the air.',
    garden: {
      sky:      '#87CEEB',
      ambient:  '#FFE4B5',
      ground:   '#8BC34A',
      moisture: 0.65,
      temp:     22,
    },
    commonAilments: ['Kapha disorders', 'Allergies', 'Respiratory congestion', 'Skin rashes', 'Low energy', 'Sinus issues'],
    bestFoods:  ['Light, dry, warm foods', 'Bitter greens', 'Honey', 'Barley', 'Mung beans'],
    avoidFoods: ['Heavy, oily, sweet foods', 'Dairy', 'Cold drinks'],
    ritualPractice: 'Daily dry brushing. Vamana (gentle emesis) to clear accumulated Kapha.',
    flourishingHerbs: ['tulsi', 'arjuna', 'manjistha', 'punarnava', 'moringa', 'rose', 'palash'],
    dormantHerbs:    ['ashwagandha', 'kesar', 'shilajit'],
    colour:     '#FFD166',
    icon:       'flower',
  },

  grishma: {
    id:         'grishma',
    name:       'Grishma',
    english:    'Summer',
    sanskrit:   'ग्रीष्म',
    months:     [4, 5],         // May–June
    dominantDosha: 'pitta',
    qualities:  ['hot', 'dry', 'sharp', 'light'],
    description:'The hottest season. Pitta aggravates. Sun is supreme. Everything dries out.',
    weather:    'Intense heat. Harsh sun. Dry winds. Sometimes dust storms.',
    garden: {
      sky:      '#87CEEB',
      ambient:  '#FFA500',
      ground:   '#D2B48C',
      moisture: 0.25,
      temp:     38,
    },
    commonAilments: ['Pitta disorders', 'Acid reflux', 'Sunstroke', 'Skin inflammation', 'Anger & irritability', 'Dehydration'],
    bestFoods:  ['Cool, sweet, liquid foods', 'Coconut water', 'Sweet fruits', 'Rice', 'Milk', 'Ghee'],
    avoidFoods: ['Spicy, sour, salty foods', 'Alcohol', 'Strenuous exercise'],
    ritualPractice: 'Moonlit walks. Cool water baths. Rest during afternoon. Sweet coconut drinks.',
    flourishingHerbs: ['aloe', 'sandalwood', 'rose', 'shatavari', 'amla', 'shankhpushpi', 'amaltas', 'karela'],
    dormantHerbs:    ['long_pepper', 'chitraka', 'pepper'],
    colour:     '#F4A261',
    icon:       'sun',
  },

  varsha: {
    id:         'varsha',
    name:       'Varsha',
    english:    'Monsoon',
    sanskrit:   'वर्षा',
    months:     [6, 7],         // July–August
    dominantDosha: 'vata',
    qualities:  ['wet', 'cold', 'cloudy', 'windy'],
    description:'The monsoon arrives. Vata aggravates from cold and wind. But herbs flourish like no other time.',
    weather:    'Heavy rains. Thunderstorms. Cool but humid. Everything turns lush green.',
    garden: {
      sky:      '#4A7C9E',
      ambient:  '#B8D4E8',
      ground:   '#3A7A3A',
      moisture: 0.95,
      temp:     26,
    },
    commonAilments: ['Vata disorders', 'Joint pain', 'Digestive weakness', 'Skin diseases', 'Fevers', 'Gas & bloating'],
    bestFoods:  ['Warm, easily digestible foods', 'Old rice', 'Ghee', 'Rock salt', 'Ginger tea', 'Cooked vegetables'],
    avoidFoods: ['Raw vegetables', 'Leafy greens (contaminated in rain)', 'River water', 'Fermented foods'],
    ritualPractice: 'Panchakarma season. Abhyanga with warm sesame oil. Avoid sleeping during day.',
    flourishingHerbs: ['tulsi', 'brahmi', 'guduchi', 'ginger', 'turmeric', 'bhringraj', 'punarnava', 'vidanga', 'musta'],
    dormantHerbs:    ['kesar', 'jatamansi', 'shilajit'],
    colour:     '#48CAE4',
    icon:       'rain',
  },

  sharad: {
    id:         'sharad',
    name:       'Sharad',
    english:    'Autumn',
    sanskrit:   'शरद',
    months:     [8, 9],         // September–October
    dominantDosha: 'pitta',
    qualities:  ['hot', 'bright', 'clear'],
    description:'Post-monsoon clarity. Pitta that was suppressed by rains now releases. The harvest season.',
    weather:    'Clear, sunny skies. Pleasant temperatures. Harvest time. Full moon nights are stunning.',
    garden: {
      sky:      '#90B4CE',
      ambient:  '#E8C88A',
      ground:   '#7A9A5A',
      moisture: 0.50,
      temp:     28,
    },
    commonAilments: ['Pitta disorders (released from monsoon)', 'Skin disorders', 'Blood diseases', 'Fever', 'Acidity'],
    bestFoods:  ['Bitter, astringent, sweet foods', 'Amla', 'Barley', 'Gooseberry', 'Rice', 'Moonlit water'],
    avoidFoods: ['Excessive oil', 'Sour foods', 'Alcohol', 'Sleeping during day'],
    ritualPractice: 'Virechana (purgation therapy). Fasting on Ekadashi. Moonbathing.',
    flourishingHerbs: ['amla', 'haritaki', 'bibhitaki', 'kesar', 'lotus', 'brahma_kamal', 'nagkesar'],
    dormantHerbs:    ['tulsi', 'moringa'],
    colour:     '#F6B73C',
    icon:       'harvest',
  },

  hemanta: {
    id:         'hemanta',
    name:       'Hemanta',
    english:    'Early Winter',
    sanskrit:   'हेमंत',
    months:     [10, 11],       // November–December
    dominantDosha: 'kapha',
    qualities:  ['cold', 'heavy', 'dense', 'stable'],
    description:'Cooling begins. Digestion fire is strongest in this season. The body builds reserves.',
    weather:    'Cool and crisp. Clear skies. Shorter days. Perfect for vigorous activity.',
    garden: {
      sky:      '#B0C8E0',
      ambient:  '#D4C8A8',
      ground:   '#6A8A5A',
      moisture: 0.40,
      temp:     18,
    },
    commonAilments: ['Low immunity building', 'Respiratory susceptibility', 'Joint stiffness', 'Dry skin begins'],
    bestFoods:  ['Nourishing, oily, sweet foods', 'Meat (traditionally)', 'Milk', 'Sesame', 'Jaggery', 'Urad dal'],
    avoidFoods: ['Light, dry, cold foods', 'Excessive fasting', 'Cold drinks'],
    ritualPractice: 'Build strength and immunity. Vigorous exercise. Warm oil massage daily.',
    flourishingHerbs: ['ashwagandha', 'shatavari', 'guggul', 'vidari', 'bala', 'methi', 'cinnamon'],
    dormantHerbs:    ['lotus', 'moringa'],
    colour:     '#B5C8B4',
    icon:       'leaf_fall',
  },

  shishira: {
    id:         'shishira',
    name:       'Shishira',
    english:    'Late Winter',
    sanskrit:   'शिशिर',
    months:     [0, 1],         // January–February
    dominantDosha: 'vata',
    qualities:  ['cold', 'dry', 'rough', 'windy'],
    description:'The coldest time. Vata increases with cold and dryness. Body needs warming and moistening.',
    weather:    'Cold, dry, and windy. Frost in northern India. Body craves warmth and nourishment.',
    garden: {
      sky:      '#9DB4C8',
      ambient:  '#C8C0A8',
      ground:   '#5A7850',
      moisture: 0.30,
      temp:     12,
    },
    commonAilments: ['Vata aggravation', 'Joint pain & stiffness', 'Dry skin & lips', 'Constipation', 'Respiratory issues', 'Cold & flu'],
    bestFoods:  ['Hot, oily, salty, sour, sweet foods', 'Sesame', 'Ghee', 'Hot soups', 'Warm dairy', 'Root vegetables'],
    avoidFoods: ['Cold, dry, light foods', 'Excessive raw salads', 'Cold water'],
    ritualPractice: 'Stay warm. Heavy blankets. Sunbathe morning. Warm sesame oil massage. Hot water drinking.',
    flourishingHerbs: ['ashwagandha', 'vidanga', 'camphor', 'guggul', 'jatamansi', 'kutki', 'shilajit'],
    dormantHerbs:    ['lotus', 'rose', 'brahma_kamal'],
    colour:     '#A8C4D8',
    icon:       'snowflake',
  },
};

/* ── TIME OF DAY → DOSHA MAPPING ─────────────────────────────────────────── */

export const TIME_DOSHAS = [
  { start: 6,  end: 10, dosha: 'kapha', quality: 'slow, heavy, grounded', energy: 'low' },
  { start: 10, end: 14, dosha: 'pitta', quality: 'sharp, focused, active', energy: 'peak' },
  { start: 14, end: 18, dosha: 'vata',  quality: 'creative, variable, mobile', energy: 'medium' },
  { start: 18, end: 22, dosha: 'kapha', quality: 'calm, reflective, winding down', energy: 'low' },
  { start: 22, end: 2,  dosha: 'pitta', quality: 'processing, dreaming, metabolising', energy: 'deep' },
  { start: 2,  end: 6,  dosha: 'vata',  quality: 'spiritual, intuitive, light sleep', energy: 'rising' },
];

/* ── CORE SEASON ENGINE ────────────────────────────────────────────────────── */

/**
 * Get the current Ayurvedic season from real-world date.
 * @param {Date} [date] — defaults to now
 * @returns {Object} current Ritu
 */
export function getCurrentSeason(date = new Date()) {
  const month = date.getMonth(); // 0-11
  return Object.values(RITUS).find(r => r.months.includes(month)) ?? RITUS.vasanta;
}

/**
 * Get current time-of-day dosha period.
 * @param {Date} [date] — defaults to now
 * @returns {Object} time dosha period
 */
export function getCurrentTimePeriod(date = new Date()) {
  const hour = date.getHours();
  return TIME_DOSHAS.find(t => {
    if (t.start < t.end) return hour >= t.start && hour < t.end;
    return hour >= t.start || hour < t.end; // wraps midnight
  }) ?? TIME_DOSHAS[0];
}

/**
 * Get the herb growth rate modifier for the current season.
 * @param {string} herbId
 * @param {string} [seasonId] — defaults to current season
 * @returns {{ multiplier: number, status: 'flourishing'|'normal'|'dormant', reason: string }}
 */
export function getHerbGrowthRate(herbId, seasonId = null) {
  const season = seasonId ? RITUS[seasonId] : getCurrentSeason();
  if (!season) return { multiplier: 1, status: 'normal', reason: 'Season unknown' };

  if (season.flourishingHerbs.includes(herbId)) {
    return {
      multiplier: 2.0,
      status: 'flourishing',
      reason: `${season.name} is ideal for this herb — grows at double speed!`,
    };
  }
  if (season.dormantHerbs.includes(herbId)) {
    return {
      multiplier: 0.25,
      status: 'dormant',
      reason: `This herb rests during ${season.name}. Very slow growth.`,
    };
  }
  return {
    multiplier: 1.0,
    status: 'normal',
    reason: `Normal growing conditions during ${season.name}.`,
  };
}

/**
 * Get all herbs that are currently flourishing.
 * @returns {string[]} herb IDs
 */
export function getFlourishingHerbs() {
  return getCurrentSeason().flourishingHerbs;
}

/**
 * Generate seasonal patient conditions.
 * The types of patients who appear in the game reflect the real season.
 * @returns {Object} seasonal condition context
 */
export function getSeasonalContext() {
  const season     = getCurrentSeason();
  const timePeriod = getCurrentTimePeriod();
  const now        = new Date();

  return {
    season,
    timePeriod,
    date: now,
    hour: now.getHours(),
    // Garden atmosphere
    atmosphere: {
      sky:       season.garden.sky,
      ambient:   season.garden.ambient,
      ground:    season.garden.ground,
      moisture:  season.garden.moisture,
      temp:      season.garden.temp,
      isDay:     now.getHours() >= 6 && now.getHours() < 19,
      isGoldenHour: (now.getHours() >= 6 && now.getHours() < 8) || (now.getHours() >= 17 && now.getHours() < 19),
      isMonsoon: season.id === 'varsha',
    },
    // Patient generation weights based on season
    patientConditionWeights: season.commonAilments,
    // Herb availability
    flourishing: season.flourishingHerbs,
    dormant:     season.dormantHerbs,
    // Daily advice
    todayAdvice: {
      dosha:     season.dominantDosha,
      bestFoods: season.bestFoods,
      avoid:     season.avoidFoods,
      practice:  season.ritualPractice,
    },
  };
}

/**
 * Calculate how many minutes until the herb finishes growing,
 * adjusted for real-world season and time.
 *
 * @param {string} herbId
 * @param {number} baseDays — herb's base growTime in days
 * @param {Date}   plantedAt — when the herb was planted
 * @returns {{ done: boolean, minutesLeft: number, progress: number (0-1) }}
 */
export function getGrowthProgress(herbId, baseDays, plantedAt) {
  const { multiplier } = getHerbGrowthRate(herbId);
  const effectiveDays  = baseDays / multiplier;
  const totalMs        = effectiveDays * 24 * 60 * 60 * 1000;
  const elapsed        = Date.now() - new Date(plantedAt).getTime();
  const progress       = Math.min(elapsed / totalMs, 1);
  const minutesLeft    = Math.max(0, Math.round((totalMs - elapsed) / 60000));

  return { done: progress >= 1, minutesLeft, progress };
}

/**
 * Get a human-readable description of current game time for UI display.
 */
export function getTimeDescription() {
  const hour    = new Date().getHours();
  const period  = getCurrentTimePeriod();
  const season  = getCurrentSeason();

  const timeLabel =
    hour < 6  ? 'Before dawn' :
    hour < 9  ? 'Morning'     :
    hour < 12 ? 'Late morning':
    hour < 14 ? 'Midday'      :
    hour < 17 ? 'Afternoon'   :
    hour < 19 ? 'Evening'     :
    hour < 22 ? 'Night'       : 'Late night';

  return {
    timeLabel,
    seasonName:   `${season.name} (${season.english})`,
    doshaTime:    `${period.dosha.charAt(0).toUpperCase() + period.dosha.slice(1)} time`,
    energy:       period.energy,
    quality:      period.quality,
    greeting:     getTimeGreeting(hour),
    tip:          `${period.quality.charAt(0).toUpperCase() + period.quality.slice(1)} — a good time for ${getTimeActivity(hour)}.`,
  };
}

function getTimeGreeting(hour) {
  if (hour < 5)  return 'Brahma Muhurta — the sacred hour before dawn';
  if (hour < 9)  return 'Suprabhatam — Good morning, Vaidya';
  if (hour < 12) return 'The morning is bright with healing potential';
  if (hour < 14) return 'Midday — your Pitta fire burns strongest';
  if (hour < 17) return 'Good afternoon — tend your garden';
  if (hour < 19) return 'The golden hour — harvest before dark';
  if (hour < 22) return 'Good evening — time to reflect';
  return 'Late night — even healers must rest';
}

function getTimeActivity(hour) {
  if (hour < 6)  return 'meditation and pranayama';
  if (hour < 9)  return 'exercise and patient diagnosis';
  if (hour < 12) return 'crafting complex remedies';
  if (hour < 14) return 'treating patients';
  if (hour < 17) return 'herb harvesting and garden work';
  if (hour < 19) return 'studying the compendium';
  if (hour < 22) return 'preparing tomorrow\'s medicines';
  return 'gentle breathing and sleep preparation';
}

export default {
  RITUS,
  TIME_DOSHAS,
  getCurrentSeason,
  getCurrentTimePeriod,
  getHerbGrowthRate,
  getFlourishingHerbs,
  getSeasonalContext,
  getGrowthProgress,
  getTimeDescription,
};

// engine.js — pure rule functions
import { TEAMS, GRACE_VALS } from './config.js';
import { PATHS, isCastle, isSafe } from './paths.js';

export function getMovable(pawns, player, val, grace) {
  const res = [];
  for (let i = 0; i < 4; i++) {
    const {pos} = pawns[player][i];
    if (pos === 80) continue;
    if (pos === -1) { if (grace) res.push(i); continue; }
    const tp = pos + val;
    if (tp > 80) continue;
    if (tp < 80) {
      const sq = PATHS[player][tp];
      if (isCastle(sq.x, sq.y) && _hasOpponent(pawns, player, sq)) continue;
    }
    res.push(i);
  }
  return res;
}

export function getTargetPos(pawns, player, pawnIdx, val) {
  const pos = pawns[player][pawnIdx].pos;
  return pos === -1 ? 0 : pos + val;
}

function _hasOpponent(pawns, myP, sq) {
  for (let p = 0; p < 4; p++) {
    if (p === myP || TEAMS[p] === TEAMS[myP]) continue;
    for (let i = 0; i < 4; i++) {
      const {pos} = pawns[p][i];
      if (pos < 0 || pos >= 80) continue;
      const osq = PATHS[p][pos];
      if (osq.x === sq.x && osq.y === sq.y) return true;
    }
  }
  return false;
}

export function resolveCapturesFull(pawns, player, landingIdx) {
  if (landingIdx < 0 || landingIdx >= 80 || isSafe(player, landingIdx)) return [];
  const sq = PATHS[player][landingIdx];
  const out = [];
  for (let p = 0; p < 4; p++) {
    if (p === player || TEAMS[p] === TEAMS[player]) continue;
    for (let i = 0; i < 4; i++) {
      const {pos} = pawns[p][i];
      if (pos < 0 || pos >= 80 || isSafe(p, pos)) continue;
      const osq = PATHS[p][pos];
      if (osq.x === sq.x && osq.y === sq.y) out.push({player:p, pawnIdx:i});
    }
  }
  return out;
}

export function checkWin(pawns) {
  for (let team = 0; team < 2; team++) {
    const players = [0,1,2,3].filter(p => TEAMS[p] === team);
    if (players.every(p => pawns[p].every(pw => pw.pos === 80))) return team;
  }
  return null;
}

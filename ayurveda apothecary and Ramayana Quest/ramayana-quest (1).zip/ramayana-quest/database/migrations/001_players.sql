CREATE TABLE rq_players (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tag         VARCHAR(20) NOT NULL UNIQUE,
  character   VARCHAR(20) NOT NULL DEFAULT 'rama',
  dharma      INT NOT NULL DEFAULT 0,
  courage     INT NOT NULL DEFAULT 0,
  devotion    INT NOT NULL DEFAULT 0,
  wisdom      INT NOT NULL DEFAULT 0,
  sanskriti   INT NOT NULL DEFAULT 0,
  consequences JSONB NOT NULL DEFAULT '[]',
  completed_kandas JSONB NOT NULL DEFAULT '[]',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

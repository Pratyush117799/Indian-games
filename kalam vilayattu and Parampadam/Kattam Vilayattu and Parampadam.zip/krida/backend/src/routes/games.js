const router = require('express').Router();
const ctrl   = require('../controllers/gameController');
const { authenticate } = require('../middleware/auth');

// Game catalogue
router.get('/',       ctrl.listGames);
router.get('/:slug',  ctrl.getGame);

// Rooms (auth required)
router.post('/:slug/rooms', authenticate, ctrl.createRoom);

module.exports = router;

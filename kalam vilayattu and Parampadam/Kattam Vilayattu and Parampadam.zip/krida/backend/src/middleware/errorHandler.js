const logger = require('../utils/logger');

// Centralised error handler — must be registered LAST in Express chain
function errorHandler(err, req, res, _next) {
  const status  = err.status  || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  logger.error(`${req.method} ${req.originalUrl} — ${status}: ${message}`, {
    stack:  err.stack,
    body:   req.body,
    userId: req.user?.id,
  });

  res.status(status).json({
    error:   message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
}

// 404 handler — register before errorHandler but after all routes
function notFound(req, res, next) {
  const err = new Error(`Route not found: ${req.originalUrl}`);
  err.status = 404;
  next(err);
}

module.exports = { errorHandler, notFound };

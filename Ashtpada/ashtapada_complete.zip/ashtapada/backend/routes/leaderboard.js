'use strict';

const express = require('express');
const router  = express.Router();

/* Seed leaderboard with sample data (replace with DB query in production) */
const leaderboard = [
  { username: 'ArjunK',  region: 'Karnataka', wins: 142, streak: 8,  avatarIndex: 0 },
  { username: 'PriyaM',  region: 'Karnataka', wins: 128, streak: 5,  avatarIndex: 1 },
  { username: 'RajanV',  region: 'Goa',       wins: 117, streak: 3,  avatarIndex: 2 },
  { username: 'DeepaS',  region: 'Tamil Nadu', wins: 98,  streak: 12, avatarIndex: 0 },
  { username: 'SureshT', region: 'Karnataka', wins: 91,  streak: 2,  avatarIndex: 3 }
];

/* GET /api/leaderboard — top 20 globally */
router.get('/', (_req, res) => {
  const sorted = [...leaderboard].sort((a, b) => b.wins - a.wins).slice(0, 20);
  res.json({ leaderboard: sorted });
});

/* GET /api/leaderboard/region/:region — filter by region */
router.get('/region/:region', (req, res) => {
  const region = decodeURIComponent(req.params.region);
  const filtered = leaderboard
    .filter(u => u.region.toLowerCase() === region.toLowerCase())
    .sort((a, b) => b.wins - a.wins);
  res.json({ region, leaderboard: filtered });
});

module.exports = router;

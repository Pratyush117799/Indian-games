# Ashtapada — Exclusive Features Specification

## 1. AI Engine (`ai-engine.md`)

### Three Difficulty Levels

| Level     | Strategy                                   | Think Time  |
|-----------|--------------------------------------------|-------------|
| Beginner  | Pure random move selection                  | instant     |
| Prince    | Greedy: maximise progress + captures        | instant     |
| Maharaja  | Greedy + threat-avoidance + blockade bonus  | 900ms delay |

### Scoring Function (Prince / Maharaja)
```
score = (toStep × 2.5)           // progress along spiral
      + (captures × 160)         // capture bonus
      + (castle landing × 40)    // safety bonus
      + (fromStep × 0.5)         // prefer advanced pieces
      - (entering when on-board × 15)  // don't enter new pieces unnecessarily
```

### Maharaja Extras
- Threat check: for each candidate move, simulate all opponent dice rolls
  (1,2,3,8) from all opponent pieces to see if destination is reachable
- Blockade bonus: +60 if move creates a 2-piece blockade on same cell
- Penalty: -80 if destination is threatened by opponent

---

## 2. Daily Spiral Challenge (`daily-challenge.md`)

A seeded daily puzzle served from the backend.

### Flow
1. Server generates a board state with 3-6 pieces mid-journey each day
2. Player's goal: bring all pieces home in ≤ par_moves
3. Results stored in `challenge_completions` table
4. Daily leaderboard: fewest moves to complete the day's challenge

### Seeding Algorithm
```js
function generateDailyChallenge(date) {
  const seed = hashDate(date);             // deterministic per day
  const rng  = seededRandom(seed);
  // Place 4 pieces at random mid-spiral positions (steps 10-50)
  // Calculate AI-computed par (minimum moves to win)
  return { boardState, parMoves };
}
```

---

## 3. Replay System (`replay-system.md`)

Every online and vs-AI game records full move history in the `moves` table.

### Replay Playback
- `GET /api/games/:id/replay` returns all moves in order
- Frontend reconstructs state step-by-step from `fromStep`/`toStep` pairs
- Controls: play / pause / step-forward / step-back / speed (0.5×, 1×, 2×)
- Share link: `pagade.in/replay/:gameId`

### What's captured per move
- Dice shells (4 booleans) and value
- Piece moved (pieceIndex, fromStep, toStep)
- Captures (array of captured pieceIndices)
- Whether destination was a castle
- Timestamp (for real-time speed replay)

---

## 4. Progression & Cosmetic Unlocks (`progression.md`)

### Board Skins (unlock by wins)
| Skin         | Unlock    | Visual                                   |
|--------------|-----------|------------------------------------------|
| Sandstone    | Default   | Warm stone, classic carved grid          |
| Vedic Parchment | 5 wins | Aged manuscript texture + Sanskrit glyphs|
| Hampi Stone  | 15 wins   | Dark basalt, Hampi temple floor style    |
| Mysore Silk  | 30 wins   | Deep indigo + gold thread borders        |

### Streak Rewards
| Streak | Reward                              |
|--------|-------------------------------------|
| 3      | "Prince" title badge                |
| 7      | Vedic Parchment skin early unlock   |
| 14     | "Maharaja" title badge              |
| 30     | Hampi Stone skin early unlock       |

### Achievement Badges
| Badge               | Condition                              |
|---------------------|----------------------------------------|
| First Castle        | Land on a castle square                |
| Great Spiral        | Move a piece from step 0 to home       |
| Blockade Master     | Form 3+ blockades in one game          |
| Chess Ancestor      | Win 10 games                           |
| Patanjali's Board   | Play 50 games                          |
| Buddha's Gamble     | Roll the special 8 three times in one game |

---

## 5. Chess Ancestry Explorer (`ancestry-explorer.md`)

An interactive visual showing the Ashtapada → Chess lineage.

### Timeline Nodes
```
Ashtapada (c.500 BCE)
  └── Same 8×8 board adopted by →
        Chaturanga (c.600 CE)
          └── Exported to Persia →
                Shatranj (c.650 CE)
                  └── Spread via Silk Road →
                        Medieval Chess (c.1000 CE)
                          └── Modern Rules standardised →
                                Today's Chess (c.1475 CE)
```

### Interactive elements
- Click any node: see the rules of that era's game
- Click castle marks on board: "This castle had no role in Chaturanga —
  it was kept purely as tradition from Ashtapada"
- "You just played on the board that created chess" banner on game end

---

## 6. Probability Overlay (`probability-overlay.md`)

Toggle available in Maharaja difficulty for learning.

Shows on each cell the probability that an opponent's piece can
reach it this turn:
- P(reach cell c) = Σ P(dice=v) for each v where (p.step + v) maps to c
- Cowrie probability: P(0)=6.25%, P(1)=25%, P(2)=37.5%, P(3)=25%, P(8)=6.25%
- Heat map: green (safe) → amber (medium threat) → red (high threat)
- Toggle button: 🎲 Show threat map

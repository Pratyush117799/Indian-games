/**
 * characters.js — Character abilities, stat modifiers, special skill engine
 */
export const CHARACTERS = {
  rama: {
    id:'rama', name:'Rama', sk:'राम', title:'Maryada Purushottama',
    emoji:'🏹', color:'#1565C0',
    virtueBonus: { dharma: 2 },
    ability: 'Maryada — every moral choice earns double Dharma points',
    specialSkill: 'Brahmastra — invoke once per Kanda to auto-complete any physical challenge',
    description: 'The ideal man. Power comes from absolute adherence to dharma — even when it costs everything.',
    start: { dharma:15, courage:12, devotion:10, wisdom:10 },
    style: 'Strategic · High dharma · Harder moral choices',
    modifyVirtueGain: (v, gains) => {
      const result = {...gains};
      if (result.dharma) result.dharma = (result.dharma || 0) + 2;
      return result;
    },
  },
  sita: {
    id:'sita', name:'Sita', sk:'सीता', title:'Daughter of Earth',
    emoji:'🌸', color:'#AD1457',
    virtueBonus: { devotion: 2 },
    ability: 'Inner Flame — can see through illusions (Maya) that fool others',
    specialSkill: 'Truth Vision — reveals the real motivation behind any character\'s action',
    description: 'Daughter of the earth itself. Strength from inner clarity — she never loses herself even under extreme pressure.',
    start: { dharma:12, courage:12, devotion:18, wisdom:15 },
    style: 'Perceptive · High wisdom rewards · Alternative story path',
    modifyVirtueGain: (v, gains) => {
      const result = {...gains};
      if (result.devotion) result.devotion = (result.devotion || 0) + 2;
      return result;
    },
  },
  hanuman: {
    id:'hanuman', name:'Hanuman', sk:'हनुमान', title:'Son of Wind',
    emoji:'🐒', color:'#E65100',
    virtueBonus: { courage: 2 },
    ability: 'Bhakti Power — devotion scores doubled; impossible tasks become possible',
    specialSkill: 'Unlimited Strength — can attempt any physical challenge regardless of stated difficulty',
    description: 'The greatest devotee. Power is literally limitless — the only constraint is his humility. He kept forgetting how strong he was.',
    start: { dharma:12, courage:18, devotion:20, wisdom:10 },
    style: 'Action-focused · High courage · Direct paths through obstacles',
    modifyVirtueGain: (v, gains) => {
      const result = {...gains};
      if (result.devotion) result.devotion = (result.devotion || 0) * 2;
      if (result.courage) result.courage = (result.courage || 0) + 2;
      return result;
    },
  },
  lakshmana: {
    id:'lakshmana', name:'Lakshmana', sk:'लक्ष्मण', title:"Rama's Shadow",
    emoji:'⚔️', color:'#2E7D32',
    virtueBonus: { devotion: 1, courage: 1 },
    ability: 'Loyalty Shield — protect one ally from wrong-choice consequences (once per Kanda)',
    specialSkill: 'Vigilance — warns about traps; prevents one ambush per Kanda',
    description: 'The perfect companion. Gave up his own kingdom, wife, and sleep for 14 years — everything — for his brother.',
    start: { dharma:13, courage:16, devotion:16, wisdom:12 },
    style: 'Protective · Balanced virtues · Defensive strategies',
    modifyVirtueGain: (v, gains) => {
      const result = {...gains};
      if (result.devotion) result.devotion = (result.devotion || 0) + 1;
      if (result.courage)  result.courage  = (result.courage  || 0) + 1;
      return result;
    },
  },
};

export const getCharacter     = id => CHARACTERS[id] ?? CHARACTERS.rama;
export const applyCharBonus   = (charId, gains) => getCharacter(charId).modifyVirtueGain(null, gains);
export default CHARACTERS;

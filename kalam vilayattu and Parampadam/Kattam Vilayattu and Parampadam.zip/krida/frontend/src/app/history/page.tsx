'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Clock, ChevronRight } from 'lucide-react';
import { clsx } from 'clsx';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import type { HistoryEntry } from '@/types';

const RESULT_STYLE = {
  win:  'bg-leaf/10 text-leaf border-leaf/30',
  loss: 'bg-red-50 text-red-500 border-red-100',
  draw: 'bg-gray-100 text-gray-500 border-gray-200',
};
const RESULT_LABEL = { win: 'Win', loss: 'Loss', draw: 'Draw' };

function fmt(secs: number | null) {
  if (!secs) return '—';
  return `${Math.floor(secs/60)}m ${secs%60}s`;
}

export default function HistoryPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.replace('/auth/login'); return; }
    api.get('/history?limit=30')
      .then(r => setEntries(r.data.history))
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 space-y-6">
      <div className="flex items-center gap-3">
        <Clock className="text-clay" size={28} />
        <div>
          <h1 className="text-2xl font-bold text-temple">Game History</h1>
          <p className="text-sm text-gray-400">Your past matches & replays</p>
        </div>
      </div>

      <div className="space-y-2">
        {loading ? (
          <div className="text-center py-16 text-gray-300 animate-pulse text-sm">Loading history…</div>
        ) : entries.length === 0 ? (
          <div className="card text-center py-16 text-gray-400 text-sm">
            No games played yet — <a href="/" className="text-clay underline">start playing!</a>
          </div>
        ) : (
          entries.map((e) => (
            <div key={e.session_id}
              className="card flex items-center justify-between gap-4 hover:shadow-md transition cursor-pointer py-3 px-4"
              onClick={() => router.push(`/history/${e.session_id}`)}>
              <div className="flex items-center gap-3">
                <span className={clsx('badge border text-xs font-semibold', RESULT_STYLE[e.result])}>
                  {RESULT_LABEL[e.result]}
                </span>
                <div>
                  <p className="font-medium text-temple text-sm">{e.game_name}</p>
                  <p className="text-xs text-gray-400">
                    {e.game_slug === 'kattam-vilayattu' ? `Level ${e.game_level} · ` : ''}
                    {e.total_moves} moves · {fmt(e.duration_secs)}
                    {e.winner_username && e.result !== 'win' && ` · Won by ${e.winner_username}`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <span className="text-xs">{new Date(e.started_at).toLocaleDateString()}</span>
                <ChevronRight size={14} />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

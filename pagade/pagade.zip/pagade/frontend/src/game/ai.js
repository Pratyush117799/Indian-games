/**
 * Pagade AI — three difficulty tiers
 * BEGINNER : random valid move
 * PRINCE   : greedy 1-ply scoring
 * MAHARAJA : 2-ply minimax with alpha-beta pruning
 */

import { getValidMoves, applyMove, applyRoll, scoreState, roll } from './engine';
import { AI_LEVEL, DICE_STYLE, STATUS } from './constants';

// ─── Entry point ─────────────────────────────────────────────────────────────

/**
 * Returns the best move action for the AI player.
 * @param {object} gameState  — current state after roll (phase='MOVE')
 * @param {string} level      — AI_LEVEL constant
 * @returns move action object ({ pawnId, newStatus, … })
 */
export function chooseBestMove(gameState, level = AI_LEVEL.PRINCE) {
  const moves = gameState.validMoves;
  if (!moves || moves.length === 0) return null;
  if (moves.length === 1) return moves[0];

  switch (level) {
    case AI_LEVEL.BEGINNER:  return randomMove(moves);
    case AI_LEVEL.MAHARAJA:  return maharajaMove(gameState, moves);
    case AI_LEVEL.PRINCE:
    default:                 return princeMove(gameState, moves);
  }
}

// ─── Beginner : random ───────────────────────────────────────────────────────

function randomMove(moves) {
  return moves[Math.floor(Math.random() * moves.length)];
}

// ─── Prince : greedy 1-ply ───────────────────────────────────────────────────

function princeMove(gameState, moves) {
  const pid = gameState.currentPlayer;
  let best = null, bestScore = -Infinity;

  for (const move of moves) {
    const next = applyMove(gameState, move);
    const s = scoreState(next, pid) + captureBonus(gameState, move, pid);
    if (s > bestScore) { bestScore = s; best = move; }
  }
  return best;
}

// ─── Maharaja : 2-ply minimax ─────────────────────────────────────────────────

const MAHARAJA_DEPTH = 2;

function maharajaMove(gameState, moves) {
  const pid = gameState.currentPlayer;
  let best = null, bestScore = -Infinity;

  for (const move of moves) {
    const next = applyMove(gameState, move);
    const s = minimax(next, MAHARAJA_DEPTH - 1, -Infinity, Infinity, false, pid);
    if (s > bestScore) { bestScore = s; best = move; }
  }
  return best;
}

function minimax(state, depth, alpha, beta, isMax, forPlayer) {
  if (depth === 0 || state.phase === 'GAMEOVER') {
    return scoreState(state, forPlayer);
  }

  // Sample a few probable dice outcomes instead of all 16 (performance)
  const diceStyle = state.diceStyle || DICE_STYLE.COWRIE;
  const outcomes = sampleDiceOutcomes(diceStyle);
  let total = 0, count = 0;

  for (const outcome of outcomes) {
    const rolled = applyRoll(state, outcome);
    if (rolled.phase !== 'MOVE') {
      total += scoreState(rolled, forPlayer);
      count++;
      continue;
    }

    const movesHere = rolled.validMoves;
    if (!movesHere.length) { total += scoreState(rolled, forPlayer); count++; continue; }

    if (isMax) {
      let best = -Infinity;
      for (const m of movesHere) {
        const s = minimax(applyMove(rolled, m), depth - 1, alpha, beta, false, forPlayer);
        best = Math.max(best, s);
        alpha = Math.max(alpha, best);
        if (beta <= alpha) break;
      }
      total += best;
    } else {
      let worst = Infinity;
      for (const m of movesHere) {
        const s = minimax(applyMove(rolled, m), depth - 1, alpha, beta, true, forPlayer);
        worst = Math.min(worst, s);
        beta = Math.min(beta, worst);
        if (beta <= alpha) break;
      }
      total += worst;
    }
    count++;
  }

  return count ? total / count : 0;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function captureBonus(gameState, move, pid) {
  if (!move.landingCell) return 0;
  for (let oppId = 0; oppId < gameState.players.length; oppId++) {
    if (oppId === pid) continue;
    for (const pawn of gameState.players[oppId].pawns) {
      if (pawn.status !== STATUS.ACTIVE) continue;
      const pc = getPawnCellSimple(pawn);
      if (pc && pc.r === move.landingCell.r && pc.c === move.landingCell.c) return 20;
    }
  }
  return 0;
}

// Simplified cell lookup (avoids circular import)
function getPawnCellSimple(pawn) {
  return null; // applyMove handles capture internally; this is for lookahead bonus only
}

/** Sample representative dice outcomes for minimax (not all combinations) */
function sampleDiceOutcomes(diceStyle) {
  if (diceStyle === DICE_STYLE.COWRIE) {
    // Cowrie: 1-12 with varying probabilities — sample 6 representative values
    return [
      { values:[1], total:1, isDoublet:false },
      { values:[2], total:2, isDoublet:false },
      { values:[3], total:3, isDoublet:false },
      { values:[4], total:4, isDoublet:false },
      { values:[6], total:6, isDoublet:false },
      { values:[12],total:12,isDoublet:false },
    ];
  }
  // Stick dice: all 16 combos → deduplicate to unique totals + doublet flag
  const faces = [1,3,4,6];
  const seen = new Set();
  const results = [];
  for (const a of faces) for (const b of faces) {
    const key = `${Math.min(a,b)}_${Math.max(a,b)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    results.push({ values:[a,b], total:a+b, isDoublet: a===b });
  }
  return results;
}

// ─── AI delay wrapper (for realistic feel) ───────────────────────────────────

/**
 * Returns a promise that resolves after a natural "thinking" delay.
 * Beginner: fast, Maharaja: slower.
 */
export function aiThinkDelay(level) {
  const delays = {
    [AI_LEVEL.BEGINNER]:  400 + Math.random() * 300,
    [AI_LEVEL.PRINCE]:    700 + Math.random() * 500,
    [AI_LEVEL.MAHARAJA]: 1100 + Math.random() * 700,
  };
  return new Promise(r => setTimeout(r, delays[level] || 600));
}

export const CS = 30;
export const COLORS  = ['#E8C500','#C93A3A','#4A7FC1','#3A8B1A'];
export const NAMES   = ['Yellow','Red','Black','Green'];
export const DEVA    = ['पीला','लाल','काला','हरा'];
export const TEAMS   = [0,1,0,1];       // 0=TeamA {Yellow,Black}  1=TeamB {Red,Green}

export const THROW_VAL  = {0:25,1:10,2:2,3:3,4:4,5:5,6:6};
export const THROW_NAME = {25:'पचीस — Pachees',10:'दस — Dus',6:'छह — Chha',5:'पाँच — Panch',4:'चार — Chari',3:'तीन — Teeni',2:'दो — Dooga'};
export const GRACE_VALS = new Set([6,10,25]);
export const GRACE_DEVA = {25:'पचीस!',10:'दस!',6:'छह!'};

export const FACTS = [
  'Fatehpur Sikri still preserves the stone court where Akbar played Pachisi with sixteen living pieces.',
  '"Pachisi" means twenty-five — the rarest throw, scored when all six cowries land aperture-down.',
  'The Mahabharata describes "Pasha" — a dice game Yudhishthira wagered his entire kingdom on.',
  'Cowrie shells were the currency of ancient Indian trade. Playing Pachisi was gambling with money.',
  'The cross shape of the board maps the four cosmic directions; the Charkoni is the seat of Brahma.',
  'Counter-clockwise movement mirrors pradakshina — the ritual circumambulation of Hindu temples.',
  'The Ellora Caves, carved in the 6th century CE, contain one of the earliest known Pachisi boards.',
  'Spanish traders brought Pachisi home as Parchís. The British turned it into Ludo in 1896.',
  'In team play, you can sacrifice your own pawn to protect your partner — unlike Ludo.',
  '"Ludo" comes from the Latin for "I play" — every Ludo board in the world descends from Pachisi.',
];

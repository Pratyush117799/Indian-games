// ═══════════════════════════════════════════════════
//  MAIN · Orchestration entry point
//  Wires: board, pawns, cowrie, engine, ai, effects,
//         ui, api → into a full playable game loop
// ═══════════════════════════════════════════════════

import { NAMES, TEAMS, THROW_NAME } from './config.js';
import { G, resetState, serialiseState } from './state.js';
import { getMovable, getTargetPos, resolveCapturesFull, checkWin } from './engine.js';
import { rollCowries, animateCowries }   from './cowrie.js';
import { drawBoard }                     from './board.js';
import { renderPawns, stepAnimate, showHighlights, clearHighlights,
         markSelectable, unmarkSelectable, markSelected }  from './pawns.js';
import { graceFlash, showFact, captureEffect,
         winBloom, showWinOverlay }      from './effects.js';
import { chooseMove }                    from './ai.js';
import { initPips, updatePips, updateActiveCard, setHint, setThrowDisplay,
         resetThrowDisplay, setThrowEnabled, logAdd,
         renderStats, registerPawnClicks, clearPawnClicks } from './ui.js';
import { createGame, saveState, endGame, fetchStats }       from './api.js';

// ── Boot ──────────────────────────────────────────
document.getElementById('btn-start').addEventListener('click', startGame);
document.getElementById('btn-throw').addEventListener('click', onThrowClick);
document.getElementById('btn-new').addEventListener('click', () => location.reload());
document.getElementById('btn-play-again').addEventListener('click', () => location.reload());
document.getElementById('btn-hints').addEventListener('click', () => {
  G.hintsOn = !G.hintsOn;
  document.getElementById('hint-panel').style.display = G.hintsOn ? '' : 'none';
});

// ═══════════════════════════════════════════════════
//  GAME INIT
// ═══════════════════════════════════════════════════
async function startGame() {
  // Animate intro out
  const intro = document.getElementById('intro');
  intro.classList.add('hiding');
  setTimeout(() => intro.classList.add('hidden'), 850);

  // Show game screen
  document.getElementById('game').classList.remove('hidden');

  // Reset pure state
  resetState();

  // Draw static board
  drawBoard();

  // Render initial pawns (all in Charkoni)
  initPips();
  renderPawns();
  updateActiveCard();

  // Register server session (non-blocking)
  G.gameId = await createGame();

  // Load stats into the panel
  const stats = await fetchStats();
  if (stats) renderStats(stats);

  // Ready
  setHint('Yellow plays first. Throw the cowries to begin!');
  logAdd('The Royal Game of Pachisi begins…');
  logAdd('You are Yellow (Team A). Red, Black & Green are AI (Team B).');
  logAdd('You need a Grace throw (6, 10 or 25) to enter a pawn onto the board.');
  setThrowEnabled(true);
}

// ═══════════════════════════════════════════════════
//  THROW
// ═══════════════════════════════════════════════════
function onThrowClick() {
  if (G.busy || G.phase !== 'throw' || G.over) return;
  setThrowEnabled(false);
  G.busy = true;

  const roll = rollCowries();
  G.val   = roll.val;
  G.grace = roll.grace;

  const cowrieArea = document.getElementById('cowrie-area');
  animateCowries(roll.shells, cowrieArea, () => {
    setThrowDisplay(roll.val, THROW_NAME[roll.val] || '');
    if (roll.grace) { graceFlash(roll.val); showFact(); }
    G.busy = false;
    processThrow(G.cur, roll.val, roll.grace);
  });
}

// ─── Decide what to do after a throw ──────────────
function processThrow(player, val, grace) {
  G.movable = getMovable(player, val, grace);

  if (!G.movable.length) {
    logAdd(`${NAMES[player]} throws ${val} — no valid move.`);
    setHint(`No valid move for ${NAMES[player]}. Turn passes.`);
    setTimeout(() => advanceTurn(false), 950);
    return;
  }

  if (player === 0) {
    // Human player — enter selection phase
    G.phase = 'select';
    setHint(`Throw: ${val}${grace ? ' ✦ Grace!' : ''}  Click a pawn to move it.`);

    const moves = G.movable.map(i => ({
      player, targetPos: getTargetPos(player, i, val),
    }));
    showHighlights(moves);
    markSelectable(player, G.movable);
    registerPawnClicks(player, G.movable, onPawnClick);
  } else {
    // AI player
    G.phase = 'anim';
    setTimeout(() => runAI(player, val, grace), 580);
  }
}

// ─── Human pawn selection ─────────────────────────
function onPawnClick(player, pawnIdx) {
  if (G.phase !== 'select' || G.busy || player !== 0) return;
  if (!G.movable.includes(pawnIdx)) return;

  clearHighlights();
  unmarkSelectable();
  clearPawnClicks(0);
  markSelected(player, pawnIdx);
  G.phase = 'anim';
  G.busy  = true;
  executeMove(player, pawnIdx, G.val, G.grace);
}

// ═══════════════════════════════════════════════════
//  AI TURN
// ═══════════════════════════════════════════════════
function aiTurn(player) {
  if (G.over) return;
  G.busy = true;

  const roll = rollCowries();
  G.val   = roll.val;
  G.grace = roll.grace;

  const cowrieArea = document.getElementById('cowrie-area');
  animateCowries(roll.shells, cowrieArea, () => {
    setThrowDisplay(roll.val, THROW_NAME[roll.val] || '');
    if (roll.grace) showFact();
    G.busy = false;

    const movable = getMovable(player, roll.val, roll.grace);
    if (!movable.length) {
      logAdd(`${NAMES[player]} throws ${roll.val} — no valid move.`);
      setTimeout(() => advanceTurn(false), 750);
      return;
    }

    G.phase = 'anim';
    setTimeout(() => runAI(player, roll.val, roll.grace), 300);
  });
}

function runAI(player, val, grace) {
  const pawnIdx = chooseMove(player, val, grace);
  if (pawnIdx === null) { advanceTurn(false); return; }
  logAdd(`${NAMES[player]} throws ${val}${grace ? ' ✦' : ''}. Pawn ${pawnIdx + 1} moves.`);
  G.busy = true;
  executeMove(player, pawnIdx, val, grace);
}

// ═══════════════════════════════════════════════════
//  MOVE EXECUTION
// ═══════════════════════════════════════════════════
function executeMove(player, pawnIdx, val, grace) {
  const targetPos = getTargetPos(player, pawnIdx, val);

  stepAnimate(player, pawnIdx, targetPos, async () => {
    // Pawn is now at targetPos in G.pawns
    renderPawns();
    updatePips();

    let bonusTurn = grace;

    if (targetPos === 80) {
      logAdd(`${NAMES[player]}'s pawn reaches the Charkoni! 🏠`);
      setHint(`${NAMES[player]}'s pawn is home!${grace ? ' Grace — throw again!' : ''}`);

      const winner = checkWin();
      if (winner !== null) {
        await handleWin(winner);
        return;
      }
    } else {
      // Resolve captures
      const captured = resolveCapturesFull(player, targetPos);
      for (const { player: cp, pawnIdx: ci } of captured) {
        await captureEffect(cp, ci);
        G.pawns[cp][ci].pos = -1;
        logAdd(`${NAMES[player]} captures ${NAMES[cp]}'s pawn! ⚔️`);
        bonusTurn = true;
      }
      if (captured.length) renderPawns();
    }

    // Auto-save to server (fire and forget)
    saveState(G.gameId, serialiseState());

    G.busy = false;
    advanceTurn(bonusTurn);
  });
}

// ═══════════════════════════════════════════════════
//  TURN MANAGEMENT
// ═══════════════════════════════════════════════════
function advanceTurn(bonusTurn) {
  if (G.over) return;

  if (bonusTurn) {
    logAdd(`${NAMES[G.cur]} gets another throw!`);
    setHint(`${NAMES[G.cur]} throws again! (Grace or capture)`);
  } else {
    G.cur = (G.cur + 1) % 4;
  }

  G.phase   = 'throw';
  G.val     = 0;
  G.grace   = false;
  G.movable = [];

  resetThrowDisplay();
  clearHighlights();
  unmarkSelectable();
  updateActiveCard();
  updatePips();

  if (G.cur === 0) {
    setHint('Your turn, Yellow. Throw the cowries!');
    setThrowEnabled(true);
  } else {
    setHint(`${NAMES[G.cur]}'s turn (AI)…`);
    setThrowEnabled(false);
    setTimeout(() => aiTurn(G.cur), 720);
  }
}

// ═══════════════════════════════════════════════════
//  WIN
// ═══════════════════════════════════════════════════
async function handleWin(team) {
  G.over  = true;
  G.phase = 'done';

  const winner = team === 0 ? 'A' : 'B';
  await endGame(G.gameId, winner);

  // Refresh stats after the game ends
  const stats = await fetchStats();
  if (stats) renderStats(stats);

  winBloom(team);
  const players = [0, 1, 2, 3].filter(p => TEAMS[p] === team);
  setTimeout(() => showWinOverlay(team, players), 700);
}

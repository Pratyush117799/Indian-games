'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { clsx } from 'clsx';
import type { ParamapadamState } from '@/types';

const SNAKES  = new Set([99,92,87,72,64,54,41,36]);
const LADDERS = new Set([4,9,20,28,40,51,63,71]);

const PLAYER_COLORS = ['bg-leaf text-white','bg-clay text-white','bg-red-500 text-white','bg-blue-500 text-white','bg-purple-500 text-white','bg-yellow-500 text-gray-900'];

/** Convert square (1-100) to { row, col } on visual board (row 0 = top) */
function squareToPos(sq: number): { row: number; col: number } {
  const idx    = sq - 1;
  const gridRow = Math.floor(idx / 10);
  const col     = gridRow % 2 === 0 ? idx % 10 : 9 - (idx % 10);
  return { row: 9 - gridRow, col };
}

interface Props {
  state:      ParamapadamState;
  myPlayerId: string;
  playerMap:  Record<string, { username: string; color: string }>;
  onRoll:     () => void;
  disabled?:  boolean;
}

export default function ParamapadamBoard({ state, myPlayerId, playerMap, onRoll, disabled }: Props) {
  const { players, positions, currentPlayerIndex, winner, lastDiceRoll, lastEvent, bonusTurn } = state;
  const isMyTurn  = !disabled && !winner && players[currentPlayerIndex] === myPlayerId;

  // Build cells with player tokens
  const playerTokens: Record<number, string[]> = {};
  players.forEach(pid => {
    const pos = positions[pid];
    if (pos > 0) {
      if (!playerTokens[pos]) playerTokens[pos] = [];
      playerTokens[pos].push(pid);
    }
  });

  const squares = Array.from({ length: 100 }, (_, i) => {
    const sq  = i + 1;
    const { row, col } = squareToPos(sq);
    return { sq, row, col };
  });

  // Sort so we can render row by row
  const grid: { sq: number; col: number }[][] = Array.from({ length: 10 }, () => []);
  squares.forEach(({ sq, row, col }) => grid[row].push({ sq, col }));
  grid.forEach(row => row.sort((a, b) => a.col - b.col));

  const cellBg = (sq: number) => {
    if (sq === 100)       return 'bg-kolam/30 border-kolam font-bold';
    if (sq === 1)         return 'bg-leaf/20 border-leaf';
    if (SNAKES.has(sq))   return 'bg-red-50 border-red-200';
    if (LADDERS.has(sq))  return 'bg-green-50 border-green-200';
    return 'bg-white border-clay/10';
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Event banner */}
      <AnimatePresence mode="wait">
        {lastEvent && (
          <motion.div
            key={lastEvent}
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className={clsx(
              'text-sm font-semibold px-4 py-1.5 rounded-full',
              lastEvent === 'snake'   && 'bg-red-100 text-red-700',
              lastEvent === 'ladder'  && 'bg-green-100 text-green-700',
              lastEvent === 'win'     && 'bg-kolam/20 text-temple',
              lastEvent === 'waiting' && 'bg-gray-100 text-gray-500',
              !lastEvent              && 'bg-gray-50 text-gray-400',
            )}>
            {lastEvent === 'snake'   && `🐍 Snake! Slide down…`}
            {lastEvent === 'ladder'  && `🪜 Ladder! Climb up! +Bonus turn`}
            {lastEvent === 'win'     && `🎉 ${playerMap[winner!]?.username} reached Vaikuntam!`}
            {lastEvent === 'waiting' && `Waiting to enter — roll a 1`}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Board grid */}
      <div className="bg-cream rounded-2xl p-2 shadow-board border-2 border-clay/20 overflow-auto max-w-full">
        <div className="grid gap-px" style={{ gridTemplateRows: 'repeat(10, 52px)', gridTemplateColumns: 'repeat(10, 52px)' }}>
          {grid.map((row, ri) =>
            row.map(({ sq, col }) => (
              <div key={sq}
                className={clsx(
                  'relative border rounded flex flex-col items-center justify-start pt-0.5 text-[10px] font-medium text-gray-400 overflow-hidden',
                  cellBg(sq)
                )}
                style={{ gridRow: ri + 1, gridColumn: col + 1 }}
              >
                {/* Square number */}
                <span className={clsx('leading-none', sq === 100 && 'text-temple font-bold text-[9px]')}>
                  {sq === 100 ? '🙏' : sq === 1 ? '▶' : sq}
                </span>

                {/* Snake / Ladder indicator */}
                {SNAKES.has(sq)  && <span className="text-[11px]">🐍</span>}
                {LADDERS.has(sq) && <span className="text-[11px]">🪜</span>}

                {/* Player tokens */}
                {playerTokens[sq] && (
                  <div className="flex flex-wrap gap-px justify-center mt-auto mb-0.5">
                    {playerTokens[sq].map((pid, ti) => (
                      <motion.span
                        key={pid} layout
                        className={clsx(
                          'w-4 h-4 rounded-full text-[8px] flex items-center justify-center font-bold border border-white/50',
                          PLAYER_COLORS[players.indexOf(pid) % PLAYER_COLORS.length]
                        )}
                      >
                        {playerMap[pid]?.username?.[0]?.toUpperCase() || '?'}
                      </motion.span>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Dice + Roll button */}
      <div className="flex items-center gap-6">
        {/* Dice face display */}
        <div className={clsx(
          'w-14 h-14 rounded-xl border-2 border-clay/40 bg-cream flex items-center justify-center text-3xl shadow-board',
          lastDiceRoll && 'dice-rolling'
        )}>
          {lastDiceRoll ? ['','⚀','⚁','⚂','⚃','⚄','⚅'][lastDiceRoll] : '🎲'}
        </div>

        <button
          onClick={onRoll}
          disabled={!isMyTurn}
          className="btn-primary text-base px-8 py-3 disabled:opacity-40"
        >
          {winner    ? '🏆 Game Over'       :
           isMyTurn  ? `Roll Dice ${bonusTurn ? '(Bonus!)' : ''}` :
                       `${playerMap[players[currentPlayerIndex]]?.username || 'Opponent'}'s turn…`}
        </button>
      </div>

      {/* Player positions table */}
      <div className="w-full max-w-xs space-y-1">
        {players.map((pid, si) => (
          <div key={pid} className={clsx(
            'flex items-center justify-between text-sm px-3 py-1.5 rounded-lg',
            pid === players[currentPlayerIndex] && !winner ? 'bg-clay/10 font-semibold' : 'bg-white/50'
          )}>
            <div className="flex items-center gap-2">
              <span className={clsx('w-5 h-5 rounded-full text-[10px] flex items-center justify-center', PLAYER_COLORS[si % PLAYER_COLORS.length])}>
                {playerMap[pid]?.username?.[0]?.toUpperCase()}
              </span>
              <span>{playerMap[pid]?.username || `P${si+1}`}</span>
            </div>
            <span className="text-clay font-mono">
              {positions[pid] === 0 ? '—' : `Sq ${positions[pid]}`}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Paramapadam — Game Logic Engine
 *
 * 10×10 board (100 squares). Square 1 = start, Square 100 = Vaikuntam (win).
 * Snakes drag pieces DOWN; Ladders carry pieces UP.
 * Traditional rules:
 *   - Roll 1 to enter (place on Square 1). Already-entered players roll normally.
 *   - Roll 6 → bonus turn.
 *   - Climb a ladder → bonus turn.
 *   - Bitten by snake → no bonus turn.
 *   - Must land EXACTLY on 100; overshoot bounces back.
 */

// ─── Board Definition ────────────────────────────────────────
// snakes: { headSquare: tailSquare }   (fall from head to tail)
// ladders:{ bottomSquare: topSquare }  (climb from bottom to top)
const SNAKES = {
  99: 7,
  92: 25,
  87: 24,
  72: 51,
  64: 11,
  54: 19,
  41: 20,
  36: 6,
};

const LADDERS = {
  4:  14,
  9:  31,
  20: 38,
  28: 84,
  40: 59,
  51: 67,
  63: 81,
  71: 91,
};

const TOTAL_SQUARES = 100;

// ─── State Factory ───────────────────────────────────────────

/**
 * @param {string[]} playerIds   2–6 player UUIDs in turn order
 */
function createGameState(playerIds) {
  return {
    players:           playerIds,
    positions:         Object.fromEntries(playerIds.map(id => [id, 0])), // 0 = not yet entered
    currentPlayerIndex: 0,
    phase:             'active',   // 'active' | 'finished'
    winner:            null,
    lastDiceRoll:      null,
    lastEvent:         null,       // 'snake' | 'ladder' | 'win' | null
    bonusTurn:         false,
    moveCount:         0,
  };
}

// ─── Dice ────────────────────────────────────────────────────

/** Roll a single standard die (1–6). */
function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}

// ─── Move Application ────────────────────────────────────────

/**
 * Apply one turn for a player.
 * @param {object} state   Current game state
 * @param {string} playerId
 * @param {number} [forcedRoll]  For deterministic testing; omit for random roll
 * @returns {{ newState, roll, event, landed }}
 */
function applyTurn(state, playerId, forcedRoll) {
  if (state.phase === 'finished')    return { error: 'Game is already over' };
  const currentPlayer = state.players[state.currentPlayerIndex];
  if (playerId !== currentPlayer)    return { error: 'Not your turn' };

  const roll     = forcedRoll !== undefined ? forcedRoll : rollDice();
  const positions = { ...state.positions };
  let   current  = positions[playerId];
  let   event    = null;
  let   bonusTurn = false;

  // Entry rule: must roll 1 to enter the board
  if (current === 0) {
    if (roll !== 1) {
      // Turn passes without movement
      return {
        newState: {
          ...state,
          currentPlayerIndex: (state.currentPlayerIndex + 1) % state.players.length,
          lastDiceRoll: roll,
          lastEvent: 'waiting',
          bonusTurn: false,
          moveCount: state.moveCount + 1,
        },
        roll,
        event: 'waiting',
        landed: 0,
      };
    }
    current = 1; // enter the board
  } else {
    let target = current + roll;

    if (target > TOTAL_SQUARES) {
      // Overshoot: bounce back
      target = TOTAL_SQUARES - (target - TOTAL_SQUARES);
    }

    current = target;
  }

  // Check snake
  if (SNAKES[current] !== undefined) {
    current = SNAKES[current];
    event   = 'snake';
  }
  // Check ladder
  else if (LADDERS[current] !== undefined) {
    current = LADDERS[current];
    event   = 'ladder';
    bonusTurn = true; // ladder gives bonus turn
  }

  // Check win
  let winner = null;
  if (current === TOTAL_SQUARES) {
    event   = 'win';
    winner  = playerId;
    bonusTurn = false;
  }

  // Bonus turn for rolling 6 (if no snake/win)
  if (roll === 6 && !winner && event !== 'snake') {
    bonusTurn = true;
  }

  positions[playerId] = current;

  const nextIndex = bonusTurn
    ? state.currentPlayerIndex
    : (state.currentPlayerIndex + 1) % state.players.length;

  return {
    newState: {
      ...state,
      positions,
      currentPlayerIndex: nextIndex,
      phase:       winner ? 'finished' : 'active',
      winner,
      lastDiceRoll: roll,
      lastEvent:    event,
      bonusTurn,
      moveCount:    state.moveCount + 1,
    },
    roll,
    event,
    landed: current,
  };
}

/**
 * Get the board coordinates for a given square number.
 * Boustrophedon layout: square 1 starts at bottom-left.
 * Returns { row, col } where row 0 = top row visually.
 */
function squareToCoord(square) {
  if (square < 1 || square > TOTAL_SQUARES) return null;
  const index    = square - 1;
  const gridRow  = Math.floor(index / 10); // 0 = bottom, 9 = top
  const gridCol  = gridRow % 2 === 0
    ? index % 10               // even rows: left to right
    : 9 - (index % 10);        // odd rows:  right to left

  return {
    row: 9 - gridRow,  // flip so row 0 = top of visual board
    col: gridCol,
  };
}

module.exports = {
  createGameState,
  applyTurn,
  rollDice,
  squareToCoord,
  SNAKES,
  LADDERS,
  TOTAL_SQUARES,
};

const { verifyAccessToken } = require('../utils/jwt');
const db = require('../config/db');

/**
 * Middleware: require a valid Bearer access token.
 * Attaches req.user = { id, username, email } on success.
 */
async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or malformed Authorization header' });
    }

    const token   = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);

    // Fetch user to confirm they still exist
    const { rows } = await db.query(
      'SELECT id, username, email FROM users WHERE id = $1',
      [decoded.sub]
    );
    if (!rows.length) return res.status(401).json({ error: 'User not found' });

    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Access token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

/**
 * Optional auth: attaches req.user if token present, but never blocks.
 */
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token   = authHeader.split(' ')[1];
      const decoded = verifyAccessToken(token);
      const { rows } = await db.query(
        'SELECT id, username, email FROM users WHERE id = $1',
        [decoded.sub]
      );
      if (rows.length) req.user = rows[0];
    }
  } catch (_) { /* ignored */ }
  next();
}

module.exports = { authenticate, optionalAuth };

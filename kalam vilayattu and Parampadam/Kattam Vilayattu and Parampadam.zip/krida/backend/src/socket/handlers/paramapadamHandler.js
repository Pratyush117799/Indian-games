/**
 * Paramapadam — Socket.IO event handler
 *
 * Client events:  paramapadam:roll   { roomCode }
 *
 * Server emits:   paramapadam:state  { state, roll, event, landed }  → room
 *                 paramapadam:error  { message }                     → sender
 *                 paramapadam:win    { winnerId, state }              → room
 */

const db         = require('../../config/db');
const roomStore  = require('../roomStore');
const { applyTurn } = require('../../game-logic/paramapadam/engine');
const { updateStats } = require('../../controllers/leaderboardController');
const logger     = require('../../utils/logger');

async function persistMove(sessionId, playerId, moveNumber, moveData, positions) {
  await db.query(
    `INSERT INTO moves (session_id, player_id, move_number, move_data, board_state)
     VALUES ($1, $2, $3, $4, $5)`,
    [sessionId, playerId, moveNumber, JSON.stringify(moveData), JSON.stringify(positions)]
  );
}

async function finaliseSession(sessionId, winnerId, duration, finalState) {
  await db.query(
    `UPDATE game_sessions
     SET winner_id = $2, duration_secs = $3, total_moves = $4,
         game_state = $5, ended_at = NOW()
     WHERE id = $1`,
    [sessionId, winnerId, duration, finalState.moveCount, JSON.stringify(finalState)]
  );
  await updateStats(sessionId);
}

function registerParamapadamHandlers(io, socket) {
  socket.on('paramapadam:roll', async ({ roomCode }) => {
    try {
      const room = roomStore.get(roomCode);
      if (!room) return socket.emit('paramapadam:error', { message: 'Room not found' });

      const result = applyTurn(room.state, socket.user.id);
      if (result.error) return socket.emit('paramapadam:error', { message: result.error });

      const { newState, roll, event, landed } = result;
      roomStore.patch(roomCode, { state: newState });

      const moveData = { roll, event, landed, playerId: socket.user.id };
      await persistMove(room.sessionId, socket.user.id, newState.moveCount, moveData, newState.positions);

      if (newState.winner) {
        const duration = Math.round((Date.now() - room.startedAt) / 1000);
        await finaliseSession(room.sessionId, newState.winner, duration, newState);
        io.to(roomCode).emit('paramapadam:win', { winnerId: newState.winner, state: newState });
        await db.query("UPDATE game_rooms SET status='finished', finished_at=NOW() WHERE room_code=$1", [roomCode]);
        roomStore.delete(roomCode);
      } else {
        io.to(roomCode).emit('paramapadam:state', { state: newState, roll, event, landed });
      }
    } catch (err) {
      logger.error('paramapadam:roll error', err);
      socket.emit('paramapadam:error', { message: 'Server error processing roll' });
    }
  });
}

module.exports = { registerParamapadamHandlers };

'use client';
import Link from 'next/link';
import { useAuthStore } from '@/store/authStore';
import { Trophy, Clock, LogOut, User } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuthStore();

  return (
    <nav className="sticky top-0 z-50 bg-temple text-cream shadow-lg">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold text-lg tracking-wide">
          <span className="text-kolam text-xl">♟</span>
          <span>Krida</span>
          <span className="hidden sm:block text-cream/50 text-sm font-normal font-tamil">
            · கட்டம் · பரமபதம்
          </span>
        </Link>

        {/* Nav links */}
        <div className="flex items-center gap-1 text-sm">
          {user ? (
            <>
              <Link href="/leaderboard"
                className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-white/10 transition">
                <Trophy size={14} /> <span className="hidden sm:block">Leaderboard</span>
              </Link>
              <Link href="/history"
                className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-white/10 transition">
                <Clock size={14} /> <span className="hidden sm:block">History</span>
              </Link>
              <Link href="/profile"
                className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-white/10 transition">
                <User size={14} /> <span className="hidden sm:block">{user.username}</span>
              </Link>
              <button onClick={logout}
                className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-white/10 transition text-cream/70">
                <LogOut size={14} />
              </button>
            </>
          ) : (
            <>
              <Link href="/auth/login"
                className="px-3 py-1.5 rounded hover:bg-white/10 transition">Login</Link>
              <Link href="/auth/register"
                className="px-3 py-1.5 rounded bg-kolam text-temple font-semibold hover:bg-kolam-light transition">
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

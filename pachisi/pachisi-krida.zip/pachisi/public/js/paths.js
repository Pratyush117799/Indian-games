// ═══════════════════════════════════════════════════
//  PATHS · Player path arrays (80 squares each)
//          Castle square coordinates
//
//  Path structure per player (positions 0–79):
//    [0–7]   Home arm center col/row, BASE→TIP (outbound)
//    [8–15]  Home arm LEFT outer,     TIP→BASE
//    [16–23] 1st CCW arm, outer A,    BASE→TIP
//    [24–31] 1st CCW arm, outer B,    TIP→BASE
//    [32–39] 2nd CCW arm, outer A,    BASE→TIP
//    [40–47] 2nd CCW arm, outer B,    TIP→BASE
//    [48–55] 3rd CCW arm, outer A,    BASE→TIP
//    [56–63] 3rd CCW arm, outer B,    TIP→BASE
//    [64–71] Home arm RIGHT outer,    BASE→TIP
//    [72–79] Home arm center col/row, TIP→BASE (return home)
//
//  Position -1 = waiting in Charkoni
//  Position 80 = HOME (finished)
//
//  CCW arm visit order per player:
//    Yellow (N): N→W→S→E→N
//    Red    (E): E→N→W→S→E
//    Black  (S): S→E→N→W→S
//    Green  (W): W→S→E→N→W
// ═══════════════════════════════════════════════════

import { N, W, S, E } from './geometry.js';

export const PATHS = [
  // ── 0: YELLOW (North arm) ─────────────────────
  [
    N(7,1),N(6,1),N(5,1),N(4,1),N(3,1),N(2,1),N(1,1),N(0,1), // 0-7   out N center
    N(0,0),N(1,0),N(2,0),N(3,0),N(4,0),N(5,0),N(6,0),N(7,0), // 8-15  L outer N col0
    W(0,7),W(0,6),W(0,5),W(0,4),W(0,3),W(0,2),W(0,1),W(0,0), // 16-23 W top row
    W(2,0),W(2,1),W(2,2),W(2,3),W(2,4),W(2,5),W(2,6),W(2,7), // 24-31 W bottom row
    S(0,0),S(1,0),S(2,0),S(3,0),S(4,0),S(5,0),S(6,0),S(7,0), // 32-39 S left col
    S(7,2),S(6,2),S(5,2),S(4,2),S(3,2),S(2,2),S(1,2),S(0,2), // 40-47 S right col
    E(2,0),E(2,1),E(2,2),E(2,3),E(2,4),E(2,5),E(2,6),E(2,7), // 48-55 E bottom row
    E(0,7),E(0,6),E(0,5),E(0,4),E(0,3),E(0,2),E(0,1),E(0,0), // 56-63 E top row
    N(7,2),N(6,2),N(5,2),N(4,2),N(3,2),N(2,2),N(1,2),N(0,2), // 64-71 R outer N col2
    N(0,1),N(1,1),N(2,1),N(3,1),N(4,1),N(5,1),N(6,1),N(7,1), // 72-79 return N center
  ],
  // ── 1: RED (East arm) ─────────────────────────
  [
    E(1,0),E(1,1),E(1,2),E(1,3),E(1,4),E(1,5),E(1,6),E(1,7), // 0-7   out E center
    E(0,7),E(0,6),E(0,5),E(0,4),E(0,3),E(0,2),E(0,1),E(0,0), // 8-15  L outer E row0
    N(7,2),N(6,2),N(5,2),N(4,2),N(3,2),N(2,2),N(1,2),N(0,2), // 16-23 N right col
    N(0,0),N(1,0),N(2,0),N(3,0),N(4,0),N(5,0),N(6,0),N(7,0), // 24-31 N left col
    W(0,7),W(0,6),W(0,5),W(0,4),W(0,3),W(0,2),W(0,1),W(0,0), // 32-39 W top row
    W(2,0),W(2,1),W(2,2),W(2,3),W(2,4),W(2,5),W(2,6),W(2,7), // 40-47 W bottom row
    S(0,0),S(1,0),S(2,0),S(3,0),S(4,0),S(5,0),S(6,0),S(7,0), // 48-55 S left col
    S(7,2),S(6,2),S(5,2),S(4,2),S(3,2),S(2,2),S(1,2),S(0,2), // 56-63 S right col
    E(2,0),E(2,1),E(2,2),E(2,3),E(2,4),E(2,5),E(2,6),E(2,7), // 64-71 R outer E row2
    E(1,7),E(1,6),E(1,5),E(1,4),E(1,3),E(1,2),E(1,1),E(1,0), // 72-79 return E center
  ],
  // ── 2: BLACK (South arm) ──────────────────────
  [
    S(0,1),S(1,1),S(2,1),S(3,1),S(4,1),S(5,1),S(6,1),S(7,1), // 0-7   out S center
    S(7,2),S(6,2),S(5,2),S(4,2),S(3,2),S(2,2),S(1,2),S(0,2), // 8-15  L outer S col2
    E(2,0),E(2,1),E(2,2),E(2,3),E(2,4),E(2,5),E(2,6),E(2,7), // 16-23 E bottom row
    E(0,7),E(0,6),E(0,5),E(0,4),E(0,3),E(0,2),E(0,1),E(0,0), // 24-31 E top row
    N(7,2),N(6,2),N(5,2),N(4,2),N(3,2),N(2,2),N(1,2),N(0,2), // 32-39 N right col
    N(0,0),N(1,0),N(2,0),N(3,0),N(4,0),N(5,0),N(6,0),N(7,0), // 40-47 N left col
    W(0,7),W(0,6),W(0,5),W(0,4),W(0,3),W(0,2),W(0,1),W(0,0), // 48-55 W top row
    W(2,0),W(2,1),W(2,2),W(2,3),W(2,4),W(2,5),W(2,6),W(2,7), // 56-63 W bottom row
    S(0,0),S(1,0),S(2,0),S(3,0),S(4,0),S(5,0),S(6,0),S(7,0), // 64-71 R outer S col0
    S(7,1),S(6,1),S(5,1),S(4,1),S(3,1),S(2,1),S(1,1),S(0,1), // 72-79 return S center
  ],
  // ── 3: GREEN (West arm) ───────────────────────
  [
    W(1,7),W(1,6),W(1,5),W(1,4),W(1,3),W(1,2),W(1,1),W(1,0), // 0-7   out W center
    W(2,0),W(2,1),W(2,2),W(2,3),W(2,4),W(2,5),W(2,6),W(2,7), // 8-15  L outer W row2
    S(0,0),S(1,0),S(2,0),S(3,0),S(4,0),S(5,0),S(6,0),S(7,0), // 16-23 S left col
    S(7,2),S(6,2),S(5,2),S(4,2),S(3,2),S(2,2),S(1,2),S(0,2), // 24-31 S right col
    E(2,0),E(2,1),E(2,2),E(2,3),E(2,4),E(2,5),E(2,6),E(2,7), // 32-39 E bottom row
    E(0,7),E(0,6),E(0,5),E(0,4),E(0,3),E(0,2),E(0,1),E(0,0), // 40-47 E top row
    N(7,2),N(6,2),N(5,2),N(4,2),N(3,2),N(2,2),N(1,2),N(0,2), // 48-55 N right col
    N(0,0),N(1,0),N(2,0),N(3,0),N(4,0),N(5,0),N(6,0),N(7,0), // 56-63 N left col
    W(0,7),W(0,6),W(0,5),W(0,4),W(0,3),W(0,2),W(0,1),W(0,0), // 64-71 R outer W row0
    W(1,0),W(1,1),W(1,2),W(1,3),W(1,4),W(1,5),W(1,6),W(1,7), // 72-79 return W center
  ],
];

// ── Castle squares (12 total) ──────────────────────
// 4 at arm-center tips + 8 at outer-col 4th-from-tip
export const CASTLES = [
  N(0,1), N(3,0), N(3,2), // North arm
  S(7,1), S(4,0), S(4,2), // South arm
  W(1,0), W(0,3), W(2,3), // West arm
  E(1,7), E(0,4), E(2,4), // East arm
];

// Fast lookup: is a board coordinate a castle?
const _castleSet = new Set(CASTLES.map(c => `${c.x},${c.y}`));
export function isCastle(x, y) { return _castleSet.has(`${x},${y}`); }

// Is a player's path position safe from capture?
// Safe = castle square OR return home column (positions 72–79)
export function isSafe(player, pathIdx) {
  if (pathIdx < 0 || pathIdx >= 80) return false;
  if (pathIdx >= 72) return true; // return home col always safe
  const sq = PATHS[player][pathIdx];
  return isCastle(sq.x, sq.y);
}

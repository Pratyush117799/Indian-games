'use strict';

/* ─── Board geometry ─────────────────────────────────────── */
const CELL = 50;
const BOARD_PX = CELL * 8; // 400

/*
 * Full clockwise-inward spiral path covering all 64 squares.
 * Index 0 = entry point (top-left corner).
 * Indices 60-63 = centre HOME squares.
 *
 * Ring 1 (outer, 28 cells) → Ring 2 (20) → Ring 3 (12) → Home (4)
 */
const PATH = [
  /* Ring 1 ── top row */
  [0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],   // 0-7
  /* Ring 1 ── right col */
  [1,7],[2,7],[3,7],[4,7],[5,7],[6,7],[7,7],           // 8-14
  /* Ring 1 ── bottom row */
  [7,6],[7,5],[7,4],[7,3],[7,2],[7,1],[7,0],            // 15-21
  /* Ring 1 ── left col */
  [6,0],[5,0],[4,0],[3,0],[2,0],[1,0],                  // 22-27
  /* Ring 2 ── second row */
  [1,1],[1,2],[1,3],[1,4],[1,5],[1,6],                  // 28-33
  /* Ring 2 ── second-to-last col */
  [2,6],[3,6],[4,6],[5,6],[6,6],                        // 34-38
  /* Ring 2 ── second-to-last row */
  [6,5],[6,4],[6,3],[6,2],[6,1],                        // 39-43
  /* Ring 2 ── second col */
  [5,1],[4,1],[3,1],[2,1],                              // 44-47
  /* Ring 3 ── third row */
  [2,2],[2,3],[2,4],[2,5],                              // 48-51
  /* Ring 3 ── third-to-last col */
  [3,5],[4,5],[5,5],                                    // 52-54
  /* Ring 3 ── third-to-last row */
  [5,4],[5,3],[5,2],                                    // 55-57
  /* Ring 3 ── third col */
  [4,2],[3,2],                                          // 58-59
  /* Home centre */
  [3,3],[3,4],[4,4],[4,3]                               // 60-63
];

const PATH_LENGTH = PATH.length; // 64

/* Indices that are castle (sanctuary) squares */
const CASTLE_STEPS = new Set([
  0, 3, 4, 7,          // top edge: corner + mid-points
  10, 11, 14,          // right edge: mid-points + corner
  17, 18, 21,          // bottom edge: mid-points + corner
  24, 25,              // left edge: mid-points (corner already 0 & 22→but 22=[6,0] not a castle; actual left mid is 24=[4,0], 25=[3,0])
  60, 61, 62, 63       // home
]);

/* Home threshold — step >= HOME means piece is home */
const HOME_STEP = 60;

/* Absolute castle board cells (for capture logic) */
const CASTLE_CELLS = new Set(
  [...CASTLE_STEPS].map(i => `${PATH[i][0]},${PATH[i][1]}`)
);

/* ─── Player config ──────────────────────────────────────── */
const PLAYERS = [
  {
    id: 0,
    name: 'Player 1',
    label: 'Saffron',
    color: '#C8721A',
    colorLight: '#FDF0E0',
    colorDark: '#7A3D08',
    textOnColor: '#fff'
  },
  {
    id: 1,
    name: 'Player 2',
    label: 'Indigo',
    color: '#2B3A8F',
    colorLight: '#EEF0FA',
    colorDark: '#111840',
    textOnColor: '#fff'
  }
];

const NUM_PLAYERS = 2;
const PIECES_PER_PLAYER = 4;

/* ─── Cowrie dice ────────────────────────────────────────── */
/*
 * Roll 4 cowrie shells. Count how many land mouth-up.
 *   0 mouths → skip turn (0)
 *   1 mouth  → move 1
 *   2 mouths → move 2
 *   3 mouths → move 3
 *   4 mouths → move 8 (special throw)
 */
function rollCowries() {
  const shells = Array.from({ length: 4 }, () => Math.random() < 0.5);
  const mouthsUp = shells.filter(Boolean).length;
  const value = mouthsUp === 4 ? 8 : mouthsUp;
  return { shells, mouthsUp, value };
}

/* ─── Utilities ──────────────────────────────────────────── */
function cellCenter(row, col) {
  return { x: col * CELL + CELL / 2, y: row * CELL + CELL / 2 };
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

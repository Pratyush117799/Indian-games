// ── Auth ─────────────────────────────────────────────────────
export interface User {
  id:         string;
  username:   string;
  email:      string;
  avatar_url: string | null;
  created_at: string;
}

export interface AuthTokens {
  accessToken:  string;
  refreshToken: string;
}

// ── Games ─────────────────────────────────────────────────────
export type GameSlug = 'kattam-vilayattu' | 'paramapadam';

export interface Game {
  id:          string;
  slug:        GameSlug;
  name:        string;
  name_tamil:  string;
  description: string;
  min_players: number;
  max_players: number;
}

// ── Rooms ─────────────────────────────────────────────────────
export type RoomStatus = 'waiting' | 'active' | 'finished' | 'abandoned';
export type PlayerColor = 'green' | 'brown' | 'red' | 'blue' | 'yellow' | 'purple';

export interface GameRoom {
  id:          string;
  game_id:     string;
  room_code:   string;
  host_id:     string;
  status:      RoomStatus;
  max_players: number;
  is_private:  boolean;
  game_level:  number;
  started_at:  string | null;
  finished_at: string | null;
  created_at:  string;
  game_slug?:  GameSlug;
}

export interface RoomPlayer {
  id:          string;
  username:    string;
  avatar_url:  string | null;
  seat_index:  number;
  color:       PlayerColor;
  is_ready:    boolean;
}

// ── Kattam Vilayattu ─────────────────────────────────────────
export type KattamPhase = 'placement' | 'movement';

export interface KattamState {
  level:               number;
  size:                number;
  piecesPerPlayer:     number;
  board:               (string | null)[];   // indexed by cell; value = playerId
  phase:               KattamPhase;
  currentPlayerIndex:  number;
  players:             string[];
  piecesPlaced:        Record<string, number>;
  winner:              string | null;
  moveCount:           number;
}

export interface KattamMove {
  type:      'place' | 'move';
  cellIndex?: number;
  fromIndex?: number;
  toIndex?:   number;
  playerId:  string;
  phase:     KattamPhase;
}

// ── Paramapadam ───────────────────────────────────────────────
export type ParamapadamEvent = 'snake' | 'ladder' | 'win' | 'waiting' | null;

export interface ParamapadamState {
  players:             string[];
  positions:           Record<string, number>;
  currentPlayerIndex:  number;
  phase:               'active' | 'finished';
  winner:              string | null;
  lastDiceRoll:        number | null;
  lastEvent:           ParamapadamEvent;
  bonusTurn:           boolean;
  moveCount:           number;
}

// ── Leaderboard ───────────────────────────────────────────────
export interface LeaderboardEntry {
  rank:           number;
  id:             string;
  username:       string;
  avatar_url:     string | null;
  wins:           number;
  losses:         number;
  draws:          number;
  total_games:    number;
  win_rate:       number;
  rating:         number;
  best_time_secs: number | null;
}

// ── History ───────────────────────────────────────────────────
export type GameResult = 'win' | 'loss' | 'draw';

export interface HistoryEntry {
  session_id:       string;
  game_name:        string;
  game_slug:        GameSlug;
  room_code:        string;
  game_level:       number;
  total_moves:      number;
  duration_secs:    number | null;
  started_at:       string;
  ended_at:         string | null;
  result:           GameResult;
  winner_username:  string | null;
}

export interface ReplayMove {
  move_number:      number;
  move_data:        KattamMove | { roll: number; event: ParamapadamEvent; landed: number };
  board_state:      unknown;
  created_at:       string;
  player_username:  string;
  player_id:        string;
}

/**
 * questSlice.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Active quest state machine for patient encounters.
 *
 * Quest phases:
 *   idle        → no quest active
 *   arrival     → patient arriving (dialogue phase 1)
 *   diagnosis   → player identifies dosha imbalance
 *   prescription→ player selects herbs / recipe
 *   crafting    → mini-game: mortar & pestle
 *   outcome     → healing story + moral choice result
 *   complete    → XP awarded, quest closed
 */
import { createSlice } from '@reduxjs/toolkit';

const PHASES = ['idle','arrival','diagnosis','prescription','crafting','outcome','complete'];

const questSlice = createSlice({
  name: 'quest',
  initialState: {
    phase:          'idle',
    activePatient:  null,
    dailyPatients:  [],      // today's patient queue (3 patients)
    diagnosedDosha: null,    // what player diagnosed
    selectedRecipe: null,    // recipe player chose to craft
    craftResult:    null,    // result from attemptCraft
    moralChoice:    null,    // index 0-2 of moral choice made
    outcomeResult:  null,    // from evaluateTreatment
    history:        [],      // log of completed encounters this session
  },

  reducers: {
    setDailyPatients: (s, { payload }) => { s.dailyPatients = payload; },

    startQuest: (s, { payload: patient }) => {
      s.activePatient  = patient;
      s.phase          = 'arrival';
      s.diagnosedDosha = null;
      s.selectedRecipe = null;
      s.craftResult    = null;
      s.moralChoice    = null;
      s.outcomeResult  = null;
    },

    advancePhase: (s) => {
      const idx = PHASES.indexOf(s.phase);
      if (idx < PHASES.length - 1) s.phase = PHASES[idx + 1];
    },

    setPhase: (s, { payload }) => { s.phase = payload; },

    setDiagnosis: (s, { payload: dosha }) => {
      s.diagnosedDosha = dosha;
    },

    selectRecipe: (s, { payload: recipeId }) => {
      s.selectedRecipe = recipeId;
    },

    setCraftResult: (s, { payload: result }) => {
      s.craftResult = result;
    },

    setMoralChoice: (s, { payload: idx }) => {
      s.moralChoice = idx;
    },

    setOutcomeResult: (s, { payload: result }) => {
      s.outcomeResult = result;
    },

    completeQuest: (s) => {
      if (s.activePatient && s.outcomeResult) {
        s.history.push({
          patientId:   s.activePatient.id,
          patientName: s.activePatient.name,
          tier:        s.outcomeResult.outcomeTier,
          xpEarned:    s.outcomeResult.xpEarned,
          timestamp:   new Date().toISOString(),
        });
      }
      s.phase          = 'idle';
      s.activePatient  = null;
      s.diagnosedDosha = null;
      s.selectedRecipe = null;
      s.craftResult    = null;
      s.moralChoice    = null;
      s.outcomeResult  = null;
    },

    abandonQuest: (s) => {
      s.phase         = 'idle';
      s.activePatient = null;
    },
  },
});

export const {
  setDailyPatients, startQuest, advancePhase, setPhase,
  setDiagnosis, selectRecipe, setCraftResult,
  setMoralChoice, setOutcomeResult, completeQuest, abandonQuest,
} = questSlice.actions;

// Selectors
export const selectQuestPhase    = (s) => s.quest.phase;
export const selectActivePatient = (s) => s.quest.activePatient;
export const selectDailyPatients = (s) => s.quest.dailyPatients;
export const selectDiagnosis     = (s) => s.quest.diagnosedDosha;
export const selectSelectedRecipe= (s) => s.quest.selectedRecipe;
export const selectCraftResult   = (s) => s.quest.craftResult;
export const selectOutcomeResult = (s) => s.quest.outcomeResult;
export const selectQuestHistory  = (s) => s.quest.history;

export default questSlice.reducer;

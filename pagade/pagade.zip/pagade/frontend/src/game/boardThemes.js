/**
 * boardThemes.js — visual theme definitions for the Pagade board.
 * Each theme overrides CSS variables and board cell colours.
 *
 * Themes are cosmetic only — no gameplay change.
 * Unlock conditions: Temple Stone = default, Royal Silk = 5 wins, Night Festival = 15 wins
 */

export const BOARD_THEMES = {
  temple_stone: {
    id:           'temple_stone',
    name:         'Temple Stone',
    emoji:        '🗿',
    unlockWins:   0,
    description:  'Carved granite of Hampi temples',
    vars: {
      '--board-bg':       '#1a0e06',
      '--cell-default':   '#f5efe6',
      '--cell-stroke':    '#c4aa84',
      '--cell-safe-path': '#f0f7e8',
      '--cell-home':      '#2c1a0e',
      '--border-main':    '#8B6914',
      '--accent':         '#D4A017',
    },
    cellColors: {
      default:   '#f5efe6',
      safePath:  '#f0f7e8',
      home:      '#2c1a0e',
      safelanes:  ['#e8c4bc', '#b8d8c0', '#e8dfa8', '#b8cce0'],
    },
  },

  royal_silk: {
    id:           'royal_silk',
    name:         'Royal Silk',
    emoji:        '🪡',
    unlockWins:   5,
    description:  'Mysore silk — crimson & ivory',
    vars: {
      '--board-bg':       '#1c0a14',
      '--cell-default':   '#f9f0f5',
      '--cell-stroke':    '#c48ea0',
      '--cell-safe-path': '#f5eef8',
      '--cell-home':      '#2e0f22',
      '--border-main':    '#a04070',
      '--accent':         '#e07090',
    },
    cellColors: {
      default:   '#f9f0f5',
      safePath:  '#f5eef8',
      home:      '#2e0f22',
      safelanes: ['#f5c4d0', '#c4d8b0', '#f5e0b0', '#b0c4e0'],
      safelanes: ['#e8b8c8', '#b8d4a8', '#e8d8a8', '#b8c8d8'],
    },
  },

  night_festival: {
    id:           'night_festival',
    name:         'Night Festival',
    emoji:        '🪔',
    unlockWins:   15,
    description:  'Deepavali diyas on midnight stone',
    vars: {
      '--board-bg':       '#060412',
      '--cell-default':   '#1a1630',
      '--cell-stroke':    '#4a3878',
      '--cell-safe-path': '#141028',
      '--cell-home':      '#080618',
      '--border-main':    '#6040b0',
      '--accent':         '#c090ff',
    },
    cellColors: {
      default:   '#1a1630',
      safePath:  '#141028',
      home:      '#080618',
      safelanes: ['#301828', '#183018', '#302010', '#101828'],
    },
  },
};

export const DEFAULT_THEME = 'temple_stone';

/**
 * Returns the theme object for a given theme ID (falls back to default).
 */
export function getTheme(id) {
  return BOARD_THEMES[id] || BOARD_THEMES[DEFAULT_THEME];
}

/**
 * Applies a theme's CSS variables to document.documentElement.
 * Call this whenever the active theme changes.
 */
export function applyTheme(themeId) {
  const theme = getTheme(themeId);
  const root = document.documentElement;
  for (const [key, value] of Object.entries(theme.vars || {})) {
    root.style.setProperty(key, value);
  }
}

/**
 * Returns the correct safe lane fill colour for a given theme + player.
 */
export function getSafeLaneColor(themeId, playerId) {
  const theme = getTheme(themeId);
  const lanes = theme.cellColors.safelanes ||
                ['#e8c4bc', '#b8d8c0', '#e8dfa8', '#b8cce0'];
  return lanes[playerId] || lanes[0];
}

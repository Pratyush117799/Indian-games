/**
 * usePWA — registers the service worker and exposes the install prompt.
 * Call promptInstall() to trigger the browser's "Add to Home Screen" flow.
 */

import { useEffect, useState, useCallback } from 'react';

export function usePWA() {
  const [installPrompt, setInstallPrompt] = useState(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js')
        .then(reg => console.log('[PWA] SW registered:', reg.scope))
        .catch(err => console.warn('[PWA] SW registration failed:', err));
    }

    // Detect standalone mode (already installed)
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Capture install prompt event (Chrome/Edge)
    const beforeInstall = (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    // Network status
    const goOnline  = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', beforeInstall);
    window.addEventListener('appinstalled', () => { setIsInstalled(true); setInstallPrompt(null); });
    window.addEventListener('online',  goOnline);
    window.addEventListener('offline', goOffline);

    return () => {
      window.removeEventListener('beforeinstallprompt', beforeInstall);
      window.removeEventListener('online',  goOnline);
      window.removeEventListener('offline', goOffline);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') setIsInstalled(true);
    setInstallPrompt(null);
  }, [installPrompt]);

  return { canInstall: !!installPrompt && !isInstalled, isInstalled, isOnline, promptInstall };
}

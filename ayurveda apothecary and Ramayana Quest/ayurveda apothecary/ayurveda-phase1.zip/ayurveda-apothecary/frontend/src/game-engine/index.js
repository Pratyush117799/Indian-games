/**
 * index.js — Ayurveda Apothecary Game Engine
 * ─────────────────────────────────────────────────────────────────────────────
 * Single entry point. Import everything from here.
 *
 *   import { HERBS, getHerbById, RECIPES, attemptCraft,
 *            calculateDosha, getCurrentSeason, getDailyPatients }
 *     from './game-engine';
 */

// ── Herb database ──────────────────────────────────────────────────────────
export {
  HERBS,
  getHerbById,
  getHerbsByRarity,
  getHerbsBySeason,
  getHerbsByDosha,
  getHerbsByHabitat,
  getRandomHerbs,
} from './herbs.data.js';

// ── Dosha system ────────────────────────────────────────────────────────────
export {
  DOSHA_PROFILES,
  QUIZ_QUESTIONS,
  BALANCING_FORMULAS,
  calculateDosha,
  getDoshaAdvice,
  getDoshaForPatient,
} from './doshas.js';

// ── Crafting engine ─────────────────────────────────────────────────────────
export {
  RECIPES,
  getRecipeById,
  getRecipesByCategory,
  getRecipesByDosha,
  getRecipesByLevel,
  getRecipesByRarity,
  attemptCraft,
  suggestRecipesForSymptoms,
  discoverRecipe,
} from './crafting.js';

// ── Season engine ───────────────────────────────────────────────────────────
export {
  RITUS,
  TIME_DOSHAS,
  getCurrentSeason,
  getCurrentTimePeriod,
  getHerbGrowthRate,
  getFlourishingHerbs,
  getSeasonalContext,
  getGrowthProgress,
  getTimeDescription,
} from './seasons.js';

// ── Patient quest engine ────────────────────────────────────────────────────
export {
  PATIENTS,
  getDailyPatients,
  evaluateTreatment,
  getPatientById,
} from './patients.js';

// ── Derived helpers ─────────────────────────────────────────────────────────

import { HERBS }           from './herbs.data.js';
import { RECIPES }         from './crafting.js';
import { getCurrentSeason, getHerbGrowthRate } from './seasons.js';

/**
 * Returns a complete garden snapshot for the current real-world moment.
 * Used by the Garden scene to initialise state.
 */
export function getGardenSnapshot(plantedHerbs = []) {
  const season = getCurrentSeason();
  return plantedHerbs.map(plant => ({
    ...plant,
    growthRate: getHerbGrowthRate(plant.herbId),
    herb: HERBS.find(h => h.id === plant.herbId),
  }));
}

/**
 * Quick dosha-to-herbs mapping for UI hint tooltips.
 */
export const DOSHA_HERBS = {
  vata:  ['ashwagandha', 'brahmi', 'shatavari', 'bala', 'licorice', 'ginger', 'cinnamon'],
  pitta: ['amla', 'shatavari', 'rose', 'aloe', 'licorice', 'cardamom', 'coriander'],
  kapha: ['trikatu', 'turmeric', 'ginger', 'pepper', 'tulsi', 'guduchi', 'moringa'],
};

/**
 * XP thresholds for level progression.
 */
export const LEVEL_XP = [
  0,     // Level 1
  100,   // Level 2
  250,   // Level 3
  500,   // Level 4
  900,   // Level 5
  1500,  // Level 6
  2500,  // Level 7
  4000,  // Level 8
  6000,  // Level 9
  9000,  // Level 10 — Sage rank
];

export const getLevelFromXP = (xp) =>
  LEVEL_XP.findLastIndex(threshold => xp >= threshold) + 1;

export const getXPForNextLevel = (xp) => {
  const level = getLevelFromXP(xp);
  return LEVEL_XP[level] ?? null; // null = max level
};

/**
 * Rank titles by level.
 */
export const RANKS = [
  'Shishya',        // 1  — Apprentice
  'Chikitsaka',     // 2  — Practitioner
  'Aushadhika',     // 3  — Herbalist
  'Vaidya',         // 4  — Physician
  'Visharada',      // 5  — Expert
  'Acharya',        // 6  — Teacher
  'Mahavaidya',     // 7  — Master Healer
  'Dhanvantari',    // 8  — Divine Healer (mythological reference)
  'Charaka',        // 9  — Legendary (named after the father of Ayurveda)
  'Parama Vaidya',  // 10 — Supreme Healer
];

export const getRankFromLevel = (level) => RANKS[Math.min(level - 1, RANKS.length - 1)];

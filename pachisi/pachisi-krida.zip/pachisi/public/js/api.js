// ═══════════════════════════════════════════════════
//  API · HTTP client for the Express backend
// ═══════════════════════════════════════════════════

const BASE = '/api/games';

async function _json(url, opts = {}) {
  try {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...opts,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    // Non-fatal — game runs fine offline
    console.warn('[API]', err.message);
    return null;
  }
}

// Start a new game session; returns { gameId } or null
export async function createGame() {
  const data = await _json(BASE, { method: 'POST' });
  return data?.ok ? data.gameId : null;
}

// Auto-save current state (fire-and-forget)
export function saveState(gameId, state) {
  if (!gameId) return;
  _json(`${BASE}/${gameId}/state`, {
    method: 'PUT',
    body: JSON.stringify({ state }),
  });
}

// Mark the game as finished
export async function endGame(gameId, winner) {
  if (!gameId) return;
  await _json(`${BASE}/${gameId}/end`, {
    method: 'POST',
    body: JSON.stringify({ winner }),
  });
}

// Fetch global stats
export async function fetchStats() {
  const data = await _json(`${BASE}/meta/stats`);
  return data?.ok ? data.stats : null;
}

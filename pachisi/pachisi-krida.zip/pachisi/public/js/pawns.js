// ═══════════════════════════════════════════════════
//  PAWNS · Beehive pawn rendering + step-animation
// ═══════════════════════════════════════════════════

import { CS, COLORS } from './config.js';
import { PATHS } from './paths.js';
import { HOME, se } from './geometry.js';
import { G } from './state.js';

const $ = id => document.getElementById(id);

// ── Compute on-screen coordinate for a pawn ───────
export function getPawnCoord(player, pawnIdx) {
  const pawn = G.pawns[player][pawnIdx];
  if (pawn.pos === 80) return null; // finished — off board

  if (pawn.pos === -1) {
    // Waiting in Charkoni — arrange 4 per player in a small cluster
    const qOff = [[-1, -1], [1, -1], [-1, 1], [1, 1]]; // quadrant per player
    const qo   = qOff[player];
    const iOff = [[-1,-1],[1,-1],[-1,1],[1,1]];         // within quadrant
    const io   = iOff[pawnIdx];
    return {
      x: HOME.x + qo[0] * 8 + io[0] * 4,
      y: HOME.y + qo[1] * 8 + io[1] * 4,
    };
  }

  const sq = PATHS[player][pawn.pos];
  // Stack offset: offset pieces sharing the same square
  const n  = _stackCount(player, pawnIdx, sq);
  const sOff = [[0,0],[4,-4],[-4,4],[4,4]];
  const so = sOff[Math.min(n, 3)];
  return { x: sq.x + so[0], y: sq.y + so[1] };
}

// Count how many pawns (from any player/team) are already on sq
// before this pawn in render order
function _stackCount(player, pawnIdx, sq) {
  let n = 0;
  outer: for (let p = 0; p < 4; p++) {
    for (let i = 0; i < 4; i++) {
      if (p === player && i === pawnIdx) break outer;
      const pw = G.pawns[p][i];
      if (pw.pos >= 0 && pw.pos < 80) {
        const osq = PATHS[p][pw.pos];
        if (osq.x === sq.x && osq.y === sq.y) n++;
      }
    }
  }
  return n;
}

// ── Full pawn layer re-render ──────────────────────
export function renderPawns() {
  const layer = $('layer-pawns');
  layer.innerHTML = '';
  for (let p = 0; p < 4; p++) {
    for (let i = 0; i < 4; i++) {
      if (G.pawns[p][i].pos === 80) continue;
      const pos = getPawnCoord(p, i);
      if (!pos) continue;
      layer.appendChild(_buildPawnEl(p, i, pos));
    }
  }
}

// Build a beehive-shaped SVG pawn element
function _buildPawnEl(player, pawnIdx, pos) {
  const col = COLORS[player];
  const g   = se('g', {
    class: 'pawn-group',
    id:    `pg-${player}-${pawnIdx}`,
    transform: `translate(${pos.x},${pos.y})`,
  });

  // Ground shadow
  g.appendChild(se('ellipse', { cx: 0, cy: 8, rx: 7, ry: 2.5, fill: 'rgba(0,0,0,0.44)' }));

  // Body parts
  const body = se('g', { class: 'pawn-body' });
  // Base disc
  body.appendChild(se('ellipse', { cx: 0, cy:  5,   rx: 7.5, ry: 4,   fill: col, stroke: 'rgba(0,0,0,0.3)', 'stroke-width': 0.6 }));
  // Waist bulge
  body.appendChild(se('ellipse', { cx: 0, cy:  0,   rx: 6.2, ry: 6.2, fill: col, stroke: 'rgba(0,0,0,0.2)', 'stroke-width': 0.5 }));
  // Upper taper
  body.appendChild(se('ellipse', { cx: 0, cy: -5.2, rx: 3.8, ry: 4.2, fill: col, stroke: 'rgba(0,0,0,0.15)', 'stroke-width': 0.4 }));
  // Gold cap
  body.appendChild(se('ellipse', { cx: 0, cy: -7.2, rx: 3.2, ry: 2.4,
    fill: 'rgba(201,153,58,0.93)', stroke: 'rgba(232,201,106,0.82)', 'stroke-width': 0.7 }));
  // Cap jewel
  body.appendChild(se('circle',  { cx: 0, cy: -8.4, r: 1.4, fill: 'rgba(240,220,100,0.95)' }));
  // Specular highlight
  body.appendChild(se('ellipse', { cx: -2.2, cy: -2, rx: 1.7, ry: 3,
    fill: 'rgba(255,255,255,0.18)', transform: 'rotate(-25,-2.2,-2)' }));

  g.appendChild(body);
  return g;
}

// ── Update a single pawn's position (fast, no full re-render) ─
export function movePawnEl(player, pawnIdx) {
  const el  = document.getElementById(`pg-${player}-${pawnIdx}`);
  if (!el) { renderPawns(); return; }
  const pos = getPawnCoord(player, pawnIdx);
  if (!pos) { el.style.display = 'none'; return; }
  el.style.display = '';
  el.setAttribute('transform', `translate(${pos.x},${pos.y})`);
}

// ── Step-by-step pawn movement animation ─────────
// Moves pawn one square at a time; calls done() when finished.
export function stepAnimate(player, pawnIdx, targetPos, done) {
  const pawn = G.pawns[player][pawnIdx];
  const from = pawn.pos === -1 ? -1 : pawn.pos;

  if (from === -1) {
    // Enter from Charkoni → position 0
    pawn.pos = 0;
    movePawnEl(player, pawnIdx);
    setTimeout(done, 280);
    return;
  }
  _stepNext(player, pawnIdx, from, targetPos, 0, done);
}

function _stepNext(player, pawnIdx, from, to, step, done) {
  const next = from + step + 1;
  if (next > to) { done(); return; }
  G.pawns[player][pawnIdx].pos = Math.min(next, 80);
  movePawnEl(player, pawnIdx);
  setTimeout(() => _stepNext(player, pawnIdx, from, to, step + 1, done),
    next < 80 ? 90 : 150);
}

// ── Move highlight squares ─────────────────────────
export function showHighlights(moves) {
  const layer = $('layer-highlights');
  layer.innerHTML = '';
  moves.forEach(({ player, targetPos }) => {
    if (targetPos < 0 || targetPos >= 80) return;
    const sq = PATHS[player][targetPos];
    const r  = se('rect', {
      x: sq.x - CS / 2, y: sq.y - CS / 2, width: CS, height: CS, rx: 2,
      fill: 'rgba(232,201,106,0.18)',
      stroke: 'rgba(232,201,106,0.78)', 'stroke-width': 1,
      class: 'move-hl',
    });
    layer.appendChild(r);
  });
}

export function clearHighlights() {
  $('layer-highlights').innerHTML = '';
}

// ── Mark / unmark selectable pawns ────────────────
export function markSelectable(player, pawnIndices) {
  pawnIndices.forEach(i => {
    const el = document.getElementById(`pg-${player}-${i}`);
    if (el) el.classList.add('selectable');
  });
}
export function unmarkSelectable() {
  document.querySelectorAll('.pawn-group.selectable, .pawn-group.selected')
    .forEach(el => el.classList.remove('selectable', 'selected'));
}
export function markSelected(player, pawnIdx) {
  const el = document.getElementById(`pg-${player}-${pawnIdx}`);
  if (el) el.classList.add('selected');
}

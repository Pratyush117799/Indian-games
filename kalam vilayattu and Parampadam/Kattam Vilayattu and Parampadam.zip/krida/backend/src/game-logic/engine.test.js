/**
 * Game Engine Unit Tests
 * Run: node backend/src/game-logic/engine.test.js
 */

const {
  createGameState: createKattam,
  applyPlacement, applyMovement, getLegalMoves, buildWinLines,
} = require('./kattam/engine');

const {
  createGameState: createParamapadam,
  applyTurn, squareToCoord, SNAKES, LADDERS,
} = require('./paramapadam/engine');

// ── Simple test harness ───────────────────────────────────────
let passed = 0, failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓  ${name}`);
    passed++;
  } catch (e) {
    console.error(`  ✗  ${name}`);
    console.error(`     ${e.message}`);
    failed++;
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'Assertion failed');
}
function assertEqual(a, b, msg) {
  if (a !== b) throw new Error(msg || `Expected ${b}, got ${a}`);
}

// ══════════════════════════════════════════════════════════════
// KATTAM VILAYATTU
// ══════════════════════════════════════════════════════════════
console.log('\n── Kattam Vilayattu ────────────────────────────────');

const P1 = 'player-1', P2 = 'player-2';

test('createGameState level 2 produces correct shape', () => {
  const s = createKattam(2, [P1, P2]);
  assertEqual(s.size, 4);
  assertEqual(s.piecesPerPlayer, 4);
  assertEqual(s.board.length, 16);
  assertEqual(s.phase, 'placement');
  assertEqual(s.currentPlayerIndex, 0);
  assert(s.winner === null);
});

test('placement puts piece on board', () => {
  const s = createKattam(2, [P1, P2]);
  const { newState } = applyPlacement(s, P1, 0);
  assertEqual(newState.board[0], P1);
  assertEqual(newState.currentPlayerIndex, 1);
  assertEqual(newState.piecesPlaced[P1], 1);
});

test('cannot place on occupied cell', () => {
  let s = createKattam(2, [P1, P2]);
  ({ newState: s } = applyPlacement(s, P1, 0));
  ({ newState: s } = applyPlacement(s, P2, 1));
  const { error } = applyPlacement(s, P1, 0);
  assert(error, 'Expected error for occupied cell');
});

test('wrong player gets error', () => {
  const s = createKattam(2, [P1, P2]);
  const { error } = applyPlacement(s, P2, 0); // P1's turn
  assert(error, 'Expected error for wrong player');
});

test('transitions to movement phase after all pieces placed', () => {
  let s = createKattam(2, [P1, P2]);
  const cells = [0,1,2,3,4,5,6,7]; // 8 cells for 2×4 pieces
  for (let i = 0; i < 8; i++) {
    const player = i % 2 === 0 ? P1 : P2;
    ({ newState: s } = applyPlacement(s, player, cells[i]));
  }
  assertEqual(s.phase, 'movement');
});

test('win detected in placement phase (3×3)', () => {
  let s = createKattam(1, [P1, P2]);
  // P1 places at 0,2,4 — not a win (need full row/col/diag)
  // P1 places at 0,1,2 (top row) → win
  ({ newState: s } = applyPlacement(s, P1, 0));
  ({ newState: s } = applyPlacement(s, P2, 3));
  ({ newState: s } = applyPlacement(s, P1, 1));
  ({ newState: s } = applyPlacement(s, P2, 4));
  ({ newState: s } = applyPlacement(s, P1, 2)); // completes top row
  assertEqual(s.winner, P1);
});

test('getLegalMoves returns all empty cells in placement', () => {
  const s = createKattam(1, [P1, P2]); // 3×3 = 9 cells
  const moves = getLegalMoves(s);
  assertEqual(moves.length, 9);
  assert(moves.every(m => m.type === 'place'));
});

test('buildWinLines 3×3 has 8 lines (3 rows + 3 cols + 2 diags)', () => {
  const lines = buildWinLines(3);
  assertEqual(lines.length, 8);
});

test('buildWinLines 4×4 has 10 lines', () => {
  const lines = buildWinLines(4);
  assertEqual(lines.length, 10);
});

// ══════════════════════════════════════════════════════════════
// PARAMAPADAM
// ══════════════════════════════════════════════════════════════
console.log('\n── Paramapadam ─────────────────────────────────────');

test('createGameState for 2 players has correct shape', () => {
  const s = createParamapadam([P1, P2]);
  assertEqual(s.players.length, 2);
  assertEqual(s.positions[P1], 0);
  assertEqual(s.positions[P2], 0);
  assertEqual(s.phase, 'active');
  assert(s.winner === null);
});

test('must roll 1 to enter board', () => {
  const s = createParamapadam([P1, P2]);
  // Force roll of 3 — should not enter
  const { newState, event } = applyTurn(s, P1, 3);
  assertEqual(newState.positions[P1], 0);
  assertEqual(event, 'waiting');
  assertEqual(newState.currentPlayerIndex, 1);
});

test('roll 1 enters board at square 1', () => {
  const s = createParamapadam([P1, P2]);
  const { newState } = applyTurn(s, P1, 1);
  assertEqual(newState.positions[P1], 1);
});

test('normal advance moves piece forward', () => {
  let s = createParamapadam([P1, P2]);
  ({ newState: s } = applyTurn(s, P1, 1)); // enter at 1
  ({ newState: s } = applyTurn(s, P2, 1)); // P2 enter
  ({ newState: s } = applyTurn(s, P1, 3)); // P1: 1+3=4 → ladder to 14
  // square 4 is a ladder bottom → should be 14
  assertEqual(s.positions[P1], 14);
  assertEqual(s.lastEvent, 'ladder');
});

test('landing on snake head slides down', () => {
  let s = createParamapadam([P1, P2]);
  // Put P1 at square 94 artificially then roll 5 to reach 99 (snake head)
  s = { ...s, positions: { ...s.positions, [P1]: 94 }, currentPlayerIndex: 0 };
  const { newState } = applyTurn(s, P1, 5);
  assertEqual(newState.positions[P1], SNAKES[99]); // 99 → 7
  assertEqual(newState.lastEvent, 'snake');
});

test('overshoot bounces back', () => {
  let s = createParamapadam([P1, P2]);
  s = { ...s, positions: { ...s.positions, [P1]: 98 }, currentPlayerIndex: 0 };
  const { newState } = applyTurn(s, P1, 5); // 98+5=103 → bounce to 97
  assertEqual(newState.positions[P1], 97);
});

test('roll 6 gives bonus turn', () => {
  let s = createParamapadam([P1, P2]);
  s = { ...s, positions: { ...s.positions, [P1]: 10 }, currentPlayerIndex: 0 };
  const { newState } = applyTurn(s, P1, 6);
  assert(newState.bonusTurn, 'Expected bonus turn for rolling 6');
  assertEqual(newState.currentPlayerIndex, 0); // still P1's turn
});

test('winning: reaching exactly 100 sets winner', () => {
  let s = createParamapadam([P1, P2]);
  s = { ...s, positions: { ...s.positions, [P1]: 97 }, currentPlayerIndex: 0 };
  const { newState } = applyTurn(s, P1, 3);
  assertEqual(newState.winner, P1);
  assertEqual(newState.phase, 'finished');
});

test('squareToCoord: square 1 is bottom-left (row 9, col 0)', () => {
  const { row, col } = squareToCoord(1);
  assertEqual(row, 9);
  assertEqual(col, 0);
});

test('squareToCoord: square 100 is top-left (row 0, col 0)', () => {
  const { row, col } = squareToCoord(100);
  assertEqual(row, 0);
  // col depends on which direction row 9 (0-indexed from bottom) faces
  // row 9 from bottom = gridRow 9, which is odd → right-to-left → col 9-9=0... actually 9 from bottom
  // Let's just check row
  assertEqual(row, 0);
});

test('wrong player gets error in paramapadam', () => {
  const s = createParamapadam([P1, P2]);
  const { error } = applyTurn(s, P2, 1); // P1's turn
  assert(error, 'Expected error for wrong player');
});

// ── Summary ───────────────────────────────────────────────────
console.log(`\n${'─'.repeat(50)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);

/**
 * guru.js — AI Guru Charaka handler
 * Uses Anthropic Claude to answer children's Ayurvedic questions in-character.
 */
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

const CHARAKA_SYSTEM = `You are Sage Charaka, the ancient father of Ayurvedic medicine, 
speaking to a young student playing a healing card game. You are wise, warm, and patient.
Speak in clear, simple English that even a 10-year-old can understand.
Keep answers to 2-3 sentences. Always tie your answer back to herbs or healing.
Never break character. You lived in India around 300 BCE.
When asked about herbs, share ONE specific fascinating fact.
Greet the student warmly as "young Vaidya" or "my student".`;

export async function askGuru(question, language = 'english') {
  const langInstruction = language !== 'english'
    ? `Answer in simple ${language} that a child can understand.`
    : '';

  const response = await client.messages.create({
    model: 'claude-opus-4-6',
    max_tokens: 200,
    system: CHARAKA_SYSTEM,
    messages: [{ role: 'user', content: `${question}\n${langInstruction}` }],
  });

  return response.content[0]?.text ?? 'The ancient texts are silent on this matter, young Vaidya. Ask again.';
}

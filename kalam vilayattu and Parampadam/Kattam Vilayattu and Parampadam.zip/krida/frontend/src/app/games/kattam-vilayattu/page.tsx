'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { Hash, Lock, Unlock } from 'lucide-react';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

const LEVELS = [
  { value: 1, label: 'Level I',  grid: '3×3', pieces: '3 pieces', desc: 'Beginner — fast & simple' },
  { value: 2, label: 'Level II', grid: '4×4', pieces: '4 pieces', desc: 'Standard — deeper strategy' },
  { value: 3, label: 'Level III',grid: '5×5', pieces: '5 pieces', desc: 'Advanced — complex tactics' },
];

export default function KattamLobbyPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [level,     setLevel]     = useState(2);
  const [isPrivate, setIsPrivate] = useState(false);
  const [joinCode,  setJoinCode]  = useState('');
  const [loading,   setLoading]   = useState(false);
  const [tab,       setTab]       = useState<'create' | 'join'>('create');

  async function handleCreate() {
    if (!user) return router.push('/auth/login');
    setLoading(true);
    try {
      const { data } = await api.post('/games/kattam-vilayattu/rooms', {
        level, isPrivate, maxPlayers: 2,
      });
      toast.success(`Room ${data.roomCode} created!`);
      router.push(`/games/kattam-vilayattu/play?room=${data.roomCode}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Could not create room');
    } finally { setLoading(false); }
  }

  async function handleJoin(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return router.push('/auth/login');
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setLoading(true);
    try {
      await api.post(`/rooms/${code}/join`);
      router.push(`/games/kattam-vilayattu/play?room=${code}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.error || 'Could not join room');
    } finally { setLoading(false); }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 space-y-8">
      {/* Header */}
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold text-temple">Kattam Vilayattu</h1>
        <p className="font-tamil text-clay/70">கட்டம் விளையாட்டு</p>
        <p className="text-sm text-gray-500 max-w-md mx-auto">
          Ancient Tamil alignment game. Place and move pieces on a kolam-drawn grid to align your pieces first.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl overflow-hidden border border-clay/20">
        {(['create','join'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-2.5 text-sm font-semibold transition ${tab === t ? 'bg-clay text-cream' : 'bg-white text-clay hover:bg-clay/5'}`}>
            {t === 'create' ? '+ Create Room' : '→ Join Room'}
          </button>
        ))}
      </div>

      {tab === 'create' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card space-y-6">
          {/* Level selector */}
          <div>
            <label className="text-sm font-semibold text-gray-600 block mb-2">Select Level</label>
            <div className="grid grid-cols-3 gap-3">
              {LEVELS.map(l => (
                <button key={l.value} onClick={() => setLevel(l.value)}
                  className={`rounded-xl border-2 p-3 text-left transition ${
                    level === l.value ? 'border-clay bg-clay/5' : 'border-clay/15 hover:border-clay/30'}`}>
                  <p className="font-bold text-temple text-sm">{l.label}</p>
                  <p className="text-xs text-kolam font-mono">{l.grid}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{l.pieces}</p>
                  <p className="text-xs text-gray-400">{l.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Privacy toggle */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-600">Room Privacy</p>
              <p className="text-xs text-gray-400">{isPrivate ? 'Private — share code to invite' : 'Public — anyone can join'}</p>
            </div>
            <button onClick={() => setIsPrivate(!isPrivate)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition text-sm font-medium ${
                isPrivate ? 'border-clay bg-clay/5 text-clay' : 'border-gray-200 text-gray-400'}`}>
              {isPrivate ? <Lock size={14} /> : <Unlock size={14} />}
              {isPrivate ? 'Private' : 'Public'}
            </button>
          </div>

          <button onClick={handleCreate} disabled={loading} className="btn-primary w-full text-base py-3">
            {loading ? 'Creating…' : 'Create Room →'}
          </button>
        </motion.div>
      )}

      {tab === 'join' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card space-y-4">
          <p className="text-sm text-gray-500">Enter the 6-character room code shared by your opponent.</p>
          <form onSubmit={handleJoin} className="space-y-3">
            <div className="relative">
              <Hash size={16} className="absolute left-3 top-3 text-clay/40" />
              <input
                value={joinCode}
                onChange={e => setJoinCode(e.target.value.toUpperCase().slice(0, 6))}
                className="input pl-8 font-mono text-lg tracking-widest uppercase"
                placeholder="ABC123"
                maxLength={6}
              />
            </div>
            <button type="submit" disabled={loading || joinCode.length !== 6} className="btn-primary w-full py-3">
              {loading ? 'Joining…' : 'Join Room →'}
            </button>
          </form>
        </motion.div>
      )}

      {/* How to play quick-ref */}
      <div className="card border-l-4 border-kolam bg-kolam/5 space-y-1 text-sm text-gray-600">
        <p className="font-semibold text-clay">How to play</p>
        <p>① <strong>Placement:</strong> Take turns placing pieces on any empty intersection.</p>
        <p>② <strong>Movement:</strong> Once all placed, slide pieces to adjacent connected points.</p>
        <p>③ <strong>Win:</strong> First to align all your pieces in one row, column, or diagonal wins.</p>
      </div>
    </div>
  );
}

import { Router } from 'express';
export const sanskritiRouter = Router();
sanskritiRouter.get('/:id', (req,res) => res.json({playerId:req.params.id,score:0}));
sanskritiRouter.post('/:id/award', (req,res) => res.json({playerId:req.params.id,awarded:req.body.points}));

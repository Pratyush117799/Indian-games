'use strict';
/* Game model — wraps DB queries for game persistence */
/* Replace `pool` with your pg/better-sqlite3 connection */

class GameModel {
  constructor(pool) { this.pool = pool; }

  async create({ mode, difficulty, hostUserId }) {
    const { rows } = await this.pool.query(
      `INSERT INTO games (mode, difficulty, host_user_id)
       VALUES ($1, $2, $3) RETURNING *`,
      [mode, difficulty, hostUserId]
    );
    return rows[0];
  }

  async findById(id) {
    const { rows } = await this.pool.query('SELECT * FROM games WHERE id=$1', [id]);
    return rows[0] || null;
  }

  async finish(id, { winner, totalMoves, durationSecs }) {
    const { rows } = await this.pool.query(
      `UPDATE games SET status='finished', winner=$2,
       total_moves=$3, duration_secs=$4, finished_at=NOW()
       WHERE id=$1 RETURNING *`,
      [id, winner, totalMoves, durationSecs]
    );
    return rows[0];
  }

  async recordMove(gameId, move) {
    const { moveNumber, player, pieceIndex, fromStep, toStep,
            diceValue, shells, captured, isCastle } = move;
    await this.pool.query(
      `INSERT INTO moves
       (game_id,move_number,player,piece_index,from_step,to_step,
        dice_value,shells,captured,is_castle)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [gameId, moveNumber, player, pieceIndex, fromStep, toStep,
       diceValue, shells, captured, isCastle]
    );
  }

  async getReplay(gameId) {
    const game = await this.findById(gameId);
    const { rows: moves } = await this.pool.query(
      'SELECT * FROM moves WHERE game_id=$1 ORDER BY move_number ASC',
      [gameId]
    );
    return { game, moves };
  }
}

module.exports = GameModel;

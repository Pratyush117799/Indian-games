/**
 * doshas.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Complete Dosha system engine.
 *
 * Exports:
 *   DOSHA_PROFILES       — Vata / Pitta / Kapha descriptions
 *   QUIZ_QUESTIONS       — 20 questions across 4 categories
 *   calculateDosha(answers) → { vata, pitta, kapha, dominant, secondary, type }
 *   getDoshaAdvice(type)  → { diet, lifestyle, herbs, avoid }
 *   getDoshaForPatient(symptoms) → dominant dosha causing imbalance
 */

/* ── DOSHA PROFILES ────────────────────────────────────────────────────────── */

export const DOSHA_PROFILES = {
  vata: {
    id: 'vata',
    name: 'Vata',
    sanskrit: 'वात',
    emoji: '💨',
    element: 'Air + Space',
    colour: '#A8DADC',
    qualities: ['Creative', 'Energetic', 'Enthusiastic', 'Quick-thinking', 'Talkative'],
    physique: 'Slim, light frame. Dry skin and hair. Cold hands and feet. Variable appetite.',
    mind: 'Quick learner but forgets quickly. Creative and imaginative. Tends to worry.',
    season: 'autumn',
    timeOfDay: 'Dawn (2am–6am) and Dusk (2pm–6pm)',
    bodyParts: 'Nervous system, colon, bones, joints',
    imbalanceSigns: ['Anxiety & worry', 'Dry skin', 'Constipation', 'Joint pain', 'Insomnia', 'Racing thoughts'],
    balancingQualities: ['Warmth', 'Moisture', 'Stability', 'Routine', 'Nourishment'],
    avatar: 'vata_avatar',
    colour_dark: '#2B7A78',
  },
  pitta: {
    id: 'pitta',
    name: 'Pitta',
    sanskrit: 'पित्त',
    emoji: '🔥',
    element: 'Fire + Water',
    colour: '#E9C46A',
    qualities: ['Intelligent', 'Focused', 'Courageous', 'Leadership', 'Sharp'],
    physique: 'Medium build, muscular. Warm skin, often oily. Good metabolism. Sharp features.',
    mind: 'Excellent concentration. Natural leader. Tendency to be critical or angry when imbalanced.',
    season: 'summer',
    timeOfDay: 'Mid-morning (10am–2pm) and Midnight (10pm–2am)',
    bodyParts: 'Digestive system, liver, blood, eyes',
    imbalanceSigns: ['Anger & irritability', 'Acid reflux', 'Skin rashes', 'Excessive sweating', 'Inflammation', 'Perfectionism to excess'],
    balancingQualities: ['Coolness', 'Moderation', 'Calmness', 'Sweetness', 'Rest'],
    avatar: 'pitta_avatar',
    colour_dark: '#C77800',
  },
  kapha: {
    id: 'kapha',
    name: 'Kapha',
    sanskrit: 'कफ',
    emoji: '🌊',
    element: 'Earth + Water',
    colour: '#95D5B2',
    qualities: ['Caring', 'Patient', 'Loyal', 'Stable', 'Strong memory'],
    physique: 'Larger, heavier frame. Smooth, oily skin. Thick hair. Steady appetite.',
    mind: 'Slow learner but never forgets. Deep empathy and compassion. Can become possessive.',
    season: 'spring',
    timeOfDay: 'Morning (6am–10am) and Evening (6pm–10pm)',
    bodyParts: 'Lungs, stomach, lymph, joints',
    imbalanceSigns: ['Weight gain', 'Congestion & mucus', 'Lethargy', 'Depression', 'Attachment', 'Slow digestion'],
    balancingQualities: ['Warmth', 'Lightness', 'Stimulation', 'Movement', 'Dryness'],
    avatar: 'kapha_avatar',
    colour_dark: '#0B6E4F',
  },
};

/* ── QUIZ QUESTIONS (20 questions across 4 categories) ─────────────────────── */
/*
 * Each question has:
 *   id       unique identifier
 *   category physical | mental | digestion | lifestyle
 *   text     the question shown to player
 *   childText simpler version for younger players
 *   options  [{ label, vata, pitta, kapha }] — scores added on selection
 */

export const QUIZ_QUESTIONS = [

  /* ── PHYSICAL APPEARANCE ────────────────────────────────────────────────── */
  {
    id: 'body_frame',
    category: 'physical',
    text: 'My body frame is naturally…',
    childText: 'My body looks…',
    options: [
      { label: 'Thin and light — hard to gain weight', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Medium and muscular', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Larger and sturdy — easy to gain weight', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'skin_type',
    category: 'physical',
    text: 'My skin is usually…',
    childText: 'My skin feels…',
    options: [
      { label: 'Dry, rough, or flaky — especially in cold weather', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Warm, reddish, oily in some areas', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Smooth, soft, and often oily', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'hair',
    category: 'physical',
    text: 'My hair is naturally…',
    childText: 'My hair is…',
    options: [
      { label: 'Dry, thin, and gets tangled easily', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Fine, straight, and prone to early greying', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Thick, wavy, lustrous, and grows fast', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'temperature',
    category: 'physical',
    text: 'I tend to feel…',
    childText: 'Usually I feel…',
    options: [
      { label: 'Cold most of the time — love warmth', vata: 2, pitta: 0, kapha: 1 },
      { label: 'Hot — prefer cool environments', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Generally comfortable, neither too hot nor cold', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'energy',
    category: 'physical',
    text: 'My energy levels are…',
    childText: 'I get tired…',
    options: [
      { label: 'Variable — bursts of energy then sudden crashes', vata: 2, pitta: 0, kapha: 0 },
      { label: 'High and sustained — driven and purposeful', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Steady but slow — I can endure for long', vata: 0, pitta: 0, kapha: 2 },
    ],
  },

  /* ── DIGESTION & APPETITE ────────────────────────────────────────────────── */
  {
    id: 'appetite',
    category: 'digestion',
    text: 'My appetite is usually…',
    childText: 'When it comes to eating, I…',
    options: [
      { label: 'Irregular — sometimes very hungry, sometimes not at all', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Strong — I get irritable if I miss a meal', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Steady but I can skip meals without much trouble', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'digestion',
    category: 'digestion',
    text: 'After eating a full meal, I usually…',
    childText: 'After eating, I feel…',
    options: [
      { label: 'Feel bloated or have gas', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Feel good quickly — I digest fast', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Feel heavy and sleepy — digest slowly', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'food_preference',
    category: 'digestion',
    text: 'I am naturally drawn to foods that are…',
    childText: 'I like food that is…',
    options: [
      { label: 'Warm, soft, and comforting', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Cool, fresh, and light', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Spicy, pungent, and stimulating', vata: 0, pitta: 0, kapha: 2 },
    ],
  },

  /* ── MENTAL & EMOTIONAL ──────────────────────────────────────────────────── */
  {
    id: 'memory',
    category: 'mental',
    text: 'When it comes to memory…',
    childText: 'When I learn new things…',
    options: [
      { label: 'I learn quickly but forget quickly', vata: 2, pitta: 0, kapha: 0 },
      { label: 'I am sharp and focused — remember what matters', vata: 0, pitta: 2, kapha: 0 },
      { label: 'I learn slowly but once I know it, I never forget', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'under_stress',
    category: 'mental',
    text: 'When I am under pressure or stress, I tend to…',
    childText: 'When things go wrong, I…',
    options: [
      { label: 'Worry, feel anxious, or get scattered', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Get irritable, critical, or controlling', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Withdraw, become quiet, or feel stuck', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'mood',
    category: 'mental',
    text: 'My mood is generally…',
    childText: 'Most of the time I feel…',
    options: [
      { label: 'Changeable — up and down throughout the day', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Focused and intense — I care deeply about things', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Stable and calm — rarely get upset', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'speech',
    category: 'mental',
    text: 'The way I talk is…',
    childText: 'When I talk, I…',
    options: [
      { label: 'Fast, enthusiastic, jump from topic to topic', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Direct, precise, and sharp — I say what I mean', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Slow, melodic, and thoughtful', vata: 0, pitta: 0, kapha: 2 },
    ],
  },

  /* ── SLEEP & LIFESTYLE ───────────────────────────────────────────────────── */
  {
    id: 'sleep',
    category: 'lifestyle',
    text: 'My sleep pattern is…',
    childText: 'At night, I…',
    options: [
      { label: 'Light and interrupted — I wake up easily', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Moderate — 6-7 hours and I am fine', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Deep and long — hard to wake up in the morning', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'activity',
    category: 'lifestyle',
    text: 'When I take on tasks and projects, I…',
    childText: 'When I start a new activity, I…',
    options: [
      { label: 'Start many things enthusiastically but struggle to finish', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Plan carefully and drive hard to completion', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Start slowly but once committed, I always finish', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'weather_preference',
    category: 'lifestyle',
    text: 'My favourite weather is…',
    childText: 'I like it best when…',
    options: [
      { label: 'Warm and sunny — I dislike cold and wind', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Cool and breezy — hot weather drains me', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Warm and dry — I dislike cold and damp', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'exercise_preference',
    category: 'lifestyle',
    text: 'My approach to exercise is…',
    childText: 'When it comes to exercise, I…',
    options: [
      { label: 'Love variety — yoga, dance, walking. Dislike intense workouts', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Enjoy competitive sport and intense training', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Prefer gentle, endurance-based activities but need motivation', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'buying_habits',
    category: 'lifestyle',
    text: 'With money, I tend to…',
    childText: 'With my pocket money, I…',
    options: [
      { label: 'Spend impulsively on many small things', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Spend on quality — I research before buying', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Save carefully — dislike spending unnecessarily', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'relationships',
    category: 'lifestyle',
    text: 'In relationships and friendships, I am…',
    childText: 'As a friend, I am…',
    options: [
      { label: 'Enthusiastic with many friends — variety of connections', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Selective — few deep friendships, intensely loyal', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Devoted and consistent — friends for life', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'creativity',
    category: 'lifestyle',
    text: 'In creative activities, I…',
    childText: 'When I draw or make things, I…',
    options: [
      { label: 'Love starting new ideas but get distracted quickly', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Have a clear vision and execute it precisely', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Work slowly and steadily to create something beautiful', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
  {
    id: 'response_to_change',
    category: 'lifestyle',
    text: 'When my routine changes suddenly, I…',
    childText: 'When something unexpected happens, I…',
    options: [
      { label: 'Feel anxious or unsettled at first', vata: 2, pitta: 0, kapha: 0 },
      { label: 'Quickly assess and adapt — take control', vata: 0, pitta: 2, kapha: 0 },
      { label: 'Resist change — prefer my comfortable routine', vata: 0, pitta: 0, kapha: 2 },
    ],
  },
];

/* ── CORE CALCULATION ENGINE ─────────────────────────────────────────────── */

/**
 * Calculate dosha constitution from quiz answers.
 * @param {Array} answers — [{ questionId, optionIndex }]
 * @returns {Object} constitution result
 */
export function calculateDosha(answers) {
  let scores = { vata: 0, pitta: 0, kapha: 0 };
  let total  = 0;

  for (const answer of answers) {
    const question = QUIZ_QUESTIONS.find(q => q.id === answer.questionId);
    if (!question) continue;
    const option = question.options[answer.optionIndex];
    if (!option) continue;
    scores.vata  += option.vata;
    scores.pitta += option.pitta;
    scores.kapha += option.kapha;
    total += Math.max(option.vata, option.pitta, option.kapha);
  }

  const maxScore = Math.max(scores.vata, scores.pitta, scores.kapha) || 1;

  // Percentages
  const pct = {
    vata:  Math.round((scores.vata  / (total || 1)) * 100),
    pitta: Math.round((scores.pitta / (total || 1)) * 100),
    kapha: Math.round((scores.kapha / (total || 1)) * 100),
  };

  // Dominant dosha
  const sorted   = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const dominant = sorted[0][0];
  const secondary= sorted[1][1] >= sorted[0][1] * 0.6 ? sorted[1][0] : null;

  // Constitution type
  let type;
  if (!secondary) {
    type = dominant; // e.g. 'vata'
  } else {
    // Dual constitution — alphabetical order is conventional
    const pair = [dominant, secondary].sort();
    type = pair.join('-'); // e.g. 'pitta-vata'
  }

  return {
    scores,
    percentages: pct,
    dominant,
    secondary,
    type,
    profile: DOSHA_PROFILES[dominant],
    label: getDoshaLabel(type),
    imbalance: detectImbalance(scores),
  };
}

function getDoshaLabel(type) {
  const labels = {
    'vata':        'Vata Prakriti — the Air Type',
    'pitta':       'Pitta Prakriti — the Fire Type',
    'kapha':       'Kapha Prakriti — the Earth Type',
    'pitta-vata':  'Vata-Pitta Prakriti — Air & Fire',
    'kapha-vata':  'Vata-Kapha Prakriti — Air & Earth',
    'kapha-pitta': 'Pitta-Kapha Prakriti — Fire & Earth',
    'kapha-pitta-vata': 'Sama Prakriti — Perfectly Balanced (very rare!)',
  };
  return labels[type] ?? type;
}

/**
 * Detect which dosha is most out of balance.
 * Uses ratio of scores — if one is disproportionately high, it's aggravated.
 */
function detectImbalance(scores) {
  const total = scores.vata + scores.pitta + scores.kapha;
  if (total === 0) return null;
  const avg = total / 3;
  let maxExcess = 0;
  let aggravated = null;
  for (const [dosha, score] of Object.entries(scores)) {
    const excess = score - avg;
    if (excess > maxExcess) { maxExcess = excess; aggravated = dosha; }
  }
  return maxExcess > avg * 0.3 ? aggravated : null;
}

/* ── DOSHA ADVICE ────────────────────────────────────────────────────────── */

/**
 * Returns personalised advice based on constitution type.
 */
export function getDoshaAdvice(dominantDosha) {
  const advice = {
    vata: {
      diet: {
        favour:  ['Warm cooked foods', 'Sweet fruits', 'Root vegetables', 'Warming spices (ginger, cinnamon)', 'Sesame oil', 'Dairy', 'Ghee'],
        reduce:  ['Cold & raw foods', 'Dry crackers', 'Carbonated drinks', 'Beans & legumes (gas-forming)', 'Caffeine'],
        tastes:  ['Sweet', 'Sour', 'Salty'],
      },
      lifestyle: [
        'Maintain a consistent daily routine (same wake time, meal times, sleep time)',
        'Daily warm oil massage (abhyanga) with sesame oil',
        'Gentle yoga and walking — avoid intense, erratic exercise',
        'Stay warm and avoid cold drafts',
        'Meditate daily to calm the racing mind',
        'Get 8 hours of sleep — prioritise rest',
      ],
      herbs: ['ashwagandha', 'shatavari', 'brahmi', 'licorice', 'bala', 'ginger', 'cinnamon'],
      avoid: ['Fasting', 'Skipping meals', 'Cold environments', 'Excessive travel', 'Stimulants', 'Multitasking excessively'],
      bestSeasonPractice: 'Autumn — most important season to follow Vata routines. Extra warm foods and oils.',
    },
    pitta: {
      diet: {
        favour:  ['Cool and sweet foods', 'Coconut', 'Leafy greens', 'Cucumber', 'Dairy', 'Sweet fruits', 'Coriander', 'Mint', 'Fennel'],
        reduce:  ['Spicy hot foods', 'Sour foods (vinegar, citrus)', 'Alcohol', 'Red meat', 'Coffee', 'Fried foods'],
        tastes:  ['Sweet', 'Bitter', 'Astringent'],
      },
      lifestyle: [
        'Avoid excessive competition and overworking',
        'Spend time in nature — near water and green spaces',
        'Avoid midday sun (peak Pitta time)',
        'Cooling yoga poses and swimming',
        'Practice compassion and forgiveness — release judgment',
        'Allow yourself to play without goals',
      ],
      herbs: ['shatavari', 'amla', 'brahmi', 'licorice', 'coriander', 'aloe', 'rose', 'cardamom'],
      avoid: ['Overheating', 'Skipping meals (leads to irritability)', 'Excessive ambition', 'Arguments', 'Alcohol', 'Sour fermented foods'],
      bestSeasonPractice: 'Summer — most important season to follow Pitta routines. Stay cool, eat light and sweet.',
    },
    kapha: {
      diet: {
        favour:  ['Light and spicy foods', 'Bitter vegetables', 'Dry grains', 'Legumes', 'Honey (raw)', 'Pungent spices (pepper, ginger, turmeric)', 'Astringent fruits'],
        reduce:  ['Heavy, oily, sweet foods', 'Dairy', 'Meat', 'Cold drinks', 'Wheat', 'Sugar'],
        tastes:  ['Pungent', 'Bitter', 'Astringent'],
      },
      lifestyle: [
        'Exercise vigorously daily — Kapha needs stimulation',
        'Wake up before 6am — avoid sleeping in',
        'Try new activities and break routines',
        'Dry body brushing and occasional fasting',
        'Socialise actively — avoid isolation',
        'Learn something new every day',
      ],
      herbs: ['trikatu', 'turmeric', 'ginger', 'pepper', 'tulsi', 'guduchi', 'moringa', 'karela'],
      avoid: ['Oversleeping', 'Daytime napping', 'Heavy meals', 'Sugar and sweets', 'Sedentary lifestyle', 'Emotional attachment'],
      bestSeasonPractice: 'Spring — most important season to follow Kapha routines. Cleanse and stimulate.',
    },
  };
  return advice[dominantDosha] ?? advice.vata;
}

/* ── PATIENT DIAGNOSIS ENGINE ────────────────────────────────────────────── */

/**
 * Infer the aggravated dosha from a patient's symptoms.
 * Used by the patient quest system to determine what herbs are needed.
 *
 * @param {string[]} symptoms — array of symptom strings
 * @returns {{ dosha: string, confidence: number, explanation: string }}
 */
export function getDoshaForPatient(symptoms) {
  const symptomMap = {
    vata: [
      'anxiety', 'worry', 'fear', 'insomnia', 'constipation', 'bloating', 'gas',
      'joint pain', 'dry skin', 'cracking joints', 'low weight', 'fatigue',
      'cold hands', 'cold feet', 'irregular digestion', 'forgetfulness',
      'restlessness', 'tremors', 'stiffness', 'poor circulation',
    ],
    pitta: [
      'inflammation', 'acidity', 'acid reflux', 'heartburn', 'anger', 'irritability',
      'rashes', 'skin redness', 'fever', 'excessive sweating', 'liver issues',
      'yellow eyes', 'burning sensation', 'diarrhea', 'blood disorders',
      'eye inflammation', 'perfectionism', 'intense hunger', 'bleeding',
    ],
    kapha: [
      'congestion', 'mucus', 'weight gain', 'lethargy', 'depression', 'swelling',
      'water retention', 'slow digestion', 'nausea', 'attachment', 'possessiveness',
      'oversleeping', 'respiratory issues', 'cough', 'cold', 'low motivation',
      'oily skin', 'heavy feeling', 'diabetes tendency', 'lymph congestion',
    ],
  };

  const lowerSymptoms = symptoms.map(s => s.toLowerCase());
  const scores = { vata: 0, pitta: 0, kapha: 0 };

  for (const [dosha, signs] of Object.entries(symptomMap)) {
    for (const symptom of lowerSymptoms) {
      for (const sign of signs) {
        if (symptom.includes(sign) || sign.includes(symptom)) {
          scores[dosha] += 1;
        }
      }
    }
  }

  const total = scores.vata + scores.pitta + scores.kapha;
  if (total === 0) return { dosha: 'vata', confidence: 0, explanation: 'No clear dosha imbalance detected.' };

  const dominant = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  const confidence = Math.round((dominant[1] / total) * 100);
  const explanations = {
    vata:  `Vata aggravation: symptoms suggest excess Air — dryness, irregularity, and nervous energy.`,
    pitta: `Pitta aggravation: symptoms suggest excess Fire — inflammation, heat, and intensity.`,
    kapha: `Kapha aggravation: symptoms suggest excess Earth — heaviness, congestion, and stagnation.`,
  };

  return {
    dosha: dominant[0],
    confidence,
    scores,
    explanation: explanations[dominant[0]],
  };
}

/* ── TRIDOSHA BALANCING RECIPES ──────────────────────────────────────────── */
/*
 * Pre-built balancing formulas for common conditions.
 * Each formula targets a specific dosha imbalance.
 */
export const BALANCING_FORMULAS = {
  vata_anxiety: {
    name: 'Shanti Churna',
    targetDosha: 'vata',
    condition: 'Anxiety & Restless Mind',
    herbs: ['ashwagandha', 'brahmi', 'shankhpushpi', 'licorice'],
    ratios: [2, 2, 1, 1],
    instructions: 'Mix powders in given ratios. Take 1 tsp with warm milk at bedtime.',
    effectiveness: 85,
  },
  pitta_anger: {
    name: 'Sheetala Churna',
    targetDosha: 'pitta',
    condition: 'Anger & Inflammation',
    herbs: ['amla', 'shatavari', 'licorice', 'rose'],
    ratios: [2, 2, 1, 1],
    instructions: 'Mix and take with cool water or coconut milk in the morning.',
    effectiveness: 88,
  },
  kapha_sluggish: {
    name: 'Deepana Churna',
    targetDosha: 'kapha',
    condition: 'Sluggish Digestion & Lethargy',
    herbs: ['ginger', 'pepper', 'long_pepper', 'turmeric'],
    ratios: [2, 1, 1, 1],
    instructions: 'Mix and take with warm water and honey before meals.',
    effectiveness: 90,
  },
  tridosha_balance: {
    name: 'Triphala Churna',
    targetDosha: 'all',
    condition: 'General Detox & Balancing',
    herbs: ['haritaki', 'bibhitaki', 'amla'],
    ratios: [1, 1, 1],
    instructions: 'Equal parts. Take 1 tsp with warm water before sleep.',
    effectiveness: 95,
  },
};

export default {
  DOSHA_PROFILES,
  QUIZ_QUESTIONS,
  BALANCING_FORMULAS,
  calculateDosha,
  getDoshaAdvice,
  getDoshaForPatient,
};

import pg from 'pg';
const { Pool } = pg;
export const db = new Pool({
  connectionString: process.env.DATABASE_URL ?? 'postgresql://localhost:5432/ayurveda',
  max: 10,
});

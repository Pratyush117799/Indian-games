# ಪಗಡೆ · Pagade

> Royal Board Game of Karnataka — fully playable digital implementation.
> Solo vs AI · Pass & Play · Tournament · PWA installable · Offline capable

---

## Quick Start

```bash
# One command — PostgreSQL + backend + frontend
docker compose up

# Frontend  →  http://localhost:5173
# Backend   →  http://localhost:3001
# Health    →  http://localhost:3001/health
```

Or run locally without Docker:

```bash
# 1. Create DB
psql -U postgres -c "CREATE USER pagade_user WITH PASSWORD 'pagade_secret';"
psql -U postgres -c "CREATE DATABASE pagade OWNER pagade_user;"
psql -U pagade_user -d pagade -f database/migrations/001_initial.sql

# 2. Backend
cd backend && cp .env.example .env && npm install && npm run dev

# 3. Frontend (separate terminal)
cd frontend && npm install && npm run dev
```

---

## Stack

| Layer       | Technology                                   |
|-------------|----------------------------------------------|
| Frontend    | React 18 + Vite 5 + pure SVG board          |
| Game logic  | Pure-functional JS engine (no dependencies) |
| AI          | Minimax 2-ply + greedy + random (3 levels)  |
| Backend     | Node.js 20 + Express 4                       |
| Database    | PostgreSQL 16                                |
| PWA         | Service Worker + Web App Manifest            |
| Deploy      | Docker Compose                               |

---

## Project Structure (51 files)

```
pagade/
├── docker-compose.yml
├── database/
│   └── migrations/001_initial.sql          ← Full PostgreSQL schema
├── backend/
│   ├── server.js                           ← Express entry + middleware
│   ├── config/db.js                        ← PG pool + migration runner
│   ├── middleware/errorHandler.js
│   ├── routes/
│   │   ├── player.js                       ← /api/players
│   │   ├── game.js                         ← /api/games
│   │   └── tournament.js                   ← /api/tournaments
│   └── services/
│       ├── gameService.js
│       └── tournamentService.js
└── frontend/
    ├── index.html
    ├── vite.config.js
    ├── public/
    │   ├── manifest.json                   ← PWA manifest
    │   └── sw.js                           ← Service Worker (offline)
    └── src/
        ├── App.jsx                         ← Screen router, all hooks wired
        ├── main.jsx
        ├── styles/main.css                 ← Full design system
        ├── game/
        │   ├── constants.js                ← 68-cell path, safe lanes, colours
        │   ├── engine.js                   ← Pure-functional game logic
        │   ├── ai.js                       ← Beginner / Prince / Maharaja AI
        │   ├── api.js                      ← Backend REST client
        │   └── boardThemes.js              ← Temple Stone / Royal Silk / Night Festival
        ├── hooks/
        │   ├── useGame.js                  ← Central state + AI turn runner
        │   ├── useSounds.js                ← Procedural Web Audio (6 sounds)
        │   ├── useBackend.js               ← DB persistence (fire-and-forget)
        │   ├── useLocalSave.js             ← localStorage auto-save + resume
        │   ├── useAnimatedMove.js          ← Step-by-step pawn path animation
        │   ├── useTournament.js            ← 4P single-elimination bracket
        │   ├── useSettings.js              ← Persistent user preferences
        │   └── usePWA.js                   ← Service Worker + install prompt
        └── components/
            ├── Board/
            │   ├── Board.jsx               ← SVG renderer, blockade detection
            │   ├── BoardCell.jsx           ← Theme-aware cell colouring
            │   └── Pawn.jsx                ← Animated pawn, blockade crown
            ├── Dice/
            │   └── Dice.jsx                ← CowrieDice + StickDice
            ├── UI/
            │   ├── Effects.jsx             ← CaptureEffect / SafeEffect / HomeEffect
            │   ├── EmojiReaction.jsx       ← Quick-pick toolbar + float animation
            │   ├── MoveLog.jsx             ← Live 14-entry sidebar
            │   ├── PlayerPanel.jsx         ← Pawn pips + progress bar
            │   ├── ResumePrompt.jsx        ← Saved game detection card
            │   ├── TournamentBracket.jsx   ← SVG bracket with connectors
            │   └── WinCelebration.jsx      ← Canvas confetti + win card
            └── screens/
                ├── HomeScreen.jsx          ← Mode picker + setup + leaderboard nav
                ├── GameScreen.jsx          ← Main play screen
                ├── LeaderboardScreen.jsx   ← Podium + full rank table
                └── SettingsScreen.jsx      ← Themes, dice, animation, name
```

---

## Game Rules (implemented)

| Rule              | Detail                                                           |
|-------------------|------------------------------------------------------------------|
| Start             | 2 pawns ACTIVE at arm entry, 2 in BELLY                         |
| Direction         | Counter-clockwise · 68-cell main path                           |
| Safe squares      | Entry + 2 tip cells per arm (12 total) — no capture here        |
| Safe lane         | 8-cell private channel per player → HOME                         |
| Capture           | Land on opponent on non-safe cell → they return to BELLY         |
| Blockade          | 2 same-colour pawns on same cell → opponents cannot capture or pass |
| Doublet (stick)   | Both dice equal → option to split move between two pawns         |
| Home entry        | Exact roll required — no overshoot                               |
| Cowrie score      | 0 mouths=6, 6 mouths=12, else count mouths                       |
| Stick dice faces  | 1, 3, 4, 6 (ancient South Indian dice)                          |

## AI Levels

| Level     | Strategy                                                   |
|-----------|------------------------------------------------------------|
| 🌱 Beginner | Random valid move                                        |
| 👑 Prince   | Greedy 1-ply heuristic scoring                           |
| ⚔️ Maharaja | 2-ply minimax + alpha-beta + dice outcome expectation    |

## Board Themes

| Theme          | Unlock    | Aesthetic                              |
|----------------|-----------|----------------------------------------|
| 🗿 Temple Stone | Default   | Hampi granite — ochre & jade           |
| 🪡 Royal Silk   | 5 wins    | Mysore silk — crimson & ivory          |
| 🪔 Night Festival | 15 wins | Deepavali diyas on midnight stone      |

## API Endpoints

```
GET  /health
POST /api/players                    Register player
GET  /api/players/:id                Get profile
GET  /api/players/leaderboard        Top 100 by wins
POST /api/games                      Create game session
PATCH /api/games/:id/state           Auto-save state JSON
POST /api/games/:id/moves            Log move
POST /api/games/:id/complete         Finish game + update stats
GET  /api/tournaments                List tournaments
POST /api/tournaments                Create tournament
POST /api/tournaments/:id/join       Join tournament
```

## Design

**Aesthetic:** Karnataka temple-craft — deep ochre & jade on dark stone.  
**Typography:** Yatra One (Kannada display) · Noto Serif · DM Sans  
**Sounds:** 6 procedural Web Audio API tones — muted by default, single toggle  
**Text:** Minimal — icons and colour communicate game state, not labels  
**Board:** Pure SVG, 19×19 grid, fully responsive, no canvas  

const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function createTournament({ name, maxPlayers = 16 }) {
  const id = uuidv4();
  await query(
    `INSERT INTO tournaments (id, name, max_players) VALUES ($1, $2, $3)`,
    [id, name, maxPlayers]
  );
  return { id };
}

async function joinTournament({ tournamentId, playerId }) {
  const t = await query(
    `SELECT status, max_players,
            (SELECT COUNT(*) FROM tournament_players WHERE tournament_id=$1) AS current
     FROM tournaments WHERE id=$1`,
    [tournamentId]
  );
  const row = t.rows[0];
  if (!row) throw Object.assign(new Error('Tournament not found'), { status: 404 });
  if (row.status !== 'open') throw Object.assign(new Error('Tournament not open'), { status: 400 });
  if (parseInt(row.current) >= row.max_players)
    throw Object.assign(new Error('Tournament full'), { status: 400 });

  await query(
    `INSERT INTO tournament_players (tournament_id, player_id)
     VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [tournamentId, playerId]
  );
  return { joined: true };
}

async function getTournament(tournamentId) {
  const res = await query(
    `SELECT t.*,
            json_agg(json_build_object(
              'playerId', tp.player_id,
              'username', p.username,
              'eliminated', tp.eliminated,
              'finalRank', tp.final_rank
            )) AS players
     FROM tournaments t
     LEFT JOIN tournament_players tp ON tp.tournament_id = t.id
     LEFT JOIN players p ON p.id = tp.player_id
     WHERE t.id = $1
     GROUP BY t.id`,
    [tournamentId]
  );
  return res.rows[0] || null;
}

async function listTournaments() {
  const res = await query(
    `SELECT id, name, status, max_players, created_at,
            (SELECT COUNT(*) FROM tournament_players WHERE tournament_id=t.id) AS registered
     FROM tournaments t ORDER BY created_at DESC LIMIT 20`
  );
  return res.rows;
}

module.exports = { createTournament, joinTournament, getTournament, listTournaments };

/**
 * api.js — thin wrapper around the Pagade backend REST API.
 * All functions return { data } | { error }.
 */

const BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001';

async function req(method, path, body) {
  try {
    const res = await fetch(`${BASE}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    const json = await res.json();
    if (!res.ok) return { error: json.error?.message || 'Request failed' };
    return { data: json };
  } catch (e) {
    return { error: e.message };
  }
}

// ─── Players ─────────────────────────────────────────────────────────────────

export const players = {
  create:      (body)     => req('POST',  '/api/players', body),
  get:         (id)       => req('GET',   `/api/players/${id}`),
  leaderboard: ()         => req('GET',   '/api/players/leaderboard'),
  setPrefs:    (id, body) => req('PATCH', `/api/players/${id}/preferences`, body),
};

// ─── Games ───────────────────────────────────────────────────────────────────

export const games = {
  create:    (body)         => req('POST',  '/api/games', body),
  get:       (id)           => req('GET',   `/api/games/${id}`),
  saveState: (id, state)    => req('PATCH', `/api/games/${id}/state`, { state }),
  logMove:   (id, move)     => req('POST',  `/api/games/${id}/moves`, move),
  complete:  (id, body)     => req('POST',  `/api/games/${id}/complete`, body),
  getMoves:  (id)           => req('GET',   `/api/games/${id}/moves`),
};

// ─── Tournaments ─────────────────────────────────────────────────────────────

export const tournaments = {
  list:   ()                           => req('GET',  '/api/tournaments'),
  create: (name, maxPlayers)           => req('POST', '/api/tournaments', { name, maxPlayers }),
  get:    (id)                         => req('GET',  `/api/tournaments/${id}`),
  join:   (id, playerId)               => req('POST', `/api/tournaments/${id}/join`, { playerId }),
};
